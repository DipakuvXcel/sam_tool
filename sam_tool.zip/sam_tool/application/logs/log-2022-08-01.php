<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-01 12:52:01 --> Config Class Initialized
INFO - 2022-08-01 12:52:01 --> Hooks Class Initialized
DEBUG - 2022-08-01 12:52:01 --> UTF-8 Support Enabled
INFO - 2022-08-01 12:52:01 --> Utf8 Class Initialized
INFO - 2022-08-01 12:52:01 --> URI Class Initialized
INFO - 2022-08-01 12:52:01 --> Router Class Initialized
INFO - 2022-08-01 12:52:01 --> Output Class Initialized
INFO - 2022-08-01 12:52:01 --> Security Class Initialized
DEBUG - 2022-08-01 12:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-01 12:52:01 --> Input Class Initialized
INFO - 2022-08-01 12:52:01 --> Language Class Initialized
INFO - 2022-08-01 12:52:01 --> Loader Class Initialized
INFO - 2022-08-01 12:52:01 --> Helper loaded: url_helper
INFO - 2022-08-01 12:52:01 --> Controller Class Initialized
INFO - 2022-08-01 12:52:01 --> File loaded: /sam_tool/application/views/frontend/register_org.php
INFO - 2022-08-01 12:52:01 --> Final output sent to browser
DEBUG - 2022-08-01 12:52:01 --> Total execution time: 0.1858
INFO - 2022-08-01 12:58:04 --> Config Class Initialized
INFO - 2022-08-01 12:58:04 --> Hooks Class Initialized
DEBUG - 2022-08-01 12:58:04 --> UTF-8 Support Enabled
INFO - 2022-08-01 12:58:04 --> Utf8 Class Initialized
INFO - 2022-08-01 12:58:04 --> URI Class Initialized
INFO - 2022-08-01 12:58:04 --> Router Class Initialized
INFO - 2022-08-01 12:58:04 --> Output Class Initialized
INFO - 2022-08-01 12:58:05 --> Security Class Initialized
DEBUG - 2022-08-01 12:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-01 12:58:05 --> Input Class Initialized
INFO - 2022-08-01 12:58:05 --> Language Class Initialized
INFO - 2022-08-01 12:58:05 --> Loader Class Initialized
INFO - 2022-08-01 12:58:05 --> Helper loaded: url_helper
INFO - 2022-08-01 12:58:05 --> Controller Class Initialized
INFO - 2022-08-01 12:58:05 --> Final output sent to browser
DEBUG - 2022-08-01 12:58:05 --> Total execution time: 0.1801
