<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-01 11:44:36 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 11:45:22 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 11:45:22 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 11:45:22 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 11:45:22 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 11:45:22 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 11:45:22 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 11:53:03 --> {"type_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:37:41 --> {"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:37:45 --> {"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:37:52 --> {"type_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:37:59 --> {"type_id":4,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:38:05 --> {"type_id":5,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:57:47 --> {"type_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:57:51 --> {"bank_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:57:53 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:58:00 --> {"bank_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:58:01 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 12:58:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 12:58:32 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 12:59:02 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 13:56:56 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 13:57:05 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 13:58:39 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 13:58:53 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:04:25 --> {"type_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:04:25 --> Severity: error --> Exception: syntax error, unexpected ';' /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:04:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-09-01 14:04:59 --> {"type_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:05:05 --> {"type_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:05:48 --> {"type_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:07:30 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:07:30 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:07:30 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:07:30 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:07 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:07 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:07 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:07 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:09:27 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:10:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:11:17 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:11:20 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:11:20 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:11:20 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:11:23 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:12:13 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:12:25 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:12:26 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:12:36 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:12:36 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:12:36 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:12:36 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:12:36 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:12:36 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:12:39 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:12:41 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 14:12:41 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:12:41 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 14:12:43 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:13:08 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:14:03 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:16:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:18:24 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:18:27 --> {"type_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:18:27 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:24:41 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:24:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:24:54 --> {"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:24:58 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:34:52 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:34:52 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:34:52 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:34:52 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:34:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:35:18 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:35:19 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:35:19 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:35:19 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:35:20 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:35:55 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:36:19 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:36:25 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:36:25 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:36:25 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:36:25 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 14:36:26 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:37:26 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:37:26 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:37:26 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:37:26 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:37:28 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:37:53 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:37:53 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:37:53 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:37:53 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 14:37:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:38:48 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:38:48 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:38:48 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:38:48 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:38:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:39:01 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:39:01 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:39:01 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:39:01 --> Severity: Warning --> array_count_values() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:39:03 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:39:10 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:42:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:42:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:42:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:42:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 14:42:31 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:43:16 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:43:22 --> {"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:43:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 14:43:32 --> {"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 14:43:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 15:02:02 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 15:06:53 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /sam_tool/application/views/frontend/dashboard.php 269
ERROR - 2022-09-01 15:07:02 --> Severity: Warning --> usort() expects exactly 2 parameters, 1 given /sam_tool/application/views/frontend/dashboard.php 269
ERROR - 2022-09-01 15:07:03 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 15:07:34 --> Severity: Warning --> usort() expects exactly 2 parameters, 1 given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 15:07:34 --> Severity: Warning --> usort() expects exactly 2 parameters, 1 given /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-01 15:07:35 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 15:13:20 --> Severity: error --> Exception: syntax error, unexpected '?>' /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 15:13:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 15:23:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 15:23:10 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 15:23:43 --> {"city_id":1,"state_id":2,"bank_id":5,"type_id":2,"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 15:23:44 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 15:32:27 --> Severity: error --> Exception: syntax error, unexpected '>' /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-09-01 15:32:39 --> Severity: error --> Exception: syntax error, unexpected end of file /sam_tool/application/views/frontend/dashboard.php 402
ERROR - 2022-09-01 15:33:03 --> Severity: error --> Exception: syntax error, unexpected end of file /sam_tool/application/views/frontend/dashboard.php 402
ERROR - 2022-09-01 15:33:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:33:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:33:43 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:33:44 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:08 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:09 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:15 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:16 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:50 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:50 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:51 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:35:58 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:36:01 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:36:31 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:36:32 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:36:43 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:36:46 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:37:46 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:37:48 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:38:48 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:38:49 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:38:57 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:00 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:06 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:19 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:20 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:20 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:22 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:22 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:29 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:31 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:45 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:46 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:39:56 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:40:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:40:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:40:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:40:35 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:41:17 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:41:17 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:41:18 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:41:28 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:41:44 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:41:45 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:42:40 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:42:56 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:42:56 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:42:57 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:05 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:07 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:07 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:27 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:27 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:27 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:27 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:27 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:28 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:43:41 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:44:18 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:44:18 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:44:18 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:44:34 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:46:50 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:46:50 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:46:51 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:00 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:27 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:33 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:40 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:42 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:43 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:49 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:47:56 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:48:05 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:48:32 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:48:32 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:48:40 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:48:52 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:48:57 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:48:58 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:50:08 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:50:08 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:50:09 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:50:16 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:50:19 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:50:20 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:50:28 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:51:25 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 15:51:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:51:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:51:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:51:35 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:51:48 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:51:57 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:52:49 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 15:52:49 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:52:59 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:54:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:54:26 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:57:04 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:57:04 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:57:11 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:57:19 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 15:57:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 16:17:18 --> Severity: Notice --> Undefined variable: check /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:52 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:52 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:52 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:52 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:52 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:17:52 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-09-01 16:20:34 --> Severity: Notice --> Undefined variable: array /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:20:34 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:20:34 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:20:34 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:20:34 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:20:34 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:20:34 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:20:34 --> Severity: Warning --> array_diff_assoc(): Argument #1 is not an array /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Notice --> Undefined variable: array /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Warning --> array_diff_assoc(): Argument #1 is not an array /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:13 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-09-01 16:21:15 --> Severity: Notice --> Undefined variable: array /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:15 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:15 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:15 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:15 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:15 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:15 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:15 --> Severity: Warning --> array_diff_assoc(): Argument #1 is not an array /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-09-01 16:21:52 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:52 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:52 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:52 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:52 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:52 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:52 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:52 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:55 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:55 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:55 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:55 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:55 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:55 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:55 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:21:55 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 16:25:02 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-09-01 16:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 213
ERROR - 2022-09-01 16:29:24 --> Severity: Warning --> array_filter() expects parameter 1 to be array, string given /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-09-01 16:29:24 --> Severity: Error --> Cannot redeclare array_uniq() (previously declared in /sam_tool/application/views/frontend/dashboard.php:209) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-09-01 16:32:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 16:32:28 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 16:32:31 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 16:32:31 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 16:32:31 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 16:32:31 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 16:32:31 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 16:32:31 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 16:32:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 16:39:59 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 16:40:06 --> {"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 16:40:07 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 16:42:12 --> Severity: error --> Exception: syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 16:42:27 --> Severity: error --> Exception: syntax error, unexpected '.' /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 16:42:39 --> Severity: error --> Exception: syntax error, unexpected '||' (T_BOOLEAN_OR) /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-09-01 16:42:44 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 16:43:31 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 16:44:04 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 16:45:22 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 16:45:23 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:19:14 --> {"type_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 17:19:15 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:20:00 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 17:20:00 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-01 17:20:00 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 17:20:00 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-01 17:20:00 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 17:20:00 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-01 17:20:02 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:27:10 --> {"bank_id":5,"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 17:27:11 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:46:34 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 257
ERROR - 2022-09-01 17:46:36 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:51:20 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 17:51:20 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 257
ERROR - 2022-09-01 17:51:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:52:47 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 257
ERROR - 2022-09-01 17:52:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:52:52 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 17:52:53 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 257
ERROR - 2022-09-01 17:52:53 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:56:22 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 257
ERROR - 2022-09-01 17:56:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: category /sam_tool/application/views/frontend/dashboard.php 297
ERROR - 2022-09-01 17:57:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 297
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: brandarr /sam_tool/application/views/frontend/dashboard.php 328
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: brands /sam_tool/application/views/frontend/dashboard.php 332
ERROR - 2022-09-01 17:57:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 332
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 349
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: materials /sam_tool/application/views/frontend/dashboard.php 353
ERROR - 2022-09-01 17:57:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 353
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 360
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: max_price /sam_tool/application/views/frontend/dashboard.php 372
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: highprice /sam_tool/application/views/frontend/dashboard.php 382
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: giftflag /sam_tool/application/views/frontend/dashboard.php 397
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: cat_id /sam_tool/application/views/frontend/dashboard.php 409
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: scat_id /sam_tool/application/views/frontend/dashboard.php 410
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: brandarr /sam_tool/application/views/frontend/dashboard.php 411
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 412
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 413
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: giftflag /sam_tool/application/views/frontend/dashboard.php 414
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: tags /sam_tool/application/views/frontend/dashboard.php 419
ERROR - 2022-09-01 17:57:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 419
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 438
ERROR - 2022-09-01 17:57:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 438
ERROR - 2022-09-01 17:57:50 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 575
ERROR - 2022-09-01 17:57:50 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:57:50 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:57:50 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:57:50 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:57:50 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: brandarr /sam_tool/application/views/frontend/dashboard.php 328
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: brands /sam_tool/application/views/frontend/dashboard.php 332
ERROR - 2022-09-01 17:58:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 332
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 349
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: materials /sam_tool/application/views/frontend/dashboard.php 353
ERROR - 2022-09-01 17:58:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 353
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 360
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: max_price /sam_tool/application/views/frontend/dashboard.php 372
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: highprice /sam_tool/application/views/frontend/dashboard.php 382
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: giftflag /sam_tool/application/views/frontend/dashboard.php 397
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: cat_id /sam_tool/application/views/frontend/dashboard.php 409
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: scat_id /sam_tool/application/views/frontend/dashboard.php 410
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: brandarr /sam_tool/application/views/frontend/dashboard.php 411
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 412
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 413
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: giftflag /sam_tool/application/views/frontend/dashboard.php 414
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: tags /sam_tool/application/views/frontend/dashboard.php 419
ERROR - 2022-09-01 17:58:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 419
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 438
ERROR - 2022-09-01 17:58:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 438
ERROR - 2022-09-01 17:58:54 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 575
ERROR - 2022-09-01 17:58:54 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:58:54 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:58:54 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:58:54 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: cat_id /sam_tool/application/views/frontend/dashboard.php 296
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: scat_id /sam_tool/application/views/frontend/dashboard.php 297
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: brandarr /sam_tool/application/views/frontend/dashboard.php 298
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 299
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 300
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: giftflag /sam_tool/application/views/frontend/dashboard.php 301
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: tags /sam_tool/application/views/frontend/dashboard.php 306
ERROR - 2022-09-01 17:59:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 306
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 325
ERROR - 2022-09-01 17:59:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 325
ERROR - 2022-09-01 17:59:29 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 462
ERROR - 2022-09-01 17:59:30 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:59:30 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:59:30 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:59:30 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: cat_id /sam_tool/application/views/frontend/dashboard.php 270
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: scat_id /sam_tool/application/views/frontend/dashboard.php 271
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: brandarr /sam_tool/application/views/frontend/dashboard.php 272
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 273
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 274
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: giftflag /sam_tool/application/views/frontend/dashboard.php 275
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: tags /sam_tool/application/views/frontend/dashboard.php 280
ERROR - 2022-09-01 17:59:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 280
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 299
ERROR - 2022-09-01 17:59:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 299
ERROR - 2022-09-01 17:59:46 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 436
ERROR - 2022-09-01 17:59:47 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:59:47 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:59:47 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 17:59:47 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: cat_id /sam_tool/application/views/frontend/dashboard.php 372
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: scat_id /sam_tool/application/views/frontend/dashboard.php 373
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: brandarr /sam_tool/application/views/frontend/dashboard.php 374
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 375
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 376
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: giftflag /sam_tool/application/views/frontend/dashboard.php 377
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: tags /sam_tool/application/views/frontend/dashboard.php 382
ERROR - 2022-09-01 18:01:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 382
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 401
ERROR - 2022-09-01 18:01:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 401
ERROR - 2022-09-01 18:01:17 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 538
ERROR - 2022-09-01 18:01:17 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:01:17 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:01:17 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:01:17 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: cat_id /sam_tool/application/views/frontend/dashboard.php 393
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: scat_id /sam_tool/application/views/frontend/dashboard.php 394
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: brandarr /sam_tool/application/views/frontend/dashboard.php 395
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: materialarr /sam_tool/application/views/frontend/dashboard.php 396
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 397
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: giftflag /sam_tool/application/views/frontend/dashboard.php 398
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: tags /sam_tool/application/views/frontend/dashboard.php 403
ERROR - 2022-09-01 18:01:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 403
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 422
ERROR - 2022-09-01 18:01:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 422
ERROR - 2022-09-01 18:01:56 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 559
ERROR - 2022-09-01 18:01:56 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:01:56 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:01:56 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:01:56 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:02:53 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 353
ERROR - 2022-09-01 18:02:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 353
ERROR - 2022-09-01 18:02:53 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 490
ERROR - 2022-09-01 18:02:53 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:02:53 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:02:53 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:02:53 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:04:29 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 353
ERROR - 2022-09-01 18:04:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 353
ERROR - 2022-09-01 18:04:29 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 497
ERROR - 2022-09-01 18:04:29 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:04:29 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:04:29 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:04:29 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:05:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /sam_tool/application/views/frontend/dashboard.php 474
ERROR - 2022-09-01 18:05:58 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 356
ERROR - 2022-09-01 18:05:58 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 357
ERROR - 2022-09-01 18:05:58 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 358
ERROR - 2022-09-01 18:05:58 --> Severity: error --> Exception: Call to undefined function divider() /sam_tool/application/views/frontend/dashboard.php 393
ERROR - 2022-09-01 18:05:59 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:05:59 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:06:27 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 357
ERROR - 2022-09-01 18:06:27 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 358
ERROR - 2022-09-01 18:06:27 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 359
ERROR - 2022-09-01 18:06:27 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 466
ERROR - 2022-09-01 18:06:27 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:06:27 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:06:27 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:06:28 --> 404 Page Not Found: Assets/img
ERROR - 2022-09-01 18:06:28 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:06:54 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:06:54 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:06:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 18:07:07 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 357
ERROR - 2022-09-01 18:07:07 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 358
ERROR - 2022-09-01 18:07:07 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 359
ERROR - 2022-09-01 18:07:07 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 466
ERROR - 2022-09-01 18:07:07 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:07:07 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:07:07 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:07:07 --> 404 Page Not Found: Assets/img
ERROR - 2022-09-01 18:07:07 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:07:08 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 18:07:22 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 357
ERROR - 2022-09-01 18:07:22 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 358
ERROR - 2022-09-01 18:07:22 --> Severity: Notice --> Undefined variable: sortby /sam_tool/application/views/frontend/dashboard.php 359
ERROR - 2022-09-01 18:07:22 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 466
ERROR - 2022-09-01 18:07:23 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:07:23 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:07:23 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:07:23 --> 404 Page Not Found: Assets/products
ERROR - 2022-09-01 18:07:23 --> 404 Page Not Found: Assets/img
ERROR - 2022-09-01 18:07:23 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 18:08:25 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 18:25:34 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 18:28:35 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 18:28:48 --> {"type_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 18:28:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-01 18:32:25 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 18:35:43 --> {"city_id":1,"state_id":1,"bank_id":1,"type_id":1,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-01 18:35:59 --> {"city_id":2,"state_id":1,"bank_id":1,"type_id":3,"locality":5,"batch_size":12,"batch_number":1}
