<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-05 11:20:43 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:20:51 --> {"city_id":1,"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:20:54 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:20:58 --> {"city_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:21:04 --> {"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:21:13 --> {"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:21:17 --> {"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:21:23 --> {"locality":4,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:21:28 --> {"locality":5,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:21:35 --> {"locality":6,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:26:43 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-05 11:26:43 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-05 11:26:43 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-05 11:26:43 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-05 11:26:43 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-05 11:26:43 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-05 11:27:00 --> {"city_id":3,"state_id":1,"type_id":3,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 11:27:40 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-05 11:27:40 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-09-05 11:27:40 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-05 11:27:40 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-09-05 11:27:40 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-05 11:27:40 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-09-05 16:03:19 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-05 16:20:35 --> {"state_id":1,"batch_size":12,"batch_number":1}
