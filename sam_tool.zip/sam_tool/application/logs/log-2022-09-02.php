<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-02 18:24:44 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-02 18:27:08 --> Severity: Notice --> Undefined index: count /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-02 18:27:08 --> Severity: Notice --> Undefined index: count /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-02 18:27:08 --> Severity: Notice --> Undefined index: count /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-02 18:27:08 --> Severity: Notice --> Undefined index: count /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-02 18:27:08 --> Severity: Notice --> Undefined index: count /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-02 18:27:08 --> Severity: Notice --> Undefined index: count /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-09-02 18:27:40 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-09-02 18:27:59 --> {"city_id":2,"state_id":1,"bank_id":2,"type_id":3,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-02 18:33:15 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-02 18:33:50 --> {"city_id":1,"state_id":1,"type_id":3,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-09-02 18:36:03 --> {"city_id":3,"state_id":2,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-09-02 18:37:38 --> {"city_id":1,"state_id":1,"locality":1,"batch_size":12,"batch_number":1}
