<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-18 11:14:35 --> Config Class Initialized
INFO - 2022-08-18 11:14:35 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:14:35 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:14:35 --> Utf8 Class Initialized
INFO - 2022-08-18 11:14:35 --> URI Class Initialized
DEBUG - 2022-08-18 11:14:35 --> No URI present. Default controller set.
INFO - 2022-08-18 11:14:35 --> Router Class Initialized
INFO - 2022-08-18 11:14:35 --> Output Class Initialized
INFO - 2022-08-18 11:14:35 --> Security Class Initialized
DEBUG - 2022-08-18 11:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:14:35 --> Input Class Initialized
INFO - 2022-08-18 11:14:35 --> Language Class Initialized
INFO - 2022-08-18 11:14:35 --> Loader Class Initialized
INFO - 2022-08-18 11:14:35 --> Helper loaded: url_helper
INFO - 2022-08-18 11:14:35 --> Controller Class Initialized
INFO - 2022-08-18 11:14:35 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 11:14:35 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 11:14:35 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 11:14:35 --> Final output sent to browser
DEBUG - 2022-08-18 11:14:35 --> Total execution time: 0.6701
INFO - 2022-08-18 11:14:43 --> Config Class Initialized
INFO - 2022-08-18 11:14:43 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:14:43 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:14:43 --> Utf8 Class Initialized
INFO - 2022-08-18 11:14:43 --> URI Class Initialized
INFO - 2022-08-18 11:14:43 --> Router Class Initialized
INFO - 2022-08-18 11:14:43 --> Output Class Initialized
INFO - 2022-08-18 11:14:43 --> Security Class Initialized
DEBUG - 2022-08-18 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:14:43 --> Input Class Initialized
INFO - 2022-08-18 11:14:43 --> Language Class Initialized
INFO - 2022-08-18 11:14:43 --> Loader Class Initialized
INFO - 2022-08-18 11:14:43 --> Helper loaded: url_helper
INFO - 2022-08-18 11:14:43 --> Controller Class Initialized
DEBUG - 2022-08-18 11:14:43 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 11:14:43 --> Helper loaded: inflector_helper
INFO - 2022-08-18 11:14:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 11:14:43 --> Final output sent to browser
DEBUG - 2022-08-18 11:14:43 --> Total execution time: 0.5170
INFO - 2022-08-18 11:14:43 --> Config Class Initialized
INFO - 2022-08-18 11:14:43 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:14:43 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:14:43 --> Utf8 Class Initialized
INFO - 2022-08-18 11:14:43 --> URI Class Initialized
INFO - 2022-08-18 11:14:43 --> Router Class Initialized
INFO - 2022-08-18 11:14:43 --> Output Class Initialized
INFO - 2022-08-18 11:14:43 --> Security Class Initialized
DEBUG - 2022-08-18 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:14:43 --> Input Class Initialized
INFO - 2022-08-18 11:14:43 --> Language Class Initialized
ERROR - 2022-08-18 11:14:43 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-18 11:14:51 --> Config Class Initialized
INFO - 2022-08-18 11:14:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:14:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:14:51 --> Utf8 Class Initialized
INFO - 2022-08-18 11:14:51 --> URI Class Initialized
INFO - 2022-08-18 11:14:51 --> Router Class Initialized
INFO - 2022-08-18 11:14:51 --> Output Class Initialized
INFO - 2022-08-18 11:14:51 --> Security Class Initialized
DEBUG - 2022-08-18 11:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:14:51 --> Input Class Initialized
INFO - 2022-08-18 11:14:51 --> Language Class Initialized
INFO - 2022-08-18 11:14:51 --> Loader Class Initialized
INFO - 2022-08-18 11:14:51 --> Helper loaded: url_helper
INFO - 2022-08-18 11:14:51 --> Controller Class Initialized
INFO - 2022-08-18 11:14:51 --> Config Class Initialized
INFO - 2022-08-18 11:14:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:14:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:14:51 --> Utf8 Class Initialized
INFO - 2022-08-18 11:14:51 --> URI Class Initialized
INFO - 2022-08-18 11:14:51 --> Router Class Initialized
INFO - 2022-08-18 11:14:52 --> Output Class Initialized
INFO - 2022-08-18 11:14:52 --> Security Class Initialized
DEBUG - 2022-08-18 11:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:14:52 --> Input Class Initialized
INFO - 2022-08-18 11:14:52 --> Language Class Initialized
INFO - 2022-08-18 11:14:52 --> Loader Class Initialized
INFO - 2022-08-18 11:14:52 --> Helper loaded: url_helper
INFO - 2022-08-18 11:14:52 --> Controller Class Initialized
INFO - 2022-08-18 11:14:52 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 11:14:52 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 11:14:52 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 11:14:52 --> Final output sent to browser
DEBUG - 2022-08-18 11:14:52 --> Total execution time: 0.3925
INFO - 2022-08-18 11:15:04 --> Config Class Initialized
INFO - 2022-08-18 11:15:04 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:04 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:04 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:04 --> URI Class Initialized
INFO - 2022-08-18 11:15:04 --> Router Class Initialized
INFO - 2022-08-18 11:15:04 --> Output Class Initialized
INFO - 2022-08-18 11:15:04 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:04 --> Input Class Initialized
INFO - 2022-08-18 11:15:04 --> Language Class Initialized
INFO - 2022-08-18 11:15:04 --> Loader Class Initialized
INFO - 2022-08-18 11:15:04 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:04 --> Controller Class Initialized
INFO - 2022-08-18 11:15:04 --> Config Class Initialized
INFO - 2022-08-18 11:15:04 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:04 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:04 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:04 --> URI Class Initialized
INFO - 2022-08-18 11:15:04 --> Router Class Initialized
INFO - 2022-08-18 11:15:05 --> Output Class Initialized
INFO - 2022-08-18 11:15:05 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:05 --> Input Class Initialized
INFO - 2022-08-18 11:15:05 --> Language Class Initialized
INFO - 2022-08-18 11:15:05 --> Loader Class Initialized
INFO - 2022-08-18 11:15:05 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:05 --> Controller Class Initialized
INFO - 2022-08-18 11:15:05 --> Config Class Initialized
INFO - 2022-08-18 11:15:05 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:05 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:05 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:05 --> URI Class Initialized
INFO - 2022-08-18 11:15:05 --> Router Class Initialized
INFO - 2022-08-18 11:15:05 --> Output Class Initialized
INFO - 2022-08-18 11:15:05 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:05 --> Input Class Initialized
INFO - 2022-08-18 11:15:05 --> Language Class Initialized
INFO - 2022-08-18 11:15:05 --> Loader Class Initialized
INFO - 2022-08-18 11:15:05 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:05 --> Controller Class Initialized
INFO - 2022-08-18 11:15:05 --> Config Class Initialized
INFO - 2022-08-18 11:15:05 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:05 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:05 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:05 --> URI Class Initialized
INFO - 2022-08-18 11:15:05 --> Router Class Initialized
INFO - 2022-08-18 11:15:05 --> Output Class Initialized
INFO - 2022-08-18 11:15:05 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:05 --> Input Class Initialized
INFO - 2022-08-18 11:15:05 --> Language Class Initialized
INFO - 2022-08-18 11:15:05 --> Loader Class Initialized
INFO - 2022-08-18 11:15:05 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:05 --> Controller Class Initialized
INFO - 2022-08-18 11:15:05 --> Config Class Initialized
INFO - 2022-08-18 11:15:05 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:05 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:05 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:05 --> URI Class Initialized
INFO - 2022-08-18 11:15:05 --> Router Class Initialized
INFO - 2022-08-18 11:15:05 --> Output Class Initialized
INFO - 2022-08-18 11:15:05 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:05 --> Input Class Initialized
INFO - 2022-08-18 11:15:05 --> Language Class Initialized
INFO - 2022-08-18 11:15:06 --> Loader Class Initialized
INFO - 2022-08-18 11:15:06 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:06 --> Controller Class Initialized
INFO - 2022-08-18 11:15:06 --> Config Class Initialized
INFO - 2022-08-18 11:15:06 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:06 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:06 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:06 --> URI Class Initialized
INFO - 2022-08-18 11:15:06 --> Router Class Initialized
INFO - 2022-08-18 11:15:06 --> Output Class Initialized
INFO - 2022-08-18 11:15:06 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:06 --> Input Class Initialized
INFO - 2022-08-18 11:15:06 --> Language Class Initialized
INFO - 2022-08-18 11:15:06 --> Loader Class Initialized
INFO - 2022-08-18 11:15:06 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:06 --> Controller Class Initialized
INFO - 2022-08-18 11:15:06 --> Config Class Initialized
INFO - 2022-08-18 11:15:06 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:06 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:06 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:06 --> URI Class Initialized
INFO - 2022-08-18 11:15:06 --> Router Class Initialized
INFO - 2022-08-18 11:15:06 --> Output Class Initialized
INFO - 2022-08-18 11:15:06 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:06 --> Input Class Initialized
INFO - 2022-08-18 11:15:06 --> Language Class Initialized
INFO - 2022-08-18 11:15:06 --> Loader Class Initialized
INFO - 2022-08-18 11:15:06 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:06 --> Controller Class Initialized
INFO - 2022-08-18 11:15:06 --> Config Class Initialized
INFO - 2022-08-18 11:15:06 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:06 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:06 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:06 --> URI Class Initialized
INFO - 2022-08-18 11:15:06 --> Router Class Initialized
INFO - 2022-08-18 11:15:06 --> Output Class Initialized
INFO - 2022-08-18 11:15:06 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:06 --> Input Class Initialized
INFO - 2022-08-18 11:15:06 --> Language Class Initialized
INFO - 2022-08-18 11:15:06 --> Loader Class Initialized
INFO - 2022-08-18 11:15:06 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:06 --> Controller Class Initialized
INFO - 2022-08-18 11:15:07 --> Config Class Initialized
INFO - 2022-08-18 11:15:07 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:07 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:07 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:07 --> URI Class Initialized
INFO - 2022-08-18 11:15:07 --> Router Class Initialized
INFO - 2022-08-18 11:15:07 --> Output Class Initialized
INFO - 2022-08-18 11:15:07 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:07 --> Input Class Initialized
INFO - 2022-08-18 11:15:07 --> Language Class Initialized
INFO - 2022-08-18 11:15:07 --> Loader Class Initialized
INFO - 2022-08-18 11:15:07 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:07 --> Controller Class Initialized
INFO - 2022-08-18 11:15:07 --> Config Class Initialized
INFO - 2022-08-18 11:15:07 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:07 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:07 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:07 --> URI Class Initialized
INFO - 2022-08-18 11:15:07 --> Router Class Initialized
INFO - 2022-08-18 11:15:07 --> Output Class Initialized
INFO - 2022-08-18 11:15:07 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:07 --> Input Class Initialized
INFO - 2022-08-18 11:15:07 --> Language Class Initialized
INFO - 2022-08-18 11:15:07 --> Loader Class Initialized
INFO - 2022-08-18 11:15:07 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:07 --> Controller Class Initialized
INFO - 2022-08-18 11:15:07 --> Config Class Initialized
INFO - 2022-08-18 11:15:07 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:07 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:07 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:07 --> URI Class Initialized
INFO - 2022-08-18 11:15:07 --> Router Class Initialized
INFO - 2022-08-18 11:15:07 --> Output Class Initialized
INFO - 2022-08-18 11:15:07 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:07 --> Input Class Initialized
INFO - 2022-08-18 11:15:07 --> Language Class Initialized
INFO - 2022-08-18 11:15:08 --> Loader Class Initialized
INFO - 2022-08-18 11:15:08 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:08 --> Controller Class Initialized
INFO - 2022-08-18 11:15:08 --> Config Class Initialized
INFO - 2022-08-18 11:15:08 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:08 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:08 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:08 --> URI Class Initialized
INFO - 2022-08-18 11:15:08 --> Router Class Initialized
INFO - 2022-08-18 11:15:08 --> Output Class Initialized
INFO - 2022-08-18 11:15:08 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:08 --> Input Class Initialized
INFO - 2022-08-18 11:15:08 --> Language Class Initialized
INFO - 2022-08-18 11:15:08 --> Loader Class Initialized
INFO - 2022-08-18 11:15:08 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:08 --> Controller Class Initialized
INFO - 2022-08-18 11:15:08 --> Config Class Initialized
INFO - 2022-08-18 11:15:08 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:08 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:08 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:08 --> URI Class Initialized
INFO - 2022-08-18 11:15:08 --> Router Class Initialized
INFO - 2022-08-18 11:15:08 --> Output Class Initialized
INFO - 2022-08-18 11:15:08 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:08 --> Input Class Initialized
INFO - 2022-08-18 11:15:08 --> Language Class Initialized
INFO - 2022-08-18 11:15:08 --> Loader Class Initialized
INFO - 2022-08-18 11:15:08 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:08 --> Controller Class Initialized
INFO - 2022-08-18 11:15:09 --> Config Class Initialized
INFO - 2022-08-18 11:15:09 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:09 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:09 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:09 --> URI Class Initialized
INFO - 2022-08-18 11:15:09 --> Router Class Initialized
INFO - 2022-08-18 11:15:09 --> Output Class Initialized
INFO - 2022-08-18 11:15:09 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:09 --> Input Class Initialized
INFO - 2022-08-18 11:15:09 --> Language Class Initialized
INFO - 2022-08-18 11:15:09 --> Loader Class Initialized
INFO - 2022-08-18 11:15:09 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:09 --> Controller Class Initialized
INFO - 2022-08-18 11:15:09 --> Config Class Initialized
INFO - 2022-08-18 11:15:09 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:09 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:09 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:09 --> URI Class Initialized
INFO - 2022-08-18 11:15:09 --> Router Class Initialized
INFO - 2022-08-18 11:15:09 --> Output Class Initialized
INFO - 2022-08-18 11:15:09 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:09 --> Input Class Initialized
INFO - 2022-08-18 11:15:09 --> Language Class Initialized
INFO - 2022-08-18 11:15:09 --> Loader Class Initialized
INFO - 2022-08-18 11:15:09 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:09 --> Controller Class Initialized
INFO - 2022-08-18 11:15:09 --> Config Class Initialized
INFO - 2022-08-18 11:15:09 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:09 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:09 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:09 --> URI Class Initialized
INFO - 2022-08-18 11:15:09 --> Router Class Initialized
INFO - 2022-08-18 11:15:09 --> Output Class Initialized
INFO - 2022-08-18 11:15:09 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:09 --> Input Class Initialized
INFO - 2022-08-18 11:15:09 --> Language Class Initialized
INFO - 2022-08-18 11:15:09 --> Loader Class Initialized
INFO - 2022-08-18 11:15:10 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:10 --> Controller Class Initialized
INFO - 2022-08-18 11:15:10 --> Config Class Initialized
INFO - 2022-08-18 11:15:10 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:10 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:10 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:10 --> URI Class Initialized
INFO - 2022-08-18 11:15:10 --> Router Class Initialized
INFO - 2022-08-18 11:15:10 --> Output Class Initialized
INFO - 2022-08-18 11:15:10 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:10 --> Input Class Initialized
INFO - 2022-08-18 11:15:10 --> Language Class Initialized
INFO - 2022-08-18 11:15:10 --> Loader Class Initialized
INFO - 2022-08-18 11:15:10 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:10 --> Controller Class Initialized
INFO - 2022-08-18 11:15:10 --> Config Class Initialized
INFO - 2022-08-18 11:15:10 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:10 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:10 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:10 --> URI Class Initialized
INFO - 2022-08-18 11:15:10 --> Router Class Initialized
INFO - 2022-08-18 11:15:10 --> Output Class Initialized
INFO - 2022-08-18 11:15:10 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:10 --> Input Class Initialized
INFO - 2022-08-18 11:15:10 --> Language Class Initialized
INFO - 2022-08-18 11:15:10 --> Loader Class Initialized
INFO - 2022-08-18 11:15:10 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:10 --> Controller Class Initialized
INFO - 2022-08-18 11:15:10 --> Config Class Initialized
INFO - 2022-08-18 11:15:10 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:10 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:10 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:10 --> URI Class Initialized
INFO - 2022-08-18 11:15:10 --> Router Class Initialized
INFO - 2022-08-18 11:15:10 --> Output Class Initialized
INFO - 2022-08-18 11:15:10 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:10 --> Input Class Initialized
INFO - 2022-08-18 11:15:10 --> Language Class Initialized
INFO - 2022-08-18 11:15:10 --> Loader Class Initialized
INFO - 2022-08-18 11:15:10 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:10 --> Controller Class Initialized
INFO - 2022-08-18 11:15:11 --> Config Class Initialized
INFO - 2022-08-18 11:15:11 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:11 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:11 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:11 --> URI Class Initialized
INFO - 2022-08-18 11:15:11 --> Router Class Initialized
INFO - 2022-08-18 11:15:11 --> Output Class Initialized
INFO - 2022-08-18 11:15:11 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:11 --> Input Class Initialized
INFO - 2022-08-18 11:15:11 --> Language Class Initialized
INFO - 2022-08-18 11:15:11 --> Loader Class Initialized
INFO - 2022-08-18 11:15:11 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:11 --> Controller Class Initialized
INFO - 2022-08-18 11:15:12 --> Config Class Initialized
INFO - 2022-08-18 11:15:12 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:12 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:12 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:12 --> URI Class Initialized
INFO - 2022-08-18 11:15:12 --> Router Class Initialized
INFO - 2022-08-18 11:15:12 --> Output Class Initialized
INFO - 2022-08-18 11:15:12 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:12 --> Input Class Initialized
INFO - 2022-08-18 11:15:12 --> Language Class Initialized
INFO - 2022-08-18 11:15:12 --> Loader Class Initialized
INFO - 2022-08-18 11:15:12 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:12 --> Controller Class Initialized
INFO - 2022-08-18 11:15:12 --> Config Class Initialized
INFO - 2022-08-18 11:15:12 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:13 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:13 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:13 --> URI Class Initialized
INFO - 2022-08-18 11:15:13 --> Router Class Initialized
INFO - 2022-08-18 11:15:13 --> Output Class Initialized
INFO - 2022-08-18 11:15:13 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:13 --> Input Class Initialized
INFO - 2022-08-18 11:15:13 --> Language Class Initialized
INFO - 2022-08-18 11:15:13 --> Loader Class Initialized
INFO - 2022-08-18 11:15:13 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:13 --> Controller Class Initialized
INFO - 2022-08-18 11:15:13 --> Config Class Initialized
INFO - 2022-08-18 11:15:13 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:13 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:13 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:13 --> URI Class Initialized
INFO - 2022-08-18 11:15:13 --> Router Class Initialized
INFO - 2022-08-18 11:15:13 --> Output Class Initialized
INFO - 2022-08-18 11:15:13 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:13 --> Input Class Initialized
INFO - 2022-08-18 11:15:13 --> Language Class Initialized
INFO - 2022-08-18 11:15:13 --> Loader Class Initialized
INFO - 2022-08-18 11:15:13 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:13 --> Controller Class Initialized
INFO - 2022-08-18 11:15:38 --> Config Class Initialized
INFO - 2022-08-18 11:15:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:15:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:15:38 --> Utf8 Class Initialized
INFO - 2022-08-18 11:15:39 --> URI Class Initialized
INFO - 2022-08-18 11:15:39 --> Router Class Initialized
INFO - 2022-08-18 11:15:39 --> Output Class Initialized
INFO - 2022-08-18 11:15:39 --> Security Class Initialized
DEBUG - 2022-08-18 11:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:15:39 --> Input Class Initialized
INFO - 2022-08-18 11:15:39 --> Language Class Initialized
INFO - 2022-08-18 11:15:39 --> Loader Class Initialized
INFO - 2022-08-18 11:15:39 --> Helper loaded: url_helper
INFO - 2022-08-18 11:15:39 --> Controller Class Initialized
DEBUG - 2022-08-18 11:15:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 11:15:39 --> Helper loaded: inflector_helper
INFO - 2022-08-18 11:15:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 11:15:39 --> Final output sent to browser
DEBUG - 2022-08-18 11:15:39 --> Total execution time: 0.5547
INFO - 2022-08-18 11:23:22 --> Config Class Initialized
INFO - 2022-08-18 11:23:22 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:22 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:22 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:22 --> URI Class Initialized
INFO - 2022-08-18 11:23:22 --> Router Class Initialized
INFO - 2022-08-18 11:23:22 --> Output Class Initialized
INFO - 2022-08-18 11:23:22 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:22 --> Input Class Initialized
INFO - 2022-08-18 11:23:22 --> Language Class Initialized
ERROR - 2022-08-18 11:23:22 --> 404 Page Not Found: Login/index
INFO - 2022-08-18 11:23:29 --> Config Class Initialized
INFO - 2022-08-18 11:23:29 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:29 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:29 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:29 --> URI Class Initialized
INFO - 2022-08-18 11:23:29 --> Router Class Initialized
INFO - 2022-08-18 11:23:29 --> Output Class Initialized
INFO - 2022-08-18 11:23:29 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:29 --> Input Class Initialized
INFO - 2022-08-18 11:23:29 --> Language Class Initialized
INFO - 2022-08-18 11:23:29 --> Loader Class Initialized
INFO - 2022-08-18 11:23:29 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:29 --> Controller Class Initialized
INFO - 2022-08-18 11:23:30 --> Config Class Initialized
INFO - 2022-08-18 11:23:30 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:30 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:30 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:30 --> URI Class Initialized
INFO - 2022-08-18 11:23:30 --> Router Class Initialized
INFO - 2022-08-18 11:23:30 --> Output Class Initialized
INFO - 2022-08-18 11:23:30 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:30 --> Input Class Initialized
INFO - 2022-08-18 11:23:30 --> Language Class Initialized
INFO - 2022-08-18 11:23:30 --> Loader Class Initialized
INFO - 2022-08-18 11:23:30 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:30 --> Controller Class Initialized
INFO - 2022-08-18 11:23:30 --> Config Class Initialized
INFO - 2022-08-18 11:23:30 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:30 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:30 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:30 --> URI Class Initialized
INFO - 2022-08-18 11:23:30 --> Router Class Initialized
INFO - 2022-08-18 11:23:30 --> Output Class Initialized
INFO - 2022-08-18 11:23:30 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:30 --> Input Class Initialized
INFO - 2022-08-18 11:23:30 --> Language Class Initialized
INFO - 2022-08-18 11:23:30 --> Loader Class Initialized
INFO - 2022-08-18 11:23:30 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:30 --> Controller Class Initialized
INFO - 2022-08-18 11:23:31 --> Config Class Initialized
INFO - 2022-08-18 11:23:31 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:31 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:31 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:31 --> URI Class Initialized
INFO - 2022-08-18 11:23:31 --> Router Class Initialized
INFO - 2022-08-18 11:23:31 --> Output Class Initialized
INFO - 2022-08-18 11:23:31 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:31 --> Input Class Initialized
INFO - 2022-08-18 11:23:31 --> Language Class Initialized
INFO - 2022-08-18 11:23:31 --> Loader Class Initialized
INFO - 2022-08-18 11:23:31 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:31 --> Controller Class Initialized
INFO - 2022-08-18 11:23:31 --> Config Class Initialized
INFO - 2022-08-18 11:23:31 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:31 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:31 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:31 --> URI Class Initialized
INFO - 2022-08-18 11:23:31 --> Router Class Initialized
INFO - 2022-08-18 11:23:31 --> Output Class Initialized
INFO - 2022-08-18 11:23:31 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:31 --> Input Class Initialized
INFO - 2022-08-18 11:23:31 --> Language Class Initialized
INFO - 2022-08-18 11:23:31 --> Loader Class Initialized
INFO - 2022-08-18 11:23:31 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:31 --> Controller Class Initialized
INFO - 2022-08-18 11:23:31 --> Config Class Initialized
INFO - 2022-08-18 11:23:31 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:32 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:32 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:32 --> URI Class Initialized
INFO - 2022-08-18 11:23:32 --> Router Class Initialized
INFO - 2022-08-18 11:23:32 --> Output Class Initialized
INFO - 2022-08-18 11:23:32 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:32 --> Input Class Initialized
INFO - 2022-08-18 11:23:32 --> Language Class Initialized
INFO - 2022-08-18 11:23:32 --> Loader Class Initialized
INFO - 2022-08-18 11:23:32 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:32 --> Controller Class Initialized
INFO - 2022-08-18 11:23:32 --> Config Class Initialized
INFO - 2022-08-18 11:23:32 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:32 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:32 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:32 --> URI Class Initialized
INFO - 2022-08-18 11:23:32 --> Router Class Initialized
INFO - 2022-08-18 11:23:32 --> Output Class Initialized
INFO - 2022-08-18 11:23:32 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:32 --> Input Class Initialized
INFO - 2022-08-18 11:23:32 --> Language Class Initialized
INFO - 2022-08-18 11:23:32 --> Loader Class Initialized
INFO - 2022-08-18 11:23:32 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:32 --> Controller Class Initialized
INFO - 2022-08-18 11:23:32 --> Config Class Initialized
INFO - 2022-08-18 11:23:32 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:32 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:32 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:32 --> URI Class Initialized
INFO - 2022-08-18 11:23:33 --> Router Class Initialized
INFO - 2022-08-18 11:23:33 --> Output Class Initialized
INFO - 2022-08-18 11:23:33 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:33 --> Input Class Initialized
INFO - 2022-08-18 11:23:33 --> Language Class Initialized
INFO - 2022-08-18 11:23:33 --> Loader Class Initialized
INFO - 2022-08-18 11:23:33 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:33 --> Controller Class Initialized
INFO - 2022-08-18 11:23:33 --> Config Class Initialized
INFO - 2022-08-18 11:23:33 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:33 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:33 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:33 --> URI Class Initialized
INFO - 2022-08-18 11:23:33 --> Router Class Initialized
INFO - 2022-08-18 11:23:33 --> Output Class Initialized
INFO - 2022-08-18 11:23:33 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:33 --> Input Class Initialized
INFO - 2022-08-18 11:23:33 --> Language Class Initialized
INFO - 2022-08-18 11:23:33 --> Loader Class Initialized
INFO - 2022-08-18 11:23:33 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:33 --> Controller Class Initialized
INFO - 2022-08-18 11:23:33 --> Config Class Initialized
INFO - 2022-08-18 11:23:33 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:33 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:33 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:33 --> URI Class Initialized
INFO - 2022-08-18 11:23:33 --> Router Class Initialized
INFO - 2022-08-18 11:23:33 --> Output Class Initialized
INFO - 2022-08-18 11:23:33 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:34 --> Input Class Initialized
INFO - 2022-08-18 11:23:34 --> Language Class Initialized
INFO - 2022-08-18 11:23:34 --> Loader Class Initialized
INFO - 2022-08-18 11:23:34 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:34 --> Controller Class Initialized
INFO - 2022-08-18 11:23:34 --> Config Class Initialized
INFO - 2022-08-18 11:23:34 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:34 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:34 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:34 --> URI Class Initialized
INFO - 2022-08-18 11:23:34 --> Router Class Initialized
INFO - 2022-08-18 11:23:34 --> Output Class Initialized
INFO - 2022-08-18 11:23:34 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:34 --> Input Class Initialized
INFO - 2022-08-18 11:23:34 --> Language Class Initialized
INFO - 2022-08-18 11:23:34 --> Loader Class Initialized
INFO - 2022-08-18 11:23:34 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:34 --> Controller Class Initialized
INFO - 2022-08-18 11:23:34 --> Config Class Initialized
INFO - 2022-08-18 11:23:34 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:34 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:34 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:34 --> URI Class Initialized
INFO - 2022-08-18 11:23:34 --> Router Class Initialized
INFO - 2022-08-18 11:23:34 --> Output Class Initialized
INFO - 2022-08-18 11:23:34 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:34 --> Input Class Initialized
INFO - 2022-08-18 11:23:34 --> Language Class Initialized
INFO - 2022-08-18 11:23:35 --> Loader Class Initialized
INFO - 2022-08-18 11:23:35 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:35 --> Controller Class Initialized
INFO - 2022-08-18 11:23:35 --> Config Class Initialized
INFO - 2022-08-18 11:23:35 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:35 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:35 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:35 --> URI Class Initialized
INFO - 2022-08-18 11:23:35 --> Router Class Initialized
INFO - 2022-08-18 11:23:35 --> Output Class Initialized
INFO - 2022-08-18 11:23:35 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:35 --> Input Class Initialized
INFO - 2022-08-18 11:23:35 --> Language Class Initialized
INFO - 2022-08-18 11:23:35 --> Loader Class Initialized
INFO - 2022-08-18 11:23:35 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:35 --> Controller Class Initialized
INFO - 2022-08-18 11:23:35 --> Config Class Initialized
INFO - 2022-08-18 11:23:35 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:35 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:35 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:35 --> URI Class Initialized
INFO - 2022-08-18 11:23:35 --> Router Class Initialized
INFO - 2022-08-18 11:23:35 --> Output Class Initialized
INFO - 2022-08-18 11:23:35 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:35 --> Input Class Initialized
INFO - 2022-08-18 11:23:35 --> Language Class Initialized
INFO - 2022-08-18 11:23:35 --> Loader Class Initialized
INFO - 2022-08-18 11:23:35 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:35 --> Controller Class Initialized
INFO - 2022-08-18 11:23:36 --> Config Class Initialized
INFO - 2022-08-18 11:23:36 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:36 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:36 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:36 --> URI Class Initialized
INFO - 2022-08-18 11:23:36 --> Router Class Initialized
INFO - 2022-08-18 11:23:36 --> Output Class Initialized
INFO - 2022-08-18 11:23:36 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:36 --> Input Class Initialized
INFO - 2022-08-18 11:23:36 --> Language Class Initialized
INFO - 2022-08-18 11:23:36 --> Loader Class Initialized
INFO - 2022-08-18 11:23:36 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:36 --> Controller Class Initialized
INFO - 2022-08-18 11:23:36 --> Config Class Initialized
INFO - 2022-08-18 11:23:36 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:36 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:36 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:36 --> URI Class Initialized
INFO - 2022-08-18 11:23:36 --> Router Class Initialized
INFO - 2022-08-18 11:23:36 --> Output Class Initialized
INFO - 2022-08-18 11:23:36 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:36 --> Input Class Initialized
INFO - 2022-08-18 11:23:36 --> Language Class Initialized
INFO - 2022-08-18 11:23:36 --> Loader Class Initialized
INFO - 2022-08-18 11:23:36 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:36 --> Controller Class Initialized
INFO - 2022-08-18 11:23:36 --> Config Class Initialized
INFO - 2022-08-18 11:23:36 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:36 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:36 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:36 --> URI Class Initialized
INFO - 2022-08-18 11:23:36 --> Router Class Initialized
INFO - 2022-08-18 11:23:36 --> Output Class Initialized
INFO - 2022-08-18 11:23:36 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:37 --> Input Class Initialized
INFO - 2022-08-18 11:23:37 --> Language Class Initialized
INFO - 2022-08-18 11:23:37 --> Loader Class Initialized
INFO - 2022-08-18 11:23:37 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:37 --> Controller Class Initialized
INFO - 2022-08-18 11:23:37 --> Config Class Initialized
INFO - 2022-08-18 11:23:37 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:37 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:37 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:37 --> URI Class Initialized
INFO - 2022-08-18 11:23:37 --> Router Class Initialized
INFO - 2022-08-18 11:23:37 --> Output Class Initialized
INFO - 2022-08-18 11:23:37 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:37 --> Input Class Initialized
INFO - 2022-08-18 11:23:37 --> Language Class Initialized
INFO - 2022-08-18 11:23:37 --> Loader Class Initialized
INFO - 2022-08-18 11:23:37 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:37 --> Controller Class Initialized
INFO - 2022-08-18 11:23:37 --> Config Class Initialized
INFO - 2022-08-18 11:23:37 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:37 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:37 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:37 --> URI Class Initialized
INFO - 2022-08-18 11:23:37 --> Router Class Initialized
INFO - 2022-08-18 11:23:37 --> Output Class Initialized
INFO - 2022-08-18 11:23:37 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:37 --> Input Class Initialized
INFO - 2022-08-18 11:23:37 --> Language Class Initialized
INFO - 2022-08-18 11:23:37 --> Loader Class Initialized
INFO - 2022-08-18 11:23:37 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:37 --> Controller Class Initialized
INFO - 2022-08-18 11:23:38 --> Config Class Initialized
INFO - 2022-08-18 11:23:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:38 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:38 --> URI Class Initialized
INFO - 2022-08-18 11:23:38 --> Router Class Initialized
INFO - 2022-08-18 11:23:38 --> Output Class Initialized
INFO - 2022-08-18 11:23:38 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:38 --> Input Class Initialized
INFO - 2022-08-18 11:23:38 --> Language Class Initialized
INFO - 2022-08-18 11:23:38 --> Loader Class Initialized
INFO - 2022-08-18 11:23:38 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:38 --> Controller Class Initialized
INFO - 2022-08-18 11:23:38 --> Config Class Initialized
INFO - 2022-08-18 11:23:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:39 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:39 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:39 --> URI Class Initialized
INFO - 2022-08-18 11:23:39 --> Router Class Initialized
INFO - 2022-08-18 11:23:39 --> Output Class Initialized
INFO - 2022-08-18 11:23:39 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:39 --> Input Class Initialized
INFO - 2022-08-18 11:23:39 --> Language Class Initialized
INFO - 2022-08-18 11:23:39 --> Loader Class Initialized
INFO - 2022-08-18 11:23:39 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:39 --> Controller Class Initialized
INFO - 2022-08-18 11:23:39 --> Config Class Initialized
INFO - 2022-08-18 11:23:39 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:39 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:39 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:39 --> URI Class Initialized
INFO - 2022-08-18 11:23:39 --> Router Class Initialized
INFO - 2022-08-18 11:23:39 --> Output Class Initialized
INFO - 2022-08-18 11:23:39 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:39 --> Input Class Initialized
INFO - 2022-08-18 11:23:39 --> Language Class Initialized
INFO - 2022-08-18 11:23:39 --> Loader Class Initialized
INFO - 2022-08-18 11:23:39 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:39 --> Controller Class Initialized
INFO - 2022-08-18 11:23:39 --> Config Class Initialized
INFO - 2022-08-18 11:23:39 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:39 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:39 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:39 --> URI Class Initialized
INFO - 2022-08-18 11:23:39 --> Router Class Initialized
INFO - 2022-08-18 11:23:39 --> Output Class Initialized
INFO - 2022-08-18 11:23:40 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:40 --> Input Class Initialized
INFO - 2022-08-18 11:23:40 --> Language Class Initialized
INFO - 2022-08-18 11:23:40 --> Loader Class Initialized
INFO - 2022-08-18 11:23:40 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:40 --> Controller Class Initialized
INFO - 2022-08-18 11:23:40 --> Config Class Initialized
INFO - 2022-08-18 11:23:40 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:40 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:40 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:40 --> URI Class Initialized
INFO - 2022-08-18 11:23:40 --> Router Class Initialized
INFO - 2022-08-18 11:23:40 --> Output Class Initialized
INFO - 2022-08-18 11:23:40 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:40 --> Input Class Initialized
INFO - 2022-08-18 11:23:40 --> Language Class Initialized
INFO - 2022-08-18 11:23:40 --> Loader Class Initialized
INFO - 2022-08-18 11:23:40 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:40 --> Controller Class Initialized
INFO - 2022-08-18 11:23:40 --> Config Class Initialized
INFO - 2022-08-18 11:23:40 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:40 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:40 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:40 --> URI Class Initialized
INFO - 2022-08-18 11:23:40 --> Router Class Initialized
INFO - 2022-08-18 11:23:40 --> Output Class Initialized
INFO - 2022-08-18 11:23:40 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:40 --> Input Class Initialized
INFO - 2022-08-18 11:23:40 --> Language Class Initialized
INFO - 2022-08-18 11:23:40 --> Loader Class Initialized
INFO - 2022-08-18 11:23:40 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:40 --> Controller Class Initialized
INFO - 2022-08-18 11:23:40 --> Config Class Initialized
INFO - 2022-08-18 11:23:40 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:41 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:41 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:41 --> URI Class Initialized
INFO - 2022-08-18 11:23:41 --> Router Class Initialized
INFO - 2022-08-18 11:23:41 --> Output Class Initialized
INFO - 2022-08-18 11:23:41 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:41 --> Input Class Initialized
INFO - 2022-08-18 11:23:41 --> Language Class Initialized
INFO - 2022-08-18 11:23:41 --> Loader Class Initialized
INFO - 2022-08-18 11:23:41 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:41 --> Controller Class Initialized
INFO - 2022-08-18 11:23:41 --> Config Class Initialized
INFO - 2022-08-18 11:23:41 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:41 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:41 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:41 --> URI Class Initialized
INFO - 2022-08-18 11:23:41 --> Router Class Initialized
INFO - 2022-08-18 11:23:41 --> Output Class Initialized
INFO - 2022-08-18 11:23:41 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:41 --> Input Class Initialized
INFO - 2022-08-18 11:23:41 --> Language Class Initialized
INFO - 2022-08-18 11:23:41 --> Loader Class Initialized
INFO - 2022-08-18 11:23:41 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:41 --> Controller Class Initialized
INFO - 2022-08-18 11:23:41 --> Config Class Initialized
INFO - 2022-08-18 11:23:41 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:41 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:41 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:41 --> URI Class Initialized
INFO - 2022-08-18 11:23:41 --> Router Class Initialized
INFO - 2022-08-18 11:23:41 --> Output Class Initialized
INFO - 2022-08-18 11:23:41 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:41 --> Input Class Initialized
INFO - 2022-08-18 11:23:41 --> Language Class Initialized
INFO - 2022-08-18 11:23:41 --> Loader Class Initialized
INFO - 2022-08-18 11:23:41 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:41 --> Controller Class Initialized
INFO - 2022-08-18 11:23:41 --> Config Class Initialized
INFO - 2022-08-18 11:23:41 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:41 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:41 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:41 --> URI Class Initialized
INFO - 2022-08-18 11:23:41 --> Router Class Initialized
INFO - 2022-08-18 11:23:41 --> Output Class Initialized
INFO - 2022-08-18 11:23:41 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:42 --> Input Class Initialized
INFO - 2022-08-18 11:23:42 --> Language Class Initialized
INFO - 2022-08-18 11:23:42 --> Loader Class Initialized
INFO - 2022-08-18 11:23:42 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:42 --> Controller Class Initialized
INFO - 2022-08-18 11:23:42 --> Config Class Initialized
INFO - 2022-08-18 11:23:42 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:42 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:42 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:42 --> URI Class Initialized
INFO - 2022-08-18 11:23:42 --> Router Class Initialized
INFO - 2022-08-18 11:23:42 --> Output Class Initialized
INFO - 2022-08-18 11:23:42 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:42 --> Input Class Initialized
INFO - 2022-08-18 11:23:42 --> Language Class Initialized
INFO - 2022-08-18 11:23:42 --> Loader Class Initialized
INFO - 2022-08-18 11:23:42 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:42 --> Controller Class Initialized
INFO - 2022-08-18 11:23:42 --> Config Class Initialized
INFO - 2022-08-18 11:23:42 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:42 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:42 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:42 --> URI Class Initialized
INFO - 2022-08-18 11:23:42 --> Router Class Initialized
INFO - 2022-08-18 11:23:42 --> Output Class Initialized
INFO - 2022-08-18 11:23:42 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:42 --> Input Class Initialized
INFO - 2022-08-18 11:23:42 --> Language Class Initialized
INFO - 2022-08-18 11:23:42 --> Loader Class Initialized
INFO - 2022-08-18 11:23:42 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:42 --> Controller Class Initialized
INFO - 2022-08-18 11:23:42 --> Config Class Initialized
INFO - 2022-08-18 11:23:42 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:42 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:42 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:42 --> URI Class Initialized
INFO - 2022-08-18 11:23:43 --> Router Class Initialized
INFO - 2022-08-18 11:23:43 --> Output Class Initialized
INFO - 2022-08-18 11:23:43 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:43 --> Input Class Initialized
INFO - 2022-08-18 11:23:43 --> Language Class Initialized
INFO - 2022-08-18 11:23:43 --> Loader Class Initialized
INFO - 2022-08-18 11:23:43 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:43 --> Controller Class Initialized
INFO - 2022-08-18 11:23:43 --> Config Class Initialized
INFO - 2022-08-18 11:23:43 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:43 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:43 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:43 --> URI Class Initialized
INFO - 2022-08-18 11:23:43 --> Router Class Initialized
INFO - 2022-08-18 11:23:43 --> Output Class Initialized
INFO - 2022-08-18 11:23:43 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:43 --> Input Class Initialized
INFO - 2022-08-18 11:23:43 --> Language Class Initialized
INFO - 2022-08-18 11:23:43 --> Loader Class Initialized
INFO - 2022-08-18 11:23:43 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:43 --> Controller Class Initialized
INFO - 2022-08-18 11:23:43 --> Config Class Initialized
INFO - 2022-08-18 11:23:43 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:43 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:43 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:43 --> URI Class Initialized
INFO - 2022-08-18 11:23:43 --> Router Class Initialized
INFO - 2022-08-18 11:23:43 --> Output Class Initialized
INFO - 2022-08-18 11:23:43 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:43 --> Input Class Initialized
INFO - 2022-08-18 11:23:43 --> Language Class Initialized
INFO - 2022-08-18 11:23:43 --> Loader Class Initialized
INFO - 2022-08-18 11:23:43 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:43 --> Controller Class Initialized
INFO - 2022-08-18 11:23:44 --> Config Class Initialized
INFO - 2022-08-18 11:23:44 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:44 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:44 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:44 --> URI Class Initialized
INFO - 2022-08-18 11:23:44 --> Router Class Initialized
INFO - 2022-08-18 11:23:44 --> Output Class Initialized
INFO - 2022-08-18 11:23:44 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:44 --> Input Class Initialized
INFO - 2022-08-18 11:23:44 --> Language Class Initialized
INFO - 2022-08-18 11:23:44 --> Loader Class Initialized
INFO - 2022-08-18 11:23:44 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:44 --> Controller Class Initialized
INFO - 2022-08-18 11:23:44 --> Config Class Initialized
INFO - 2022-08-18 11:23:44 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:44 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:44 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:44 --> URI Class Initialized
INFO - 2022-08-18 11:23:44 --> Router Class Initialized
INFO - 2022-08-18 11:23:44 --> Output Class Initialized
INFO - 2022-08-18 11:23:44 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:44 --> Input Class Initialized
INFO - 2022-08-18 11:23:44 --> Language Class Initialized
INFO - 2022-08-18 11:23:44 --> Loader Class Initialized
INFO - 2022-08-18 11:23:44 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:44 --> Controller Class Initialized
INFO - 2022-08-18 11:23:45 --> Config Class Initialized
INFO - 2022-08-18 11:23:45 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:45 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:45 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:45 --> URI Class Initialized
INFO - 2022-08-18 11:23:45 --> Router Class Initialized
INFO - 2022-08-18 11:23:45 --> Output Class Initialized
INFO - 2022-08-18 11:23:45 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:45 --> Input Class Initialized
INFO - 2022-08-18 11:23:45 --> Language Class Initialized
INFO - 2022-08-18 11:23:45 --> Loader Class Initialized
INFO - 2022-08-18 11:23:45 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:45 --> Controller Class Initialized
INFO - 2022-08-18 11:23:45 --> Config Class Initialized
INFO - 2022-08-18 11:23:45 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:45 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:45 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:45 --> URI Class Initialized
INFO - 2022-08-18 11:23:45 --> Router Class Initialized
INFO - 2022-08-18 11:23:45 --> Output Class Initialized
INFO - 2022-08-18 11:23:45 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:45 --> Input Class Initialized
INFO - 2022-08-18 11:23:45 --> Language Class Initialized
INFO - 2022-08-18 11:23:45 --> Loader Class Initialized
INFO - 2022-08-18 11:23:45 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:45 --> Controller Class Initialized
INFO - 2022-08-18 11:23:45 --> Config Class Initialized
INFO - 2022-08-18 11:23:45 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:45 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:45 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:45 --> URI Class Initialized
INFO - 2022-08-18 11:23:45 --> Router Class Initialized
INFO - 2022-08-18 11:23:45 --> Output Class Initialized
INFO - 2022-08-18 11:23:45 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:45 --> Input Class Initialized
INFO - 2022-08-18 11:23:45 --> Language Class Initialized
INFO - 2022-08-18 11:23:45 --> Loader Class Initialized
INFO - 2022-08-18 11:23:45 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:45 --> Controller Class Initialized
INFO - 2022-08-18 11:23:46 --> Config Class Initialized
INFO - 2022-08-18 11:23:46 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:46 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:46 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:46 --> URI Class Initialized
INFO - 2022-08-18 11:23:46 --> Router Class Initialized
INFO - 2022-08-18 11:23:46 --> Output Class Initialized
INFO - 2022-08-18 11:23:46 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:46 --> Input Class Initialized
INFO - 2022-08-18 11:23:46 --> Language Class Initialized
INFO - 2022-08-18 11:23:46 --> Loader Class Initialized
INFO - 2022-08-18 11:23:46 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:46 --> Controller Class Initialized
INFO - 2022-08-18 11:23:47 --> Config Class Initialized
INFO - 2022-08-18 11:23:47 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:47 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:47 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:47 --> URI Class Initialized
INFO - 2022-08-18 11:23:47 --> Router Class Initialized
INFO - 2022-08-18 11:23:47 --> Output Class Initialized
INFO - 2022-08-18 11:23:47 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:47 --> Input Class Initialized
INFO - 2022-08-18 11:23:47 --> Language Class Initialized
INFO - 2022-08-18 11:23:47 --> Loader Class Initialized
INFO - 2022-08-18 11:23:47 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:47 --> Controller Class Initialized
INFO - 2022-08-18 11:23:48 --> Config Class Initialized
INFO - 2022-08-18 11:23:48 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:48 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:48 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:48 --> URI Class Initialized
INFO - 2022-08-18 11:23:48 --> Router Class Initialized
INFO - 2022-08-18 11:23:48 --> Output Class Initialized
INFO - 2022-08-18 11:23:48 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:48 --> Input Class Initialized
INFO - 2022-08-18 11:23:48 --> Language Class Initialized
INFO - 2022-08-18 11:23:48 --> Loader Class Initialized
INFO - 2022-08-18 11:23:48 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:48 --> Controller Class Initialized
INFO - 2022-08-18 11:23:48 --> Config Class Initialized
INFO - 2022-08-18 11:23:48 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:48 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:48 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:48 --> URI Class Initialized
INFO - 2022-08-18 11:23:48 --> Router Class Initialized
INFO - 2022-08-18 11:23:48 --> Output Class Initialized
INFO - 2022-08-18 11:23:48 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:48 --> Input Class Initialized
INFO - 2022-08-18 11:23:48 --> Language Class Initialized
INFO - 2022-08-18 11:23:48 --> Loader Class Initialized
INFO - 2022-08-18 11:23:48 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:48 --> Controller Class Initialized
INFO - 2022-08-18 11:23:48 --> Config Class Initialized
INFO - 2022-08-18 11:23:48 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:48 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:48 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:48 --> URI Class Initialized
INFO - 2022-08-18 11:23:48 --> Router Class Initialized
INFO - 2022-08-18 11:23:48 --> Output Class Initialized
INFO - 2022-08-18 11:23:48 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:48 --> Input Class Initialized
INFO - 2022-08-18 11:23:48 --> Language Class Initialized
INFO - 2022-08-18 11:23:48 --> Loader Class Initialized
INFO - 2022-08-18 11:23:48 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:48 --> Controller Class Initialized
INFO - 2022-08-18 11:23:49 --> Config Class Initialized
INFO - 2022-08-18 11:23:49 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:49 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:49 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:49 --> URI Class Initialized
INFO - 2022-08-18 11:23:49 --> Router Class Initialized
INFO - 2022-08-18 11:23:49 --> Output Class Initialized
INFO - 2022-08-18 11:23:49 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:49 --> Input Class Initialized
INFO - 2022-08-18 11:23:49 --> Language Class Initialized
INFO - 2022-08-18 11:23:49 --> Loader Class Initialized
INFO - 2022-08-18 11:23:49 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:49 --> Controller Class Initialized
INFO - 2022-08-18 11:23:49 --> Config Class Initialized
INFO - 2022-08-18 11:23:49 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:49 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:49 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:49 --> URI Class Initialized
INFO - 2022-08-18 11:23:49 --> Router Class Initialized
INFO - 2022-08-18 11:23:49 --> Output Class Initialized
INFO - 2022-08-18 11:23:49 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:49 --> Input Class Initialized
INFO - 2022-08-18 11:23:49 --> Language Class Initialized
INFO - 2022-08-18 11:23:49 --> Loader Class Initialized
INFO - 2022-08-18 11:23:49 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:49 --> Controller Class Initialized
INFO - 2022-08-18 11:23:49 --> Config Class Initialized
INFO - 2022-08-18 11:23:49 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:49 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:49 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:49 --> URI Class Initialized
INFO - 2022-08-18 11:23:49 --> Router Class Initialized
INFO - 2022-08-18 11:23:49 --> Output Class Initialized
INFO - 2022-08-18 11:23:49 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:49 --> Input Class Initialized
INFO - 2022-08-18 11:23:49 --> Language Class Initialized
INFO - 2022-08-18 11:23:50 --> Loader Class Initialized
INFO - 2022-08-18 11:23:50 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:50 --> Controller Class Initialized
INFO - 2022-08-18 11:23:50 --> Config Class Initialized
INFO - 2022-08-18 11:23:50 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:50 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:50 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:50 --> URI Class Initialized
INFO - 2022-08-18 11:23:50 --> Router Class Initialized
INFO - 2022-08-18 11:23:50 --> Output Class Initialized
INFO - 2022-08-18 11:23:50 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:50 --> Input Class Initialized
INFO - 2022-08-18 11:23:50 --> Language Class Initialized
INFO - 2022-08-18 11:23:50 --> Loader Class Initialized
INFO - 2022-08-18 11:23:50 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:50 --> Controller Class Initialized
INFO - 2022-08-18 11:23:50 --> Config Class Initialized
INFO - 2022-08-18 11:23:50 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:50 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:50 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:50 --> URI Class Initialized
INFO - 2022-08-18 11:23:50 --> Router Class Initialized
INFO - 2022-08-18 11:23:50 --> Output Class Initialized
INFO - 2022-08-18 11:23:50 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:50 --> Input Class Initialized
INFO - 2022-08-18 11:23:50 --> Language Class Initialized
INFO - 2022-08-18 11:23:50 --> Loader Class Initialized
INFO - 2022-08-18 11:23:50 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:50 --> Controller Class Initialized
INFO - 2022-08-18 11:23:51 --> Config Class Initialized
INFO - 2022-08-18 11:23:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:51 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:51 --> URI Class Initialized
INFO - 2022-08-18 11:23:51 --> Router Class Initialized
INFO - 2022-08-18 11:23:51 --> Output Class Initialized
INFO - 2022-08-18 11:23:51 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:51 --> Input Class Initialized
INFO - 2022-08-18 11:23:51 --> Language Class Initialized
INFO - 2022-08-18 11:23:51 --> Loader Class Initialized
INFO - 2022-08-18 11:23:51 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:51 --> Controller Class Initialized
INFO - 2022-08-18 11:23:51 --> Config Class Initialized
INFO - 2022-08-18 11:23:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:51 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:51 --> URI Class Initialized
INFO - 2022-08-18 11:23:51 --> Router Class Initialized
INFO - 2022-08-18 11:23:51 --> Output Class Initialized
INFO - 2022-08-18 11:23:51 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:51 --> Input Class Initialized
INFO - 2022-08-18 11:23:51 --> Language Class Initialized
INFO - 2022-08-18 11:23:51 --> Loader Class Initialized
INFO - 2022-08-18 11:23:51 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:51 --> Controller Class Initialized
INFO - 2022-08-18 11:23:51 --> Config Class Initialized
INFO - 2022-08-18 11:23:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:51 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:51 --> URI Class Initialized
INFO - 2022-08-18 11:23:51 --> Router Class Initialized
INFO - 2022-08-18 11:23:51 --> Output Class Initialized
INFO - 2022-08-18 11:23:51 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:52 --> Input Class Initialized
INFO - 2022-08-18 11:23:52 --> Language Class Initialized
INFO - 2022-08-18 11:23:52 --> Loader Class Initialized
INFO - 2022-08-18 11:23:52 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:52 --> Controller Class Initialized
INFO - 2022-08-18 11:23:52 --> Config Class Initialized
INFO - 2022-08-18 11:23:52 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:52 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:52 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:52 --> URI Class Initialized
INFO - 2022-08-18 11:23:52 --> Router Class Initialized
INFO - 2022-08-18 11:23:52 --> Output Class Initialized
INFO - 2022-08-18 11:23:52 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:52 --> Input Class Initialized
INFO - 2022-08-18 11:23:52 --> Language Class Initialized
INFO - 2022-08-18 11:23:52 --> Loader Class Initialized
INFO - 2022-08-18 11:23:52 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:52 --> Controller Class Initialized
INFO - 2022-08-18 11:23:52 --> Config Class Initialized
INFO - 2022-08-18 11:23:52 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:52 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:52 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:52 --> URI Class Initialized
INFO - 2022-08-18 11:23:52 --> Router Class Initialized
INFO - 2022-08-18 11:23:52 --> Output Class Initialized
INFO - 2022-08-18 11:23:52 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:52 --> Input Class Initialized
INFO - 2022-08-18 11:23:52 --> Language Class Initialized
INFO - 2022-08-18 11:23:52 --> Loader Class Initialized
INFO - 2022-08-18 11:23:52 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:52 --> Controller Class Initialized
INFO - 2022-08-18 11:23:53 --> Config Class Initialized
INFO - 2022-08-18 11:23:53 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:53 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:53 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:53 --> URI Class Initialized
INFO - 2022-08-18 11:23:53 --> Router Class Initialized
INFO - 2022-08-18 11:23:53 --> Output Class Initialized
INFO - 2022-08-18 11:23:53 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:53 --> Input Class Initialized
INFO - 2022-08-18 11:23:53 --> Language Class Initialized
INFO - 2022-08-18 11:23:53 --> Loader Class Initialized
INFO - 2022-08-18 11:23:53 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:53 --> Controller Class Initialized
INFO - 2022-08-18 11:23:53 --> Config Class Initialized
INFO - 2022-08-18 11:23:53 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:53 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:53 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:53 --> URI Class Initialized
INFO - 2022-08-18 11:23:53 --> Router Class Initialized
INFO - 2022-08-18 11:23:53 --> Output Class Initialized
INFO - 2022-08-18 11:23:53 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:53 --> Input Class Initialized
INFO - 2022-08-18 11:23:53 --> Language Class Initialized
INFO - 2022-08-18 11:23:53 --> Loader Class Initialized
INFO - 2022-08-18 11:23:53 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:53 --> Controller Class Initialized
INFO - 2022-08-18 11:23:53 --> Config Class Initialized
INFO - 2022-08-18 11:23:53 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:53 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:53 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:53 --> URI Class Initialized
INFO - 2022-08-18 11:23:53 --> Router Class Initialized
INFO - 2022-08-18 11:23:53 --> Output Class Initialized
INFO - 2022-08-18 11:23:53 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:53 --> Input Class Initialized
INFO - 2022-08-18 11:23:53 --> Language Class Initialized
INFO - 2022-08-18 11:23:53 --> Loader Class Initialized
INFO - 2022-08-18 11:23:53 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:53 --> Controller Class Initialized
INFO - 2022-08-18 11:23:54 --> Config Class Initialized
INFO - 2022-08-18 11:23:54 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:54 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:54 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:54 --> URI Class Initialized
INFO - 2022-08-18 11:23:54 --> Router Class Initialized
INFO - 2022-08-18 11:23:54 --> Output Class Initialized
INFO - 2022-08-18 11:23:54 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:54 --> Input Class Initialized
INFO - 2022-08-18 11:23:54 --> Language Class Initialized
INFO - 2022-08-18 11:23:54 --> Loader Class Initialized
INFO - 2022-08-18 11:23:54 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:54 --> Controller Class Initialized
INFO - 2022-08-18 11:23:54 --> Config Class Initialized
INFO - 2022-08-18 11:23:54 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:54 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:54 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:54 --> URI Class Initialized
INFO - 2022-08-18 11:23:54 --> Router Class Initialized
INFO - 2022-08-18 11:23:54 --> Output Class Initialized
INFO - 2022-08-18 11:23:54 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:54 --> Input Class Initialized
INFO - 2022-08-18 11:23:54 --> Language Class Initialized
INFO - 2022-08-18 11:23:54 --> Loader Class Initialized
INFO - 2022-08-18 11:23:54 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:54 --> Controller Class Initialized
INFO - 2022-08-18 11:23:54 --> Config Class Initialized
INFO - 2022-08-18 11:23:54 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:23:54 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:23:54 --> Utf8 Class Initialized
INFO - 2022-08-18 11:23:54 --> URI Class Initialized
INFO - 2022-08-18 11:23:54 --> Router Class Initialized
INFO - 2022-08-18 11:23:54 --> Output Class Initialized
INFO - 2022-08-18 11:23:54 --> Security Class Initialized
DEBUG - 2022-08-18 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:23:54 --> Input Class Initialized
INFO - 2022-08-18 11:23:54 --> Language Class Initialized
INFO - 2022-08-18 11:23:54 --> Loader Class Initialized
INFO - 2022-08-18 11:23:54 --> Helper loaded: url_helper
INFO - 2022-08-18 11:23:54 --> Controller Class Initialized
INFO - 2022-08-18 11:24:00 --> Config Class Initialized
INFO - 2022-08-18 11:24:00 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:00 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:00 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:00 --> URI Class Initialized
INFO - 2022-08-18 11:24:00 --> Router Class Initialized
INFO - 2022-08-18 11:24:00 --> Output Class Initialized
INFO - 2022-08-18 11:24:00 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:00 --> Input Class Initialized
INFO - 2022-08-18 11:24:00 --> Language Class Initialized
INFO - 2022-08-18 11:24:00 --> Loader Class Initialized
INFO - 2022-08-18 11:24:00 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:00 --> Controller Class Initialized
INFO - 2022-08-18 11:24:00 --> Config Class Initialized
INFO - 2022-08-18 11:24:00 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:00 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:00 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:00 --> URI Class Initialized
INFO - 2022-08-18 11:24:00 --> Router Class Initialized
INFO - 2022-08-18 11:24:00 --> Output Class Initialized
INFO - 2022-08-18 11:24:00 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:00 --> Input Class Initialized
INFO - 2022-08-18 11:24:00 --> Language Class Initialized
INFO - 2022-08-18 11:24:00 --> Loader Class Initialized
INFO - 2022-08-18 11:24:00 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:00 --> Controller Class Initialized
INFO - 2022-08-18 11:24:01 --> Config Class Initialized
INFO - 2022-08-18 11:24:01 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:01 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:01 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:01 --> URI Class Initialized
INFO - 2022-08-18 11:24:01 --> Router Class Initialized
INFO - 2022-08-18 11:24:01 --> Output Class Initialized
INFO - 2022-08-18 11:24:01 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:01 --> Input Class Initialized
INFO - 2022-08-18 11:24:01 --> Language Class Initialized
INFO - 2022-08-18 11:24:01 --> Loader Class Initialized
INFO - 2022-08-18 11:24:01 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:01 --> Controller Class Initialized
INFO - 2022-08-18 11:24:01 --> Config Class Initialized
INFO - 2022-08-18 11:24:01 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:01 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:01 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:01 --> URI Class Initialized
INFO - 2022-08-18 11:24:01 --> Router Class Initialized
INFO - 2022-08-18 11:24:01 --> Output Class Initialized
INFO - 2022-08-18 11:24:01 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:01 --> Input Class Initialized
INFO - 2022-08-18 11:24:01 --> Language Class Initialized
INFO - 2022-08-18 11:24:01 --> Loader Class Initialized
INFO - 2022-08-18 11:24:01 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:01 --> Controller Class Initialized
INFO - 2022-08-18 11:24:01 --> Config Class Initialized
INFO - 2022-08-18 11:24:01 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:02 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:02 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:02 --> URI Class Initialized
INFO - 2022-08-18 11:24:02 --> Router Class Initialized
INFO - 2022-08-18 11:24:02 --> Output Class Initialized
INFO - 2022-08-18 11:24:02 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:02 --> Input Class Initialized
INFO - 2022-08-18 11:24:02 --> Language Class Initialized
INFO - 2022-08-18 11:24:02 --> Loader Class Initialized
INFO - 2022-08-18 11:24:02 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:02 --> Controller Class Initialized
INFO - 2022-08-18 11:24:02 --> Config Class Initialized
INFO - 2022-08-18 11:24:02 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:02 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:02 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:02 --> URI Class Initialized
INFO - 2022-08-18 11:24:02 --> Router Class Initialized
INFO - 2022-08-18 11:24:02 --> Output Class Initialized
INFO - 2022-08-18 11:24:02 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:02 --> Input Class Initialized
INFO - 2022-08-18 11:24:02 --> Language Class Initialized
INFO - 2022-08-18 11:24:02 --> Loader Class Initialized
INFO - 2022-08-18 11:24:02 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:02 --> Controller Class Initialized
INFO - 2022-08-18 11:24:03 --> Config Class Initialized
INFO - 2022-08-18 11:24:03 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:03 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:03 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:03 --> URI Class Initialized
INFO - 2022-08-18 11:24:03 --> Router Class Initialized
INFO - 2022-08-18 11:24:03 --> Output Class Initialized
INFO - 2022-08-18 11:24:03 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:03 --> Input Class Initialized
INFO - 2022-08-18 11:24:03 --> Language Class Initialized
INFO - 2022-08-18 11:24:03 --> Loader Class Initialized
INFO - 2022-08-18 11:24:03 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:03 --> Controller Class Initialized
INFO - 2022-08-18 11:24:03 --> Config Class Initialized
INFO - 2022-08-18 11:24:03 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:03 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:03 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:03 --> URI Class Initialized
INFO - 2022-08-18 11:24:03 --> Router Class Initialized
INFO - 2022-08-18 11:24:03 --> Output Class Initialized
INFO - 2022-08-18 11:24:03 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:03 --> Input Class Initialized
INFO - 2022-08-18 11:24:03 --> Language Class Initialized
INFO - 2022-08-18 11:24:03 --> Loader Class Initialized
INFO - 2022-08-18 11:24:03 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:03 --> Controller Class Initialized
INFO - 2022-08-18 11:24:03 --> Config Class Initialized
INFO - 2022-08-18 11:24:03 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:03 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:03 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:03 --> URI Class Initialized
INFO - 2022-08-18 11:24:04 --> Router Class Initialized
INFO - 2022-08-18 11:24:04 --> Output Class Initialized
INFO - 2022-08-18 11:24:04 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:04 --> Input Class Initialized
INFO - 2022-08-18 11:24:04 --> Language Class Initialized
INFO - 2022-08-18 11:24:04 --> Loader Class Initialized
INFO - 2022-08-18 11:24:04 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:04 --> Controller Class Initialized
INFO - 2022-08-18 11:24:04 --> Config Class Initialized
INFO - 2022-08-18 11:24:04 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:04 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:04 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:04 --> URI Class Initialized
INFO - 2022-08-18 11:24:04 --> Router Class Initialized
INFO - 2022-08-18 11:24:04 --> Output Class Initialized
INFO - 2022-08-18 11:24:04 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:04 --> Input Class Initialized
INFO - 2022-08-18 11:24:04 --> Language Class Initialized
INFO - 2022-08-18 11:24:04 --> Loader Class Initialized
INFO - 2022-08-18 11:24:04 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:04 --> Controller Class Initialized
INFO - 2022-08-18 11:24:04 --> Config Class Initialized
INFO - 2022-08-18 11:24:04 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:04 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:04 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:04 --> URI Class Initialized
INFO - 2022-08-18 11:24:04 --> Router Class Initialized
INFO - 2022-08-18 11:24:04 --> Output Class Initialized
INFO - 2022-08-18 11:24:04 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:04 --> Input Class Initialized
INFO - 2022-08-18 11:24:04 --> Language Class Initialized
INFO - 2022-08-18 11:24:04 --> Loader Class Initialized
INFO - 2022-08-18 11:24:04 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:04 --> Controller Class Initialized
INFO - 2022-08-18 11:24:05 --> Config Class Initialized
INFO - 2022-08-18 11:24:05 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:05 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:05 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:05 --> URI Class Initialized
INFO - 2022-08-18 11:24:05 --> Router Class Initialized
INFO - 2022-08-18 11:24:05 --> Output Class Initialized
INFO - 2022-08-18 11:24:05 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:05 --> Input Class Initialized
INFO - 2022-08-18 11:24:05 --> Language Class Initialized
INFO - 2022-08-18 11:24:05 --> Loader Class Initialized
INFO - 2022-08-18 11:24:05 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:05 --> Controller Class Initialized
INFO - 2022-08-18 11:24:05 --> Config Class Initialized
INFO - 2022-08-18 11:24:05 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:05 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:05 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:05 --> URI Class Initialized
INFO - 2022-08-18 11:24:05 --> Router Class Initialized
INFO - 2022-08-18 11:24:05 --> Output Class Initialized
INFO - 2022-08-18 11:24:05 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:05 --> Input Class Initialized
INFO - 2022-08-18 11:24:05 --> Language Class Initialized
INFO - 2022-08-18 11:24:05 --> Loader Class Initialized
INFO - 2022-08-18 11:24:05 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:05 --> Controller Class Initialized
INFO - 2022-08-18 11:24:05 --> Config Class Initialized
INFO - 2022-08-18 11:24:05 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:05 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:05 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:05 --> URI Class Initialized
INFO - 2022-08-18 11:24:06 --> Router Class Initialized
INFO - 2022-08-18 11:24:06 --> Output Class Initialized
INFO - 2022-08-18 11:24:06 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:06 --> Input Class Initialized
INFO - 2022-08-18 11:24:06 --> Language Class Initialized
INFO - 2022-08-18 11:24:06 --> Loader Class Initialized
INFO - 2022-08-18 11:24:06 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:06 --> Controller Class Initialized
INFO - 2022-08-18 11:24:06 --> Config Class Initialized
INFO - 2022-08-18 11:24:06 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:06 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:06 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:06 --> URI Class Initialized
INFO - 2022-08-18 11:24:06 --> Router Class Initialized
INFO - 2022-08-18 11:24:06 --> Output Class Initialized
INFO - 2022-08-18 11:24:06 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:06 --> Input Class Initialized
INFO - 2022-08-18 11:24:06 --> Language Class Initialized
INFO - 2022-08-18 11:24:06 --> Loader Class Initialized
INFO - 2022-08-18 11:24:06 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:06 --> Controller Class Initialized
INFO - 2022-08-18 11:24:06 --> Config Class Initialized
INFO - 2022-08-18 11:24:06 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:06 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:06 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:06 --> URI Class Initialized
INFO - 2022-08-18 11:24:06 --> Router Class Initialized
INFO - 2022-08-18 11:24:06 --> Output Class Initialized
INFO - 2022-08-18 11:24:07 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:07 --> Input Class Initialized
INFO - 2022-08-18 11:24:07 --> Language Class Initialized
INFO - 2022-08-18 11:24:07 --> Loader Class Initialized
INFO - 2022-08-18 11:24:07 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:07 --> Controller Class Initialized
INFO - 2022-08-18 11:24:07 --> Config Class Initialized
INFO - 2022-08-18 11:24:07 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:07 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:07 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:07 --> URI Class Initialized
INFO - 2022-08-18 11:24:07 --> Router Class Initialized
INFO - 2022-08-18 11:24:07 --> Output Class Initialized
INFO - 2022-08-18 11:24:07 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:07 --> Input Class Initialized
INFO - 2022-08-18 11:24:07 --> Language Class Initialized
INFO - 2022-08-18 11:24:07 --> Loader Class Initialized
INFO - 2022-08-18 11:24:07 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:07 --> Controller Class Initialized
INFO - 2022-08-18 11:24:07 --> Config Class Initialized
INFO - 2022-08-18 11:24:07 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:07 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:07 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:07 --> URI Class Initialized
INFO - 2022-08-18 11:24:07 --> Router Class Initialized
INFO - 2022-08-18 11:24:08 --> Output Class Initialized
INFO - 2022-08-18 11:24:08 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:08 --> Input Class Initialized
INFO - 2022-08-18 11:24:08 --> Language Class Initialized
INFO - 2022-08-18 11:24:08 --> Loader Class Initialized
INFO - 2022-08-18 11:24:08 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:08 --> Controller Class Initialized
INFO - 2022-08-18 11:24:08 --> Config Class Initialized
INFO - 2022-08-18 11:24:08 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:08 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:08 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:08 --> URI Class Initialized
INFO - 2022-08-18 11:24:08 --> Router Class Initialized
INFO - 2022-08-18 11:24:08 --> Output Class Initialized
INFO - 2022-08-18 11:24:08 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:08 --> Input Class Initialized
INFO - 2022-08-18 11:24:08 --> Language Class Initialized
INFO - 2022-08-18 11:24:08 --> Loader Class Initialized
INFO - 2022-08-18 11:24:08 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:08 --> Controller Class Initialized
INFO - 2022-08-18 11:24:08 --> Config Class Initialized
INFO - 2022-08-18 11:24:08 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:08 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:08 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:08 --> URI Class Initialized
INFO - 2022-08-18 11:24:08 --> Router Class Initialized
INFO - 2022-08-18 11:24:08 --> Output Class Initialized
INFO - 2022-08-18 11:24:08 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:08 --> Input Class Initialized
INFO - 2022-08-18 11:24:08 --> Language Class Initialized
INFO - 2022-08-18 11:24:09 --> Loader Class Initialized
INFO - 2022-08-18 11:24:09 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:09 --> Controller Class Initialized
INFO - 2022-08-18 11:24:10 --> Config Class Initialized
INFO - 2022-08-18 11:24:10 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:10 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:10 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:10 --> URI Class Initialized
INFO - 2022-08-18 11:24:10 --> Router Class Initialized
INFO - 2022-08-18 11:24:10 --> Output Class Initialized
INFO - 2022-08-18 11:24:10 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:10 --> Input Class Initialized
INFO - 2022-08-18 11:24:10 --> Language Class Initialized
INFO - 2022-08-18 11:24:10 --> Loader Class Initialized
INFO - 2022-08-18 11:24:10 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:10 --> Controller Class Initialized
INFO - 2022-08-18 11:24:10 --> Config Class Initialized
INFO - 2022-08-18 11:24:10 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:10 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:10 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:10 --> URI Class Initialized
INFO - 2022-08-18 11:24:10 --> Router Class Initialized
INFO - 2022-08-18 11:24:10 --> Output Class Initialized
INFO - 2022-08-18 11:24:10 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:10 --> Input Class Initialized
INFO - 2022-08-18 11:24:10 --> Language Class Initialized
INFO - 2022-08-18 11:24:10 --> Loader Class Initialized
INFO - 2022-08-18 11:24:10 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:11 --> Controller Class Initialized
INFO - 2022-08-18 11:24:11 --> Config Class Initialized
INFO - 2022-08-18 11:24:11 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:11 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:11 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:11 --> URI Class Initialized
INFO - 2022-08-18 11:24:11 --> Router Class Initialized
INFO - 2022-08-18 11:24:11 --> Output Class Initialized
INFO - 2022-08-18 11:24:11 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:11 --> Input Class Initialized
INFO - 2022-08-18 11:24:11 --> Language Class Initialized
INFO - 2022-08-18 11:24:11 --> Loader Class Initialized
INFO - 2022-08-18 11:24:11 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:11 --> Controller Class Initialized
INFO - 2022-08-18 11:24:11 --> Config Class Initialized
INFO - 2022-08-18 11:24:11 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:11 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:11 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:11 --> URI Class Initialized
INFO - 2022-08-18 11:24:11 --> Router Class Initialized
INFO - 2022-08-18 11:24:11 --> Output Class Initialized
INFO - 2022-08-18 11:24:11 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:11 --> Input Class Initialized
INFO - 2022-08-18 11:24:11 --> Language Class Initialized
INFO - 2022-08-18 11:24:11 --> Loader Class Initialized
INFO - 2022-08-18 11:24:11 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:11 --> Controller Class Initialized
INFO - 2022-08-18 11:24:12 --> Config Class Initialized
INFO - 2022-08-18 11:24:12 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:12 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:12 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:12 --> URI Class Initialized
INFO - 2022-08-18 11:24:12 --> Router Class Initialized
INFO - 2022-08-18 11:24:12 --> Output Class Initialized
INFO - 2022-08-18 11:24:12 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:12 --> Input Class Initialized
INFO - 2022-08-18 11:24:12 --> Language Class Initialized
INFO - 2022-08-18 11:24:12 --> Loader Class Initialized
INFO - 2022-08-18 11:24:12 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:12 --> Controller Class Initialized
INFO - 2022-08-18 11:24:12 --> Config Class Initialized
INFO - 2022-08-18 11:24:12 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:12 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:12 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:12 --> URI Class Initialized
INFO - 2022-08-18 11:24:12 --> Router Class Initialized
INFO - 2022-08-18 11:24:12 --> Output Class Initialized
INFO - 2022-08-18 11:24:12 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:12 --> Input Class Initialized
INFO - 2022-08-18 11:24:12 --> Language Class Initialized
INFO - 2022-08-18 11:24:12 --> Loader Class Initialized
INFO - 2022-08-18 11:24:12 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:12 --> Controller Class Initialized
INFO - 2022-08-18 11:24:12 --> Config Class Initialized
INFO - 2022-08-18 11:24:12 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:12 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:12 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:12 --> URI Class Initialized
INFO - 2022-08-18 11:24:12 --> Router Class Initialized
INFO - 2022-08-18 11:24:13 --> Output Class Initialized
INFO - 2022-08-18 11:24:13 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:13 --> Input Class Initialized
INFO - 2022-08-18 11:24:13 --> Language Class Initialized
INFO - 2022-08-18 11:24:13 --> Loader Class Initialized
INFO - 2022-08-18 11:24:13 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:13 --> Controller Class Initialized
INFO - 2022-08-18 11:24:13 --> Config Class Initialized
INFO - 2022-08-18 11:24:13 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:13 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:13 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:13 --> URI Class Initialized
INFO - 2022-08-18 11:24:13 --> Router Class Initialized
INFO - 2022-08-18 11:24:13 --> Output Class Initialized
INFO - 2022-08-18 11:24:13 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:13 --> Input Class Initialized
INFO - 2022-08-18 11:24:13 --> Language Class Initialized
INFO - 2022-08-18 11:24:13 --> Loader Class Initialized
INFO - 2022-08-18 11:24:13 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:13 --> Controller Class Initialized
INFO - 2022-08-18 11:24:13 --> Config Class Initialized
INFO - 2022-08-18 11:24:13 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:13 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:13 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:13 --> URI Class Initialized
INFO - 2022-08-18 11:24:13 --> Router Class Initialized
INFO - 2022-08-18 11:24:13 --> Output Class Initialized
INFO - 2022-08-18 11:24:13 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:13 --> Input Class Initialized
INFO - 2022-08-18 11:24:13 --> Language Class Initialized
INFO - 2022-08-18 11:24:13 --> Loader Class Initialized
INFO - 2022-08-18 11:24:13 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:13 --> Controller Class Initialized
INFO - 2022-08-18 11:24:13 --> Config Class Initialized
INFO - 2022-08-18 11:24:13 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:13 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:13 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:13 --> URI Class Initialized
INFO - 2022-08-18 11:24:13 --> Router Class Initialized
INFO - 2022-08-18 11:24:13 --> Output Class Initialized
INFO - 2022-08-18 11:24:13 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:13 --> Input Class Initialized
INFO - 2022-08-18 11:24:13 --> Language Class Initialized
INFO - 2022-08-18 11:24:13 --> Loader Class Initialized
INFO - 2022-08-18 11:24:13 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:13 --> Controller Class Initialized
INFO - 2022-08-18 11:24:14 --> Config Class Initialized
INFO - 2022-08-18 11:24:14 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:14 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:14 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:14 --> URI Class Initialized
INFO - 2022-08-18 11:24:14 --> Router Class Initialized
INFO - 2022-08-18 11:24:14 --> Output Class Initialized
INFO - 2022-08-18 11:24:14 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:14 --> Input Class Initialized
INFO - 2022-08-18 11:24:14 --> Language Class Initialized
INFO - 2022-08-18 11:24:14 --> Loader Class Initialized
INFO - 2022-08-18 11:24:14 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:14 --> Controller Class Initialized
INFO - 2022-08-18 11:24:14 --> Config Class Initialized
INFO - 2022-08-18 11:24:14 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:14 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:14 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:14 --> URI Class Initialized
INFO - 2022-08-18 11:24:14 --> Router Class Initialized
INFO - 2022-08-18 11:24:14 --> Output Class Initialized
INFO - 2022-08-18 11:24:14 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:14 --> Input Class Initialized
INFO - 2022-08-18 11:24:14 --> Language Class Initialized
INFO - 2022-08-18 11:24:14 --> Loader Class Initialized
INFO - 2022-08-18 11:24:14 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:14 --> Controller Class Initialized
INFO - 2022-08-18 11:24:14 --> Config Class Initialized
INFO - 2022-08-18 11:24:14 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:14 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:14 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:15 --> URI Class Initialized
INFO - 2022-08-18 11:24:15 --> Router Class Initialized
INFO - 2022-08-18 11:24:15 --> Output Class Initialized
INFO - 2022-08-18 11:24:15 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:15 --> Input Class Initialized
INFO - 2022-08-18 11:24:15 --> Language Class Initialized
INFO - 2022-08-18 11:24:15 --> Loader Class Initialized
INFO - 2022-08-18 11:24:15 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:15 --> Controller Class Initialized
INFO - 2022-08-18 11:24:15 --> Config Class Initialized
INFO - 2022-08-18 11:24:15 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:15 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:15 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:15 --> URI Class Initialized
INFO - 2022-08-18 11:24:15 --> Router Class Initialized
INFO - 2022-08-18 11:24:15 --> Output Class Initialized
INFO - 2022-08-18 11:24:15 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:15 --> Input Class Initialized
INFO - 2022-08-18 11:24:15 --> Language Class Initialized
INFO - 2022-08-18 11:24:15 --> Loader Class Initialized
INFO - 2022-08-18 11:24:15 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:15 --> Controller Class Initialized
INFO - 2022-08-18 11:24:15 --> Config Class Initialized
INFO - 2022-08-18 11:24:15 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:15 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:15 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:15 --> URI Class Initialized
INFO - 2022-08-18 11:24:15 --> Router Class Initialized
INFO - 2022-08-18 11:24:15 --> Output Class Initialized
INFO - 2022-08-18 11:24:16 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:16 --> Input Class Initialized
INFO - 2022-08-18 11:24:16 --> Language Class Initialized
INFO - 2022-08-18 11:24:16 --> Loader Class Initialized
INFO - 2022-08-18 11:24:16 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:16 --> Controller Class Initialized
INFO - 2022-08-18 11:24:16 --> Config Class Initialized
INFO - 2022-08-18 11:24:16 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:16 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:16 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:16 --> URI Class Initialized
INFO - 2022-08-18 11:24:16 --> Router Class Initialized
INFO - 2022-08-18 11:24:16 --> Output Class Initialized
INFO - 2022-08-18 11:24:16 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:16 --> Input Class Initialized
INFO - 2022-08-18 11:24:16 --> Language Class Initialized
INFO - 2022-08-18 11:24:16 --> Loader Class Initialized
INFO - 2022-08-18 11:24:16 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:16 --> Controller Class Initialized
INFO - 2022-08-18 11:24:16 --> Config Class Initialized
INFO - 2022-08-18 11:24:16 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:16 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:16 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:17 --> URI Class Initialized
INFO - 2022-08-18 11:24:17 --> Router Class Initialized
INFO - 2022-08-18 11:24:17 --> Output Class Initialized
INFO - 2022-08-18 11:24:17 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:17 --> Input Class Initialized
INFO - 2022-08-18 11:24:17 --> Language Class Initialized
INFO - 2022-08-18 11:24:17 --> Loader Class Initialized
INFO - 2022-08-18 11:24:17 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:17 --> Controller Class Initialized
INFO - 2022-08-18 11:24:17 --> Config Class Initialized
INFO - 2022-08-18 11:24:17 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:17 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:17 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:17 --> URI Class Initialized
INFO - 2022-08-18 11:24:17 --> Router Class Initialized
INFO - 2022-08-18 11:24:17 --> Output Class Initialized
INFO - 2022-08-18 11:24:17 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:17 --> Input Class Initialized
INFO - 2022-08-18 11:24:17 --> Language Class Initialized
INFO - 2022-08-18 11:24:17 --> Loader Class Initialized
INFO - 2022-08-18 11:24:17 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:17 --> Controller Class Initialized
INFO - 2022-08-18 11:24:17 --> Config Class Initialized
INFO - 2022-08-18 11:24:17 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:17 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:17 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:17 --> URI Class Initialized
INFO - 2022-08-18 11:24:17 --> Router Class Initialized
INFO - 2022-08-18 11:24:17 --> Output Class Initialized
INFO - 2022-08-18 11:24:18 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:18 --> Input Class Initialized
INFO - 2022-08-18 11:24:18 --> Language Class Initialized
INFO - 2022-08-18 11:24:18 --> Loader Class Initialized
INFO - 2022-08-18 11:24:18 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:18 --> Controller Class Initialized
INFO - 2022-08-18 11:24:18 --> Config Class Initialized
INFO - 2022-08-18 11:24:18 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:18 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:18 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:18 --> URI Class Initialized
INFO - 2022-08-18 11:24:18 --> Router Class Initialized
INFO - 2022-08-18 11:24:18 --> Output Class Initialized
INFO - 2022-08-18 11:24:18 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:18 --> Input Class Initialized
INFO - 2022-08-18 11:24:18 --> Language Class Initialized
INFO - 2022-08-18 11:24:18 --> Loader Class Initialized
INFO - 2022-08-18 11:24:18 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:18 --> Controller Class Initialized
INFO - 2022-08-18 11:24:26 --> Config Class Initialized
INFO - 2022-08-18 11:24:26 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:26 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:26 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:26 --> URI Class Initialized
INFO - 2022-08-18 11:24:26 --> Router Class Initialized
INFO - 2022-08-18 11:24:26 --> Output Class Initialized
INFO - 2022-08-18 11:24:26 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:26 --> Input Class Initialized
INFO - 2022-08-18 11:24:26 --> Language Class Initialized
INFO - 2022-08-18 11:24:26 --> Loader Class Initialized
INFO - 2022-08-18 11:24:26 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:26 --> Controller Class Initialized
INFO - 2022-08-18 11:24:26 --> Config Class Initialized
INFO - 2022-08-18 11:24:26 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:26 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:26 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:26 --> URI Class Initialized
INFO - 2022-08-18 11:24:26 --> Router Class Initialized
INFO - 2022-08-18 11:24:26 --> Output Class Initialized
INFO - 2022-08-18 11:24:26 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:26 --> Input Class Initialized
INFO - 2022-08-18 11:24:26 --> Language Class Initialized
INFO - 2022-08-18 11:24:26 --> Loader Class Initialized
INFO - 2022-08-18 11:24:26 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:26 --> Controller Class Initialized
INFO - 2022-08-18 11:24:27 --> Config Class Initialized
INFO - 2022-08-18 11:24:27 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:27 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:27 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:27 --> URI Class Initialized
INFO - 2022-08-18 11:24:27 --> Router Class Initialized
INFO - 2022-08-18 11:24:27 --> Output Class Initialized
INFO - 2022-08-18 11:24:27 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:27 --> Input Class Initialized
INFO - 2022-08-18 11:24:27 --> Language Class Initialized
INFO - 2022-08-18 11:24:27 --> Loader Class Initialized
INFO - 2022-08-18 11:24:27 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:27 --> Controller Class Initialized
INFO - 2022-08-18 11:24:27 --> Config Class Initialized
INFO - 2022-08-18 11:24:27 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:27 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:27 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:27 --> URI Class Initialized
INFO - 2022-08-18 11:24:27 --> Router Class Initialized
INFO - 2022-08-18 11:24:27 --> Output Class Initialized
INFO - 2022-08-18 11:24:27 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:27 --> Input Class Initialized
INFO - 2022-08-18 11:24:27 --> Language Class Initialized
INFO - 2022-08-18 11:24:27 --> Loader Class Initialized
INFO - 2022-08-18 11:24:27 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:27 --> Controller Class Initialized
INFO - 2022-08-18 11:24:27 --> Config Class Initialized
INFO - 2022-08-18 11:24:27 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:27 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:27 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:27 --> URI Class Initialized
INFO - 2022-08-18 11:24:28 --> Router Class Initialized
INFO - 2022-08-18 11:24:28 --> Output Class Initialized
INFO - 2022-08-18 11:24:28 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:28 --> Input Class Initialized
INFO - 2022-08-18 11:24:28 --> Language Class Initialized
INFO - 2022-08-18 11:24:28 --> Loader Class Initialized
INFO - 2022-08-18 11:24:28 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:28 --> Controller Class Initialized
INFO - 2022-08-18 11:24:28 --> Config Class Initialized
INFO - 2022-08-18 11:24:28 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:28 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:28 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:28 --> URI Class Initialized
INFO - 2022-08-18 11:24:28 --> Router Class Initialized
INFO - 2022-08-18 11:24:28 --> Output Class Initialized
INFO - 2022-08-18 11:24:28 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:28 --> Input Class Initialized
INFO - 2022-08-18 11:24:28 --> Language Class Initialized
INFO - 2022-08-18 11:24:28 --> Loader Class Initialized
INFO - 2022-08-18 11:24:28 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:28 --> Controller Class Initialized
INFO - 2022-08-18 11:24:28 --> Config Class Initialized
INFO - 2022-08-18 11:24:28 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:28 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:28 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:28 --> URI Class Initialized
INFO - 2022-08-18 11:24:28 --> Router Class Initialized
INFO - 2022-08-18 11:24:28 --> Output Class Initialized
INFO - 2022-08-18 11:24:28 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:28 --> Input Class Initialized
INFO - 2022-08-18 11:24:28 --> Language Class Initialized
INFO - 2022-08-18 11:24:28 --> Loader Class Initialized
INFO - 2022-08-18 11:24:28 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:28 --> Controller Class Initialized
INFO - 2022-08-18 11:24:28 --> Config Class Initialized
INFO - 2022-08-18 11:24:28 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:28 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:29 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:29 --> URI Class Initialized
INFO - 2022-08-18 11:24:29 --> Router Class Initialized
INFO - 2022-08-18 11:24:29 --> Output Class Initialized
INFO - 2022-08-18 11:24:29 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:29 --> Input Class Initialized
INFO - 2022-08-18 11:24:29 --> Language Class Initialized
INFO - 2022-08-18 11:24:29 --> Loader Class Initialized
INFO - 2022-08-18 11:24:29 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:29 --> Controller Class Initialized
INFO - 2022-08-18 11:24:29 --> Config Class Initialized
INFO - 2022-08-18 11:24:29 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:29 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:29 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:29 --> URI Class Initialized
INFO - 2022-08-18 11:24:29 --> Router Class Initialized
INFO - 2022-08-18 11:24:29 --> Output Class Initialized
INFO - 2022-08-18 11:24:29 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:29 --> Input Class Initialized
INFO - 2022-08-18 11:24:29 --> Language Class Initialized
INFO - 2022-08-18 11:24:29 --> Loader Class Initialized
INFO - 2022-08-18 11:24:29 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:29 --> Controller Class Initialized
INFO - 2022-08-18 11:24:29 --> Config Class Initialized
INFO - 2022-08-18 11:24:29 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:29 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:29 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:29 --> URI Class Initialized
INFO - 2022-08-18 11:24:29 --> Router Class Initialized
INFO - 2022-08-18 11:24:29 --> Output Class Initialized
INFO - 2022-08-18 11:24:29 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:29 --> Input Class Initialized
INFO - 2022-08-18 11:24:29 --> Language Class Initialized
INFO - 2022-08-18 11:24:29 --> Loader Class Initialized
INFO - 2022-08-18 11:24:29 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:29 --> Controller Class Initialized
INFO - 2022-08-18 11:24:29 --> Config Class Initialized
INFO - 2022-08-18 11:24:29 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:29 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:29 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:29 --> URI Class Initialized
INFO - 2022-08-18 11:24:29 --> Router Class Initialized
INFO - 2022-08-18 11:24:29 --> Output Class Initialized
INFO - 2022-08-18 11:24:30 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:30 --> Input Class Initialized
INFO - 2022-08-18 11:24:30 --> Language Class Initialized
INFO - 2022-08-18 11:24:30 --> Loader Class Initialized
INFO - 2022-08-18 11:24:30 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:30 --> Controller Class Initialized
INFO - 2022-08-18 11:24:30 --> Config Class Initialized
INFO - 2022-08-18 11:24:30 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:30 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:30 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:30 --> URI Class Initialized
INFO - 2022-08-18 11:24:30 --> Router Class Initialized
INFO - 2022-08-18 11:24:30 --> Output Class Initialized
INFO - 2022-08-18 11:24:30 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:30 --> Input Class Initialized
INFO - 2022-08-18 11:24:30 --> Language Class Initialized
INFO - 2022-08-18 11:24:30 --> Loader Class Initialized
INFO - 2022-08-18 11:24:30 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:30 --> Controller Class Initialized
INFO - 2022-08-18 11:24:30 --> Config Class Initialized
INFO - 2022-08-18 11:24:30 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:30 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:30 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:30 --> URI Class Initialized
INFO - 2022-08-18 11:24:30 --> Router Class Initialized
INFO - 2022-08-18 11:24:30 --> Output Class Initialized
INFO - 2022-08-18 11:24:30 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:30 --> Input Class Initialized
INFO - 2022-08-18 11:24:30 --> Language Class Initialized
INFO - 2022-08-18 11:24:30 --> Loader Class Initialized
INFO - 2022-08-18 11:24:30 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:30 --> Controller Class Initialized
INFO - 2022-08-18 11:24:30 --> Config Class Initialized
INFO - 2022-08-18 11:24:30 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:30 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:30 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:30 --> URI Class Initialized
INFO - 2022-08-18 11:24:30 --> Router Class Initialized
INFO - 2022-08-18 11:24:31 --> Output Class Initialized
INFO - 2022-08-18 11:24:31 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:31 --> Input Class Initialized
INFO - 2022-08-18 11:24:31 --> Language Class Initialized
INFO - 2022-08-18 11:24:31 --> Loader Class Initialized
INFO - 2022-08-18 11:24:31 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:31 --> Controller Class Initialized
INFO - 2022-08-18 11:24:31 --> Config Class Initialized
INFO - 2022-08-18 11:24:31 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:31 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:31 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:31 --> URI Class Initialized
INFO - 2022-08-18 11:24:31 --> Router Class Initialized
INFO - 2022-08-18 11:24:31 --> Output Class Initialized
INFO - 2022-08-18 11:24:31 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:31 --> Input Class Initialized
INFO - 2022-08-18 11:24:31 --> Language Class Initialized
INFO - 2022-08-18 11:24:31 --> Loader Class Initialized
INFO - 2022-08-18 11:24:31 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:31 --> Controller Class Initialized
INFO - 2022-08-18 11:24:31 --> Config Class Initialized
INFO - 2022-08-18 11:24:31 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:31 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:31 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:31 --> URI Class Initialized
INFO - 2022-08-18 11:24:31 --> Router Class Initialized
INFO - 2022-08-18 11:24:31 --> Output Class Initialized
INFO - 2022-08-18 11:24:31 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:31 --> Input Class Initialized
INFO - 2022-08-18 11:24:31 --> Language Class Initialized
INFO - 2022-08-18 11:24:31 --> Loader Class Initialized
INFO - 2022-08-18 11:24:31 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:31 --> Controller Class Initialized
INFO - 2022-08-18 11:24:32 --> Config Class Initialized
INFO - 2022-08-18 11:24:32 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:32 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:32 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:32 --> URI Class Initialized
INFO - 2022-08-18 11:24:32 --> Router Class Initialized
INFO - 2022-08-18 11:24:32 --> Output Class Initialized
INFO - 2022-08-18 11:24:32 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:32 --> Input Class Initialized
INFO - 2022-08-18 11:24:32 --> Language Class Initialized
INFO - 2022-08-18 11:24:32 --> Loader Class Initialized
INFO - 2022-08-18 11:24:32 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:32 --> Controller Class Initialized
INFO - 2022-08-18 11:24:32 --> Config Class Initialized
INFO - 2022-08-18 11:24:32 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:32 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:32 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:32 --> URI Class Initialized
INFO - 2022-08-18 11:24:32 --> Router Class Initialized
INFO - 2022-08-18 11:24:32 --> Output Class Initialized
INFO - 2022-08-18 11:24:32 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:32 --> Input Class Initialized
INFO - 2022-08-18 11:24:32 --> Language Class Initialized
INFO - 2022-08-18 11:24:32 --> Loader Class Initialized
INFO - 2022-08-18 11:24:32 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:32 --> Controller Class Initialized
INFO - 2022-08-18 11:24:32 --> Config Class Initialized
INFO - 2022-08-18 11:24:32 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:32 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:33 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:33 --> URI Class Initialized
INFO - 2022-08-18 11:24:33 --> Router Class Initialized
INFO - 2022-08-18 11:24:33 --> Output Class Initialized
INFO - 2022-08-18 11:24:33 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:33 --> Input Class Initialized
INFO - 2022-08-18 11:24:33 --> Language Class Initialized
INFO - 2022-08-18 11:24:33 --> Loader Class Initialized
INFO - 2022-08-18 11:24:33 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:33 --> Controller Class Initialized
INFO - 2022-08-18 11:24:33 --> Config Class Initialized
INFO - 2022-08-18 11:24:33 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:33 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:33 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:33 --> URI Class Initialized
INFO - 2022-08-18 11:24:33 --> Router Class Initialized
INFO - 2022-08-18 11:24:33 --> Output Class Initialized
INFO - 2022-08-18 11:24:33 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:33 --> Input Class Initialized
INFO - 2022-08-18 11:24:33 --> Language Class Initialized
INFO - 2022-08-18 11:24:33 --> Loader Class Initialized
INFO - 2022-08-18 11:24:33 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:33 --> Controller Class Initialized
INFO - 2022-08-18 11:24:44 --> Config Class Initialized
INFO - 2022-08-18 11:24:44 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:44 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:44 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:44 --> URI Class Initialized
INFO - 2022-08-18 11:24:44 --> Router Class Initialized
INFO - 2022-08-18 11:24:44 --> Output Class Initialized
INFO - 2022-08-18 11:24:44 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:44 --> Input Class Initialized
INFO - 2022-08-18 11:24:45 --> Language Class Initialized
INFO - 2022-08-18 11:24:45 --> Loader Class Initialized
INFO - 2022-08-18 11:24:45 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:45 --> Controller Class Initialized
INFO - 2022-08-18 11:24:45 --> Config Class Initialized
INFO - 2022-08-18 11:24:45 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:45 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:45 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:45 --> URI Class Initialized
INFO - 2022-08-18 11:24:45 --> Router Class Initialized
INFO - 2022-08-18 11:24:45 --> Output Class Initialized
INFO - 2022-08-18 11:24:45 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:45 --> Input Class Initialized
INFO - 2022-08-18 11:24:45 --> Language Class Initialized
INFO - 2022-08-18 11:24:45 --> Loader Class Initialized
INFO - 2022-08-18 11:24:45 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:45 --> Controller Class Initialized
INFO - 2022-08-18 11:24:45 --> Config Class Initialized
INFO - 2022-08-18 11:24:45 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:45 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:45 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:45 --> URI Class Initialized
INFO - 2022-08-18 11:24:45 --> Router Class Initialized
INFO - 2022-08-18 11:24:45 --> Output Class Initialized
INFO - 2022-08-18 11:24:45 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:45 --> Input Class Initialized
INFO - 2022-08-18 11:24:45 --> Language Class Initialized
INFO - 2022-08-18 11:24:45 --> Loader Class Initialized
INFO - 2022-08-18 11:24:45 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:46 --> Controller Class Initialized
INFO - 2022-08-18 11:24:46 --> Config Class Initialized
INFO - 2022-08-18 11:24:46 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:46 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:46 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:46 --> URI Class Initialized
INFO - 2022-08-18 11:24:46 --> Router Class Initialized
INFO - 2022-08-18 11:24:46 --> Output Class Initialized
INFO - 2022-08-18 11:24:46 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:46 --> Input Class Initialized
INFO - 2022-08-18 11:24:46 --> Language Class Initialized
INFO - 2022-08-18 11:24:46 --> Loader Class Initialized
INFO - 2022-08-18 11:24:46 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:46 --> Controller Class Initialized
INFO - 2022-08-18 11:24:46 --> Config Class Initialized
INFO - 2022-08-18 11:24:46 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:46 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:46 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:46 --> URI Class Initialized
INFO - 2022-08-18 11:24:46 --> Router Class Initialized
INFO - 2022-08-18 11:24:46 --> Output Class Initialized
INFO - 2022-08-18 11:24:46 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:46 --> Input Class Initialized
INFO - 2022-08-18 11:24:46 --> Language Class Initialized
INFO - 2022-08-18 11:24:46 --> Loader Class Initialized
INFO - 2022-08-18 11:24:46 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:46 --> Controller Class Initialized
INFO - 2022-08-18 11:24:46 --> Config Class Initialized
INFO - 2022-08-18 11:24:46 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:47 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:47 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:47 --> URI Class Initialized
INFO - 2022-08-18 11:24:47 --> Router Class Initialized
INFO - 2022-08-18 11:24:47 --> Output Class Initialized
INFO - 2022-08-18 11:24:47 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:47 --> Input Class Initialized
INFO - 2022-08-18 11:24:47 --> Language Class Initialized
INFO - 2022-08-18 11:24:47 --> Loader Class Initialized
INFO - 2022-08-18 11:24:47 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:47 --> Controller Class Initialized
INFO - 2022-08-18 11:24:47 --> Config Class Initialized
INFO - 2022-08-18 11:24:47 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:47 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:47 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:47 --> URI Class Initialized
INFO - 2022-08-18 11:24:47 --> Router Class Initialized
INFO - 2022-08-18 11:24:47 --> Output Class Initialized
INFO - 2022-08-18 11:24:47 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:47 --> Input Class Initialized
INFO - 2022-08-18 11:24:47 --> Language Class Initialized
INFO - 2022-08-18 11:24:47 --> Loader Class Initialized
INFO - 2022-08-18 11:24:47 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:47 --> Controller Class Initialized
INFO - 2022-08-18 11:24:47 --> Config Class Initialized
INFO - 2022-08-18 11:24:47 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:47 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:47 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:47 --> URI Class Initialized
INFO - 2022-08-18 11:24:47 --> Router Class Initialized
INFO - 2022-08-18 11:24:47 --> Output Class Initialized
INFO - 2022-08-18 11:24:47 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:47 --> Input Class Initialized
INFO - 2022-08-18 11:24:47 --> Language Class Initialized
INFO - 2022-08-18 11:24:47 --> Loader Class Initialized
INFO - 2022-08-18 11:24:47 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:47 --> Controller Class Initialized
INFO - 2022-08-18 11:24:48 --> Config Class Initialized
INFO - 2022-08-18 11:24:48 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:48 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:48 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:48 --> URI Class Initialized
INFO - 2022-08-18 11:24:48 --> Router Class Initialized
INFO - 2022-08-18 11:24:48 --> Output Class Initialized
INFO - 2022-08-18 11:24:48 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:48 --> Input Class Initialized
INFO - 2022-08-18 11:24:48 --> Language Class Initialized
INFO - 2022-08-18 11:24:48 --> Loader Class Initialized
INFO - 2022-08-18 11:24:48 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:48 --> Controller Class Initialized
INFO - 2022-08-18 11:24:48 --> Config Class Initialized
INFO - 2022-08-18 11:24:48 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:48 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:48 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:48 --> URI Class Initialized
INFO - 2022-08-18 11:24:48 --> Router Class Initialized
INFO - 2022-08-18 11:24:48 --> Output Class Initialized
INFO - 2022-08-18 11:24:48 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:48 --> Input Class Initialized
INFO - 2022-08-18 11:24:48 --> Language Class Initialized
INFO - 2022-08-18 11:24:48 --> Loader Class Initialized
INFO - 2022-08-18 11:24:48 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:48 --> Controller Class Initialized
INFO - 2022-08-18 11:24:48 --> Config Class Initialized
INFO - 2022-08-18 11:24:48 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:48 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:48 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:48 --> URI Class Initialized
INFO - 2022-08-18 11:24:48 --> Router Class Initialized
INFO - 2022-08-18 11:24:48 --> Output Class Initialized
INFO - 2022-08-18 11:24:48 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:48 --> Input Class Initialized
INFO - 2022-08-18 11:24:48 --> Language Class Initialized
INFO - 2022-08-18 11:24:48 --> Loader Class Initialized
INFO - 2022-08-18 11:24:48 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:48 --> Controller Class Initialized
INFO - 2022-08-18 11:24:49 --> Config Class Initialized
INFO - 2022-08-18 11:24:49 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:49 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:49 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:49 --> URI Class Initialized
INFO - 2022-08-18 11:24:49 --> Router Class Initialized
INFO - 2022-08-18 11:24:49 --> Output Class Initialized
INFO - 2022-08-18 11:24:49 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:49 --> Input Class Initialized
INFO - 2022-08-18 11:24:49 --> Language Class Initialized
INFO - 2022-08-18 11:24:49 --> Loader Class Initialized
INFO - 2022-08-18 11:24:49 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:49 --> Controller Class Initialized
INFO - 2022-08-18 11:24:49 --> Config Class Initialized
INFO - 2022-08-18 11:24:49 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:49 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:49 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:49 --> URI Class Initialized
INFO - 2022-08-18 11:24:49 --> Router Class Initialized
INFO - 2022-08-18 11:24:49 --> Output Class Initialized
INFO - 2022-08-18 11:24:49 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:49 --> Input Class Initialized
INFO - 2022-08-18 11:24:49 --> Language Class Initialized
INFO - 2022-08-18 11:24:49 --> Loader Class Initialized
INFO - 2022-08-18 11:24:49 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:49 --> Controller Class Initialized
INFO - 2022-08-18 11:24:49 --> Config Class Initialized
INFO - 2022-08-18 11:24:49 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:49 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:49 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:49 --> URI Class Initialized
INFO - 2022-08-18 11:24:49 --> Router Class Initialized
INFO - 2022-08-18 11:24:49 --> Output Class Initialized
INFO - 2022-08-18 11:24:49 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:49 --> Input Class Initialized
INFO - 2022-08-18 11:24:49 --> Language Class Initialized
INFO - 2022-08-18 11:24:49 --> Loader Class Initialized
INFO - 2022-08-18 11:24:50 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:50 --> Controller Class Initialized
INFO - 2022-08-18 11:24:50 --> Config Class Initialized
INFO - 2022-08-18 11:24:50 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:50 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:50 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:50 --> URI Class Initialized
INFO - 2022-08-18 11:24:50 --> Router Class Initialized
INFO - 2022-08-18 11:24:50 --> Output Class Initialized
INFO - 2022-08-18 11:24:50 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:50 --> Input Class Initialized
INFO - 2022-08-18 11:24:50 --> Language Class Initialized
INFO - 2022-08-18 11:24:50 --> Loader Class Initialized
INFO - 2022-08-18 11:24:50 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:50 --> Controller Class Initialized
INFO - 2022-08-18 11:24:50 --> Config Class Initialized
INFO - 2022-08-18 11:24:50 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:50 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:50 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:50 --> URI Class Initialized
INFO - 2022-08-18 11:24:50 --> Router Class Initialized
INFO - 2022-08-18 11:24:50 --> Output Class Initialized
INFO - 2022-08-18 11:24:50 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:50 --> Input Class Initialized
INFO - 2022-08-18 11:24:50 --> Language Class Initialized
INFO - 2022-08-18 11:24:50 --> Loader Class Initialized
INFO - 2022-08-18 11:24:50 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:50 --> Controller Class Initialized
INFO - 2022-08-18 11:24:50 --> Config Class Initialized
INFO - 2022-08-18 11:24:50 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:50 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:50 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:50 --> URI Class Initialized
INFO - 2022-08-18 11:24:50 --> Router Class Initialized
INFO - 2022-08-18 11:24:50 --> Output Class Initialized
INFO - 2022-08-18 11:24:50 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:50 --> Input Class Initialized
INFO - 2022-08-18 11:24:50 --> Language Class Initialized
INFO - 2022-08-18 11:24:50 --> Loader Class Initialized
INFO - 2022-08-18 11:24:50 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:50 --> Controller Class Initialized
INFO - 2022-08-18 11:24:51 --> Config Class Initialized
INFO - 2022-08-18 11:24:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:51 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:51 --> URI Class Initialized
INFO - 2022-08-18 11:24:51 --> Router Class Initialized
INFO - 2022-08-18 11:24:51 --> Output Class Initialized
INFO - 2022-08-18 11:24:51 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:51 --> Input Class Initialized
INFO - 2022-08-18 11:24:51 --> Language Class Initialized
INFO - 2022-08-18 11:24:51 --> Loader Class Initialized
INFO - 2022-08-18 11:24:51 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:51 --> Controller Class Initialized
INFO - 2022-08-18 11:24:51 --> Config Class Initialized
INFO - 2022-08-18 11:24:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:51 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:51 --> URI Class Initialized
INFO - 2022-08-18 11:24:51 --> Router Class Initialized
INFO - 2022-08-18 11:24:51 --> Output Class Initialized
INFO - 2022-08-18 11:24:51 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:51 --> Input Class Initialized
INFO - 2022-08-18 11:24:51 --> Language Class Initialized
INFO - 2022-08-18 11:24:51 --> Loader Class Initialized
INFO - 2022-08-18 11:24:51 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:51 --> Controller Class Initialized
INFO - 2022-08-18 11:24:51 --> Config Class Initialized
INFO - 2022-08-18 11:24:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 11:24:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 11:24:51 --> Utf8 Class Initialized
INFO - 2022-08-18 11:24:51 --> URI Class Initialized
INFO - 2022-08-18 11:24:51 --> Router Class Initialized
INFO - 2022-08-18 11:24:51 --> Output Class Initialized
INFO - 2022-08-18 11:24:51 --> Security Class Initialized
DEBUG - 2022-08-18 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 11:24:51 --> Input Class Initialized
INFO - 2022-08-18 11:24:51 --> Language Class Initialized
INFO - 2022-08-18 11:24:51 --> Loader Class Initialized
INFO - 2022-08-18 11:24:52 --> Helper loaded: url_helper
INFO - 2022-08-18 11:24:52 --> Controller Class Initialized
INFO - 2022-08-18 13:03:20 --> Config Class Initialized
INFO - 2022-08-18 13:03:20 --> Hooks Class Initialized
DEBUG - 2022-08-18 13:03:20 --> UTF-8 Support Enabled
INFO - 2022-08-18 13:03:20 --> Utf8 Class Initialized
INFO - 2022-08-18 13:03:20 --> URI Class Initialized
INFO - 2022-08-18 13:03:20 --> Router Class Initialized
INFO - 2022-08-18 13:03:20 --> Output Class Initialized
INFO - 2022-08-18 13:03:20 --> Security Class Initialized
DEBUG - 2022-08-18 13:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 13:03:20 --> Input Class Initialized
INFO - 2022-08-18 13:03:20 --> Language Class Initialized
INFO - 2022-08-18 13:03:20 --> Loader Class Initialized
INFO - 2022-08-18 13:03:20 --> Helper loaded: url_helper
INFO - 2022-08-18 13:03:20 --> Controller Class Initialized
DEBUG - 2022-08-18 13:03:20 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 13:03:20 --> Helper loaded: inflector_helper
INFO - 2022-08-18 13:03:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 13:03:20 --> Final output sent to browser
DEBUG - 2022-08-18 13:03:21 --> Total execution time: 0.6647
INFO - 2022-08-18 13:36:54 --> Config Class Initialized
INFO - 2022-08-18 13:36:54 --> Hooks Class Initialized
DEBUG - 2022-08-18 13:36:54 --> UTF-8 Support Enabled
INFO - 2022-08-18 13:36:54 --> Utf8 Class Initialized
INFO - 2022-08-18 13:36:54 --> URI Class Initialized
DEBUG - 2022-08-18 13:36:54 --> No URI present. Default controller set.
INFO - 2022-08-18 13:36:54 --> Router Class Initialized
INFO - 2022-08-18 13:36:54 --> Output Class Initialized
INFO - 2022-08-18 13:36:54 --> Security Class Initialized
DEBUG - 2022-08-18 13:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 13:36:55 --> Input Class Initialized
INFO - 2022-08-18 13:36:55 --> Language Class Initialized
INFO - 2022-08-18 13:36:55 --> Loader Class Initialized
INFO - 2022-08-18 13:36:55 --> Helper loaded: url_helper
INFO - 2022-08-18 13:36:55 --> Controller Class Initialized
INFO - 2022-08-18 13:36:55 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 13:36:55 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 13:36:55 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 13:36:55 --> Final output sent to browser
DEBUG - 2022-08-18 13:36:55 --> Total execution time: 0.6650
INFO - 2022-08-18 13:42:51 --> Config Class Initialized
INFO - 2022-08-18 13:42:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 13:42:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 13:42:51 --> Utf8 Class Initialized
INFO - 2022-08-18 13:42:51 --> URI Class Initialized
DEBUG - 2022-08-18 13:42:51 --> No URI present. Default controller set.
INFO - 2022-08-18 13:42:51 --> Router Class Initialized
INFO - 2022-08-18 13:42:51 --> Output Class Initialized
INFO - 2022-08-18 13:42:51 --> Security Class Initialized
DEBUG - 2022-08-18 13:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 13:42:51 --> Input Class Initialized
INFO - 2022-08-18 13:42:51 --> Language Class Initialized
INFO - 2022-08-18 13:42:51 --> Loader Class Initialized
INFO - 2022-08-18 13:42:51 --> Helper loaded: url_helper
INFO - 2022-08-18 13:42:51 --> Controller Class Initialized
INFO - 2022-08-18 13:42:52 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-18 13:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-18 13:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-18 13:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 99
ERROR - 2022-08-18 13:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 115
ERROR - 2022-08-18 13:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 131
INFO - 2022-08-18 13:42:52 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 13:42:52 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 13:42:52 --> Final output sent to browser
DEBUG - 2022-08-18 13:42:52 --> Total execution time: 0.2673
INFO - 2022-08-18 15:00:13 --> Config Class Initialized
INFO - 2022-08-18 15:00:13 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:00:13 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:00:13 --> Utf8 Class Initialized
INFO - 2022-08-18 15:00:14 --> URI Class Initialized
DEBUG - 2022-08-18 15:00:14 --> No URI present. Default controller set.
INFO - 2022-08-18 15:00:14 --> Router Class Initialized
INFO - 2022-08-18 15:00:14 --> Output Class Initialized
INFO - 2022-08-18 15:00:14 --> Security Class Initialized
DEBUG - 2022-08-18 15:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:00:14 --> Input Class Initialized
INFO - 2022-08-18 15:00:14 --> Language Class Initialized
INFO - 2022-08-18 15:00:14 --> Loader Class Initialized
INFO - 2022-08-18 15:00:14 --> Helper loaded: url_helper
INFO - 2022-08-18 15:00:14 --> Controller Class Initialized
INFO - 2022-08-18 15:00:14 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 15:00:14 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 15:00:14 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 15:00:14 --> Final output sent to browser
DEBUG - 2022-08-18 15:00:14 --> Total execution time: 0.2458
INFO - 2022-08-18 15:00:28 --> Config Class Initialized
INFO - 2022-08-18 15:00:28 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:00:28 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:00:28 --> Utf8 Class Initialized
INFO - 2022-08-18 15:00:28 --> URI Class Initialized
INFO - 2022-08-18 15:00:28 --> Router Class Initialized
INFO - 2022-08-18 15:00:28 --> Output Class Initialized
INFO - 2022-08-18 15:00:28 --> Security Class Initialized
DEBUG - 2022-08-18 15:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:00:28 --> Input Class Initialized
INFO - 2022-08-18 15:00:28 --> Language Class Initialized
INFO - 2022-08-18 15:00:28 --> Loader Class Initialized
INFO - 2022-08-18 15:00:28 --> Helper loaded: url_helper
INFO - 2022-08-18 15:00:28 --> Controller Class Initialized
DEBUG - 2022-08-18 15:00:28 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:00:28 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:00:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:00:28 --> Final output sent to browser
DEBUG - 2022-08-18 15:00:28 --> Total execution time: 0.2231
INFO - 2022-08-18 15:00:29 --> Config Class Initialized
INFO - 2022-08-18 15:00:29 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:00:29 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:00:29 --> Utf8 Class Initialized
INFO - 2022-08-18 15:00:29 --> URI Class Initialized
INFO - 2022-08-18 15:00:29 --> Router Class Initialized
INFO - 2022-08-18 15:00:29 --> Output Class Initialized
INFO - 2022-08-18 15:00:29 --> Security Class Initialized
DEBUG - 2022-08-18 15:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:00:29 --> Input Class Initialized
INFO - 2022-08-18 15:00:29 --> Language Class Initialized
ERROR - 2022-08-18 15:00:29 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-18 15:03:36 --> Config Class Initialized
INFO - 2022-08-18 15:03:36 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:03:36 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:03:36 --> Utf8 Class Initialized
INFO - 2022-08-18 15:03:36 --> URI Class Initialized
INFO - 2022-08-18 15:03:36 --> Router Class Initialized
INFO - 2022-08-18 15:03:36 --> Output Class Initialized
INFO - 2022-08-18 15:03:36 --> Security Class Initialized
DEBUG - 2022-08-18 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:03:36 --> Input Class Initialized
INFO - 2022-08-18 15:03:36 --> Language Class Initialized
INFO - 2022-08-18 15:03:36 --> Loader Class Initialized
INFO - 2022-08-18 15:03:36 --> Helper loaded: url_helper
INFO - 2022-08-18 15:03:36 --> Controller Class Initialized
DEBUG - 2022-08-18 15:03:36 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:03:36 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:03:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:03:36 --> Final output sent to browser
DEBUG - 2022-08-18 15:03:36 --> Total execution time: 0.2474
INFO - 2022-08-18 15:03:41 --> Config Class Initialized
INFO - 2022-08-18 15:03:41 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:03:41 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:03:41 --> Utf8 Class Initialized
INFO - 2022-08-18 15:03:41 --> URI Class Initialized
INFO - 2022-08-18 15:03:41 --> Router Class Initialized
INFO - 2022-08-18 15:03:41 --> Output Class Initialized
INFO - 2022-08-18 15:03:41 --> Security Class Initialized
DEBUG - 2022-08-18 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:03:41 --> Input Class Initialized
INFO - 2022-08-18 15:03:41 --> Language Class Initialized
INFO - 2022-08-18 15:03:41 --> Loader Class Initialized
INFO - 2022-08-18 15:03:41 --> Helper loaded: url_helper
INFO - 2022-08-18 15:03:41 --> Controller Class Initialized
DEBUG - 2022-08-18 15:03:41 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:03:41 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:03:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:03:41 --> Final output sent to browser
DEBUG - 2022-08-18 15:03:41 --> Total execution time: 0.2062
INFO - 2022-08-18 15:03:46 --> Config Class Initialized
INFO - 2022-08-18 15:03:46 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:03:46 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:03:46 --> Utf8 Class Initialized
INFO - 2022-08-18 15:03:46 --> URI Class Initialized
INFO - 2022-08-18 15:03:46 --> Router Class Initialized
INFO - 2022-08-18 15:03:46 --> Output Class Initialized
INFO - 2022-08-18 15:03:46 --> Security Class Initialized
DEBUG - 2022-08-18 15:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:03:46 --> Input Class Initialized
INFO - 2022-08-18 15:03:46 --> Language Class Initialized
INFO - 2022-08-18 15:03:46 --> Loader Class Initialized
INFO - 2022-08-18 15:03:46 --> Helper loaded: url_helper
INFO - 2022-08-18 15:03:46 --> Controller Class Initialized
DEBUG - 2022-08-18 15:03:46 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:03:46 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:03:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:03:46 --> Final output sent to browser
DEBUG - 2022-08-18 15:03:46 --> Total execution time: 0.1822
INFO - 2022-08-18 15:05:27 --> Config Class Initialized
INFO - 2022-08-18 15:05:27 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:05:27 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:05:27 --> Utf8 Class Initialized
INFO - 2022-08-18 15:05:27 --> URI Class Initialized
INFO - 2022-08-18 15:05:27 --> Router Class Initialized
INFO - 2022-08-18 15:05:27 --> Output Class Initialized
INFO - 2022-08-18 15:05:27 --> Security Class Initialized
DEBUG - 2022-08-18 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:05:27 --> Input Class Initialized
INFO - 2022-08-18 15:05:27 --> Language Class Initialized
INFO - 2022-08-18 15:05:27 --> Loader Class Initialized
INFO - 2022-08-18 15:05:27 --> Helper loaded: url_helper
INFO - 2022-08-18 15:05:27 --> Controller Class Initialized
DEBUG - 2022-08-18 15:05:27 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:05:27 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:05:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:05:27 --> Final output sent to browser
DEBUG - 2022-08-18 15:05:27 --> Total execution time: 0.2001
INFO - 2022-08-18 15:08:11 --> Config Class Initialized
INFO - 2022-08-18 15:08:11 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:08:11 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:08:11 --> Utf8 Class Initialized
INFO - 2022-08-18 15:08:11 --> URI Class Initialized
INFO - 2022-08-18 15:08:11 --> Router Class Initialized
INFO - 2022-08-18 15:08:11 --> Output Class Initialized
INFO - 2022-08-18 15:08:11 --> Security Class Initialized
DEBUG - 2022-08-18 15:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:08:11 --> Input Class Initialized
INFO - 2022-08-18 15:08:11 --> Language Class Initialized
INFO - 2022-08-18 15:08:11 --> Loader Class Initialized
INFO - 2022-08-18 15:08:11 --> Helper loaded: url_helper
INFO - 2022-08-18 15:08:11 --> Controller Class Initialized
DEBUG - 2022-08-18 15:08:11 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:08:11 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:08:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:08:11 --> Final output sent to browser
DEBUG - 2022-08-18 15:08:11 --> Total execution time: 0.2512
INFO - 2022-08-18 15:08:16 --> Config Class Initialized
INFO - 2022-08-18 15:08:16 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:08:16 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:08:16 --> Utf8 Class Initialized
INFO - 2022-08-18 15:08:16 --> URI Class Initialized
INFO - 2022-08-18 15:08:16 --> Router Class Initialized
INFO - 2022-08-18 15:08:16 --> Output Class Initialized
INFO - 2022-08-18 15:08:16 --> Security Class Initialized
DEBUG - 2022-08-18 15:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:08:16 --> Input Class Initialized
INFO - 2022-08-18 15:08:16 --> Language Class Initialized
INFO - 2022-08-18 15:08:16 --> Loader Class Initialized
INFO - 2022-08-18 15:08:16 --> Helper loaded: url_helper
INFO - 2022-08-18 15:08:16 --> Controller Class Initialized
DEBUG - 2022-08-18 15:08:16 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:08:16 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:08:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:08:16 --> Final output sent to browser
DEBUG - 2022-08-18 15:08:16 --> Total execution time: 0.2767
INFO - 2022-08-18 15:08:28 --> Config Class Initialized
INFO - 2022-08-18 15:08:28 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:08:28 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:08:28 --> Utf8 Class Initialized
INFO - 2022-08-18 15:08:28 --> URI Class Initialized
DEBUG - 2022-08-18 15:08:28 --> No URI present. Default controller set.
INFO - 2022-08-18 15:08:28 --> Router Class Initialized
INFO - 2022-08-18 15:08:28 --> Output Class Initialized
INFO - 2022-08-18 15:08:29 --> Security Class Initialized
DEBUG - 2022-08-18 15:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:08:29 --> Input Class Initialized
INFO - 2022-08-18 15:08:29 --> Language Class Initialized
INFO - 2022-08-18 15:08:29 --> Loader Class Initialized
INFO - 2022-08-18 15:08:29 --> Helper loaded: url_helper
INFO - 2022-08-18 15:08:29 --> Controller Class Initialized
INFO - 2022-08-18 15:08:29 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 15:08:29 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 15:08:29 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 15:08:29 --> Final output sent to browser
DEBUG - 2022-08-18 15:08:29 --> Total execution time: 0.2572
INFO - 2022-08-18 15:09:30 --> Config Class Initialized
INFO - 2022-08-18 15:09:30 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:09:30 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:09:30 --> Utf8 Class Initialized
INFO - 2022-08-18 15:09:30 --> URI Class Initialized
DEBUG - 2022-08-18 15:09:30 --> No URI present. Default controller set.
INFO - 2022-08-18 15:09:30 --> Router Class Initialized
INFO - 2022-08-18 15:09:30 --> Output Class Initialized
INFO - 2022-08-18 15:09:30 --> Security Class Initialized
DEBUG - 2022-08-18 15:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:09:30 --> Input Class Initialized
INFO - 2022-08-18 15:09:30 --> Language Class Initialized
INFO - 2022-08-18 15:09:30 --> Loader Class Initialized
INFO - 2022-08-18 15:09:30 --> Helper loaded: url_helper
INFO - 2022-08-18 15:09:30 --> Controller Class Initialized
INFO - 2022-08-18 15:09:30 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 15:09:30 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 15:09:30 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 15:09:30 --> Final output sent to browser
DEBUG - 2022-08-18 15:09:30 --> Total execution time: 0.2332
INFO - 2022-08-18 15:09:34 --> Config Class Initialized
INFO - 2022-08-18 15:09:34 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:09:34 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:09:34 --> Utf8 Class Initialized
INFO - 2022-08-18 15:09:34 --> URI Class Initialized
INFO - 2022-08-18 15:09:34 --> Router Class Initialized
INFO - 2022-08-18 15:09:34 --> Output Class Initialized
INFO - 2022-08-18 15:09:34 --> Security Class Initialized
DEBUG - 2022-08-18 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:09:34 --> Input Class Initialized
INFO - 2022-08-18 15:09:34 --> Language Class Initialized
INFO - 2022-08-18 15:09:34 --> Loader Class Initialized
INFO - 2022-08-18 15:09:34 --> Helper loaded: url_helper
INFO - 2022-08-18 15:09:34 --> Controller Class Initialized
DEBUG - 2022-08-18 15:09:34 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:09:34 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:09:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:09:34 --> Final output sent to browser
DEBUG - 2022-08-18 15:09:34 --> Total execution time: 0.2213
INFO - 2022-08-18 15:09:38 --> Config Class Initialized
INFO - 2022-08-18 15:09:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 15:09:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 15:09:38 --> Utf8 Class Initialized
INFO - 2022-08-18 15:09:38 --> URI Class Initialized
INFO - 2022-08-18 15:09:38 --> Router Class Initialized
INFO - 2022-08-18 15:09:38 --> Output Class Initialized
INFO - 2022-08-18 15:09:38 --> Security Class Initialized
DEBUG - 2022-08-18 15:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 15:09:38 --> Input Class Initialized
INFO - 2022-08-18 15:09:38 --> Language Class Initialized
INFO - 2022-08-18 15:09:38 --> Loader Class Initialized
INFO - 2022-08-18 15:09:38 --> Helper loaded: url_helper
INFO - 2022-08-18 15:09:38 --> Controller Class Initialized
DEBUG - 2022-08-18 15:09:38 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 15:09:38 --> Helper loaded: inflector_helper
INFO - 2022-08-18 15:09:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 15:09:38 --> Final output sent to browser
DEBUG - 2022-08-18 15:09:38 --> Total execution time: 0.1919
INFO - 2022-08-18 16:06:19 --> Config Class Initialized
INFO - 2022-08-18 16:06:19 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:06:19 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:06:19 --> Utf8 Class Initialized
INFO - 2022-08-18 16:06:19 --> URI Class Initialized
INFO - 2022-08-18 16:06:19 --> Router Class Initialized
INFO - 2022-08-18 16:06:19 --> Output Class Initialized
INFO - 2022-08-18 16:06:19 --> Security Class Initialized
DEBUG - 2022-08-18 16:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:06:19 --> Input Class Initialized
INFO - 2022-08-18 16:06:19 --> Language Class Initialized
INFO - 2022-08-18 16:06:19 --> Loader Class Initialized
INFO - 2022-08-18 16:06:19 --> Helper loaded: url_helper
INFO - 2022-08-18 16:06:19 --> Controller Class Initialized
DEBUG - 2022-08-18 16:06:19 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:06:20 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:06:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:06:20 --> Final output sent to browser
DEBUG - 2022-08-18 16:06:20 --> Total execution time: 0.8143
INFO - 2022-08-18 16:08:40 --> Config Class Initialized
INFO - 2022-08-18 16:08:40 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:08:40 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:08:40 --> Utf8 Class Initialized
INFO - 2022-08-18 16:08:40 --> URI Class Initialized
DEBUG - 2022-08-18 16:08:40 --> No URI present. Default controller set.
INFO - 2022-08-18 16:08:40 --> Router Class Initialized
INFO - 2022-08-18 16:08:40 --> Output Class Initialized
INFO - 2022-08-18 16:08:40 --> Security Class Initialized
DEBUG - 2022-08-18 16:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:08:40 --> Input Class Initialized
INFO - 2022-08-18 16:08:40 --> Language Class Initialized
INFO - 2022-08-18 16:08:40 --> Loader Class Initialized
INFO - 2022-08-18 16:08:40 --> Helper loaded: url_helper
INFO - 2022-08-18 16:08:40 --> Controller Class Initialized
INFO - 2022-08-18 16:08:40 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 16:08:40 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 16:08:40 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 16:08:40 --> Final output sent to browser
DEBUG - 2022-08-18 16:08:40 --> Total execution time: 0.5510
INFO - 2022-08-18 16:08:44 --> Config Class Initialized
INFO - 2022-08-18 16:08:44 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:08:44 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:08:44 --> Utf8 Class Initialized
INFO - 2022-08-18 16:08:44 --> URI Class Initialized
INFO - 2022-08-18 16:08:44 --> Router Class Initialized
INFO - 2022-08-18 16:08:44 --> Output Class Initialized
INFO - 2022-08-18 16:08:44 --> Security Class Initialized
DEBUG - 2022-08-18 16:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:08:44 --> Input Class Initialized
INFO - 2022-08-18 16:08:44 --> Language Class Initialized
INFO - 2022-08-18 16:08:44 --> Loader Class Initialized
INFO - 2022-08-18 16:08:44 --> Helper loaded: url_helper
INFO - 2022-08-18 16:08:44 --> Controller Class Initialized
INFO - 2022-08-18 16:08:44 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-18 16:08:44 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-18 16:08:44 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-18 16:08:44 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-18 16:08:44 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-18 16:08:44 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-18 16:08:44 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
INFO - 2022-08-18 16:08:48 --> Config Class Initialized
INFO - 2022-08-18 16:08:48 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:08:48 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:08:48 --> Utf8 Class Initialized
INFO - 2022-08-18 16:08:48 --> URI Class Initialized
INFO - 2022-08-18 16:08:48 --> Router Class Initialized
INFO - 2022-08-18 16:08:48 --> Output Class Initialized
INFO - 2022-08-18 16:08:48 --> Security Class Initialized
DEBUG - 2022-08-18 16:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:08:48 --> Input Class Initialized
INFO - 2022-08-18 16:08:48 --> Language Class Initialized
INFO - 2022-08-18 16:08:48 --> Loader Class Initialized
INFO - 2022-08-18 16:08:48 --> Helper loaded: url_helper
INFO - 2022-08-18 16:08:48 --> Controller Class Initialized
DEBUG - 2022-08-18 16:08:48 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:08:48 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:08:48 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-18 16:08:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:46) /sam_tool/system/helpers/url_helper.php 564
INFO - 2022-08-18 16:09:15 --> Config Class Initialized
INFO - 2022-08-18 16:09:15 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:09:15 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:09:15 --> Utf8 Class Initialized
INFO - 2022-08-18 16:09:15 --> URI Class Initialized
INFO - 2022-08-18 16:09:15 --> Router Class Initialized
INFO - 2022-08-18 16:09:15 --> Output Class Initialized
INFO - 2022-08-18 16:09:15 --> Security Class Initialized
DEBUG - 2022-08-18 16:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:09:15 --> Input Class Initialized
INFO - 2022-08-18 16:09:15 --> Language Class Initialized
INFO - 2022-08-18 16:09:15 --> Loader Class Initialized
INFO - 2022-08-18 16:09:15 --> Helper loaded: url_helper
INFO - 2022-08-18 16:09:15 --> Controller Class Initialized
DEBUG - 2022-08-18 16:09:15 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:09:15 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:09:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:09:25 --> Config Class Initialized
INFO - 2022-08-18 16:09:25 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:09:25 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:09:25 --> Utf8 Class Initialized
INFO - 2022-08-18 16:09:25 --> URI Class Initialized
INFO - 2022-08-18 16:09:25 --> Router Class Initialized
INFO - 2022-08-18 16:09:25 --> Output Class Initialized
INFO - 2022-08-18 16:09:25 --> Security Class Initialized
DEBUG - 2022-08-18 16:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:09:26 --> Input Class Initialized
INFO - 2022-08-18 16:09:26 --> Language Class Initialized
INFO - 2022-08-18 16:09:26 --> Loader Class Initialized
INFO - 2022-08-18 16:09:26 --> Helper loaded: url_helper
INFO - 2022-08-18 16:09:26 --> Controller Class Initialized
DEBUG - 2022-08-18 16:09:26 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:09:26 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:09:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:09:26 --> Config Class Initialized
INFO - 2022-08-18 16:09:26 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:09:26 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:09:26 --> Utf8 Class Initialized
INFO - 2022-08-18 16:09:26 --> URI Class Initialized
INFO - 2022-08-18 16:09:26 --> Router Class Initialized
INFO - 2022-08-18 16:09:26 --> Output Class Initialized
INFO - 2022-08-18 16:09:26 --> Security Class Initialized
DEBUG - 2022-08-18 16:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:09:26 --> Input Class Initialized
INFO - 2022-08-18 16:09:26 --> Language Class Initialized
INFO - 2022-08-18 16:09:26 --> Loader Class Initialized
INFO - 2022-08-18 16:09:26 --> Helper loaded: url_helper
INFO - 2022-08-18 16:09:26 --> Controller Class Initialized
INFO - 2022-08-18 16:09:26 --> Config Class Initialized
INFO - 2022-08-18 16:09:26 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:09:26 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:09:26 --> Utf8 Class Initialized
INFO - 2022-08-18 16:09:26 --> URI Class Initialized
INFO - 2022-08-18 16:09:26 --> Router Class Initialized
INFO - 2022-08-18 16:09:27 --> Output Class Initialized
INFO - 2022-08-18 16:09:27 --> Security Class Initialized
DEBUG - 2022-08-18 16:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:09:27 --> Input Class Initialized
INFO - 2022-08-18 16:09:27 --> Language Class Initialized
INFO - 2022-08-18 16:09:27 --> Loader Class Initialized
INFO - 2022-08-18 16:09:27 --> Helper loaded: url_helper
INFO - 2022-08-18 16:09:27 --> Controller Class Initialized
DEBUG - 2022-08-18 16:09:27 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:09:27 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:09:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:09:27 --> Final output sent to browser
DEBUG - 2022-08-18 16:09:27 --> Total execution time: 1.0285
INFO - 2022-08-18 16:30:38 --> Config Class Initialized
INFO - 2022-08-18 16:30:39 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:30:39 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:30:39 --> Utf8 Class Initialized
INFO - 2022-08-18 16:30:39 --> URI Class Initialized
INFO - 2022-08-18 16:30:39 --> Router Class Initialized
INFO - 2022-08-18 16:30:39 --> Output Class Initialized
INFO - 2022-08-18 16:30:39 --> Security Class Initialized
DEBUG - 2022-08-18 16:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:30:39 --> Input Class Initialized
INFO - 2022-08-18 16:30:39 --> Language Class Initialized
INFO - 2022-08-18 16:30:39 --> Loader Class Initialized
INFO - 2022-08-18 16:30:39 --> Helper loaded: url_helper
INFO - 2022-08-18 16:30:39 --> Controller Class Initialized
INFO - 2022-08-18 16:30:39 --> Config Class Initialized
INFO - 2022-08-18 16:30:39 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:30:39 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:30:39 --> Utf8 Class Initialized
INFO - 2022-08-18 16:30:39 --> URI Class Initialized
INFO - 2022-08-18 16:30:39 --> Router Class Initialized
INFO - 2022-08-18 16:30:39 --> Output Class Initialized
INFO - 2022-08-18 16:30:39 --> Security Class Initialized
DEBUG - 2022-08-18 16:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:30:39 --> Input Class Initialized
INFO - 2022-08-18 16:30:39 --> Language Class Initialized
INFO - 2022-08-18 16:30:39 --> Loader Class Initialized
INFO - 2022-08-18 16:30:39 --> Helper loaded: url_helper
INFO - 2022-08-18 16:30:39 --> Controller Class Initialized
DEBUG - 2022-08-18 16:30:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:30:39 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:30:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:30:40 --> Final output sent to browser
DEBUG - 2022-08-18 16:30:40 --> Total execution time: 1.1061
INFO - 2022-08-18 16:30:44 --> Config Class Initialized
INFO - 2022-08-18 16:30:44 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:30:44 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:30:44 --> Utf8 Class Initialized
INFO - 2022-08-18 16:30:44 --> URI Class Initialized
INFO - 2022-08-18 16:30:44 --> Router Class Initialized
INFO - 2022-08-18 16:30:44 --> Output Class Initialized
INFO - 2022-08-18 16:30:44 --> Security Class Initialized
DEBUG - 2022-08-18 16:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:30:44 --> Input Class Initialized
INFO - 2022-08-18 16:30:44 --> Language Class Initialized
INFO - 2022-08-18 16:30:44 --> Loader Class Initialized
INFO - 2022-08-18 16:30:44 --> Helper loaded: url_helper
INFO - 2022-08-18 16:30:44 --> Controller Class Initialized
INFO - 2022-08-18 16:30:44 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-18 16:30:44 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-18 16:30:44 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-18 16:30:44 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-18 16:30:44 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-18 16:30:44 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-18 16:30:44 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
INFO - 2022-08-18 16:30:48 --> Config Class Initialized
INFO - 2022-08-18 16:30:48 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:30:48 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:30:48 --> Utf8 Class Initialized
INFO - 2022-08-18 16:30:48 --> URI Class Initialized
INFO - 2022-08-18 16:30:48 --> Router Class Initialized
INFO - 2022-08-18 16:30:48 --> Output Class Initialized
INFO - 2022-08-18 16:30:48 --> Security Class Initialized
DEBUG - 2022-08-18 16:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:30:48 --> Input Class Initialized
INFO - 2022-08-18 16:30:48 --> Language Class Initialized
INFO - 2022-08-18 16:30:48 --> Loader Class Initialized
INFO - 2022-08-18 16:30:48 --> Helper loaded: url_helper
INFO - 2022-08-18 16:30:49 --> Controller Class Initialized
DEBUG - 2022-08-18 16:30:49 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:30:49 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:30:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:30:54 --> Config Class Initialized
INFO - 2022-08-18 16:30:54 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:30:54 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:30:54 --> Utf8 Class Initialized
INFO - 2022-08-18 16:30:54 --> URI Class Initialized
INFO - 2022-08-18 16:30:54 --> Router Class Initialized
INFO - 2022-08-18 16:30:54 --> Output Class Initialized
INFO - 2022-08-18 16:30:54 --> Security Class Initialized
DEBUG - 2022-08-18 16:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:30:54 --> Input Class Initialized
INFO - 2022-08-18 16:30:54 --> Language Class Initialized
INFO - 2022-08-18 16:30:54 --> Loader Class Initialized
INFO - 2022-08-18 16:30:54 --> Helper loaded: url_helper
INFO - 2022-08-18 16:30:54 --> Controller Class Initialized
DEBUG - 2022-08-18 16:30:54 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:30:54 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:30:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:31:38 --> Config Class Initialized
INFO - 2022-08-18 16:31:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:31:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:31:38 --> Utf8 Class Initialized
INFO - 2022-08-18 16:31:38 --> URI Class Initialized
INFO - 2022-08-18 16:31:38 --> Router Class Initialized
INFO - 2022-08-18 16:31:38 --> Output Class Initialized
INFO - 2022-08-18 16:31:38 --> Security Class Initialized
DEBUG - 2022-08-18 16:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:31:38 --> Input Class Initialized
INFO - 2022-08-18 16:31:38 --> Language Class Initialized
INFO - 2022-08-18 16:31:38 --> Loader Class Initialized
INFO - 2022-08-18 16:31:38 --> Helper loaded: url_helper
INFO - 2022-08-18 16:31:38 --> Controller Class Initialized
DEBUG - 2022-08-18 16:31:38 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:31:38 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:31:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:31:38 --> Final output sent to browser
DEBUG - 2022-08-18 16:31:38 --> Total execution time: 0.4965
INFO - 2022-08-18 16:33:03 --> Config Class Initialized
INFO - 2022-08-18 16:33:03 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:33:03 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:33:03 --> Utf8 Class Initialized
INFO - 2022-08-18 16:33:03 --> URI Class Initialized
INFO - 2022-08-18 16:33:03 --> Router Class Initialized
INFO - 2022-08-18 16:33:03 --> Output Class Initialized
INFO - 2022-08-18 16:33:03 --> Security Class Initialized
DEBUG - 2022-08-18 16:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:33:03 --> Input Class Initialized
INFO - 2022-08-18 16:33:03 --> Language Class Initialized
INFO - 2022-08-18 16:33:03 --> Loader Class Initialized
INFO - 2022-08-18 16:33:03 --> Helper loaded: url_helper
INFO - 2022-08-18 16:33:03 --> Controller Class Initialized
DEBUG - 2022-08-18 16:33:03 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:33:03 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:33:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:33:03 --> Final output sent to browser
DEBUG - 2022-08-18 16:33:03 --> Total execution time: 0.7310
INFO - 2022-08-18 16:33:14 --> Config Class Initialized
INFO - 2022-08-18 16:33:14 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:33:14 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:33:14 --> Utf8 Class Initialized
INFO - 2022-08-18 16:33:14 --> URI Class Initialized
INFO - 2022-08-18 16:33:14 --> Router Class Initialized
INFO - 2022-08-18 16:33:14 --> Output Class Initialized
INFO - 2022-08-18 16:33:14 --> Security Class Initialized
DEBUG - 2022-08-18 16:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:33:14 --> Input Class Initialized
INFO - 2022-08-18 16:33:14 --> Language Class Initialized
INFO - 2022-08-18 16:33:14 --> Loader Class Initialized
INFO - 2022-08-18 16:33:14 --> Helper loaded: url_helper
INFO - 2022-08-18 16:33:14 --> Controller Class Initialized
DEBUG - 2022-08-18 16:33:14 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:33:15 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:33:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:33:15 --> Final output sent to browser
DEBUG - 2022-08-18 16:33:15 --> Total execution time: 0.6776
INFO - 2022-08-18 16:33:39 --> Config Class Initialized
INFO - 2022-08-18 16:33:39 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:33:39 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:33:39 --> Utf8 Class Initialized
INFO - 2022-08-18 16:33:39 --> URI Class Initialized
INFO - 2022-08-18 16:33:39 --> Router Class Initialized
INFO - 2022-08-18 16:33:39 --> Output Class Initialized
INFO - 2022-08-18 16:33:39 --> Security Class Initialized
DEBUG - 2022-08-18 16:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:33:39 --> Input Class Initialized
INFO - 2022-08-18 16:33:39 --> Language Class Initialized
INFO - 2022-08-18 16:33:39 --> Loader Class Initialized
INFO - 2022-08-18 16:33:39 --> Helper loaded: url_helper
INFO - 2022-08-18 16:33:39 --> Controller Class Initialized
DEBUG - 2022-08-18 16:33:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:33:39 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:33:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:33:39 --> Final output sent to browser
DEBUG - 2022-08-18 16:33:39 --> Total execution time: 0.6316
INFO - 2022-08-18 16:33:50 --> Config Class Initialized
INFO - 2022-08-18 16:33:50 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:33:50 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:33:50 --> Utf8 Class Initialized
INFO - 2022-08-18 16:33:50 --> URI Class Initialized
INFO - 2022-08-18 16:33:50 --> Router Class Initialized
INFO - 2022-08-18 16:33:50 --> Output Class Initialized
INFO - 2022-08-18 16:33:50 --> Security Class Initialized
DEBUG - 2022-08-18 16:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:33:50 --> Input Class Initialized
INFO - 2022-08-18 16:33:50 --> Language Class Initialized
INFO - 2022-08-18 16:33:50 --> Loader Class Initialized
INFO - 2022-08-18 16:33:50 --> Helper loaded: url_helper
INFO - 2022-08-18 16:33:50 --> Controller Class Initialized
DEBUG - 2022-08-18 16:33:50 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:33:50 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:33:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:33:50 --> Final output sent to browser
DEBUG - 2022-08-18 16:33:50 --> Total execution time: 0.5212
INFO - 2022-08-18 16:52:10 --> Config Class Initialized
INFO - 2022-08-18 16:52:10 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:52:10 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:52:10 --> Utf8 Class Initialized
INFO - 2022-08-18 16:52:11 --> URI Class Initialized
INFO - 2022-08-18 16:52:11 --> Router Class Initialized
INFO - 2022-08-18 16:52:11 --> Output Class Initialized
INFO - 2022-08-18 16:52:11 --> Security Class Initialized
DEBUG - 2022-08-18 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:52:11 --> Input Class Initialized
INFO - 2022-08-18 16:52:11 --> Language Class Initialized
ERROR - 2022-08-18 16:52:11 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 16:52:14 --> Config Class Initialized
INFO - 2022-08-18 16:52:14 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:52:14 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:52:14 --> Utf8 Class Initialized
INFO - 2022-08-18 16:52:14 --> URI Class Initialized
INFO - 2022-08-18 16:52:14 --> Router Class Initialized
INFO - 2022-08-18 16:52:14 --> Output Class Initialized
INFO - 2022-08-18 16:52:14 --> Security Class Initialized
DEBUG - 2022-08-18 16:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:52:15 --> Input Class Initialized
INFO - 2022-08-18 16:52:15 --> Language Class Initialized
INFO - 2022-08-18 16:52:15 --> Loader Class Initialized
INFO - 2022-08-18 16:52:15 --> Helper loaded: url_helper
INFO - 2022-08-18 16:52:15 --> Controller Class Initialized
DEBUG - 2022-08-18 16:52:15 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:52:15 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:52:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:52:15 --> Final output sent to browser
DEBUG - 2022-08-18 16:52:15 --> Total execution time: 0.6377
INFO - 2022-08-18 16:52:40 --> Config Class Initialized
INFO - 2022-08-18 16:52:40 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:52:40 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:52:40 --> Utf8 Class Initialized
INFO - 2022-08-18 16:52:40 --> URI Class Initialized
INFO - 2022-08-18 16:52:40 --> Router Class Initialized
INFO - 2022-08-18 16:52:40 --> Output Class Initialized
INFO - 2022-08-18 16:52:40 --> Security Class Initialized
DEBUG - 2022-08-18 16:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:52:40 --> Input Class Initialized
INFO - 2022-08-18 16:52:40 --> Language Class Initialized
ERROR - 2022-08-18 16:52:40 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 16:52:41 --> Config Class Initialized
INFO - 2022-08-18 16:52:41 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:52:41 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:52:41 --> Utf8 Class Initialized
INFO - 2022-08-18 16:52:41 --> URI Class Initialized
DEBUG - 2022-08-18 16:52:41 --> No URI present. Default controller set.
INFO - 2022-08-18 16:52:41 --> Router Class Initialized
INFO - 2022-08-18 16:52:41 --> Output Class Initialized
INFO - 2022-08-18 16:52:41 --> Security Class Initialized
DEBUG - 2022-08-18 16:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:52:41 --> Input Class Initialized
INFO - 2022-08-18 16:52:41 --> Language Class Initialized
INFO - 2022-08-18 16:52:41 --> Loader Class Initialized
INFO - 2022-08-18 16:52:41 --> Helper loaded: url_helper
INFO - 2022-08-18 16:52:41 --> Controller Class Initialized
INFO - 2022-08-18 16:52:42 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 16:52:42 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 16:52:42 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 16:52:42 --> Config Class Initialized
INFO - 2022-08-18 16:52:42 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:52:42 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:52:42 --> Utf8 Class Initialized
INFO - 2022-08-18 16:52:42 --> URI Class Initialized
DEBUG - 2022-08-18 16:52:42 --> No URI present. Default controller set.
INFO - 2022-08-18 16:52:42 --> Router Class Initialized
INFO - 2022-08-18 16:52:42 --> Output Class Initialized
INFO - 2022-08-18 16:52:42 --> Security Class Initialized
DEBUG - 2022-08-18 16:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:52:42 --> Input Class Initialized
INFO - 2022-08-18 16:52:42 --> Language Class Initialized
INFO - 2022-08-18 16:52:42 --> Loader Class Initialized
INFO - 2022-08-18 16:52:42 --> Helper loaded: url_helper
INFO - 2022-08-18 16:52:42 --> Controller Class Initialized
INFO - 2022-08-18 16:52:42 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 16:52:42 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 16:52:42 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 16:52:42 --> Final output sent to browser
DEBUG - 2022-08-18 16:52:42 --> Total execution time: 0.3542
INFO - 2022-08-18 16:52:43 --> Config Class Initialized
INFO - 2022-08-18 16:52:43 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:52:43 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:52:43 --> Utf8 Class Initialized
INFO - 2022-08-18 16:52:43 --> URI Class Initialized
INFO - 2022-08-18 16:52:43 --> Router Class Initialized
INFO - 2022-08-18 16:52:43 --> Output Class Initialized
INFO - 2022-08-18 16:52:43 --> Security Class Initialized
DEBUG - 2022-08-18 16:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:52:43 --> Input Class Initialized
INFO - 2022-08-18 16:52:43 --> Language Class Initialized
ERROR - 2022-08-18 16:52:43 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 16:52:56 --> Config Class Initialized
INFO - 2022-08-18 16:52:56 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:52:57 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:52:57 --> Utf8 Class Initialized
INFO - 2022-08-18 16:52:57 --> URI Class Initialized
DEBUG - 2022-08-18 16:52:57 --> No URI present. Default controller set.
INFO - 2022-08-18 16:52:57 --> Router Class Initialized
INFO - 2022-08-18 16:52:57 --> Output Class Initialized
INFO - 2022-08-18 16:52:57 --> Security Class Initialized
DEBUG - 2022-08-18 16:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:52:57 --> Input Class Initialized
INFO - 2022-08-18 16:52:57 --> Language Class Initialized
INFO - 2022-08-18 16:52:57 --> Loader Class Initialized
INFO - 2022-08-18 16:52:57 --> Helper loaded: url_helper
INFO - 2022-08-18 16:52:57 --> Controller Class Initialized
INFO - 2022-08-18 16:52:57 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 16:52:57 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 16:52:57 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 16:52:57 --> Final output sent to browser
DEBUG - 2022-08-18 16:52:57 --> Total execution time: 0.7090
INFO - 2022-08-18 16:52:59 --> Config Class Initialized
INFO - 2022-08-18 16:52:59 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:52:59 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:52:59 --> Utf8 Class Initialized
INFO - 2022-08-18 16:52:59 --> URI Class Initialized
INFO - 2022-08-18 16:52:59 --> Router Class Initialized
INFO - 2022-08-18 16:52:59 --> Output Class Initialized
INFO - 2022-08-18 16:52:59 --> Security Class Initialized
DEBUG - 2022-08-18 16:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:52:59 --> Input Class Initialized
INFO - 2022-08-18 16:52:59 --> Language Class Initialized
ERROR - 2022-08-18 16:52:59 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 16:53:01 --> Config Class Initialized
INFO - 2022-08-18 16:53:01 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:53:01 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:53:01 --> Utf8 Class Initialized
INFO - 2022-08-18 16:53:01 --> URI Class Initialized
DEBUG - 2022-08-18 16:53:01 --> No URI present. Default controller set.
INFO - 2022-08-18 16:53:01 --> Router Class Initialized
INFO - 2022-08-18 16:53:01 --> Output Class Initialized
INFO - 2022-08-18 16:53:01 --> Security Class Initialized
DEBUG - 2022-08-18 16:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:53:01 --> Input Class Initialized
INFO - 2022-08-18 16:53:01 --> Language Class Initialized
INFO - 2022-08-18 16:53:01 --> Loader Class Initialized
INFO - 2022-08-18 16:53:01 --> Helper loaded: url_helper
INFO - 2022-08-18 16:53:01 --> Controller Class Initialized
INFO - 2022-08-18 16:53:01 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 16:53:01 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 16:53:01 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 16:53:01 --> Final output sent to browser
DEBUG - 2022-08-18 16:53:01 --> Total execution time: 0.4850
INFO - 2022-08-18 16:53:02 --> Config Class Initialized
INFO - 2022-08-18 16:53:02 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:53:02 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:53:02 --> Utf8 Class Initialized
INFO - 2022-08-18 16:53:02 --> URI Class Initialized
INFO - 2022-08-18 16:53:02 --> Router Class Initialized
INFO - 2022-08-18 16:53:02 --> Output Class Initialized
INFO - 2022-08-18 16:53:02 --> Security Class Initialized
DEBUG - 2022-08-18 16:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:53:02 --> Input Class Initialized
INFO - 2022-08-18 16:53:02 --> Language Class Initialized
ERROR - 2022-08-18 16:53:02 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 16:53:18 --> Config Class Initialized
INFO - 2022-08-18 16:53:18 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:53:18 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:53:18 --> Utf8 Class Initialized
INFO - 2022-08-18 16:53:18 --> URI Class Initialized
INFO - 2022-08-18 16:53:18 --> Router Class Initialized
INFO - 2022-08-18 16:53:18 --> Output Class Initialized
INFO - 2022-08-18 16:53:18 --> Security Class Initialized
DEBUG - 2022-08-18 16:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:53:18 --> Input Class Initialized
INFO - 2022-08-18 16:53:18 --> Language Class Initialized
INFO - 2022-08-18 16:53:18 --> Loader Class Initialized
INFO - 2022-08-18 16:53:18 --> Helper loaded: url_helper
INFO - 2022-08-18 16:53:18 --> Controller Class Initialized
DEBUG - 2022-08-18 16:53:18 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:53:18 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:53:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:53:18 --> Final output sent to browser
DEBUG - 2022-08-18 16:53:18 --> Total execution time: 0.5216
INFO - 2022-08-18 16:53:23 --> Config Class Initialized
INFO - 2022-08-18 16:53:23 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:53:23 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:53:23 --> Utf8 Class Initialized
INFO - 2022-08-18 16:53:23 --> URI Class Initialized
DEBUG - 2022-08-18 16:53:23 --> No URI present. Default controller set.
INFO - 2022-08-18 16:53:23 --> Router Class Initialized
INFO - 2022-08-18 16:53:23 --> Output Class Initialized
INFO - 2022-08-18 16:53:23 --> Security Class Initialized
DEBUG - 2022-08-18 16:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:53:23 --> Input Class Initialized
INFO - 2022-08-18 16:53:23 --> Language Class Initialized
INFO - 2022-08-18 16:53:23 --> Loader Class Initialized
INFO - 2022-08-18 16:53:23 --> Helper loaded: url_helper
INFO - 2022-08-18 16:53:23 --> Controller Class Initialized
INFO - 2022-08-18 16:53:23 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 16:53:23 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 16:53:23 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 16:53:23 --> Final output sent to browser
DEBUG - 2022-08-18 16:53:23 --> Total execution time: 0.5475
INFO - 2022-08-18 16:53:23 --> Config Class Initialized
INFO - 2022-08-18 16:53:23 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:53:24 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:53:24 --> Utf8 Class Initialized
INFO - 2022-08-18 16:53:24 --> URI Class Initialized
INFO - 2022-08-18 16:53:24 --> Router Class Initialized
INFO - 2022-08-18 16:53:24 --> Output Class Initialized
INFO - 2022-08-18 16:53:24 --> Security Class Initialized
DEBUG - 2022-08-18 16:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:53:24 --> Input Class Initialized
INFO - 2022-08-18 16:53:24 --> Language Class Initialized
ERROR - 2022-08-18 16:53:24 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 16:53:37 --> Config Class Initialized
INFO - 2022-08-18 16:53:37 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:53:37 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:53:37 --> Utf8 Class Initialized
INFO - 2022-08-18 16:53:38 --> URI Class Initialized
DEBUG - 2022-08-18 16:53:38 --> No URI present. Default controller set.
INFO - 2022-08-18 16:53:38 --> Router Class Initialized
INFO - 2022-08-18 16:53:38 --> Output Class Initialized
INFO - 2022-08-18 16:53:38 --> Security Class Initialized
DEBUG - 2022-08-18 16:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:53:38 --> Input Class Initialized
INFO - 2022-08-18 16:53:38 --> Language Class Initialized
INFO - 2022-08-18 16:53:38 --> Loader Class Initialized
INFO - 2022-08-18 16:53:38 --> Helper loaded: url_helper
INFO - 2022-08-18 16:53:38 --> Controller Class Initialized
INFO - 2022-08-18 16:53:38 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 16:53:38 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 16:53:38 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 16:53:38 --> Final output sent to browser
DEBUG - 2022-08-18 16:53:38 --> Total execution time: 0.4372
INFO - 2022-08-18 16:53:38 --> Config Class Initialized
INFO - 2022-08-18 16:53:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:53:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:53:38 --> Utf8 Class Initialized
INFO - 2022-08-18 16:53:38 --> URI Class Initialized
INFO - 2022-08-18 16:53:38 --> Router Class Initialized
INFO - 2022-08-18 16:53:38 --> Output Class Initialized
INFO - 2022-08-18 16:53:38 --> Security Class Initialized
DEBUG - 2022-08-18 16:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:53:38 --> Input Class Initialized
INFO - 2022-08-18 16:53:38 --> Language Class Initialized
ERROR - 2022-08-18 16:53:38 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 16:57:34 --> Config Class Initialized
INFO - 2022-08-18 16:57:34 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:57:34 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:57:34 --> Utf8 Class Initialized
INFO - 2022-08-18 16:57:34 --> URI Class Initialized
DEBUG - 2022-08-18 16:57:34 --> No URI present. Default controller set.
INFO - 2022-08-18 16:57:34 --> Router Class Initialized
INFO - 2022-08-18 16:57:34 --> Output Class Initialized
INFO - 2022-08-18 16:57:34 --> Security Class Initialized
DEBUG - 2022-08-18 16:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:57:34 --> Input Class Initialized
INFO - 2022-08-18 16:57:34 --> Language Class Initialized
INFO - 2022-08-18 16:57:34 --> Loader Class Initialized
INFO - 2022-08-18 16:57:34 --> Helper loaded: url_helper
INFO - 2022-08-18 16:57:34 --> Controller Class Initialized
INFO - 2022-08-18 16:57:34 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 16:57:34 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 16:57:34 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 16:57:34 --> Final output sent to browser
DEBUG - 2022-08-18 16:57:34 --> Total execution time: 0.5748
INFO - 2022-08-18 16:57:35 --> Config Class Initialized
INFO - 2022-08-18 16:57:35 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:57:35 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:57:35 --> Utf8 Class Initialized
INFO - 2022-08-18 16:57:35 --> URI Class Initialized
INFO - 2022-08-18 16:57:35 --> Router Class Initialized
INFO - 2022-08-18 16:57:35 --> Output Class Initialized
INFO - 2022-08-18 16:57:35 --> Security Class Initialized
DEBUG - 2022-08-18 16:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:57:35 --> Input Class Initialized
INFO - 2022-08-18 16:57:35 --> Language Class Initialized
ERROR - 2022-08-18 16:57:36 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 16:57:38 --> Config Class Initialized
INFO - 2022-08-18 16:57:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 16:57:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 16:57:38 --> Utf8 Class Initialized
INFO - 2022-08-18 16:57:38 --> URI Class Initialized
INFO - 2022-08-18 16:57:38 --> Router Class Initialized
INFO - 2022-08-18 16:57:38 --> Output Class Initialized
INFO - 2022-08-18 16:57:38 --> Security Class Initialized
DEBUG - 2022-08-18 16:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 16:57:38 --> Input Class Initialized
INFO - 2022-08-18 16:57:38 --> Language Class Initialized
INFO - 2022-08-18 16:57:38 --> Loader Class Initialized
INFO - 2022-08-18 16:57:38 --> Helper loaded: url_helper
INFO - 2022-08-18 16:57:38 --> Controller Class Initialized
DEBUG - 2022-08-18 16:57:38 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 16:57:38 --> Helper loaded: inflector_helper
INFO - 2022-08-18 16:57:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 16:57:38 --> Final output sent to browser
DEBUG - 2022-08-18 16:57:38 --> Total execution time: 0.5789
INFO - 2022-08-18 17:01:33 --> Config Class Initialized
INFO - 2022-08-18 17:01:33 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:01:33 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:01:33 --> Utf8 Class Initialized
INFO - 2022-08-18 17:01:33 --> URI Class Initialized
INFO - 2022-08-18 17:01:33 --> Router Class Initialized
INFO - 2022-08-18 17:01:33 --> Output Class Initialized
INFO - 2022-08-18 17:01:33 --> Security Class Initialized
DEBUG - 2022-08-18 17:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:01:33 --> Input Class Initialized
INFO - 2022-08-18 17:01:33 --> Language Class Initialized
INFO - 2022-08-18 17:01:33 --> Loader Class Initialized
INFO - 2022-08-18 17:01:33 --> Helper loaded: url_helper
INFO - 2022-08-18 17:01:33 --> Controller Class Initialized
DEBUG - 2022-08-18 17:01:33 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 17:01:33 --> Helper loaded: inflector_helper
INFO - 2022-08-18 17:01:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 17:01:33 --> Final output sent to browser
DEBUG - 2022-08-18 17:01:33 --> Total execution time: 0.5871
INFO - 2022-08-18 17:01:38 --> Config Class Initialized
INFO - 2022-08-18 17:01:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:01:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:01:38 --> Utf8 Class Initialized
INFO - 2022-08-18 17:01:38 --> URI Class Initialized
INFO - 2022-08-18 17:01:38 --> Router Class Initialized
INFO - 2022-08-18 17:01:38 --> Output Class Initialized
INFO - 2022-08-18 17:01:39 --> Security Class Initialized
DEBUG - 2022-08-18 17:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:01:39 --> Input Class Initialized
INFO - 2022-08-18 17:01:39 --> Language Class Initialized
INFO - 2022-08-18 17:01:39 --> Loader Class Initialized
INFO - 2022-08-18 17:01:39 --> Helper loaded: url_helper
INFO - 2022-08-18 17:01:39 --> Controller Class Initialized
INFO - 2022-08-18 17:01:39 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-18 17:01:39 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-18 17:01:39 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-18 17:01:39 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-18 17:01:39 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-18 17:01:39 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-18 17:01:39 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
INFO - 2022-08-18 17:43:09 --> Config Class Initialized
INFO - 2022-08-18 17:43:09 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:43:10 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:43:10 --> Utf8 Class Initialized
INFO - 2022-08-18 17:43:10 --> URI Class Initialized
DEBUG - 2022-08-18 17:43:10 --> No URI present. Default controller set.
INFO - 2022-08-18 17:43:10 --> Router Class Initialized
INFO - 2022-08-18 17:43:10 --> Output Class Initialized
INFO - 2022-08-18 17:43:10 --> Security Class Initialized
DEBUG - 2022-08-18 17:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:43:10 --> Input Class Initialized
INFO - 2022-08-18 17:43:10 --> Language Class Initialized
INFO - 2022-08-18 17:43:10 --> Loader Class Initialized
INFO - 2022-08-18 17:43:10 --> Helper loaded: url_helper
INFO - 2022-08-18 17:43:10 --> Controller Class Initialized
INFO - 2022-08-18 17:43:10 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-18 17:43:10 --> Severity: Notice --> Undefined variable: product /sam_tool/application/views/frontend/dashboard.php 192
ERROR - 2022-08-18 17:43:10 --> Severity: Notice --> Trying to get property 'id' of non-object /sam_tool/application/views/frontend/dashboard.php 192
ERROR - 2022-08-18 17:43:10 --> Severity: Notice --> Undefined variable: all_product_count /sam_tool/application/views/frontend/dashboard.php 317
INFO - 2022-08-18 17:43:10 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 17:43:10 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 17:43:10 --> Final output sent to browser
DEBUG - 2022-08-18 17:43:10 --> Total execution time: 0.7076
INFO - 2022-08-18 17:43:37 --> Config Class Initialized
INFO - 2022-08-18 17:43:37 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:43:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:43:38 --> Utf8 Class Initialized
INFO - 2022-08-18 17:43:38 --> URI Class Initialized
DEBUG - 2022-08-18 17:43:38 --> No URI present. Default controller set.
INFO - 2022-08-18 17:43:38 --> Router Class Initialized
INFO - 2022-08-18 17:43:38 --> Output Class Initialized
INFO - 2022-08-18 17:43:38 --> Security Class Initialized
DEBUG - 2022-08-18 17:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:43:38 --> Input Class Initialized
INFO - 2022-08-18 17:43:38 --> Language Class Initialized
INFO - 2022-08-18 17:43:38 --> Loader Class Initialized
INFO - 2022-08-18 17:43:38 --> Helper loaded: url_helper
INFO - 2022-08-18 17:43:38 --> Controller Class Initialized
INFO - 2022-08-18 17:43:38 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-18 17:43:38 --> Severity: Notice --> Undefined variable: all_product_count /sam_tool/application/views/frontend/dashboard.php 317
INFO - 2022-08-18 17:43:38 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 17:43:38 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 17:43:38 --> Final output sent to browser
DEBUG - 2022-08-18 17:43:38 --> Total execution time: 0.6876
INFO - 2022-08-18 17:43:53 --> Config Class Initialized
INFO - 2022-08-18 17:43:53 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:43:53 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:43:53 --> Utf8 Class Initialized
INFO - 2022-08-18 17:43:53 --> URI Class Initialized
DEBUG - 2022-08-18 17:43:53 --> No URI present. Default controller set.
INFO - 2022-08-18 17:43:53 --> Router Class Initialized
INFO - 2022-08-18 17:43:53 --> Output Class Initialized
INFO - 2022-08-18 17:43:53 --> Security Class Initialized
DEBUG - 2022-08-18 17:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:43:53 --> Input Class Initialized
INFO - 2022-08-18 17:43:53 --> Language Class Initialized
INFO - 2022-08-18 17:43:53 --> Loader Class Initialized
INFO - 2022-08-18 17:43:53 --> Helper loaded: url_helper
INFO - 2022-08-18 17:43:53 --> Controller Class Initialized
INFO - 2022-08-18 17:43:53 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 17:43:53 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 17:43:53 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 17:43:53 --> Final output sent to browser
DEBUG - 2022-08-18 17:43:53 --> Total execution time: 0.4719
INFO - 2022-08-18 17:44:33 --> Config Class Initialized
INFO - 2022-08-18 17:44:33 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:44:33 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:44:33 --> Utf8 Class Initialized
INFO - 2022-08-18 17:44:33 --> URI Class Initialized
DEBUG - 2022-08-18 17:44:33 --> No URI present. Default controller set.
INFO - 2022-08-18 17:44:33 --> Router Class Initialized
INFO - 2022-08-18 17:44:33 --> Output Class Initialized
INFO - 2022-08-18 17:44:33 --> Security Class Initialized
DEBUG - 2022-08-18 17:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:44:33 --> Input Class Initialized
INFO - 2022-08-18 17:44:33 --> Language Class Initialized
INFO - 2022-08-18 17:44:33 --> Loader Class Initialized
INFO - 2022-08-18 17:44:33 --> Helper loaded: url_helper
INFO - 2022-08-18 17:44:33 --> Controller Class Initialized
INFO - 2022-08-18 17:44:33 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 17:44:33 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 17:44:33 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 17:44:33 --> Final output sent to browser
DEBUG - 2022-08-18 17:44:33 --> Total execution time: 0.4732
INFO - 2022-08-18 17:45:58 --> Config Class Initialized
INFO - 2022-08-18 17:45:58 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:45:59 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:45:59 --> Utf8 Class Initialized
INFO - 2022-08-18 17:45:59 --> URI Class Initialized
DEBUG - 2022-08-18 17:45:59 --> No URI present. Default controller set.
INFO - 2022-08-18 17:45:59 --> Router Class Initialized
INFO - 2022-08-18 17:45:59 --> Output Class Initialized
INFO - 2022-08-18 17:45:59 --> Security Class Initialized
DEBUG - 2022-08-18 17:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:45:59 --> Input Class Initialized
INFO - 2022-08-18 17:45:59 --> Language Class Initialized
INFO - 2022-08-18 17:45:59 --> Loader Class Initialized
INFO - 2022-08-18 17:45:59 --> Helper loaded: url_helper
INFO - 2022-08-18 17:45:59 --> Controller Class Initialized
INFO - 2022-08-18 17:45:59 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 17:45:59 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 17:45:59 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 17:45:59 --> Final output sent to browser
DEBUG - 2022-08-18 17:45:59 --> Total execution time: 0.6793
INFO - 2022-08-18 17:48:14 --> Config Class Initialized
INFO - 2022-08-18 17:48:14 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:48:14 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:48:14 --> Utf8 Class Initialized
INFO - 2022-08-18 17:48:14 --> URI Class Initialized
DEBUG - 2022-08-18 17:48:14 --> No URI present. Default controller set.
INFO - 2022-08-18 17:48:14 --> Router Class Initialized
INFO - 2022-08-18 17:48:15 --> Output Class Initialized
INFO - 2022-08-18 17:48:15 --> Security Class Initialized
DEBUG - 2022-08-18 17:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:48:15 --> Input Class Initialized
INFO - 2022-08-18 17:48:15 --> Language Class Initialized
INFO - 2022-08-18 17:48:15 --> Loader Class Initialized
INFO - 2022-08-18 17:48:15 --> Helper loaded: url_helper
INFO - 2022-08-18 17:48:15 --> Controller Class Initialized
INFO - 2022-08-18 17:48:15 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-18 17:48:15 --> Severity: Notice --> Undefined variable: proprty /sam_tool/application/views/frontend/dashboard.php 194
ERROR - 2022-08-18 17:48:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 194
INFO - 2022-08-18 17:48:15 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 17:48:15 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 17:48:15 --> Final output sent to browser
DEBUG - 2022-08-18 17:48:15 --> Total execution time: 0.6462
INFO - 2022-08-18 17:48:30 --> Config Class Initialized
INFO - 2022-08-18 17:48:30 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:48:30 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:48:30 --> Utf8 Class Initialized
INFO - 2022-08-18 17:48:30 --> URI Class Initialized
DEBUG - 2022-08-18 17:48:30 --> No URI present. Default controller set.
INFO - 2022-08-18 17:48:31 --> Router Class Initialized
INFO - 2022-08-18 17:48:31 --> Output Class Initialized
INFO - 2022-08-18 17:48:31 --> Security Class Initialized
DEBUG - 2022-08-18 17:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:48:31 --> Input Class Initialized
INFO - 2022-08-18 17:48:31 --> Language Class Initialized
INFO - 2022-08-18 17:48:31 --> Loader Class Initialized
INFO - 2022-08-18 17:48:31 --> Helper loaded: url_helper
INFO - 2022-08-18 17:48:31 --> Controller Class Initialized
INFO - 2022-08-18 17:48:31 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 17:48:31 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 17:48:31 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 17:48:31 --> Final output sent to browser
DEBUG - 2022-08-18 17:48:31 --> Total execution time: 0.5708
INFO - 2022-08-18 17:48:46 --> Config Class Initialized
INFO - 2022-08-18 17:48:46 --> Hooks Class Initialized
DEBUG - 2022-08-18 17:48:46 --> UTF-8 Support Enabled
INFO - 2022-08-18 17:48:46 --> Utf8 Class Initialized
INFO - 2022-08-18 17:48:46 --> URI Class Initialized
DEBUG - 2022-08-18 17:48:46 --> No URI present. Default controller set.
INFO - 2022-08-18 17:48:46 --> Router Class Initialized
INFO - 2022-08-18 17:48:46 --> Output Class Initialized
INFO - 2022-08-18 17:48:46 --> Security Class Initialized
DEBUG - 2022-08-18 17:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 17:48:46 --> Input Class Initialized
INFO - 2022-08-18 17:48:46 --> Language Class Initialized
INFO - 2022-08-18 17:48:46 --> Loader Class Initialized
INFO - 2022-08-18 17:48:46 --> Helper loaded: url_helper
INFO - 2022-08-18 17:48:46 --> Controller Class Initialized
INFO - 2022-08-18 17:48:46 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 17:48:46 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 17:48:46 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 17:48:46 --> Final output sent to browser
DEBUG - 2022-08-18 17:48:46 --> Total execution time: 0.4967
INFO - 2022-08-18 18:09:18 --> Config Class Initialized
INFO - 2022-08-18 18:09:18 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:09:18 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:09:18 --> Utf8 Class Initialized
INFO - 2022-08-18 18:09:18 --> URI Class Initialized
DEBUG - 2022-08-18 18:09:18 --> No URI present. Default controller set.
INFO - 2022-08-18 18:09:19 --> Router Class Initialized
INFO - 2022-08-18 18:09:19 --> Output Class Initialized
INFO - 2022-08-18 18:09:19 --> Security Class Initialized
DEBUG - 2022-08-18 18:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:09:19 --> Input Class Initialized
INFO - 2022-08-18 18:09:19 --> Language Class Initialized
ERROR - 2022-08-18 18:09:19 --> Severity: error --> Exception: syntax error, unexpected '$urlpath' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) /sam_tool/application/controllers/Frontend.php 9
INFO - 2022-08-18 18:10:28 --> Config Class Initialized
INFO - 2022-08-18 18:10:28 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:10:28 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:10:28 --> Utf8 Class Initialized
INFO - 2022-08-18 18:10:28 --> URI Class Initialized
DEBUG - 2022-08-18 18:10:28 --> No URI present. Default controller set.
INFO - 2022-08-18 18:10:28 --> Router Class Initialized
INFO - 2022-08-18 18:10:28 --> Output Class Initialized
INFO - 2022-08-18 18:10:28 --> Security Class Initialized
DEBUG - 2022-08-18 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:10:28 --> Input Class Initialized
INFO - 2022-08-18 18:10:28 --> Language Class Initialized
ERROR - 2022-08-18 18:10:28 --> Severity: error --> Exception: syntax error, unexpected ''/propertySearch/ByCity'' (T_CONSTANT_ENCAPSED_STRING) /sam_tool/application/controllers/Frontend.php 21
INFO - 2022-08-18 18:10:51 --> Config Class Initialized
INFO - 2022-08-18 18:10:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:10:52 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:10:52 --> Utf8 Class Initialized
INFO - 2022-08-18 18:10:52 --> URI Class Initialized
DEBUG - 2022-08-18 18:10:52 --> No URI present. Default controller set.
INFO - 2022-08-18 18:10:52 --> Router Class Initialized
INFO - 2022-08-18 18:10:52 --> Output Class Initialized
INFO - 2022-08-18 18:10:52 --> Security Class Initialized
DEBUG - 2022-08-18 18:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:10:52 --> Input Class Initialized
INFO - 2022-08-18 18:10:52 --> Language Class Initialized
ERROR - 2022-08-18 18:10:52 --> Severity: error --> Exception: syntax error, unexpected ''/propertySearch/ByCity'' (T_CONSTANT_ENCAPSED_STRING) /sam_tool/application/controllers/Frontend.php 172
INFO - 2022-08-18 18:11:41 --> Config Class Initialized
INFO - 2022-08-18 18:11:41 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:11:41 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:11:41 --> Utf8 Class Initialized
INFO - 2022-08-18 18:11:41 --> URI Class Initialized
DEBUG - 2022-08-18 18:11:41 --> No URI present. Default controller set.
INFO - 2022-08-18 18:11:41 --> Router Class Initialized
INFO - 2022-08-18 18:11:41 --> Output Class Initialized
INFO - 2022-08-18 18:11:41 --> Security Class Initialized
DEBUG - 2022-08-18 18:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:11:41 --> Input Class Initialized
INFO - 2022-08-18 18:11:41 --> Language Class Initialized
ERROR - 2022-08-18 18:11:41 --> Severity: error --> Exception: syntax error, unexpected ''/propertySearch/ByCity'' (T_CONSTANT_ENCAPSED_STRING) /sam_tool/application/controllers/Frontend.php 172
INFO - 2022-08-18 18:12:07 --> Config Class Initialized
INFO - 2022-08-18 18:12:07 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:12:07 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:12:07 --> Utf8 Class Initialized
INFO - 2022-08-18 18:12:07 --> URI Class Initialized
DEBUG - 2022-08-18 18:12:07 --> No URI present. Default controller set.
INFO - 2022-08-18 18:12:07 --> Router Class Initialized
INFO - 2022-08-18 18:12:07 --> Output Class Initialized
INFO - 2022-08-18 18:12:07 --> Security Class Initialized
DEBUG - 2022-08-18 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:12:07 --> Input Class Initialized
INFO - 2022-08-18 18:12:07 --> Language Class Initialized
ERROR - 2022-08-18 18:12:07 --> Severity: error --> Exception: syntax error, unexpected ''/property/by-city'' (T_CONSTANT_ENCAPSED_STRING) /sam_tool/application/controllers/Frontend.php 172
INFO - 2022-08-18 18:12:26 --> Config Class Initialized
INFO - 2022-08-18 18:12:26 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:12:26 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:12:26 --> Utf8 Class Initialized
INFO - 2022-08-18 18:12:26 --> URI Class Initialized
DEBUG - 2022-08-18 18:12:26 --> No URI present. Default controller set.
INFO - 2022-08-18 18:12:26 --> Router Class Initialized
INFO - 2022-08-18 18:12:26 --> Output Class Initialized
INFO - 2022-08-18 18:12:26 --> Security Class Initialized
DEBUG - 2022-08-18 18:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:12:26 --> Input Class Initialized
INFO - 2022-08-18 18:12:26 --> Language Class Initialized
INFO - 2022-08-18 18:12:27 --> Loader Class Initialized
INFO - 2022-08-18 18:12:27 --> Helper loaded: url_helper
INFO - 2022-08-18 18:12:27 --> Controller Class Initialized
ERROR - 2022-08-18 18:12:27 --> Severity: Warning --> Use of undefined constant property - assumed 'property' (this will throw an Error in a future version of PHP) /sam_tool/application/controllers/Frontend.php 21
ERROR - 2022-08-18 18:12:27 --> Severity: Notice --> Undefined variable: urlpath /sam_tool/application/controllers/Frontend.php 21
ERROR - 2022-08-18 18:12:27 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/controllers/Frontend.php 21
ERROR - 2022-08-18 18:12:27 --> Severity: Warning --> Division by zero /sam_tool/application/controllers/Frontend.php 21
ERROR - 2022-08-18 18:12:27 --> Severity: Warning --> Use of undefined constant by - assumed 'by' (this will throw an Error in a future version of PHP) /sam_tool/application/controllers/Frontend.php 21
ERROR - 2022-08-18 18:12:27 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/controllers/Frontend.php 21
ERROR - 2022-08-18 18:12:27 --> Severity: Warning --> Division by zero /sam_tool/application/controllers/Frontend.php 21
ERROR - 2022-08-18 18:12:27 --> Severity: Warning --> Use of undefined constant city - assumed 'city' (this will throw an Error in a future version of PHP) /sam_tool/application/controllers/Frontend.php 21
ERROR - 2022-08-18 18:12:27 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/controllers/Frontend.php 21
INFO - 2022-08-18 18:12:32 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-18 18:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 116
INFO - 2022-08-18 18:12:32 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 18:12:32 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 18:12:32 --> Final output sent to browser
DEBUG - 2022-08-18 18:12:32 --> Total execution time: 5.6839
INFO - 2022-08-18 18:13:16 --> Config Class Initialized
INFO - 2022-08-18 18:13:16 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:13:16 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:13:16 --> Utf8 Class Initialized
INFO - 2022-08-18 18:13:16 --> URI Class Initialized
DEBUG - 2022-08-18 18:13:16 --> No URI present. Default controller set.
INFO - 2022-08-18 18:13:16 --> Router Class Initialized
INFO - 2022-08-18 18:13:16 --> Output Class Initialized
INFO - 2022-08-18 18:13:16 --> Security Class Initialized
DEBUG - 2022-08-18 18:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:13:16 --> Input Class Initialized
INFO - 2022-08-18 18:13:16 --> Language Class Initialized
ERROR - 2022-08-18 18:13:16 --> Severity: error --> Exception: syntax error, unexpected '$urlpath' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) /sam_tool/application/controllers/Frontend.php 9
INFO - 2022-08-18 18:13:29 --> Config Class Initialized
INFO - 2022-08-18 18:13:29 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:13:29 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:13:29 --> Utf8 Class Initialized
INFO - 2022-08-18 18:13:29 --> URI Class Initialized
DEBUG - 2022-08-18 18:13:29 --> No URI present. Default controller set.
INFO - 2022-08-18 18:13:29 --> Router Class Initialized
INFO - 2022-08-18 18:13:29 --> Output Class Initialized
INFO - 2022-08-18 18:13:29 --> Security Class Initialized
DEBUG - 2022-08-18 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:13:29 --> Input Class Initialized
INFO - 2022-08-18 18:13:29 --> Language Class Initialized
INFO - 2022-08-18 18:13:29 --> Loader Class Initialized
INFO - 2022-08-18 18:13:29 --> Helper loaded: url_helper
INFO - 2022-08-18 18:13:29 --> Controller Class Initialized
INFO - 2022-08-18 18:13:29 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 18:13:29 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 18:13:29 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 18:13:29 --> Final output sent to browser
DEBUG - 2022-08-18 18:13:29 --> Total execution time: 0.4850
INFO - 2022-08-18 18:13:39 --> Config Class Initialized
INFO - 2022-08-18 18:13:39 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:13:39 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:13:39 --> Utf8 Class Initialized
INFO - 2022-08-18 18:13:39 --> URI Class Initialized
INFO - 2022-08-18 18:13:39 --> Router Class Initialized
INFO - 2022-08-18 18:13:39 --> Output Class Initialized
INFO - 2022-08-18 18:13:39 --> Security Class Initialized
DEBUG - 2022-08-18 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:13:39 --> Input Class Initialized
INFO - 2022-08-18 18:13:39 --> Language Class Initialized
INFO - 2022-08-18 18:13:39 --> Loader Class Initialized
INFO - 2022-08-18 18:13:39 --> Helper loaded: url_helper
INFO - 2022-08-18 18:13:39 --> Controller Class Initialized
DEBUG - 2022-08-18 18:13:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-18 18:13:39 --> Helper loaded: inflector_helper
INFO - 2022-08-18 18:13:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-18 18:13:39 --> Final output sent to browser
DEBUG - 2022-08-18 18:13:39 --> Total execution time: 0.6375
INFO - 2022-08-18 18:13:44 --> Config Class Initialized
INFO - 2022-08-18 18:13:44 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:13:44 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:13:44 --> Utf8 Class Initialized
INFO - 2022-08-18 18:13:44 --> URI Class Initialized
INFO - 2022-08-18 18:13:44 --> Router Class Initialized
INFO - 2022-08-18 18:13:44 --> Output Class Initialized
INFO - 2022-08-18 18:13:44 --> Security Class Initialized
DEBUG - 2022-08-18 18:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:13:44 --> Input Class Initialized
INFO - 2022-08-18 18:13:44 --> Language Class Initialized
ERROR - 2022-08-18 18:13:44 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 18:13:51 --> Config Class Initialized
INFO - 2022-08-18 18:13:51 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:13:51 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:13:51 --> Utf8 Class Initialized
INFO - 2022-08-18 18:13:51 --> URI Class Initialized
DEBUG - 2022-08-18 18:13:51 --> No URI present. Default controller set.
INFO - 2022-08-18 18:13:51 --> Router Class Initialized
INFO - 2022-08-18 18:13:51 --> Output Class Initialized
INFO - 2022-08-18 18:13:51 --> Security Class Initialized
DEBUG - 2022-08-18 18:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:13:51 --> Input Class Initialized
INFO - 2022-08-18 18:13:52 --> Language Class Initialized
INFO - 2022-08-18 18:13:52 --> Loader Class Initialized
INFO - 2022-08-18 18:13:52 --> Helper loaded: url_helper
INFO - 2022-08-18 18:13:52 --> Controller Class Initialized
INFO - 2022-08-18 18:13:52 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 18:13:52 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 18:13:52 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 18:13:52 --> Final output sent to browser
DEBUG - 2022-08-18 18:13:52 --> Total execution time: 0.4548
INFO - 2022-08-18 18:13:52 --> Config Class Initialized
INFO - 2022-08-18 18:13:52 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:13:52 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:13:52 --> Utf8 Class Initialized
INFO - 2022-08-18 18:13:52 --> URI Class Initialized
INFO - 2022-08-18 18:13:52 --> Router Class Initialized
INFO - 2022-08-18 18:13:52 --> Output Class Initialized
INFO - 2022-08-18 18:13:52 --> Security Class Initialized
DEBUG - 2022-08-18 18:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:13:52 --> Input Class Initialized
INFO - 2022-08-18 18:13:52 --> Language Class Initialized
ERROR - 2022-08-18 18:13:52 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 18:14:49 --> Config Class Initialized
INFO - 2022-08-18 18:14:49 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:14:49 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:14:49 --> Utf8 Class Initialized
INFO - 2022-08-18 18:14:49 --> URI Class Initialized
DEBUG - 2022-08-18 18:14:49 --> No URI present. Default controller set.
INFO - 2022-08-18 18:14:49 --> Router Class Initialized
INFO - 2022-08-18 18:14:49 --> Output Class Initialized
INFO - 2022-08-18 18:14:49 --> Security Class Initialized
DEBUG - 2022-08-18 18:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:14:49 --> Input Class Initialized
INFO - 2022-08-18 18:14:49 --> Language Class Initialized
INFO - 2022-08-18 18:14:49 --> Loader Class Initialized
INFO - 2022-08-18 18:14:49 --> Helper loaded: url_helper
INFO - 2022-08-18 18:14:49 --> Controller Class Initialized
INFO - 2022-08-18 18:14:49 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 18:14:49 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 18:14:49 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 18:14:49 --> Final output sent to browser
DEBUG - 2022-08-18 18:14:49 --> Total execution time: 0.5988
INFO - 2022-08-18 18:14:50 --> Config Class Initialized
INFO - 2022-08-18 18:14:50 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:14:50 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:14:50 --> Utf8 Class Initialized
INFO - 2022-08-18 18:14:50 --> URI Class Initialized
INFO - 2022-08-18 18:14:50 --> Router Class Initialized
INFO - 2022-08-18 18:14:50 --> Output Class Initialized
INFO - 2022-08-18 18:14:50 --> Security Class Initialized
DEBUG - 2022-08-18 18:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:14:50 --> Input Class Initialized
INFO - 2022-08-18 18:14:50 --> Language Class Initialized
ERROR - 2022-08-18 18:14:50 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-18 18:26:14 --> Config Class Initialized
INFO - 2022-08-18 18:26:14 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:26:14 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:26:14 --> Utf8 Class Initialized
INFO - 2022-08-18 18:26:14 --> URI Class Initialized
DEBUG - 2022-08-18 18:26:14 --> No URI present. Default controller set.
INFO - 2022-08-18 18:26:14 --> Router Class Initialized
INFO - 2022-08-18 18:26:14 --> Output Class Initialized
INFO - 2022-08-18 18:26:14 --> Security Class Initialized
DEBUG - 2022-08-18 18:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:26:14 --> Input Class Initialized
INFO - 2022-08-18 18:26:14 --> Language Class Initialized
ERROR - 2022-08-18 18:26:14 --> Severity: error --> Exception: syntax error, unexpected 'frontend' (T_STRING) /sam_tool/application/controllers/Frontend.php 235
INFO - 2022-08-18 18:32:16 --> Config Class Initialized
INFO - 2022-08-18 18:32:16 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:32:16 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:32:16 --> Utf8 Class Initialized
INFO - 2022-08-18 18:32:16 --> URI Class Initialized
DEBUG - 2022-08-18 18:32:16 --> No URI present. Default controller set.
INFO - 2022-08-18 18:32:16 --> Router Class Initialized
INFO - 2022-08-18 18:32:16 --> Output Class Initialized
INFO - 2022-08-18 18:32:16 --> Security Class Initialized
DEBUG - 2022-08-18 18:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:32:16 --> Input Class Initialized
INFO - 2022-08-18 18:32:16 --> Language Class Initialized
ERROR - 2022-08-18 18:32:16 --> Severity: error --> Exception: syntax error, unexpected 'frontend' (T_STRING) /sam_tool/application/controllers/Frontend.php 235
INFO - 2022-08-18 18:33:38 --> Config Class Initialized
INFO - 2022-08-18 18:33:38 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:33:38 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:33:39 --> Utf8 Class Initialized
INFO - 2022-08-18 18:33:39 --> URI Class Initialized
DEBUG - 2022-08-18 18:33:39 --> No URI present. Default controller set.
INFO - 2022-08-18 18:33:39 --> Router Class Initialized
INFO - 2022-08-18 18:33:39 --> Output Class Initialized
INFO - 2022-08-18 18:33:39 --> Security Class Initialized
DEBUG - 2022-08-18 18:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:33:39 --> Input Class Initialized
INFO - 2022-08-18 18:33:39 --> Language Class Initialized
INFO - 2022-08-18 18:33:39 --> Loader Class Initialized
INFO - 2022-08-18 18:33:39 --> Helper loaded: url_helper
INFO - 2022-08-18 18:33:39 --> Controller Class Initialized
INFO - 2022-08-18 18:33:39 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-18 18:33:39 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-18 18:33:39 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-18 18:33:39 --> Final output sent to browser
DEBUG - 2022-08-18 18:33:39 --> Total execution time: 0.3760
INFO - 2022-08-18 18:36:20 --> Config Class Initialized
INFO - 2022-08-18 18:36:20 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:36:20 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:36:20 --> Utf8 Class Initialized
INFO - 2022-08-18 18:36:20 --> URI Class Initialized
DEBUG - 2022-08-18 18:36:20 --> No URI present. Default controller set.
INFO - 2022-08-18 18:36:20 --> Router Class Initialized
INFO - 2022-08-18 18:36:20 --> Output Class Initialized
INFO - 2022-08-18 18:36:20 --> Security Class Initialized
DEBUG - 2022-08-18 18:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:36:20 --> Input Class Initialized
INFO - 2022-08-18 18:36:20 --> Language Class Initialized
ERROR - 2022-08-18 18:36:20 --> Severity: error --> Exception: syntax error, unexpected 'frontend' (T_STRING) /sam_tool/application/controllers/Frontend.php 235
INFO - 2022-08-18 18:39:31 --> Config Class Initialized
INFO - 2022-08-18 18:39:31 --> Hooks Class Initialized
DEBUG - 2022-08-18 18:39:31 --> UTF-8 Support Enabled
INFO - 2022-08-18 18:39:31 --> Utf8 Class Initialized
INFO - 2022-08-18 18:39:31 --> URI Class Initialized
DEBUG - 2022-08-18 18:39:31 --> No URI present. Default controller set.
INFO - 2022-08-18 18:39:31 --> Router Class Initialized
INFO - 2022-08-18 18:39:31 --> Output Class Initialized
INFO - 2022-08-18 18:39:31 --> Security Class Initialized
DEBUG - 2022-08-18 18:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-18 18:39:31 --> Input Class Initialized
INFO - 2022-08-18 18:39:31 --> Language Class Initialized
ERROR - 2022-08-18 18:39:31 --> Severity: error --> Exception: syntax error, unexpected 'frontend' (T_STRING) /sam_tool/application/controllers/Frontend.php 235
