<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-28 13:44:13 --> Some variable did not contain a value.
ERROR - 2022-07-28 13:44:13 --> Some variable did not contain a value.
ERROR - 2022-07-28 13:44:13 --> Some variable did not contain a value.
ERROR - 2022-07-28 13:44:13 --> Some variable did not contain a value.
ERROR - 2022-07-28 13:44:13 --> Some variable did not contain a value.
ERROR - 2022-07-28 13:44:14 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 13:44:17 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-07-28 13:44:17 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-07-28 13:44:17 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-07-28 13:44:17 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-07-28 13:44:17 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-07-28 13:44:17 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-07-28 13:45:15 --> 404 Page Not Found: Frontend/profile
ERROR - 2022-07-28 16:21:33 --> Some variable did not contain a value.
ERROR - 2022-07-28 16:21:33 --> Some variable did not contain a value.
ERROR - 2022-07-28 16:21:33 --> Some variable did not contain a value.
ERROR - 2022-07-28 16:21:33 --> Some variable did not contain a value.
ERROR - 2022-07-28 16:21:33 --> Some variable did not contain a value.
ERROR - 2022-07-28 16:21:33 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 17:17:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-28 17:20:03 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:03 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:03 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:03 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:03 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:03 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 17:20:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:14 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 17:20:23 --> 404 Page Not Found: Table/index
ERROR - 2022-07-28 17:20:31 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:31 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 17:20:32 --> 404 Page Not Found: Frontend/favicon.ico
ERROR - 2022-07-28 17:20:38 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:38 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:38 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:38 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:38 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:20:38 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 17:21:58 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-07-28 17:21:58 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-07-28 17:21:58 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-07-28 17:21:58 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-07-28 17:21:58 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-07-28 17:21:58 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-07-28 17:24:16 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:24:16 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:24:16 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:24:16 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:24:16 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:24:16 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 17:59:57 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:59:57 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:59:57 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:59:57 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:59:57 --> Some variable did not contain a value.
ERROR - 2022-07-28 17:59:57 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 18:03:42 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-07-28 18:03:42 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-07-28 18:03:42 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-07-28 18:03:42 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-07-28 18:03:42 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-07-28 18:03:42 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-07-28 18:03:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-28 18:04:08 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:04:08 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:04:08 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:04:08 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:04:08 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:04:08 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-28 18:04:15 --> 404 Page Not Found: Frontend/favicon.ico
ERROR - 2022-07-28 18:06:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-28 18:08:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-28 18:08:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:08:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:08:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:08:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:08:14 --> Some variable did not contain a value.
ERROR - 2022-07-28 18:08:14 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
