<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-09 12:41:20 --> Config Class Initialized
INFO - 2022-08-09 12:41:20 --> Hooks Class Initialized
DEBUG - 2022-08-09 12:41:20 --> UTF-8 Support Enabled
INFO - 2022-08-09 12:41:20 --> Utf8 Class Initialized
INFO - 2022-08-09 12:41:20 --> URI Class Initialized
DEBUG - 2022-08-09 12:41:20 --> No URI present. Default controller set.
INFO - 2022-08-09 12:41:20 --> Router Class Initialized
INFO - 2022-08-09 12:41:20 --> Output Class Initialized
INFO - 2022-08-09 12:41:20 --> Security Class Initialized
DEBUG - 2022-08-09 12:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-09 12:41:20 --> Input Class Initialized
INFO - 2022-08-09 12:41:20 --> Language Class Initialized
INFO - 2022-08-09 12:41:20 --> Loader Class Initialized
INFO - 2022-08-09 12:41:20 --> Helper loaded: url_helper
INFO - 2022-08-09 12:41:20 --> Controller Class Initialized
INFO - 2022-08-09 12:41:20 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-09 12:41:20 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-09 12:41:20 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-09 12:41:20 --> Final output sent to browser
DEBUG - 2022-08-09 12:41:20 --> Total execution time: 0.7053
