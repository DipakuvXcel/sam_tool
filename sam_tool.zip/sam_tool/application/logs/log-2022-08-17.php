INFO - 2022-08-17 14:15:58 --> Config Class Initialized
INFO - 2022-08-17 14:15:58 --> Hooks Class Initialized
DEBUG - 2022-08-17 14:15:59 --> UTF-8 Support Enabled
INFO - 2022-08-17 14:15:59 --> Utf8 Class Initialized
INFO - 2022-08-17 14:15:59 --> URI Class Initialized
INFO - 2022-08-17 14:15:59 --> Router Class Initialized
INFO - 2022-08-17 14:15:59 --> Output Class Initialized
INFO - 2022-08-17 14:15:59 --> Security Class Initialized
DEBUG - 2022-08-17 14:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 14:15:59 --> Input Class Initialized
INFO - 2022-08-17 14:15:59 --> Language Class Initialized
INFO - 2022-08-17 14:15:59 --> Loader Class Initialized
INFO - 2022-08-17 14:15:59 --> Helper loaded: url_helper
INFO - 2022-08-17 14:15:59 --> Controller Class Initialized
DEBUG - 2022-08-17 14:15:59 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 14:15:59 --> Helper loaded: inflector_helper
INFO - 2022-08-17 14:15:59 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-17 14:15:59 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /sam_tool/application/controllers/Sam.php 45
ERROR - 2022-08-17 14:15:59 --> 
ERROR - 2022-08-17 14:15:59 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /sam_tool/application/controllers/Sam.php 52
INFO - 2022-08-17 14:15:59 --> Final output sent to browser
DEBUG - 2022-08-17 14:15:59 --> Total execution time: 0.6105
INFO - 2022-08-17 14:17:13 --> Config Class Initialized
INFO - 2022-08-17 14:17:13 --> Hooks Class Initialized
DEBUG - 2022-08-17 14:17:13 --> UTF-8 Support Enabled
INFO - 2022-08-17 14:17:13 --> Utf8 Class Initialized
INFO - 2022-08-17 14:17:13 --> URI Class Initialized
INFO - 2022-08-17 14:17:13 --> Router Class Initialized
INFO - 2022-08-17 14:17:13 --> Output Class Initialized
INFO - 2022-08-17 14:17:13 --> Security Class Initialized
DEBUG - 2022-08-17 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 14:17:13 --> Input Class Initialized
INFO - 2022-08-17 14:17:13 --> Language Class Initialized
INFO - 2022-08-17 14:17:13 --> Loader Class Initialized
INFO - 2022-08-17 14:17:13 --> Helper loaded: url_helper
INFO - 2022-08-17 14:17:13 --> Controller Class Initialized
DEBUG - 2022-08-17 14:17:13 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 14:17:13 --> Helper loaded: inflector_helper
INFO - 2022-08-17 14:17:13 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-17 14:17:13 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /sam_tool/application/controllers/Sam.php 45
ERROR - 2022-08-17 14:17:13 --> 
ERROR - 2022-08-17 14:17:13 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /sam_tool/application/controllers/Sam.php 53
INFO - 2022-08-17 14:17:13 --> Final output sent to browser
DEBUG - 2022-08-17 14:17:13 --> Total execution time: 0.6611
INFO - 2022-08-17 14:17:27 --> Config Class Initialized
INFO - 2022-08-17 14:17:27 --> Hooks Class Initialized
DEBUG - 2022-08-17 14:17:27 --> UTF-8 Support Enabled
INFO - 2022-08-17 14:17:27 --> Utf8 Class Initialized
INFO - 2022-08-17 14:17:27 --> URI Class Initialized
INFO - 2022-08-17 14:17:27 --> Router Class Initialized
INFO - 2022-08-17 14:17:28 --> Output Class Initialized
INFO - 2022-08-17 14:17:28 --> Security Class Initialized
DEBUG - 2022-08-17 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 14:17:28 --> Input Class Initialized
INFO - 2022-08-17 14:17:28 --> Language Class Initialized
INFO - 2022-08-17 14:17:28 --> Loader Class Initialized
INFO - 2022-08-17 14:17:28 --> Helper loaded: url_helper
INFO - 2022-08-17 14:17:28 --> Controller Class Initialized
DEBUG - 2022-08-17 14:17:28 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 14:17:28 --> Helper loaded: inflector_helper
INFO - 2022-08-17 14:17:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 14:17:28 --> Final output sent to browser
DEBUG - 2022-08-17 14:17:28 --> Total execution time: 0.6250
INFO - 2022-08-17 16:49:17 --> Config Class Initialized
INFO - 2022-08-17 16:49:17 --> Hooks Class Initialized
DEBUG - 2022-08-17 16:49:17 --> UTF-8 Support Enabled
INFO - 2022-08-17 16:49:17 --> Utf8 Class Initialized
INFO - 2022-08-17 16:49:17 --> URI Class Initialized
DEBUG - 2022-08-17 16:49:17 --> No URI present. Default controller set.
INFO - 2022-08-17 16:49:17 --> Router Class Initialized
INFO - 2022-08-17 16:49:17 --> Output Class Initialized
INFO - 2022-08-17 16:49:17 --> Security Class Initialized
DEBUG - 2022-08-17 16:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 16:49:17 --> Input Class Initialized
INFO - 2022-08-17 16:49:17 --> Language Class Initialized
INFO - 2022-08-17 16:49:17 --> Loader Class Initialized
INFO - 2022-08-17 16:49:17 --> Helper loaded: url_helper
INFO - 2022-08-17 16:49:17 --> Controller Class Initialized
INFO - 2022-08-17 16:49:18 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-17 16:49:18 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-17 16:49:18 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-17 16:49:18 --> Final output sent to browser
DEBUG - 2022-08-17 16:49:18 --> Total execution time: 0.5338
INFO - 2022-08-17 16:49:22 --> Config Class Initialized
INFO - 2022-08-17 16:49:22 --> Hooks Class Initialized
DEBUG - 2022-08-17 16:49:22 --> UTF-8 Support Enabled
INFO - 2022-08-17 16:49:22 --> Utf8 Class Initialized
INFO - 2022-08-17 16:49:22 --> URI Class Initialized
INFO - 2022-08-17 16:49:22 --> Router Class Initialized
INFO - 2022-08-17 16:49:22 --> Output Class Initialized
INFO - 2022-08-17 16:49:22 --> Security Class Initialized
DEBUG - 2022-08-17 16:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 16:49:22 --> Input Class Initialized
INFO - 2022-08-17 16:49:22 --> Language Class Initialized
INFO - 2022-08-17 16:49:22 --> Loader Class Initialized
INFO - 2022-08-17 16:49:22 --> Helper loaded: url_helper
INFO - 2022-08-17 16:49:22 --> Controller Class Initialized
DEBUG - 2022-08-17 16:49:22 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 16:49:22 --> Helper loaded: inflector_helper
INFO - 2022-08-17 16:49:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 16:49:22 --> Final output sent to browser
DEBUG - 2022-08-17 16:49:23 --> Total execution time: 0.5725
INFO - 2022-08-17 16:49:23 --> Config Class Initialized
INFO - 2022-08-17 16:49:23 --> Hooks Class Initialized
DEBUG - 2022-08-17 16:49:23 --> UTF-8 Support Enabled
INFO - 2022-08-17 16:49:23 --> Utf8 Class Initialized
INFO - 2022-08-17 16:49:23 --> URI Class Initialized
INFO - 2022-08-17 16:49:23 --> Router Class Initialized
INFO - 2022-08-17 16:49:23 --> Output Class Initialized
INFO - 2022-08-17 16:49:23 --> Security Class Initialized
DEBUG - 2022-08-17 16:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 16:49:23 --> Input Class Initialized
INFO - 2022-08-17 16:49:23 --> Language Class Initialized
ERROR - 2022-08-17 16:49:23 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-17 17:48:58 --> Config Class Initialized
INFO - 2022-08-17 17:48:58 --> Hooks Class Initialized
DEBUG - 2022-08-17 17:48:58 --> UTF-8 Support Enabled
INFO - 2022-08-17 17:48:58 --> Utf8 Class Initialized
INFO - 2022-08-17 17:48:58 --> URI Class Initialized
INFO - 2022-08-17 17:48:59 --> Router Class Initialized
INFO - 2022-08-17 17:48:59 --> Output Class Initialized
INFO - 2022-08-17 17:48:59 --> Security Class Initialized
DEBUG - 2022-08-17 17:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 17:48:59 --> Input Class Initialized
INFO - 2022-08-17 17:48:59 --> Language Class Initialized
ERROR - 2022-08-17 17:48:59 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-17 17:53:24 --> Config Class Initialized
INFO - 2022-08-17 17:53:24 --> Hooks Class Initialized
DEBUG - 2022-08-17 17:53:24 --> UTF-8 Support Enabled
INFO - 2022-08-17 17:53:24 --> Utf8 Class Initialized
INFO - 2022-08-17 17:53:24 --> URI Class Initialized
INFO - 2022-08-17 17:53:24 --> Router Class Initialized
INFO - 2022-08-17 17:53:24 --> Output Class Initialized
INFO - 2022-08-17 17:53:24 --> Security Class Initialized
DEBUG - 2022-08-17 17:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 17:53:24 --> Input Class Initialized
INFO - 2022-08-17 17:53:24 --> Language Class Initialized
INFO - 2022-08-17 17:53:24 --> Loader Class Initialized
INFO - 2022-08-17 17:53:24 --> Helper loaded: url_helper
INFO - 2022-08-17 17:53:24 --> Controller Class Initialized
DEBUG - 2022-08-17 17:53:24 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 17:53:24 --> Helper loaded: inflector_helper
INFO - 2022-08-17 17:53:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 17:53:24 --> Final output sent to browser
DEBUG - 2022-08-17 17:53:24 --> Total execution time: 0.2202
INFO - 2022-08-17 17:55:24 --> Config Class Initialized
INFO - 2022-08-17 17:55:24 --> Hooks Class Initialized
DEBUG - 2022-08-17 17:55:24 --> UTF-8 Support Enabled
INFO - 2022-08-17 17:55:24 --> Utf8 Class Initialized
INFO - 2022-08-17 17:55:24 --> URI Class Initialized
INFO - 2022-08-17 17:55:24 --> Router Class Initialized
INFO - 2022-08-17 17:55:24 --> Output Class Initialized
INFO - 2022-08-17 17:55:24 --> Security Class Initialized
DEBUG - 2022-08-17 17:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 17:55:24 --> Input Class Initialized
INFO - 2022-08-17 17:55:24 --> Language Class Initialized
INFO - 2022-08-17 17:55:24 --> Loader Class Initialized
INFO - 2022-08-17 17:55:24 --> Helper loaded: url_helper
INFO - 2022-08-17 17:55:24 --> Controller Class Initialized
DEBUG - 2022-08-17 17:55:24 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 17:55:24 --> Helper loaded: inflector_helper
INFO - 2022-08-17 17:55:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 17:55:24 --> Final output sent to browser
DEBUG - 2022-08-17 17:55:24 --> Total execution time: 0.2288
INFO - 2022-08-17 17:56:20 --> Config Class Initialized
INFO - 2022-08-17 17:56:20 --> Hooks Class Initialized
DEBUG - 2022-08-17 17:56:20 --> UTF-8 Support Enabled
INFO - 2022-08-17 17:56:20 --> Utf8 Class Initialized
INFO - 2022-08-17 17:56:20 --> URI Class Initialized
INFO - 2022-08-17 17:56:20 --> Router Class Initialized
INFO - 2022-08-17 17:56:20 --> Output Class Initialized
INFO - 2022-08-17 17:56:20 --> Security Class Initialized
DEBUG - 2022-08-17 17:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 17:56:20 --> Input Class Initialized
INFO - 2022-08-17 17:56:20 --> Language Class Initialized
INFO - 2022-08-17 17:56:21 --> Loader Class Initialized
INFO - 2022-08-17 17:56:21 --> Helper loaded: url_helper
INFO - 2022-08-17 17:56:21 --> Controller Class Initialized
DEBUG - 2022-08-17 17:56:21 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 17:56:21 --> Helper loaded: inflector_helper
INFO - 2022-08-17 17:56:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 17:56:21 --> Final output sent to browser
DEBUG - 2022-08-17 17:56:21 --> Total execution time: 0.2003
INFO - 2022-08-17 17:56:34 --> Config Class Initialized
INFO - 2022-08-17 17:56:34 --> Hooks Class Initialized
DEBUG - 2022-08-17 17:56:34 --> UTF-8 Support Enabled
INFO - 2022-08-17 17:56:34 --> Utf8 Class Initialized
INFO - 2022-08-17 17:56:34 --> URI Class Initialized
INFO - 2022-08-17 17:56:34 --> Router Class Initialized
INFO - 2022-08-17 17:56:34 --> Output Class Initialized
INFO - 2022-08-17 17:56:34 --> Security Class Initialized
DEBUG - 2022-08-17 17:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 17:56:34 --> Input Class Initialized
INFO - 2022-08-17 17:56:34 --> Language Class Initialized
INFO - 2022-08-17 17:56:34 --> Loader Class Initialized
INFO - 2022-08-17 17:56:34 --> Helper loaded: url_helper
INFO - 2022-08-17 17:56:34 --> Controller Class Initialized
DEBUG - 2022-08-17 17:56:34 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 17:56:34 --> Helper loaded: inflector_helper
INFO - 2022-08-17 17:56:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 17:56:34 --> Final output sent to browser
DEBUG - 2022-08-17 17:56:34 --> Total execution time: 0.1699
INFO - 2022-08-17 18:00:06 --> Config Class Initialized
INFO - 2022-08-17 18:00:06 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:00:06 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:00:06 --> Utf8 Class Initialized
INFO - 2022-08-17 18:00:06 --> URI Class Initialized
INFO - 2022-08-17 18:00:06 --> Router Class Initialized
INFO - 2022-08-17 18:00:06 --> Output Class Initialized
INFO - 2022-08-17 18:00:06 --> Security Class Initialized
DEBUG - 2022-08-17 18:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:00:06 --> Input Class Initialized
INFO - 2022-08-17 18:00:06 --> Language Class Initialized
INFO - 2022-08-17 18:00:06 --> Loader Class Initialized
INFO - 2022-08-17 18:00:06 --> Helper loaded: url_helper
INFO - 2022-08-17 18:00:06 --> Controller Class Initialized
DEBUG - 2022-08-17 18:00:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:00:06 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:00:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:00:06 --> Final output sent to browser
DEBUG - 2022-08-17 18:00:06 --> Total execution time: 0.2386
INFO - 2022-08-17 18:04:22 --> Config Class Initialized
INFO - 2022-08-17 18:04:22 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:04:22 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:04:22 --> Utf8 Class Initialized
INFO - 2022-08-17 18:04:22 --> URI Class Initialized
INFO - 2022-08-17 18:04:22 --> Router Class Initialized
INFO - 2022-08-17 18:04:22 --> Output Class Initialized
INFO - 2022-08-17 18:04:22 --> Security Class Initialized
DEBUG - 2022-08-17 18:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:04:23 --> Input Class Initialized
INFO - 2022-08-17 18:04:23 --> Language Class Initialized
INFO - 2022-08-17 18:04:23 --> Loader Class Initialized
INFO - 2022-08-17 18:04:23 --> Helper loaded: url_helper
INFO - 2022-08-17 18:04:23 --> Controller Class Initialized
DEBUG - 2022-08-17 18:04:23 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:04:23 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:04:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:04:23 --> Final output sent to browser
DEBUG - 2022-08-17 18:04:23 --> Total execution time: 0.2280
INFO - 2022-08-17 18:05:16 --> Config Class Initialized
INFO - 2022-08-17 18:05:16 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:05:16 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:05:16 --> Utf8 Class Initialized
INFO - 2022-08-17 18:05:16 --> URI Class Initialized
INFO - 2022-08-17 18:05:16 --> Router Class Initialized
INFO - 2022-08-17 18:05:16 --> Output Class Initialized
INFO - 2022-08-17 18:05:16 --> Security Class Initialized
DEBUG - 2022-08-17 18:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:05:16 --> Input Class Initialized
INFO - 2022-08-17 18:05:16 --> Language Class Initialized
INFO - 2022-08-17 18:05:16 --> Loader Class Initialized
INFO - 2022-08-17 18:05:16 --> Helper loaded: url_helper
INFO - 2022-08-17 18:05:16 --> Controller Class Initialized
DEBUG - 2022-08-17 18:05:16 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:05:16 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:05:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:05:16 --> Final output sent to browser
DEBUG - 2022-08-17 18:05:16 --> Total execution time: 0.2425
INFO - 2022-08-17 18:06:54 --> Config Class Initialized
INFO - 2022-08-17 18:06:54 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:06:54 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:06:54 --> Utf8 Class Initialized
INFO - 2022-08-17 18:06:54 --> URI Class Initialized
INFO - 2022-08-17 18:06:54 --> Router Class Initialized
INFO - 2022-08-17 18:06:54 --> Output Class Initialized
INFO - 2022-08-17 18:06:54 --> Security Class Initialized
DEBUG - 2022-08-17 18:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:06:54 --> Input Class Initialized
INFO - 2022-08-17 18:06:54 --> Language Class Initialized
INFO - 2022-08-17 18:06:54 --> Loader Class Initialized
INFO - 2022-08-17 18:06:54 --> Helper loaded: url_helper
INFO - 2022-08-17 18:06:54 --> Controller Class Initialized
DEBUG - 2022-08-17 18:06:54 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:06:54 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:06:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:06:54 --> Final output sent to browser
DEBUG - 2022-08-17 18:06:54 --> Total execution time: 0.2350
INFO - 2022-08-17 18:09:26 --> Config Class Initialized
INFO - 2022-08-17 18:09:26 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:09:26 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:09:26 --> Utf8 Class Initialized
INFO - 2022-08-17 18:09:26 --> URI Class Initialized
INFO - 2022-08-17 18:09:26 --> Router Class Initialized
INFO - 2022-08-17 18:09:26 --> Output Class Initialized
INFO - 2022-08-17 18:09:26 --> Security Class Initialized
DEBUG - 2022-08-17 18:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:09:26 --> Input Class Initialized
INFO - 2022-08-17 18:09:26 --> Language Class Initialized
INFO - 2022-08-17 18:09:26 --> Loader Class Initialized
INFO - 2022-08-17 18:09:26 --> Helper loaded: url_helper
INFO - 2022-08-17 18:09:26 --> Controller Class Initialized
DEBUG - 2022-08-17 18:09:26 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:09:26 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:09:26 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-17 18:09:26 --> Severity: Warning --> strpos() expects at most 3 parameters, 7 given /sam_tool/application/controllers/Sam.php 55
INFO - 2022-08-17 18:09:26 --> Final output sent to browser
DEBUG - 2022-08-17 18:09:26 --> Total execution time: 0.2239
INFO - 2022-08-17 18:12:01 --> Config Class Initialized
INFO - 2022-08-17 18:12:01 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:12:01 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:12:01 --> Utf8 Class Initialized
INFO - 2022-08-17 18:12:01 --> URI Class Initialized
INFO - 2022-08-17 18:12:01 --> Router Class Initialized
INFO - 2022-08-17 18:12:01 --> Output Class Initialized
INFO - 2022-08-17 18:12:01 --> Security Class Initialized
DEBUG - 2022-08-17 18:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:12:01 --> Input Class Initialized
INFO - 2022-08-17 18:12:01 --> Language Class Initialized
INFO - 2022-08-17 18:12:01 --> Loader Class Initialized
INFO - 2022-08-17 18:12:01 --> Helper loaded: url_helper
INFO - 2022-08-17 18:12:01 --> Controller Class Initialized
DEBUG - 2022-08-17 18:12:01 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:12:01 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:12:01 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-17 18:12:01 --> Severity: Warning --> strpos() expects at most 3 parameters, 8 given /sam_tool/application/controllers/Sam.php 55
INFO - 2022-08-17 18:12:01 --> Final output sent to browser
DEBUG - 2022-08-17 18:12:01 --> Total execution time: 0.2197
INFO - 2022-08-17 18:12:19 --> Config Class Initialized
INFO - 2022-08-17 18:12:19 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:12:19 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:12:19 --> Utf8 Class Initialized
INFO - 2022-08-17 18:12:19 --> URI Class Initialized
INFO - 2022-08-17 18:12:19 --> Router Class Initialized
INFO - 2022-08-17 18:12:19 --> Output Class Initialized
INFO - 2022-08-17 18:12:19 --> Security Class Initialized
DEBUG - 2022-08-17 18:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:12:19 --> Input Class Initialized
INFO - 2022-08-17 18:12:19 --> Language Class Initialized
ERROR - 2022-08-17 18:12:19 --> Severity: error --> Exception: syntax error, unexpected ')' /sam_tool/application/controllers/Sam.php 55
INFO - 2022-08-17 18:17:14 --> Config Class Initialized
INFO - 2022-08-17 18:17:14 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:17:14 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:17:14 --> Utf8 Class Initialized
INFO - 2022-08-17 18:17:14 --> URI Class Initialized
INFO - 2022-08-17 18:17:14 --> Router Class Initialized
INFO - 2022-08-17 18:17:14 --> Output Class Initialized
INFO - 2022-08-17 18:17:14 --> Security Class Initialized
DEBUG - 2022-08-17 18:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:17:14 --> Input Class Initialized
INFO - 2022-08-17 18:17:14 --> Language Class Initialized
ERROR - 2022-08-17 18:17:14 --> Severity: error --> Exception: syntax error, unexpected ')' /sam_tool/application/controllers/Sam.php 55
INFO - 2022-08-17 18:17:32 --> Config Class Initialized
INFO - 2022-08-17 18:17:33 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:17:33 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:17:33 --> Utf8 Class Initialized
INFO - 2022-08-17 18:17:33 --> URI Class Initialized
INFO - 2022-08-17 18:17:33 --> Router Class Initialized
INFO - 2022-08-17 18:17:33 --> Output Class Initialized
INFO - 2022-08-17 18:17:33 --> Security Class Initialized
DEBUG - 2022-08-17 18:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:17:33 --> Input Class Initialized
INFO - 2022-08-17 18:17:33 --> Language Class Initialized
INFO - 2022-08-17 18:17:33 --> Loader Class Initialized
INFO - 2022-08-17 18:17:33 --> Helper loaded: url_helper
INFO - 2022-08-17 18:17:33 --> Controller Class Initialized
DEBUG - 2022-08-17 18:17:33 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:17:33 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:17:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:17:33 --> Final output sent to browser
DEBUG - 2022-08-17 18:17:33 --> Total execution time: 0.2051
INFO - 2022-08-17 18:17:43 --> Config Class Initialized
INFO - 2022-08-17 18:17:43 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:17:43 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:17:43 --> Utf8 Class Initialized
INFO - 2022-08-17 18:17:43 --> URI Class Initialized
INFO - 2022-08-17 18:17:43 --> Router Class Initialized
INFO - 2022-08-17 18:17:43 --> Output Class Initialized
INFO - 2022-08-17 18:17:43 --> Security Class Initialized
DEBUG - 2022-08-17 18:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:17:43 --> Input Class Initialized
INFO - 2022-08-17 18:17:43 --> Language Class Initialized
INFO - 2022-08-17 18:17:43 --> Loader Class Initialized
INFO - 2022-08-17 18:17:43 --> Helper loaded: url_helper
INFO - 2022-08-17 18:17:43 --> Controller Class Initialized
DEBUG - 2022-08-17 18:17:43 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:17:43 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:17:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:17:43 --> Final output sent to browser
DEBUG - 2022-08-17 18:17:43 --> Total execution time: 0.2154
INFO - 2022-08-17 18:21:10 --> Config Class Initialized
INFO - 2022-08-17 18:21:10 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:21:10 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:21:10 --> Utf8 Class Initialized
INFO - 2022-08-17 18:21:10 --> URI Class Initialized
INFO - 2022-08-17 18:21:10 --> Router Class Initialized
INFO - 2022-08-17 18:21:10 --> Output Class Initialized
INFO - 2022-08-17 18:21:10 --> Security Class Initialized
DEBUG - 2022-08-17 18:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:21:10 --> Input Class Initialized
INFO - 2022-08-17 18:21:10 --> Language Class Initialized
INFO - 2022-08-17 18:21:10 --> Loader Class Initialized
INFO - 2022-08-17 18:21:10 --> Helper loaded: url_helper
INFO - 2022-08-17 18:21:10 --> Controller Class Initialized
DEBUG - 2022-08-17 18:21:10 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:21:10 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:21:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:21:10 --> Final output sent to browser
DEBUG - 2022-08-17 18:21:10 --> Total execution time: 0.2141
INFO - 2022-08-17 18:22:23 --> Config Class Initialized
INFO - 2022-08-17 18:22:23 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:22:23 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:22:23 --> Utf8 Class Initialized
INFO - 2022-08-17 18:22:23 --> URI Class Initialized
DEBUG - 2022-08-17 18:22:23 --> No URI present. Default controller set.
INFO - 2022-08-17 18:22:23 --> Router Class Initialized
INFO - 2022-08-17 18:22:23 --> Output Class Initialized
INFO - 2022-08-17 18:22:23 --> Security Class Initialized
DEBUG - 2022-08-17 18:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:22:23 --> Input Class Initialized
INFO - 2022-08-17 18:22:23 --> Language Class Initialized
INFO - 2022-08-17 18:22:23 --> Loader Class Initialized
INFO - 2022-08-17 18:22:23 --> Helper loaded: url_helper
INFO - 2022-08-17 18:22:23 --> Controller Class Initialized
INFO - 2022-08-17 18:22:23 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-17 18:22:23 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-17 18:22:23 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-17 18:22:23 --> Final output sent to browser
DEBUG - 2022-08-17 18:22:23 --> Total execution time: 0.2809
INFO - 2022-08-17 18:22:25 --> Config Class Initialized
INFO - 2022-08-17 18:22:25 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:22:25 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:22:25 --> Utf8 Class Initialized
INFO - 2022-08-17 18:22:25 --> URI Class Initialized
INFO - 2022-08-17 18:22:25 --> Router Class Initialized
INFO - 2022-08-17 18:22:26 --> Output Class Initialized
INFO - 2022-08-17 18:22:26 --> Security Class Initialized
DEBUG - 2022-08-17 18:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:22:26 --> Input Class Initialized
INFO - 2022-08-17 18:22:26 --> Language Class Initialized
INFO - 2022-08-17 18:22:26 --> Loader Class Initialized
INFO - 2022-08-17 18:22:26 --> Helper loaded: url_helper
INFO - 2022-08-17 18:22:26 --> Controller Class Initialized
INFO - 2022-08-17 18:22:26 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-17 18:22:26 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-17 18:22:26 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-17 18:22:26 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-17 18:22:26 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-17 18:22:26 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-17 18:22:26 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
INFO - 2022-08-17 18:22:32 --> Config Class Initialized
INFO - 2022-08-17 18:22:32 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:22:32 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:22:32 --> Utf8 Class Initialized
INFO - 2022-08-17 18:22:32 --> URI Class Initialized
INFO - 2022-08-17 18:22:32 --> Router Class Initialized
INFO - 2022-08-17 18:22:32 --> Output Class Initialized
INFO - 2022-08-17 18:22:32 --> Security Class Initialized
DEBUG - 2022-08-17 18:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:22:32 --> Input Class Initialized
INFO - 2022-08-17 18:22:32 --> Language Class Initialized
INFO - 2022-08-17 18:22:32 --> Loader Class Initialized
INFO - 2022-08-17 18:22:32 --> Helper loaded: url_helper
INFO - 2022-08-17 18:22:32 --> Controller Class Initialized
DEBUG - 2022-08-17 18:22:32 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:22:32 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:22:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:22:32 --> Final output sent to browser
DEBUG - 2022-08-17 18:22:32 --> Total execution time: 0.1680
INFO - 2022-08-17 18:26:16 --> Config Class Initialized
INFO - 2022-08-17 18:26:16 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:26:16 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:26:16 --> Utf8 Class Initialized
INFO - 2022-08-17 18:26:16 --> URI Class Initialized
INFO - 2022-08-17 18:26:16 --> Router Class Initialized
INFO - 2022-08-17 18:26:16 --> Output Class Initialized
INFO - 2022-08-17 18:26:16 --> Security Class Initialized
DEBUG - 2022-08-17 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:26:16 --> Input Class Initialized
INFO - 2022-08-17 18:26:16 --> Language Class Initialized
INFO - 2022-08-17 18:26:16 --> Loader Class Initialized
INFO - 2022-08-17 18:26:16 --> Helper loaded: url_helper
INFO - 2022-08-17 18:26:16 --> Controller Class Initialized
DEBUG - 2022-08-17 18:26:16 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:26:16 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:26:16 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-17 18:26:16 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/controllers/Sam.php 48
ERROR - 2022-08-17 18:26:16 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/controllers/Sam.php 48
ERROR - 2022-08-17 18:26:16 --> Severity: Warning --> Division by zero /sam_tool/application/controllers/Sam.php 48
ERROR - 2022-08-17 18:26:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/application/controllers/Sam.php 48
INFO - 2022-08-17 18:26:16 --> Final output sent to browser
DEBUG - 2022-08-17 18:26:16 --> Total execution time: 0.2607
INFO - 2022-08-17 18:27:30 --> Config Class Initialized
INFO - 2022-08-17 18:27:30 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:27:30 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:27:30 --> Utf8 Class Initialized
INFO - 2022-08-17 18:27:30 --> URI Class Initialized
INFO - 2022-08-17 18:27:30 --> Router Class Initialized
INFO - 2022-08-17 18:27:30 --> Output Class Initialized
INFO - 2022-08-17 18:27:30 --> Security Class Initialized
DEBUG - 2022-08-17 18:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:27:30 --> Input Class Initialized
INFO - 2022-08-17 18:27:30 --> Language Class Initialized
ERROR - 2022-08-17 18:27:30 --> Severity: error --> Exception: syntax error, unexpected 'Content' (T_STRING), expecting ',' or ')' /sam_tool/application/controllers/Sam.php 53
INFO - 2022-08-17 18:28:32 --> Config Class Initialized
INFO - 2022-08-17 18:28:32 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:28:32 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:28:32 --> Utf8 Class Initialized
INFO - 2022-08-17 18:28:32 --> URI Class Initialized
INFO - 2022-08-17 18:28:32 --> Router Class Initialized
INFO - 2022-08-17 18:28:32 --> Output Class Initialized
INFO - 2022-08-17 18:28:32 --> Security Class Initialized
DEBUG - 2022-08-17 18:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:28:32 --> Input Class Initialized
INFO - 2022-08-17 18:28:32 --> Language Class Initialized
INFO - 2022-08-17 18:28:32 --> Loader Class Initialized
INFO - 2022-08-17 18:28:32 --> Helper loaded: url_helper
INFO - 2022-08-17 18:28:32 --> Controller Class Initialized
DEBUG - 2022-08-17 18:28:32 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:28:32 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:28:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:28:32 --> Final output sent to browser
DEBUG - 2022-08-17 18:28:32 --> Total execution time: 0.2347
INFO - 2022-08-17 18:31:10 --> Config Class Initialized
INFO - 2022-08-17 18:31:10 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:31:10 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:31:10 --> Utf8 Class Initialized
INFO - 2022-08-17 18:31:10 --> URI Class Initialized
INFO - 2022-08-17 18:31:10 --> Router Class Initialized
INFO - 2022-08-17 18:31:10 --> Output Class Initialized
INFO - 2022-08-17 18:31:10 --> Security Class Initialized
DEBUG - 2022-08-17 18:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:31:10 --> Input Class Initialized
INFO - 2022-08-17 18:31:10 --> Language Class Initialized
INFO - 2022-08-17 18:31:10 --> Loader Class Initialized
INFO - 2022-08-17 18:31:11 --> Helper loaded: url_helper
INFO - 2022-08-17 18:31:11 --> Controller Class Initialized
DEBUG - 2022-08-17 18:31:11 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:31:11 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:31:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:31:11 --> Final output sent to browser
DEBUG - 2022-08-17 18:31:11 --> Total execution time: 0.2032
INFO - 2022-08-17 18:34:22 --> Config Class Initialized
INFO - 2022-08-17 18:34:22 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:34:22 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:34:22 --> Utf8 Class Initialized
INFO - 2022-08-17 18:34:22 --> URI Class Initialized
DEBUG - 2022-08-17 18:34:22 --> No URI present. Default controller set.
INFO - 2022-08-17 18:34:22 --> Router Class Initialized
INFO - 2022-08-17 18:34:22 --> Output Class Initialized
INFO - 2022-08-17 18:34:22 --> Security Class Initialized
DEBUG - 2022-08-17 18:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:34:22 --> Input Class Initialized
INFO - 2022-08-17 18:34:22 --> Language Class Initialized
INFO - 2022-08-17 18:34:22 --> Loader Class Initialized
INFO - 2022-08-17 18:34:22 --> Helper loaded: url_helper
INFO - 2022-08-17 18:34:22 --> Controller Class Initialized
INFO - 2022-08-17 18:34:22 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-17 18:34:22 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-17 18:34:22 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-17 18:34:22 --> Final output sent to browser
DEBUG - 2022-08-17 18:34:22 --> Total execution time: 0.2693
INFO - 2022-08-17 18:34:30 --> Config Class Initialized
INFO - 2022-08-17 18:34:30 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:34:31 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:34:31 --> Utf8 Class Initialized
INFO - 2022-08-17 18:34:31 --> URI Class Initialized
INFO - 2022-08-17 18:34:31 --> Router Class Initialized
INFO - 2022-08-17 18:34:31 --> Output Class Initialized
INFO - 2022-08-17 18:34:31 --> Security Class Initialized
DEBUG - 2022-08-17 18:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:34:31 --> Input Class Initialized
INFO - 2022-08-17 18:34:31 --> Language Class Initialized
INFO - 2022-08-17 18:34:31 --> Loader Class Initialized
INFO - 2022-08-17 18:34:31 --> Helper loaded: url_helper
INFO - 2022-08-17 18:34:31 --> Controller Class Initialized
DEBUG - 2022-08-17 18:34:31 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:34:31 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:34:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:34:31 --> Final output sent to browser
DEBUG - 2022-08-17 18:34:31 --> Total execution time: 0.2463
INFO - 2022-08-17 18:37:38 --> Config Class Initialized
INFO - 2022-08-17 18:37:38 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:37:38 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:37:38 --> Utf8 Class Initialized
INFO - 2022-08-17 18:37:38 --> URI Class Initialized
INFO - 2022-08-17 18:37:38 --> Router Class Initialized
INFO - 2022-08-17 18:37:38 --> Output Class Initialized
INFO - 2022-08-17 18:37:38 --> Security Class Initialized
DEBUG - 2022-08-17 18:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:37:38 --> Input Class Initialized
INFO - 2022-08-17 18:37:38 --> Language Class Initialized
ERROR - 2022-08-17 18:37:39 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-17 18:37:42 --> Config Class Initialized
INFO - 2022-08-17 18:37:42 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:37:42 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:37:42 --> Utf8 Class Initialized
INFO - 2022-08-17 18:37:42 --> URI Class Initialized
INFO - 2022-08-17 18:37:42 --> Router Class Initialized
INFO - 2022-08-17 18:37:42 --> Output Class Initialized
INFO - 2022-08-17 18:37:42 --> Security Class Initialized
DEBUG - 2022-08-17 18:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:37:42 --> Input Class Initialized
INFO - 2022-08-17 18:37:42 --> Language Class Initialized
INFO - 2022-08-17 18:37:42 --> Loader Class Initialized
INFO - 2022-08-17 18:37:42 --> Helper loaded: url_helper
INFO - 2022-08-17 18:37:42 --> Controller Class Initialized
DEBUG - 2022-08-17 18:37:42 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:37:42 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:37:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:37:42 --> Final output sent to browser
DEBUG - 2022-08-17 18:37:42 --> Total execution time: 0.2258
INFO - 2022-08-17 18:37:50 --> Config Class Initialized
INFO - 2022-08-17 18:37:50 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:37:50 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:37:50 --> Utf8 Class Initialized
INFO - 2022-08-17 18:37:50 --> URI Class Initialized
INFO - 2022-08-17 18:37:50 --> Router Class Initialized
INFO - 2022-08-17 18:37:50 --> Output Class Initialized
INFO - 2022-08-17 18:37:50 --> Security Class Initialized
DEBUG - 2022-08-17 18:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:37:50 --> Input Class Initialized
INFO - 2022-08-17 18:37:50 --> Language Class Initialized
INFO - 2022-08-17 18:37:50 --> Loader Class Initialized
INFO - 2022-08-17 18:37:50 --> Helper loaded: url_helper
INFO - 2022-08-17 18:37:50 --> Controller Class Initialized
DEBUG - 2022-08-17 18:37:50 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:37:50 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:37:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:37:50 --> Final output sent to browser
DEBUG - 2022-08-17 18:37:50 --> Total execution time: 0.2175
INFO - 2022-08-17 18:45:01 --> Config Class Initialized
INFO - 2022-08-17 18:45:01 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:45:02 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:45:02 --> Utf8 Class Initialized
INFO - 2022-08-17 18:45:02 --> URI Class Initialized
INFO - 2022-08-17 18:45:02 --> Router Class Initialized
INFO - 2022-08-17 18:45:02 --> Output Class Initialized
INFO - 2022-08-17 18:45:02 --> Security Class Initialized
DEBUG - 2022-08-17 18:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:45:02 --> Input Class Initialized
INFO - 2022-08-17 18:45:02 --> Language Class Initialized
INFO - 2022-08-17 18:45:02 --> Loader Class Initialized
INFO - 2022-08-17 18:45:02 --> Helper loaded: url_helper
INFO - 2022-08-17 18:45:02 --> Controller Class Initialized
DEBUG - 2022-08-17 18:45:02 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:45:02 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:45:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:45:02 --> Final output sent to browser
DEBUG - 2022-08-17 18:45:02 --> Total execution time: 0.2934
INFO - 2022-08-17 18:58:21 --> Config Class Initialized
INFO - 2022-08-17 18:58:21 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:58:21 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:58:21 --> Utf8 Class Initialized
INFO - 2022-08-17 18:58:21 --> URI Class Initialized
INFO - 2022-08-17 18:58:21 --> Router Class Initialized
INFO - 2022-08-17 18:58:21 --> Output Class Initialized
INFO - 2022-08-17 18:58:21 --> Security Class Initialized
DEBUG - 2022-08-17 18:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:58:21 --> Input Class Initialized
INFO - 2022-08-17 18:58:21 --> Language Class Initialized
INFO - 2022-08-17 18:58:21 --> Loader Class Initialized
INFO - 2022-08-17 18:58:21 --> Helper loaded: url_helper
INFO - 2022-08-17 18:58:21 --> Controller Class Initialized
DEBUG - 2022-08-17 18:58:21 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:58:21 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:58:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:58:21 --> Final output sent to browser
DEBUG - 2022-08-17 18:58:21 --> Total execution time: 0.2758
INFO - 2022-08-17 18:58:30 --> Config Class Initialized
INFO - 2022-08-17 18:58:30 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:58:30 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:58:30 --> Utf8 Class Initialized
INFO - 2022-08-17 18:58:30 --> URI Class Initialized
INFO - 2022-08-17 18:58:30 --> Router Class Initialized
INFO - 2022-08-17 18:58:30 --> Output Class Initialized
INFO - 2022-08-17 18:58:30 --> Security Class Initialized
DEBUG - 2022-08-17 18:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:58:30 --> Input Class Initialized
INFO - 2022-08-17 18:58:30 --> Language Class Initialized
INFO - 2022-08-17 18:58:30 --> Loader Class Initialized
INFO - 2022-08-17 18:58:30 --> Helper loaded: url_helper
INFO - 2022-08-17 18:58:30 --> Controller Class Initialized
DEBUG - 2022-08-17 18:58:30 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:58:30 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:58:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:58:30 --> Final output sent to browser
DEBUG - 2022-08-17 18:58:30 --> Total execution time: 0.2416
INFO - 2022-08-17 18:59:06 --> Config Class Initialized
INFO - 2022-08-17 18:59:06 --> Hooks Class Initialized
DEBUG - 2022-08-17 18:59:06 --> UTF-8 Support Enabled
INFO - 2022-08-17 18:59:06 --> Utf8 Class Initialized
INFO - 2022-08-17 18:59:06 --> URI Class Initialized
INFO - 2022-08-17 18:59:06 --> Router Class Initialized
INFO - 2022-08-17 18:59:06 --> Output Class Initialized
INFO - 2022-08-17 18:59:06 --> Security Class Initialized
DEBUG - 2022-08-17 18:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 18:59:06 --> Input Class Initialized
INFO - 2022-08-17 18:59:06 --> Language Class Initialized
INFO - 2022-08-17 18:59:06 --> Loader Class Initialized
INFO - 2022-08-17 18:59:06 --> Helper loaded: url_helper
INFO - 2022-08-17 18:59:06 --> Controller Class Initialized
DEBUG - 2022-08-17 18:59:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 18:59:06 --> Helper loaded: inflector_helper
INFO - 2022-08-17 18:59:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 18:59:06 --> Final output sent to browser
DEBUG - 2022-08-17 18:59:06 --> Total execution time: 0.2231
INFO - 2022-08-17 19:02:56 --> Config Class Initialized
INFO - 2022-08-17 19:02:56 --> Hooks Class Initialized
DEBUG - 2022-08-17 19:02:56 --> UTF-8 Support Enabled
INFO - 2022-08-17 19:02:56 --> Utf8 Class Initialized
INFO - 2022-08-17 19:02:56 --> URI Class Initialized
INFO - 2022-08-17 19:02:56 --> Router Class Initialized
INFO - 2022-08-17 19:02:56 --> Output Class Initialized
INFO - 2022-08-17 19:02:56 --> Security Class Initialized
DEBUG - 2022-08-17 19:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 19:02:56 --> Input Class Initialized
INFO - 2022-08-17 19:02:56 --> Language Class Initialized
INFO - 2022-08-17 19:02:56 --> Loader Class Initialized
INFO - 2022-08-17 19:02:56 --> Helper loaded: url_helper
INFO - 2022-08-17 19:02:56 --> Controller Class Initialized
DEBUG - 2022-08-17 19:02:56 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 19:02:56 --> Helper loaded: inflector_helper
INFO - 2022-08-17 19:02:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 19:02:56 --> Final output sent to browser
DEBUG - 2022-08-17 19:02:56 --> Total execution time: 0.2516
INFO - 2022-08-17 19:03:05 --> Config Class Initialized
INFO - 2022-08-17 19:03:05 --> Hooks Class Initialized
DEBUG - 2022-08-17 19:03:05 --> UTF-8 Support Enabled
INFO - 2022-08-17 19:03:05 --> Utf8 Class Initialized
INFO - 2022-08-17 19:03:05 --> URI Class Initialized
DEBUG - 2022-08-17 19:03:05 --> No URI present. Default controller set.
INFO - 2022-08-17 19:03:05 --> Router Class Initialized
INFO - 2022-08-17 19:03:05 --> Output Class Initialized
INFO - 2022-08-17 19:03:05 --> Security Class Initialized
DEBUG - 2022-08-17 19:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 19:03:05 --> Input Class Initialized
INFO - 2022-08-17 19:03:05 --> Language Class Initialized
INFO - 2022-08-17 19:03:05 --> Loader Class Initialized
INFO - 2022-08-17 19:03:05 --> Helper loaded: url_helper
INFO - 2022-08-17 19:03:05 --> Controller Class Initialized
INFO - 2022-08-17 19:03:05 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-17 19:03:05 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-17 19:03:05 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-17 19:03:05 --> Final output sent to browser
DEBUG - 2022-08-17 19:03:05 --> Total execution time: 0.2759
INFO - 2022-08-17 19:03:08 --> Config Class Initialized
INFO - 2022-08-17 19:03:08 --> Hooks Class Initialized
DEBUG - 2022-08-17 19:03:08 --> UTF-8 Support Enabled
INFO - 2022-08-17 19:03:08 --> Utf8 Class Initialized
INFO - 2022-08-17 19:03:08 --> URI Class Initialized
INFO - 2022-08-17 19:03:08 --> Router Class Initialized
INFO - 2022-08-17 19:03:08 --> Output Class Initialized
INFO - 2022-08-17 19:03:08 --> Security Class Initialized
DEBUG - 2022-08-17 19:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 19:03:08 --> Input Class Initialized
INFO - 2022-08-17 19:03:08 --> Language Class Initialized
INFO - 2022-08-17 19:03:08 --> Loader Class Initialized
INFO - 2022-08-17 19:03:08 --> Helper loaded: url_helper
INFO - 2022-08-17 19:03:08 --> Controller Class Initialized
DEBUG - 2022-08-17 19:03:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 19:03:08 --> Helper loaded: inflector_helper
INFO - 2022-08-17 19:03:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 19:03:08 --> Final output sent to browser
DEBUG - 2022-08-17 19:03:08 --> Total execution time: 0.2010
INFO - 2022-08-17 19:03:43 --> Config Class Initialized
INFO - 2022-08-17 19:03:43 --> Hooks Class Initialized
DEBUG - 2022-08-17 19:03:43 --> UTF-8 Support Enabled
INFO - 2022-08-17 19:03:43 --> Utf8 Class Initialized
INFO - 2022-08-17 19:03:43 --> URI Class Initialized
INFO - 2022-08-17 19:03:43 --> Router Class Initialized
INFO - 2022-08-17 19:03:43 --> Output Class Initialized
INFO - 2022-08-17 19:03:43 --> Security Class Initialized
DEBUG - 2022-08-17 19:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 19:03:43 --> Input Class Initialized
INFO - 2022-08-17 19:03:43 --> Language Class Initialized
INFO - 2022-08-17 19:03:43 --> Loader Class Initialized
INFO - 2022-08-17 19:03:43 --> Helper loaded: url_helper
INFO - 2022-08-17 19:03:43 --> Controller Class Initialized
DEBUG - 2022-08-17 19:03:43 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 19:03:43 --> Helper loaded: inflector_helper
INFO - 2022-08-17 19:03:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 19:03:43 --> Final output sent to browser
DEBUG - 2022-08-17 19:03:43 --> Total execution time: 0.2161
INFO - 2022-08-17 19:03:43 --> Config Class Initialized
INFO - 2022-08-17 19:03:43 --> Hooks Class Initialized
DEBUG - 2022-08-17 19:03:43 --> UTF-8 Support Enabled
INFO - 2022-08-17 19:03:43 --> Utf8 Class Initialized
INFO - 2022-08-17 19:03:43 --> URI Class Initialized
INFO - 2022-08-17 19:03:43 --> Router Class Initialized
INFO - 2022-08-17 19:03:44 --> Output Class Initialized
INFO - 2022-08-17 19:03:44 --> Security Class Initialized
DEBUG - 2022-08-17 19:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 19:03:44 --> Input Class Initialized
INFO - 2022-08-17 19:03:44 --> Language Class Initialized
ERROR - 2022-08-17 19:03:44 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-17 19:04:06 --> Config Class Initialized
INFO - 2022-08-17 19:04:06 --> Hooks Class Initialized
DEBUG - 2022-08-17 19:04:06 --> UTF-8 Support Enabled
INFO - 2022-08-17 19:04:06 --> Utf8 Class Initialized
INFO - 2022-08-17 19:04:06 --> URI Class Initialized
INFO - 2022-08-17 19:04:06 --> Router Class Initialized
INFO - 2022-08-17 19:04:06 --> Output Class Initialized
INFO - 2022-08-17 19:04:06 --> Security Class Initialized
DEBUG - 2022-08-17 19:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 19:04:06 --> Input Class Initialized
INFO - 2022-08-17 19:04:06 --> Language Class Initialized
INFO - 2022-08-17 19:04:06 --> Loader Class Initialized
INFO - 2022-08-17 19:04:06 --> Helper loaded: url_helper
INFO - 2022-08-17 19:04:06 --> Controller Class Initialized
DEBUG - 2022-08-17 19:04:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 19:04:06 --> Helper loaded: inflector_helper
INFO - 2022-08-17 19:04:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 19:04:06 --> Final output sent to browser
DEBUG - 2022-08-17 19:04:06 --> Total execution time: 0.2022
INFO - 2022-08-17 19:04:13 --> Config Class Initialized
INFO - 2022-08-17 19:04:13 --> Hooks Class Initialized
DEBUG - 2022-08-17 19:04:13 --> UTF-8 Support Enabled
INFO - 2022-08-17 19:04:13 --> Utf8 Class Initialized
INFO - 2022-08-17 19:04:13 --> URI Class Initialized
INFO - 2022-08-17 19:04:13 --> Router Class Initialized
INFO - 2022-08-17 19:04:13 --> Output Class Initialized
INFO - 2022-08-17 19:04:13 --> Security Class Initialized
DEBUG - 2022-08-17 19:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 19:04:13 --> Input Class Initialized
INFO - 2022-08-17 19:04:13 --> Language Class Initialized
INFO - 2022-08-17 19:04:13 --> Loader Class Initialized
INFO - 2022-08-17 19:04:13 --> Helper loaded: url_helper
INFO - 2022-08-17 19:04:13 --> Controller Class Initialized
DEBUG - 2022-08-17 19:04:13 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 19:04:13 --> Helper loaded: inflector_helper
INFO - 2022-08-17 19:04:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 19:04:13 --> Final output sent to browser
DEBUG - 2022-08-17 19:04:13 --> Total execution time: 0.2029
INFO - 2022-08-17 19:04:21 --> Config Class Initialized
INFO - 2022-08-17 19:04:21 --> Hooks Class Initialized
DEBUG - 2022-08-17 19:04:21 --> UTF-8 Support Enabled
INFO - 2022-08-17 19:04:21 --> Utf8 Class Initialized
INFO - 2022-08-17 19:04:21 --> URI Class Initialized
INFO - 2022-08-17 19:04:21 --> Router Class Initialized
INFO - 2022-08-17 19:04:21 --> Output Class Initialized
INFO - 2022-08-17 19:04:21 --> Security Class Initialized
DEBUG - 2022-08-17 19:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-17 19:04:21 --> Input Class Initialized
INFO - 2022-08-17 19:04:21 --> Language Class Initialized
INFO - 2022-08-17 19:04:21 --> Loader Class Initialized
INFO - 2022-08-17 19:04:21 --> Helper loaded: url_helper
INFO - 2022-08-17 19:04:21 --> Controller Class Initialized
DEBUG - 2022-08-17 19:04:21 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-17 19:04:21 --> Helper loaded: inflector_helper
INFO - 2022-08-17 19:04:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-17 19:04:21 --> Final output sent to browser
DEBUG - 2022-08-17 19:04:21 --> Total execution time: 0.2301
