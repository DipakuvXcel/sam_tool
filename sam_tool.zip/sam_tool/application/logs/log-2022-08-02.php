<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-02 18:00:57 --> Config Class Initialized
INFO - 2022-08-02 18:00:57 --> Hooks Class Initialized
DEBUG - 2022-08-02 18:00:57 --> UTF-8 Support Enabled
INFO - 2022-08-02 18:00:57 --> Utf8 Class Initialized
INFO - 2022-08-02 18:00:57 --> URI Class Initialized
DEBUG - 2022-08-02 18:00:57 --> No URI present. Default controller set.
INFO - 2022-08-02 18:00:57 --> Router Class Initialized
INFO - 2022-08-02 18:00:57 --> Output Class Initialized
INFO - 2022-08-02 18:00:57 --> Security Class Initialized
DEBUG - 2022-08-02 18:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 18:00:57 --> Input Class Initialized
INFO - 2022-08-02 18:00:57 --> Language Class Initialized
INFO - 2022-08-02 18:00:57 --> Loader Class Initialized
INFO - 2022-08-02 18:00:57 --> Helper loaded: url_helper
INFO - 2022-08-02 18:00:57 --> Controller Class Initialized
INFO - 2022-08-02 18:00:57 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-02 18:00:57 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-02 18:00:57 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-02 18:00:57 --> Final output sent to browser
DEBUG - 2022-08-02 18:00:57 --> Total execution time: 0.3878
INFO - 2022-08-02 18:01:07 --> Config Class Initialized
INFO - 2022-08-02 18:01:07 --> Hooks Class Initialized
DEBUG - 2022-08-02 18:01:07 --> UTF-8 Support Enabled
INFO - 2022-08-02 18:01:07 --> Utf8 Class Initialized
INFO - 2022-08-02 18:01:07 --> URI Class Initialized
INFO - 2022-08-02 18:01:07 --> Router Class Initialized
INFO - 2022-08-02 18:01:07 --> Output Class Initialized
INFO - 2022-08-02 18:01:07 --> Security Class Initialized
DEBUG - 2022-08-02 18:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 18:01:07 --> Input Class Initialized
INFO - 2022-08-02 18:01:07 --> Language Class Initialized
INFO - 2022-08-02 18:01:08 --> Loader Class Initialized
INFO - 2022-08-02 18:01:08 --> Helper loaded: url_helper
INFO - 2022-08-02 18:01:08 --> Controller Class Initialized
INFO - 2022-08-02 18:01:08 --> Final output sent to browser
DEBUG - 2022-08-02 18:01:08 --> Total execution time: 0.2389
INFO - 2022-08-02 18:01:08 --> Config Class Initialized
INFO - 2022-08-02 18:01:08 --> Hooks Class Initialized
DEBUG - 2022-08-02 18:01:08 --> UTF-8 Support Enabled
INFO - 2022-08-02 18:01:08 --> Utf8 Class Initialized
INFO - 2022-08-02 18:01:08 --> URI Class Initialized
INFO - 2022-08-02 18:01:08 --> Router Class Initialized
INFO - 2022-08-02 18:01:08 --> Output Class Initialized
INFO - 2022-08-02 18:01:08 --> Security Class Initialized
DEBUG - 2022-08-02 18:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 18:01:08 --> Input Class Initialized
INFO - 2022-08-02 18:01:08 --> Language Class Initialized
ERROR - 2022-08-02 18:01:08 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-02 18:01:11 --> Config Class Initialized
INFO - 2022-08-02 18:01:11 --> Hooks Class Initialized
DEBUG - 2022-08-02 18:01:11 --> UTF-8 Support Enabled
INFO - 2022-08-02 18:01:11 --> Utf8 Class Initialized
INFO - 2022-08-02 18:01:11 --> URI Class Initialized
DEBUG - 2022-08-02 18:01:11 --> No URI present. Default controller set.
INFO - 2022-08-02 18:01:11 --> Router Class Initialized
INFO - 2022-08-02 18:01:11 --> Output Class Initialized
INFO - 2022-08-02 18:01:11 --> Security Class Initialized
DEBUG - 2022-08-02 18:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 18:01:11 --> Input Class Initialized
INFO - 2022-08-02 18:01:11 --> Language Class Initialized
INFO - 2022-08-02 18:01:11 --> Loader Class Initialized
INFO - 2022-08-02 18:01:11 --> Helper loaded: url_helper
INFO - 2022-08-02 18:01:11 --> Controller Class Initialized
INFO - 2022-08-02 18:01:11 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-02 18:01:11 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-02 18:01:11 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-02 18:01:11 --> Final output sent to browser
DEBUG - 2022-08-02 18:01:11 --> Total execution time: 0.2331
INFO - 2022-08-02 18:55:14 --> Config Class Initialized
INFO - 2022-08-02 18:55:14 --> Hooks Class Initialized
DEBUG - 2022-08-02 18:55:14 --> UTF-8 Support Enabled
INFO - 2022-08-02 18:55:14 --> Utf8 Class Initialized
INFO - 2022-08-02 18:55:14 --> URI Class Initialized
INFO - 2022-08-02 18:55:14 --> Router Class Initialized
INFO - 2022-08-02 18:55:14 --> Output Class Initialized
INFO - 2022-08-02 18:55:14 --> Security Class Initialized
DEBUG - 2022-08-02 18:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 18:55:14 --> Input Class Initialized
INFO - 2022-08-02 18:55:14 --> Language Class Initialized
INFO - 2022-08-02 18:55:14 --> Loader Class Initialized
INFO - 2022-08-02 18:55:14 --> Helper loaded: url_helper
INFO - 2022-08-02 18:55:14 --> Controller Class Initialized
INFO - 2022-08-02 18:55:14 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-02 18:55:14 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-02 18:55:14 --> File loaded: /sam_tool/application/views/frontend/property_details.php
INFO - 2022-08-02 18:55:14 --> Final output sent to browser
DEBUG - 2022-08-02 18:55:14 --> Total execution time: 0.2736
INFO - 2022-08-02 18:55:48 --> Config Class Initialized
INFO - 2022-08-02 18:55:48 --> Hooks Class Initialized
DEBUG - 2022-08-02 18:55:48 --> UTF-8 Support Enabled
INFO - 2022-08-02 18:55:48 --> Utf8 Class Initialized
INFO - 2022-08-02 18:55:48 --> URI Class Initialized
INFO - 2022-08-02 18:55:48 --> Router Class Initialized
INFO - 2022-08-02 18:55:48 --> Output Class Initialized
INFO - 2022-08-02 18:55:48 --> Security Class Initialized
DEBUG - 2022-08-02 18:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 18:55:48 --> Input Class Initialized
INFO - 2022-08-02 18:55:48 --> Language Class Initialized
INFO - 2022-08-02 18:55:48 --> Loader Class Initialized
INFO - 2022-08-02 18:55:48 --> Helper loaded: url_helper
INFO - 2022-08-02 18:55:48 --> Controller Class Initialized
INFO - 2022-08-02 18:55:48 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-02 18:55:48 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-02 18:55:48 --> File loaded: /sam_tool/application/views/frontend/property_details.php
INFO - 2022-08-02 18:55:48 --> Final output sent to browser
DEBUG - 2022-08-02 18:55:48 --> Total execution time: 0.2398
