<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-29 13:32:40 --> Some variable did not contain a value.
ERROR - 2022-07-29 13:32:40 --> Some variable did not contain a value.
ERROR - 2022-07-29 13:32:40 --> Some variable did not contain a value.
ERROR - 2022-07-29 13:32:40 --> Some variable did not contain a value.
ERROR - 2022-07-29 13:32:40 --> Some variable did not contain a value.
ERROR - 2022-07-29 13:32:40 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-29 13:55:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-29 16:10:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-29 16:10:28 --> Some variable did not contain a value.
ERROR - 2022-07-29 16:10:28 --> Some variable did not contain a value.
ERROR - 2022-07-29 16:10:28 --> Some variable did not contain a value.
ERROR - 2022-07-29 16:10:28 --> Some variable did not contain a value.
ERROR - 2022-07-29 16:10:28 --> Some variable did not contain a value.
ERROR - 2022-07-29 16:10:28 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-29 17:47:20 --> Some variable did not contain a value.
ERROR - 2022-07-29 17:47:20 --> Some variable did not contain a value.
ERROR - 2022-07-29 17:47:20 --> Some variable did not contain a value.
ERROR - 2022-07-29 17:47:20 --> Some variable did not contain a value.
ERROR - 2022-07-29 17:47:20 --> Some variable did not contain a value.
ERROR - 2022-07-29 17:47:20 --> Severity: Notice --> Undefined variable: initialize /sam_tool/application/views/frontend/_includes/footer.php 108
ERROR - 2022-07-29 17:48:12 --> 404 Page Not Found: Faviconico/index
