ERROR - 2022-08-30 18:20:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-30 18:24:09 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-30 18:24:37 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-30 18:24:56 --> {"city_id":1,"state_id":1,"bank_id":5,"type_id":3,"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 18:24:57 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-30 18:25:38 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-30 18:26:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-30 18:29:04 --> {"city_id":1,"state_id":1,"bank_id":1,"type_id":1,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 18:31:20 --> {"city_id":1,"state_id":1,"bank_id":1,"type_id":3,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 18:32:19 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 18:38:07 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:38:07 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:38:07 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:38:07 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:38:07 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:38:07 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:39:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:39:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:39:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:39:38 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:39:38 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:39:38 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:40:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:40:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:40:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:40:38 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:40:38 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:40:38 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:40:45 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:40:45 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:40:45 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:40:45 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:40:45 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:40:45 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:41:21 --> {"city_id":1,"state_id":1,"bank_id":1,"type_id":3,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 18:41:22 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:41:22 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:41:22 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:41:22 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:41:22 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:41:22 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:42:31 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:42:31 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:42:31 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:42:31 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:42:31 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:42:31 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:42:46 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 18:42:46 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:42:47 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:42:47 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 18:42:47 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 18:42:47 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 18:42:47 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 19:34:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 19:34:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 19:34:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 19:34:39 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 19:34:39 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 19:34:39 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 19:46:24 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 19:46:24 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 19:46:24 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 19:46:24 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 19:46:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 19:46:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 19:46:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 19:58:39 --> Severity: error --> Exception: syntax error, unexpected '*' /sam_tool/application/views/frontend/dashboard.php 235
ERROR - 2022-08-30 19:58:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-30 20:01:44 --> Severity: Error --> Cannot redeclare count_digit() (previously declared in /sam_tool/application/views/frontend/dashboard.php:208) /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-30 20:04:04 --> Severity: Error --> Cannot redeclare divider() (previously declared in /sam_tool/application/views/frontend/dashboard.php:212) /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-30 20:11:02 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:11:21 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 211
ERROR - 2022-08-30 20:11:22 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 211
ERROR - 2022-08-30 20:11:36 --> Severity: Notice --> Undefined variable: number /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-30 20:12:39 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:16:02 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-30 20:26:46 --> Severity: Notice --> Undefined variable: divider /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Warning --> Division by zero /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Notice --> Undefined variable: divider /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Warning --> Division by zero /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Notice --> Undefined variable: divider /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Warning --> Division by zero /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Notice --> Undefined variable: divider /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Warning --> Division by zero /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Notice --> Undefined variable: divider /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Warning --> Division by zero /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Notice --> Undefined variable: divider /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:26:46 --> Severity: Warning --> Division by zero /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Use of undefined constant result - assumed 'result' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> Illegal string offset 'market_price' /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:31:18 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-30 20:37:44 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-30 20:38:22 --> Severity: error --> Exception: syntax error, unexpected '<' /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-30 20:51:19 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-30 20:51:20 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-30 20:51:32 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-30 20:51:33 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-30 20:51:34 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-30 20:51:35 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-30 20:51:35 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-30 21:48:05 --> Severity: error --> Exception: syntax error, unexpected '*', expecting end of file /sam_tool/application/views/frontend/dashboard.php 271
ERROR - 2022-08-30 21:48:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 21:48:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 21:48:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 21:48:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-30 21:48:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 244
ERROR - 2022-08-30 21:48:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 244
ERROR - 2022-08-30 21:48:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 246
ERROR - 2022-08-30 21:48:37 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 246
ERROR - 2022-08-30 21:49:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 203
ERROR - 2022-08-30 21:49:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-30 21:49:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-30 21:49:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-30 21:49:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 244
ERROR - 2022-08-30 21:49:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 244
ERROR - 2022-08-30 21:49:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 246
ERROR - 2022-08-30 21:49:25 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 246
ERROR - 2022-08-30 21:50:02 --> Severity: Error --> Cannot redeclare divider() (previously declared in /sam_tool/application/views/frontend/dashboard.php:208) /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-30 21:50:22 --> Severity: Error --> Cannot redeclare divider() (previously declared in /sam_tool/application/views/frontend/dashboard.php:208) /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-30 21:52:10 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /sam_tool/application/views/frontend/dashboard.php 228
ERROR - 2022-08-30 21:53:35 --> Severity: Error --> Cannot redeclare divider() (previously declared in /sam_tool/application/views/frontend/dashboard.php:208) /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-30 22:03:21 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /sam_tool/application/views/frontend/dashboard.php 238
ERROR - 2022-08-30 22:03:22 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /sam_tool/application/views/frontend/dashboard.php 238
ERROR - 2022-08-30 22:03:48 --> Severity: error --> Exception: syntax error, unexpected '*' /sam_tool/application/views/frontend/dashboard.php 257
ERROR - 2022-08-30 22:05:47 --> Severity: error --> Exception: syntax error, unexpected '=' /sam_tool/application/views/frontend/dashboard.php 227
ERROR - 2022-08-30 22:07:52 --> {"city_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:07:59 --> {"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:08:11 --> {"bank_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:16:42 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:21:51 --> {"city_id":4,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:22:02 --> {"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:22:08 --> {"type_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:22:12 --> {"bank_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:22:17 --> {"bank_id":5,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:22:23 --> {"bank_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:22:31 --> {"city_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-30 22:29:29 --> Severity: error --> Exception: syntax error, unexpected '?>' /sam_tool/application/views/frontend/dashboard.php 261
ERROR - 2022-08-30 22:29:32 --> Severity: error --> Exception: syntax error, unexpected '?>' /sam_tool/application/views/frontend/dashboard.php 261
ERROR - 2022-08-30 22:29:51 --> Severity: error --> Exception: syntax error, unexpected '$num' (T_VARIABLE) /sam_tool/application/views/frontend/dashboard.php 339
ERROR - 2022-08-30 22:30:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 268
ERROR - 2022-08-30 22:30:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 268
ERROR - 2022-08-30 22:31:29 --> {"city_id":1,"state_id":1,"bank_id":3,"type_id":3,"locality":3,"batch_size":12,"batch_number":1}
