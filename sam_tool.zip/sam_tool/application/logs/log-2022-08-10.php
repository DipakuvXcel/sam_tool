<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-10 17:08:01 --> Config Class Initialized
INFO - 2022-08-10 17:08:01 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:08:01 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:08:01 --> Utf8 Class Initialized
INFO - 2022-08-10 17:08:01 --> URI Class Initialized
DEBUG - 2022-08-10 17:08:01 --> No URI present. Default controller set.
INFO - 2022-08-10 17:08:01 --> Router Class Initialized
INFO - 2022-08-10 17:08:01 --> Output Class Initialized
INFO - 2022-08-10 17:08:01 --> Security Class Initialized
DEBUG - 2022-08-10 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:08:01 --> Input Class Initialized
INFO - 2022-08-10 17:08:01 --> Language Class Initialized
INFO - 2022-08-10 17:08:01 --> Loader Class Initialized
INFO - 2022-08-10 17:08:01 --> Helper loaded: url_helper
INFO - 2022-08-10 17:08:01 --> Controller Class Initialized
INFO - 2022-08-10 17:08:02 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 67
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 67
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 83
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 83
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$address_id /sam_tool/application/views/frontend/dashboard.php 98
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$locality /sam_tool/application/views/frontend/dashboard.php 99
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$village /sam_tool/application/views/frontend/dashboard.php 99
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$pincode /sam_tool/application/views/frontend/dashboard.php 99
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$locality /sam_tool/application/views/frontend/dashboard.php 100
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$village /sam_tool/application/views/frontend/dashboard.php 100
ERROR - 2022-08-10 17:08:02 --> Severity: Notice --> Undefined property: stdClass::$pincode /sam_tool/application/views/frontend/dashboard.php 100
INFO - 2022-08-10 17:08:02 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 17:08:02 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 17:08:02 --> Final output sent to browser
DEBUG - 2022-08-10 17:08:02 --> Total execution time: 0.7055
INFO - 2022-08-10 17:11:00 --> Config Class Initialized
INFO - 2022-08-10 17:11:00 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:11:00 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:11:00 --> Utf8 Class Initialized
INFO - 2022-08-10 17:11:00 --> URI Class Initialized
DEBUG - 2022-08-10 17:11:00 --> No URI present. Default controller set.
INFO - 2022-08-10 17:11:00 --> Router Class Initialized
INFO - 2022-08-10 17:11:00 --> Output Class Initialized
INFO - 2022-08-10 17:11:00 --> Security Class Initialized
DEBUG - 2022-08-10 17:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:11:00 --> Input Class Initialized
INFO - 2022-08-10 17:11:00 --> Language Class Initialized
INFO - 2022-08-10 17:11:01 --> Loader Class Initialized
INFO - 2022-08-10 17:11:01 --> Helper loaded: url_helper
INFO - 2022-08-10 17:11:01 --> Controller Class Initialized
INFO - 2022-08-10 17:11:01 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 67
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 67
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 83
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 83
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$address_id /sam_tool/application/views/frontend/dashboard.php 98
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$locality /sam_tool/application/views/frontend/dashboard.php 99
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$village /sam_tool/application/views/frontend/dashboard.php 99
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$pincode /sam_tool/application/views/frontend/dashboard.php 99
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$locality /sam_tool/application/views/frontend/dashboard.php 100
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$village /sam_tool/application/views/frontend/dashboard.php 100
ERROR - 2022-08-10 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$pincode /sam_tool/application/views/frontend/dashboard.php 100
INFO - 2022-08-10 17:11:01 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 17:11:01 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 17:11:01 --> Final output sent to browser
DEBUG - 2022-08-10 17:11:01 --> Total execution time: 0.6341
INFO - 2022-08-10 17:12:50 --> Config Class Initialized
INFO - 2022-08-10 17:12:50 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:12:50 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:12:50 --> Utf8 Class Initialized
INFO - 2022-08-10 17:12:50 --> URI Class Initialized
DEBUG - 2022-08-10 17:12:50 --> No URI present. Default controller set.
INFO - 2022-08-10 17:12:50 --> Router Class Initialized
INFO - 2022-08-10 17:12:50 --> Output Class Initialized
INFO - 2022-08-10 17:12:50 --> Security Class Initialized
DEBUG - 2022-08-10 17:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:12:50 --> Input Class Initialized
INFO - 2022-08-10 17:12:50 --> Language Class Initialized
INFO - 2022-08-10 17:12:50 --> Loader Class Initialized
INFO - 2022-08-10 17:12:50 --> Helper loaded: url_helper
INFO - 2022-08-10 17:12:50 --> Controller Class Initialized
INFO - 2022-08-10 17:12:50 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 69
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 85
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$address_id /sam_tool/application/views/frontend/dashboard.php 99
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$locality /sam_tool/application/views/frontend/dashboard.php 100
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$village /sam_tool/application/views/frontend/dashboard.php 100
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$pincode /sam_tool/application/views/frontend/dashboard.php 100
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$locality /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$village /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-10 17:12:50 --> Severity: Notice --> Undefined property: stdClass::$pincode /sam_tool/application/views/frontend/dashboard.php 101
INFO - 2022-08-10 17:12:50 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 17:12:50 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 17:12:50 --> Final output sent to browser
DEBUG - 2022-08-10 17:12:50 --> Total execution time: 0.6388
INFO - 2022-08-10 17:13:34 --> Config Class Initialized
INFO - 2022-08-10 17:13:34 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:13:34 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:13:34 --> Utf8 Class Initialized
INFO - 2022-08-10 17:13:34 --> URI Class Initialized
DEBUG - 2022-08-10 17:13:34 --> No URI present. Default controller set.
INFO - 2022-08-10 17:13:34 --> Router Class Initialized
INFO - 2022-08-10 17:13:34 --> Output Class Initialized
INFO - 2022-08-10 17:13:34 --> Security Class Initialized
DEBUG - 2022-08-10 17:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:13:34 --> Input Class Initialized
INFO - 2022-08-10 17:13:34 --> Language Class Initialized
INFO - 2022-08-10 17:13:34 --> Loader Class Initialized
INFO - 2022-08-10 17:13:34 --> Helper loaded: url_helper
INFO - 2022-08-10 17:13:34 --> Controller Class Initialized
INFO - 2022-08-10 17:13:34 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 17:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 66
ERROR - 2022-08-10 17:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 82
ERROR - 2022-08-10 17:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 97
ERROR - 2022-08-10 17:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 113
ERROR - 2022-08-10 17:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 129
INFO - 2022-08-10 17:13:34 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 17:13:34 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 17:13:34 --> Final output sent to browser
DEBUG - 2022-08-10 17:13:34 --> Total execution time: 0.5668
INFO - 2022-08-10 17:13:43 --> Config Class Initialized
INFO - 2022-08-10 17:13:43 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:13:43 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:13:43 --> Utf8 Class Initialized
INFO - 2022-08-10 17:13:43 --> URI Class Initialized
DEBUG - 2022-08-10 17:13:43 --> No URI present. Default controller set.
INFO - 2022-08-10 17:13:43 --> Router Class Initialized
INFO - 2022-08-10 17:13:43 --> Output Class Initialized
INFO - 2022-08-10 17:13:43 --> Security Class Initialized
DEBUG - 2022-08-10 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:13:43 --> Input Class Initialized
INFO - 2022-08-10 17:13:43 --> Language Class Initialized
INFO - 2022-08-10 17:13:43 --> Loader Class Initialized
INFO - 2022-08-10 17:13:43 --> Helper loaded: url_helper
INFO - 2022-08-10 17:13:43 --> Controller Class Initialized
INFO - 2022-08-10 17:13:44 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 17:13:44 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:13:44 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:13:44 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 69
ERROR - 2022-08-10 17:13:44 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:13:44 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:13:44 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 85
INFO - 2022-08-10 17:13:44 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 17:13:44 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 17:13:44 --> Final output sent to browser
DEBUG - 2022-08-10 17:13:44 --> Total execution time: 0.5525
INFO - 2022-08-10 17:18:21 --> Config Class Initialized
INFO - 2022-08-10 17:18:21 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:18:21 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:18:21 --> Utf8 Class Initialized
INFO - 2022-08-10 17:18:21 --> URI Class Initialized
INFO - 2022-08-10 17:18:21 --> Router Class Initialized
INFO - 2022-08-10 17:18:21 --> Output Class Initialized
INFO - 2022-08-10 17:18:21 --> Security Class Initialized
DEBUG - 2022-08-10 17:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:18:21 --> Input Class Initialized
INFO - 2022-08-10 17:18:21 --> Language Class Initialized
INFO - 2022-08-10 17:18:21 --> Loader Class Initialized
INFO - 2022-08-10 17:18:21 --> Helper loaded: url_helper
INFO - 2022-08-10 17:18:21 --> Controller Class Initialized
INFO - 2022-08-10 17:18:21 --> Final output sent to browser
DEBUG - 2022-08-10 17:18:21 --> Total execution time: 0.5302
INFO - 2022-08-10 17:28:00 --> Config Class Initialized
INFO - 2022-08-10 17:28:00 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:28:00 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:28:00 --> Utf8 Class Initialized
INFO - 2022-08-10 17:28:00 --> URI Class Initialized
DEBUG - 2022-08-10 17:28:00 --> No URI present. Default controller set.
INFO - 2022-08-10 17:28:00 --> Router Class Initialized
INFO - 2022-08-10 17:28:00 --> Output Class Initialized
INFO - 2022-08-10 17:28:00 --> Security Class Initialized
DEBUG - 2022-08-10 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:28:00 --> Input Class Initialized
INFO - 2022-08-10 17:28:00 --> Language Class Initialized
INFO - 2022-08-10 17:28:00 --> Loader Class Initialized
INFO - 2022-08-10 17:28:00 --> Helper loaded: url_helper
INFO - 2022-08-10 17:28:00 --> Controller Class Initialized
INFO - 2022-08-10 17:28:00 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 17:28:00 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:28:01 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:28:01 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 69
ERROR - 2022-08-10 17:28:01 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:28:01 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:28:01 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 85
INFO - 2022-08-10 17:28:01 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 17:28:01 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 17:28:01 --> Final output sent to browser
DEBUG - 2022-08-10 17:28:01 --> Total execution time: 0.9006
INFO - 2022-08-10 17:28:03 --> Config Class Initialized
INFO - 2022-08-10 17:28:03 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:28:03 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:28:03 --> Utf8 Class Initialized
INFO - 2022-08-10 17:28:03 --> URI Class Initialized
INFO - 2022-08-10 17:28:03 --> Router Class Initialized
INFO - 2022-08-10 17:28:03 --> Output Class Initialized
INFO - 2022-08-10 17:28:03 --> Security Class Initialized
DEBUG - 2022-08-10 17:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:28:03 --> Input Class Initialized
INFO - 2022-08-10 17:28:03 --> Language Class Initialized
INFO - 2022-08-10 17:28:03 --> Loader Class Initialized
INFO - 2022-08-10 17:28:03 --> Helper loaded: url_helper
INFO - 2022-08-10 17:28:03 --> Controller Class Initialized
INFO - 2022-08-10 17:28:03 --> Final output sent to browser
DEBUG - 2022-08-10 17:28:03 --> Total execution time: 0.4986
INFO - 2022-08-10 17:28:08 --> Config Class Initialized
INFO - 2022-08-10 17:28:08 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:28:08 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:28:08 --> Utf8 Class Initialized
INFO - 2022-08-10 17:28:09 --> URI Class Initialized
INFO - 2022-08-10 17:28:09 --> Router Class Initialized
INFO - 2022-08-10 17:28:09 --> Output Class Initialized
INFO - 2022-08-10 17:28:09 --> Security Class Initialized
DEBUG - 2022-08-10 17:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:28:09 --> Input Class Initialized
INFO - 2022-08-10 17:28:09 --> Language Class Initialized
INFO - 2022-08-10 17:28:09 --> Loader Class Initialized
INFO - 2022-08-10 17:28:09 --> Helper loaded: url_helper
INFO - 2022-08-10 17:28:09 --> Controller Class Initialized
INFO - 2022-08-10 17:28:09 --> Final output sent to browser
DEBUG - 2022-08-10 17:28:09 --> Total execution time: 0.4015
INFO - 2022-08-10 17:28:16 --> Config Class Initialized
INFO - 2022-08-10 17:28:16 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:28:16 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:28:16 --> Utf8 Class Initialized
INFO - 2022-08-10 17:28:16 --> URI Class Initialized
INFO - 2022-08-10 17:28:16 --> Router Class Initialized
INFO - 2022-08-10 17:28:16 --> Output Class Initialized
INFO - 2022-08-10 17:28:17 --> Security Class Initialized
DEBUG - 2022-08-10 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:28:17 --> Input Class Initialized
INFO - 2022-08-10 17:28:17 --> Language Class Initialized
INFO - 2022-08-10 17:28:17 --> Loader Class Initialized
INFO - 2022-08-10 17:28:17 --> Helper loaded: url_helper
INFO - 2022-08-10 17:28:17 --> Controller Class Initialized
INFO - 2022-08-10 17:28:17 --> Final output sent to browser
DEBUG - 2022-08-10 17:28:17 --> Total execution time: 0.4263
INFO - 2022-08-10 17:37:13 --> Config Class Initialized
INFO - 2022-08-10 17:37:13 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:37:13 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:37:13 --> Utf8 Class Initialized
INFO - 2022-08-10 17:37:13 --> URI Class Initialized
DEBUG - 2022-08-10 17:37:13 --> No URI present. Default controller set.
INFO - 2022-08-10 17:37:13 --> Router Class Initialized
INFO - 2022-08-10 17:37:13 --> Output Class Initialized
INFO - 2022-08-10 17:37:13 --> Security Class Initialized
DEBUG - 2022-08-10 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:37:14 --> Input Class Initialized
INFO - 2022-08-10 17:37:14 --> Language Class Initialized
INFO - 2022-08-10 17:37:14 --> Loader Class Initialized
INFO - 2022-08-10 17:37:14 --> Helper loaded: url_helper
INFO - 2022-08-10 17:37:14 --> Controller Class Initialized
INFO - 2022-08-10 17:37:14 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 17:37:14 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:37:14 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 17:37:14 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 69
ERROR - 2022-08-10 17:37:14 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:37:14 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 17:37:14 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 85
INFO - 2022-08-10 17:37:14 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 17:37:14 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 17:37:14 --> Final output sent to browser
DEBUG - 2022-08-10 17:37:14 --> Total execution time: 0.8493
INFO - 2022-08-10 17:37:18 --> Config Class Initialized
INFO - 2022-08-10 17:37:18 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:37:18 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:37:18 --> Utf8 Class Initialized
INFO - 2022-08-10 17:37:18 --> URI Class Initialized
INFO - 2022-08-10 17:37:18 --> Router Class Initialized
INFO - 2022-08-10 17:37:18 --> Output Class Initialized
INFO - 2022-08-10 17:37:18 --> Security Class Initialized
DEBUG - 2022-08-10 17:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:37:18 --> Input Class Initialized
INFO - 2022-08-10 17:37:18 --> Language Class Initialized
INFO - 2022-08-10 17:37:18 --> Loader Class Initialized
INFO - 2022-08-10 17:37:18 --> Helper loaded: url_helper
INFO - 2022-08-10 17:37:18 --> Controller Class Initialized
DEBUG - 2022-08-10 17:37:18 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 17:37:18 --> Helper loaded: inflector_helper
INFO - 2022-08-10 17:37:30 --> Config Class Initialized
INFO - 2022-08-10 17:37:30 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:37:30 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:37:30 --> Utf8 Class Initialized
INFO - 2022-08-10 17:37:30 --> URI Class Initialized
INFO - 2022-08-10 17:37:31 --> Router Class Initialized
INFO - 2022-08-10 17:37:31 --> Output Class Initialized
INFO - 2022-08-10 17:37:31 --> Security Class Initialized
DEBUG - 2022-08-10 17:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:37:31 --> Input Class Initialized
INFO - 2022-08-10 17:37:31 --> Language Class Initialized
INFO - 2022-08-10 17:37:31 --> Loader Class Initialized
INFO - 2022-08-10 17:37:31 --> Helper loaded: url_helper
INFO - 2022-08-10 17:37:31 --> Controller Class Initialized
DEBUG - 2022-08-10 17:37:31 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 17:37:31 --> Helper loaded: inflector_helper
INFO - 2022-08-10 17:39:50 --> Config Class Initialized
INFO - 2022-08-10 17:39:50 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:39:50 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:39:50 --> Utf8 Class Initialized
INFO - 2022-08-10 17:39:50 --> URI Class Initialized
INFO - 2022-08-10 17:39:50 --> Router Class Initialized
INFO - 2022-08-10 17:39:51 --> Output Class Initialized
INFO - 2022-08-10 17:39:51 --> Security Class Initialized
DEBUG - 2022-08-10 17:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:39:51 --> Input Class Initialized
INFO - 2022-08-10 17:39:51 --> Language Class Initialized
INFO - 2022-08-10 17:39:51 --> Loader Class Initialized
INFO - 2022-08-10 17:39:51 --> Helper loaded: url_helper
INFO - 2022-08-10 17:39:51 --> Controller Class Initialized
DEBUG - 2022-08-10 17:39:51 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 17:39:51 --> Helper loaded: inflector_helper
INFO - 2022-08-10 17:42:14 --> Config Class Initialized
INFO - 2022-08-10 17:42:14 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:42:14 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:42:14 --> Utf8 Class Initialized
INFO - 2022-08-10 17:42:14 --> URI Class Initialized
INFO - 2022-08-10 17:42:14 --> Router Class Initialized
INFO - 2022-08-10 17:42:14 --> Output Class Initialized
INFO - 2022-08-10 17:42:14 --> Security Class Initialized
DEBUG - 2022-08-10 17:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:42:14 --> Input Class Initialized
INFO - 2022-08-10 17:42:14 --> Language Class Initialized
INFO - 2022-08-10 17:42:15 --> Loader Class Initialized
INFO - 2022-08-10 17:42:15 --> Helper loaded: url_helper
INFO - 2022-08-10 17:42:15 --> Controller Class Initialized
DEBUG - 2022-08-10 17:42:15 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 17:42:15 --> Helper loaded: inflector_helper
INFO - 2022-08-10 17:42:15 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 17:42:15 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 17:42:15 --> Final output sent to browser
DEBUG - 2022-08-10 17:42:15 --> Total execution time: 0.6658
INFO - 2022-08-10 17:45:02 --> Config Class Initialized
INFO - 2022-08-10 17:45:02 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:45:02 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:45:02 --> Utf8 Class Initialized
INFO - 2022-08-10 17:45:02 --> URI Class Initialized
INFO - 2022-08-10 17:45:02 --> Router Class Initialized
INFO - 2022-08-10 17:45:02 --> Output Class Initialized
INFO - 2022-08-10 17:45:02 --> Security Class Initialized
DEBUG - 2022-08-10 17:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:45:02 --> Input Class Initialized
INFO - 2022-08-10 17:45:02 --> Language Class Initialized
INFO - 2022-08-10 17:45:02 --> Loader Class Initialized
INFO - 2022-08-10 17:45:02 --> Helper loaded: url_helper
INFO - 2022-08-10 17:45:02 --> Controller Class Initialized
DEBUG - 2022-08-10 17:45:02 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 17:45:02 --> Helper loaded: inflector_helper
INFO - 2022-08-10 17:45:02 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 17:45:03 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 17:45:03 --> Final output sent to browser
DEBUG - 2022-08-10 17:45:03 --> Total execution time: 0.6023
INFO - 2022-08-10 17:45:20 --> Config Class Initialized
INFO - 2022-08-10 17:45:20 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:45:20 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:45:20 --> Utf8 Class Initialized
INFO - 2022-08-10 17:45:20 --> URI Class Initialized
INFO - 2022-08-10 17:45:20 --> Router Class Initialized
INFO - 2022-08-10 17:45:20 --> Output Class Initialized
INFO - 2022-08-10 17:45:20 --> Security Class Initialized
DEBUG - 2022-08-10 17:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:45:20 --> Input Class Initialized
INFO - 2022-08-10 17:45:20 --> Language Class Initialized
INFO - 2022-08-10 17:45:20 --> Loader Class Initialized
INFO - 2022-08-10 17:45:20 --> Helper loaded: url_helper
INFO - 2022-08-10 17:45:20 --> Controller Class Initialized
DEBUG - 2022-08-10 17:45:20 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 17:45:20 --> Helper loaded: inflector_helper
INFO - 2022-08-10 17:45:20 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 17:45:20 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 17:45:20 --> Final output sent to browser
DEBUG - 2022-08-10 17:45:20 --> Total execution time: 0.7204
INFO - 2022-08-10 17:46:30 --> Config Class Initialized
INFO - 2022-08-10 17:46:30 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:46:30 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:46:30 --> Utf8 Class Initialized
INFO - 2022-08-10 17:46:30 --> URI Class Initialized
INFO - 2022-08-10 17:46:30 --> Router Class Initialized
INFO - 2022-08-10 17:46:30 --> Output Class Initialized
INFO - 2022-08-10 17:46:30 --> Security Class Initialized
DEBUG - 2022-08-10 17:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:46:30 --> Input Class Initialized
INFO - 2022-08-10 17:46:30 --> Language Class Initialized
INFO - 2022-08-10 17:46:31 --> Loader Class Initialized
INFO - 2022-08-10 17:46:31 --> Helper loaded: url_helper
INFO - 2022-08-10 17:46:31 --> Controller Class Initialized
DEBUG - 2022-08-10 17:46:31 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 17:46:31 --> Helper loaded: inflector_helper
INFO - 2022-08-10 17:46:31 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 17:46:31 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 17:46:31 --> Final output sent to browser
DEBUG - 2022-08-10 17:46:31 --> Total execution time: 0.5934
INFO - 2022-08-10 17:46:53 --> Config Class Initialized
INFO - 2022-08-10 17:46:53 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:46:53 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:46:53 --> Utf8 Class Initialized
INFO - 2022-08-10 17:46:53 --> URI Class Initialized
INFO - 2022-08-10 17:46:53 --> Router Class Initialized
INFO - 2022-08-10 17:46:53 --> Output Class Initialized
INFO - 2022-08-10 17:46:53 --> Security Class Initialized
DEBUG - 2022-08-10 17:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:46:53 --> Input Class Initialized
INFO - 2022-08-10 17:46:53 --> Language Class Initialized
ERROR - 2022-08-10 17:46:53 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 17:46:57 --> Config Class Initialized
INFO - 2022-08-10 17:46:57 --> Hooks Class Initialized
DEBUG - 2022-08-10 17:46:57 --> UTF-8 Support Enabled
INFO - 2022-08-10 17:46:57 --> Utf8 Class Initialized
INFO - 2022-08-10 17:46:57 --> URI Class Initialized
INFO - 2022-08-10 17:46:57 --> Router Class Initialized
INFO - 2022-08-10 17:46:57 --> Output Class Initialized
INFO - 2022-08-10 17:46:57 --> Security Class Initialized
DEBUG - 2022-08-10 17:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 17:46:57 --> Input Class Initialized
INFO - 2022-08-10 17:46:57 --> Language Class Initialized
INFO - 2022-08-10 17:46:57 --> Loader Class Initialized
INFO - 2022-08-10 17:46:57 --> Helper loaded: url_helper
INFO - 2022-08-10 17:46:57 --> Controller Class Initialized
DEBUG - 2022-08-10 17:46:57 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 17:46:57 --> Helper loaded: inflector_helper
INFO - 2022-08-10 17:46:57 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 17:46:57 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 17:46:57 --> Final output sent to browser
DEBUG - 2022-08-10 17:46:57 --> Total execution time: 0.3604
INFO - 2022-08-10 18:01:40 --> Config Class Initialized
INFO - 2022-08-10 18:01:40 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:01:40 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:01:40 --> Utf8 Class Initialized
INFO - 2022-08-10 18:01:40 --> URI Class Initialized
DEBUG - 2022-08-10 18:01:40 --> No URI present. Default controller set.
INFO - 2022-08-10 18:01:40 --> Router Class Initialized
INFO - 2022-08-10 18:01:40 --> Output Class Initialized
INFO - 2022-08-10 18:01:40 --> Security Class Initialized
DEBUG - 2022-08-10 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:01:40 --> Input Class Initialized
INFO - 2022-08-10 18:01:40 --> Language Class Initialized
INFO - 2022-08-10 18:01:40 --> Loader Class Initialized
INFO - 2022-08-10 18:01:41 --> Helper loaded: url_helper
INFO - 2022-08-10 18:01:41 --> Controller Class Initialized
INFO - 2022-08-10 18:01:41 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 18:01:41 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 18:01:41 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 18:01:41 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 69
ERROR - 2022-08-10 18:01:41 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 18:01:41 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 18:01:41 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 85
INFO - 2022-08-10 18:01:41 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 18:01:41 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 18:01:41 --> Final output sent to browser
DEBUG - 2022-08-10 18:01:41 --> Total execution time: 0.3571
INFO - 2022-08-10 18:04:35 --> Config Class Initialized
INFO - 2022-08-10 18:04:35 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:04:35 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:04:35 --> Utf8 Class Initialized
INFO - 2022-08-10 18:04:35 --> URI Class Initialized
DEBUG - 2022-08-10 18:04:35 --> No URI present. Default controller set.
INFO - 2022-08-10 18:04:35 --> Router Class Initialized
INFO - 2022-08-10 18:04:35 --> Output Class Initialized
INFO - 2022-08-10 18:04:35 --> Security Class Initialized
DEBUG - 2022-08-10 18:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:04:35 --> Input Class Initialized
INFO - 2022-08-10 18:04:35 --> Language Class Initialized
INFO - 2022-08-10 18:04:35 --> Loader Class Initialized
INFO - 2022-08-10 18:04:35 --> Helper loaded: url_helper
INFO - 2022-08-10 18:04:35 --> Controller Class Initialized
INFO - 2022-08-10 18:04:35 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 68
ERROR - 2022-08-10 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 69
ERROR - 2022-08-10 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 84
ERROR - 2022-08-10 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 85
INFO - 2022-08-10 18:04:35 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 18:04:35 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 18:04:35 --> Final output sent to browser
DEBUG - 2022-08-10 18:04:35 --> Total execution time: 0.3018
INFO - 2022-08-10 18:04:39 --> Config Class Initialized
INFO - 2022-08-10 18:04:39 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:04:39 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:04:39 --> Utf8 Class Initialized
INFO - 2022-08-10 18:04:39 --> URI Class Initialized
INFO - 2022-08-10 18:04:39 --> Router Class Initialized
INFO - 2022-08-10 18:04:39 --> Output Class Initialized
INFO - 2022-08-10 18:04:39 --> Security Class Initialized
DEBUG - 2022-08-10 18:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:04:39 --> Input Class Initialized
INFO - 2022-08-10 18:04:39 --> Language Class Initialized
INFO - 2022-08-10 18:04:39 --> Loader Class Initialized
INFO - 2022-08-10 18:04:39 --> Helper loaded: url_helper
INFO - 2022-08-10 18:04:39 --> Controller Class Initialized
DEBUG - 2022-08-10 18:04:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:04:39 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:04:39 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:04:39 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:04:39 --> Final output sent to browser
DEBUG - 2022-08-10 18:04:39 --> Total execution time: 0.2480
INFO - 2022-08-10 18:05:22 --> Config Class Initialized
INFO - 2022-08-10 18:05:22 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:05:22 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:05:22 --> Utf8 Class Initialized
INFO - 2022-08-10 18:05:22 --> URI Class Initialized
INFO - 2022-08-10 18:05:22 --> Router Class Initialized
INFO - 2022-08-10 18:05:22 --> Output Class Initialized
INFO - 2022-08-10 18:05:22 --> Security Class Initialized
DEBUG - 2022-08-10 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:05:22 --> Input Class Initialized
INFO - 2022-08-10 18:05:22 --> Language Class Initialized
INFO - 2022-08-10 18:05:22 --> Loader Class Initialized
INFO - 2022-08-10 18:05:22 --> Helper loaded: url_helper
INFO - 2022-08-10 18:05:22 --> Controller Class Initialized
DEBUG - 2022-08-10 18:05:22 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:05:22 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:05:22 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:05:22 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:05:22 --> Final output sent to browser
DEBUG - 2022-08-10 18:05:22 --> Total execution time: 0.2224
INFO - 2022-08-10 18:06:27 --> Config Class Initialized
INFO - 2022-08-10 18:06:27 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:06:27 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:06:27 --> Utf8 Class Initialized
INFO - 2022-08-10 18:06:27 --> URI Class Initialized
INFO - 2022-08-10 18:06:27 --> Router Class Initialized
INFO - 2022-08-10 18:06:27 --> Output Class Initialized
INFO - 2022-08-10 18:06:27 --> Security Class Initialized
DEBUG - 2022-08-10 18:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:06:27 --> Input Class Initialized
INFO - 2022-08-10 18:06:27 --> Language Class Initialized
ERROR - 2022-08-10 18:06:27 --> Severity: Warning --> require_once(libraries/REST_Controller.php): failed to open stream: No such file or directory /sam_tool/application/controllers/Api.php 5
ERROR - 2022-08-10 18:06:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
ERROR - 2022-08-10 18:06:27 --> Severity: Compile Error --> require_once(): Failed opening required 'libraries/REST_Controller.php' (include_path='.:/usr/local/lib/php') /sam_tool/application/controllers/Api.php 5
INFO - 2022-08-10 18:06:39 --> Config Class Initialized
INFO - 2022-08-10 18:06:39 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:06:39 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:06:39 --> Utf8 Class Initialized
INFO - 2022-08-10 18:06:39 --> URI Class Initialized
INFO - 2022-08-10 18:06:39 --> Router Class Initialized
INFO - 2022-08-10 18:06:39 --> Output Class Initialized
INFO - 2022-08-10 18:06:39 --> Security Class Initialized
DEBUG - 2022-08-10 18:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:06:39 --> Input Class Initialized
INFO - 2022-08-10 18:06:39 --> Language Class Initialized
INFO - 2022-08-10 18:06:39 --> Loader Class Initialized
INFO - 2022-08-10 18:06:39 --> Helper loaded: url_helper
INFO - 2022-08-10 18:06:39 --> Controller Class Initialized
DEBUG - 2022-08-10 18:06:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:06:39 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:06:39 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:06:40 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:06:40 --> Final output sent to browser
DEBUG - 2022-08-10 18:06:40 --> Total execution time: 0.2260
INFO - 2022-08-10 18:09:07 --> Config Class Initialized
INFO - 2022-08-10 18:09:07 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:09:07 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:09:07 --> Utf8 Class Initialized
INFO - 2022-08-10 18:09:07 --> URI Class Initialized
INFO - 2022-08-10 18:09:07 --> Router Class Initialized
INFO - 2022-08-10 18:09:07 --> Output Class Initialized
INFO - 2022-08-10 18:09:07 --> Security Class Initialized
DEBUG - 2022-08-10 18:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:09:07 --> Input Class Initialized
INFO - 2022-08-10 18:09:07 --> Language Class Initialized
INFO - 2022-08-10 18:09:07 --> Loader Class Initialized
INFO - 2022-08-10 18:09:07 --> Helper loaded: url_helper
INFO - 2022-08-10 18:09:07 --> Controller Class Initialized
DEBUG - 2022-08-10 18:09:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:09:07 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:09:07 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:09:07 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:09:07 --> Final output sent to browser
DEBUG - 2022-08-10 18:09:07 --> Total execution time: 0.4634
INFO - 2022-08-10 18:09:27 --> Config Class Initialized
INFO - 2022-08-10 18:09:27 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:09:27 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:09:27 --> Utf8 Class Initialized
INFO - 2022-08-10 18:09:27 --> URI Class Initialized
INFO - 2022-08-10 18:09:27 --> Router Class Initialized
INFO - 2022-08-10 18:09:27 --> Output Class Initialized
INFO - 2022-08-10 18:09:27 --> Security Class Initialized
DEBUG - 2022-08-10 18:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:09:27 --> Input Class Initialized
INFO - 2022-08-10 18:09:27 --> Language Class Initialized
ERROR - 2022-08-10 18:09:27 --> Severity: error --> Exception: syntax error, unexpected '200' (T_LNUMBER) /sam_tool/application/controllers/Api.php 35
INFO - 2022-08-10 18:10:22 --> Config Class Initialized
INFO - 2022-08-10 18:10:22 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:10:22 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:10:22 --> Utf8 Class Initialized
INFO - 2022-08-10 18:10:22 --> URI Class Initialized
INFO - 2022-08-10 18:10:22 --> Router Class Initialized
INFO - 2022-08-10 18:10:22 --> Output Class Initialized
INFO - 2022-08-10 18:10:22 --> Security Class Initialized
DEBUG - 2022-08-10 18:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:10:23 --> Input Class Initialized
INFO - 2022-08-10 18:10:23 --> Language Class Initialized
INFO - 2022-08-10 18:10:23 --> Loader Class Initialized
INFO - 2022-08-10 18:10:23 --> Helper loaded: url_helper
INFO - 2022-08-10 18:10:23 --> Controller Class Initialized
DEBUG - 2022-08-10 18:10:23 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:10:23 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:10:23 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:10:23 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:10:23 --> Final output sent to browser
DEBUG - 2022-08-10 18:10:23 --> Total execution time: 0.5409
INFO - 2022-08-10 18:14:42 --> Config Class Initialized
INFO - 2022-08-10 18:14:42 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:14:42 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:14:42 --> Utf8 Class Initialized
INFO - 2022-08-10 18:14:42 --> URI Class Initialized
INFO - 2022-08-10 18:14:42 --> Router Class Initialized
INFO - 2022-08-10 18:14:43 --> Output Class Initialized
INFO - 2022-08-10 18:14:43 --> Security Class Initialized
DEBUG - 2022-08-10 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:14:43 --> Input Class Initialized
INFO - 2022-08-10 18:14:43 --> Language Class Initialized
INFO - 2022-08-10 18:14:43 --> Loader Class Initialized
INFO - 2022-08-10 18:14:43 --> Helper loaded: url_helper
INFO - 2022-08-10 18:14:43 --> Controller Class Initialized
DEBUG - 2022-08-10 18:14:43 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:14:43 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:14:43 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:14:43 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:14:43 --> Final output sent to browser
DEBUG - 2022-08-10 18:14:43 --> Total execution time: 0.7515
INFO - 2022-08-10 18:17:58 --> Config Class Initialized
INFO - 2022-08-10 18:17:58 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:17:58 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:17:58 --> Utf8 Class Initialized
INFO - 2022-08-10 18:17:58 --> URI Class Initialized
INFO - 2022-08-10 18:17:58 --> Router Class Initialized
INFO - 2022-08-10 18:17:58 --> Output Class Initialized
INFO - 2022-08-10 18:17:58 --> Security Class Initialized
DEBUG - 2022-08-10 18:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:17:59 --> Input Class Initialized
INFO - 2022-08-10 18:17:59 --> Language Class Initialized
ERROR - 2022-08-10 18:17:59 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) /sam_tool/application/controllers/Api.php 28
INFO - 2022-08-10 18:18:18 --> Config Class Initialized
INFO - 2022-08-10 18:18:18 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:18:18 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:18:18 --> Utf8 Class Initialized
INFO - 2022-08-10 18:18:18 --> URI Class Initialized
INFO - 2022-08-10 18:18:18 --> Router Class Initialized
INFO - 2022-08-10 18:18:18 --> Output Class Initialized
INFO - 2022-08-10 18:18:18 --> Security Class Initialized
DEBUG - 2022-08-10 18:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:18:18 --> Input Class Initialized
INFO - 2022-08-10 18:18:18 --> Language Class Initialized
INFO - 2022-08-10 18:18:18 --> Loader Class Initialized
INFO - 2022-08-10 18:18:18 --> Helper loaded: url_helper
INFO - 2022-08-10 18:18:18 --> Controller Class Initialized
DEBUG - 2022-08-10 18:18:18 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:18:18 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:18:18 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:18:18 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:18:18 --> Final output sent to browser
DEBUG - 2022-08-10 18:18:18 --> Total execution time: 0.5756
INFO - 2022-08-10 18:18:30 --> Config Class Initialized
INFO - 2022-08-10 18:18:30 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:18:30 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:18:30 --> Utf8 Class Initialized
INFO - 2022-08-10 18:18:30 --> URI Class Initialized
INFO - 2022-08-10 18:18:30 --> Router Class Initialized
INFO - 2022-08-10 18:18:30 --> Output Class Initialized
INFO - 2022-08-10 18:18:30 --> Security Class Initialized
DEBUG - 2022-08-10 18:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:18:30 --> Input Class Initialized
INFO - 2022-08-10 18:18:30 --> Language Class Initialized
INFO - 2022-08-10 18:18:30 --> Loader Class Initialized
INFO - 2022-08-10 18:18:30 --> Helper loaded: url_helper
INFO - 2022-08-10 18:18:30 --> Controller Class Initialized
DEBUG - 2022-08-10 18:18:30 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:18:30 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:18:30 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:18:30 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:18:30 --> Final output sent to browser
DEBUG - 2022-08-10 18:18:30 --> Total execution time: 0.6046
INFO - 2022-08-10 18:27:07 --> Config Class Initialized
INFO - 2022-08-10 18:27:07 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:27:07 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:27:07 --> Utf8 Class Initialized
INFO - 2022-08-10 18:27:07 --> URI Class Initialized
INFO - 2022-08-10 18:27:07 --> Router Class Initialized
INFO - 2022-08-10 18:27:07 --> Output Class Initialized
INFO - 2022-08-10 18:27:07 --> Security Class Initialized
DEBUG - 2022-08-10 18:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:27:07 --> Input Class Initialized
INFO - 2022-08-10 18:27:07 --> Language Class Initialized
INFO - 2022-08-10 18:27:07 --> Loader Class Initialized
INFO - 2022-08-10 18:27:07 --> Helper loaded: url_helper
INFO - 2022-08-10 18:27:07 --> Controller Class Initialized
DEBUG - 2022-08-10 18:27:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:27:08 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:27:08 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:27:08 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:27:08 --> Final output sent to browser
DEBUG - 2022-08-10 18:27:08 --> Total execution time: 0.5947
INFO - 2022-08-10 18:44:25 --> Config Class Initialized
INFO - 2022-08-10 18:44:25 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:44:25 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:44:25 --> Utf8 Class Initialized
INFO - 2022-08-10 18:44:25 --> URI Class Initialized
INFO - 2022-08-10 18:44:25 --> Router Class Initialized
INFO - 2022-08-10 18:44:25 --> Output Class Initialized
INFO - 2022-08-10 18:44:25 --> Security Class Initialized
DEBUG - 2022-08-10 18:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:44:25 --> Input Class Initialized
INFO - 2022-08-10 18:44:25 --> Language Class Initialized
INFO - 2022-08-10 18:44:25 --> Loader Class Initialized
INFO - 2022-08-10 18:44:25 --> Helper loaded: url_helper
INFO - 2022-08-10 18:44:25 --> Controller Class Initialized
DEBUG - 2022-08-10 18:44:25 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:44:25 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:44:25 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:44:25 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:44:25 --> Final output sent to browser
DEBUG - 2022-08-10 18:44:25 --> Total execution time: 0.8046
INFO - 2022-08-10 18:44:37 --> Config Class Initialized
INFO - 2022-08-10 18:44:37 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:44:37 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:44:37 --> Utf8 Class Initialized
INFO - 2022-08-10 18:44:37 --> URI Class Initialized
INFO - 2022-08-10 18:44:37 --> Router Class Initialized
INFO - 2022-08-10 18:44:37 --> Output Class Initialized
INFO - 2022-08-10 18:44:37 --> Security Class Initialized
DEBUG - 2022-08-10 18:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:44:37 --> Input Class Initialized
INFO - 2022-08-10 18:44:37 --> Language Class Initialized
INFO - 2022-08-10 18:44:37 --> Loader Class Initialized
INFO - 2022-08-10 18:44:37 --> Helper loaded: url_helper
INFO - 2022-08-10 18:44:37 --> Controller Class Initialized
DEBUG - 2022-08-10 18:44:37 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:44:37 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:44:37 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:44:37 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:44:37 --> Final output sent to browser
DEBUG - 2022-08-10 18:44:37 --> Total execution time: 0.6291
INFO - 2022-08-10 18:44:40 --> Config Class Initialized
INFO - 2022-08-10 18:44:40 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:44:40 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:44:40 --> Utf8 Class Initialized
INFO - 2022-08-10 18:44:40 --> URI Class Initialized
INFO - 2022-08-10 18:44:40 --> Router Class Initialized
INFO - 2022-08-10 18:44:40 --> Output Class Initialized
INFO - 2022-08-10 18:44:40 --> Security Class Initialized
DEBUG - 2022-08-10 18:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:44:40 --> Input Class Initialized
INFO - 2022-08-10 18:44:40 --> Language Class Initialized
INFO - 2022-08-10 18:44:40 --> Loader Class Initialized
INFO - 2022-08-10 18:44:40 --> Helper loaded: url_helper
INFO - 2022-08-10 18:44:40 --> Controller Class Initialized
DEBUG - 2022-08-10 18:44:40 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:44:40 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:44:40 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:44:40 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_get' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:44:40 --> Final output sent to browser
DEBUG - 2022-08-10 18:44:40 --> Total execution time: 0.4534
INFO - 2022-08-10 18:47:49 --> Config Class Initialized
INFO - 2022-08-10 18:47:49 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:47:49 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:47:49 --> Utf8 Class Initialized
INFO - 2022-08-10 18:47:49 --> URI Class Initialized
INFO - 2022-08-10 18:47:49 --> Router Class Initialized
INFO - 2022-08-10 18:47:49 --> Output Class Initialized
INFO - 2022-08-10 18:47:49 --> Security Class Initialized
DEBUG - 2022-08-10 18:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:47:49 --> Input Class Initialized
INFO - 2022-08-10 18:47:49 --> Language Class Initialized
INFO - 2022-08-10 18:47:49 --> Loader Class Initialized
INFO - 2022-08-10 18:47:50 --> Helper loaded: url_helper
INFO - 2022-08-10 18:47:50 --> Controller Class Initialized
DEBUG - 2022-08-10 18:47:50 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:47:50 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:47:50 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:47:50 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:47:50 --> Final output sent to browser
DEBUG - 2022-08-10 18:47:50 --> Total execution time: 0.5236
INFO - 2022-08-10 18:47:52 --> Config Class Initialized
INFO - 2022-08-10 18:47:52 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:47:52 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:47:52 --> Utf8 Class Initialized
INFO - 2022-08-10 18:47:52 --> URI Class Initialized
INFO - 2022-08-10 18:47:52 --> Router Class Initialized
INFO - 2022-08-10 18:47:52 --> Output Class Initialized
INFO - 2022-08-10 18:47:52 --> Security Class Initialized
DEBUG - 2022-08-10 18:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:47:52 --> Input Class Initialized
INFO - 2022-08-10 18:47:52 --> Language Class Initialized
INFO - 2022-08-10 18:47:52 --> Loader Class Initialized
INFO - 2022-08-10 18:47:52 --> Helper loaded: url_helper
INFO - 2022-08-10 18:47:52 --> Controller Class Initialized
DEBUG - 2022-08-10 18:47:52 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:47:52 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:47:52 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:47:53 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_get' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:47:53 --> Final output sent to browser
DEBUG - 2022-08-10 18:47:53 --> Total execution time: 0.4136
INFO - 2022-08-10 18:48:59 --> Config Class Initialized
INFO - 2022-08-10 18:48:59 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:48:59 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:48:59 --> Utf8 Class Initialized
INFO - 2022-08-10 18:48:59 --> URI Class Initialized
INFO - 2022-08-10 18:48:59 --> Router Class Initialized
INFO - 2022-08-10 18:48:59 --> Output Class Initialized
INFO - 2022-08-10 18:48:59 --> Security Class Initialized
DEBUG - 2022-08-10 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:48:59 --> Input Class Initialized
INFO - 2022-08-10 18:48:59 --> Language Class Initialized
INFO - 2022-08-10 18:48:59 --> Loader Class Initialized
INFO - 2022-08-10 18:48:59 --> Helper loaded: url_helper
INFO - 2022-08-10 18:48:59 --> Controller Class Initialized
DEBUG - 2022-08-10 18:48:59 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:48:59 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:48:59 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:48:59 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:48:59 --> Final output sent to browser
DEBUG - 2022-08-10 18:48:59 --> Total execution time: 0.5393
INFO - 2022-08-10 18:49:30 --> Config Class Initialized
INFO - 2022-08-10 18:49:30 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:49:30 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:49:30 --> Utf8 Class Initialized
INFO - 2022-08-10 18:49:30 --> URI Class Initialized
INFO - 2022-08-10 18:49:30 --> Router Class Initialized
INFO - 2022-08-10 18:49:30 --> Output Class Initialized
INFO - 2022-08-10 18:49:30 --> Security Class Initialized
DEBUG - 2022-08-10 18:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:49:30 --> Input Class Initialized
INFO - 2022-08-10 18:49:30 --> Language Class Initialized
ERROR - 2022-08-10 18:49:30 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 18:49:42 --> Config Class Initialized
INFO - 2022-08-10 18:49:42 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:49:42 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:49:42 --> Utf8 Class Initialized
INFO - 2022-08-10 18:49:42 --> URI Class Initialized
DEBUG - 2022-08-10 18:49:42 --> No URI present. Default controller set.
INFO - 2022-08-10 18:49:42 --> Router Class Initialized
INFO - 2022-08-10 18:49:42 --> Output Class Initialized
INFO - 2022-08-10 18:49:42 --> Security Class Initialized
DEBUG - 2022-08-10 18:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:49:42 --> Input Class Initialized
INFO - 2022-08-10 18:49:42 --> Language Class Initialized
INFO - 2022-08-10 18:49:42 --> Loader Class Initialized
INFO - 2022-08-10 18:49:42 --> Helper loaded: url_helper
INFO - 2022-08-10 18:49:42 --> Controller Class Initialized
INFO - 2022-08-10 18:49:42 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 18:49:42 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 18:49:42 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 18:49:42 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 71
ERROR - 2022-08-10 18:49:42 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 18:49:42 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 18:49:42 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 87
INFO - 2022-08-10 18:49:42 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 18:49:42 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 18:49:42 --> Final output sent to browser
DEBUG - 2022-08-10 18:49:42 --> Total execution time: 0.6739
INFO - 2022-08-10 18:49:45 --> Config Class Initialized
INFO - 2022-08-10 18:49:45 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:49:45 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:49:45 --> Utf8 Class Initialized
INFO - 2022-08-10 18:49:45 --> URI Class Initialized
INFO - 2022-08-10 18:49:45 --> Router Class Initialized
INFO - 2022-08-10 18:49:45 --> Output Class Initialized
INFO - 2022-08-10 18:49:45 --> Security Class Initialized
DEBUG - 2022-08-10 18:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:49:45 --> Input Class Initialized
INFO - 2022-08-10 18:49:45 --> Language Class Initialized
ERROR - 2022-08-10 18:49:45 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 18:49:51 --> Config Class Initialized
INFO - 2022-08-10 18:49:51 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:49:51 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:49:51 --> Utf8 Class Initialized
INFO - 2022-08-10 18:49:51 --> URI Class Initialized
DEBUG - 2022-08-10 18:49:51 --> No URI present. Default controller set.
INFO - 2022-08-10 18:49:51 --> Router Class Initialized
INFO - 2022-08-10 18:49:51 --> Output Class Initialized
INFO - 2022-08-10 18:49:51 --> Security Class Initialized
DEBUG - 2022-08-10 18:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:49:51 --> Input Class Initialized
INFO - 2022-08-10 18:49:51 --> Language Class Initialized
INFO - 2022-08-10 18:49:51 --> Loader Class Initialized
INFO - 2022-08-10 18:49:51 --> Helper loaded: url_helper
INFO - 2022-08-10 18:49:51 --> Controller Class Initialized
INFO - 2022-08-10 18:49:51 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 18:49:51 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 18:49:51 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 18:49:51 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 71
ERROR - 2022-08-10 18:49:51 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 18:49:51 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 18:49:51 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 87
INFO - 2022-08-10 18:49:52 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 18:49:52 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 18:49:52 --> Final output sent to browser
DEBUG - 2022-08-10 18:49:52 --> Total execution time: 0.6908
INFO - 2022-08-10 18:49:52 --> Config Class Initialized
INFO - 2022-08-10 18:49:52 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:49:52 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:49:52 --> Utf8 Class Initialized
INFO - 2022-08-10 18:49:52 --> URI Class Initialized
INFO - 2022-08-10 18:49:52 --> Router Class Initialized
INFO - 2022-08-10 18:49:52 --> Output Class Initialized
INFO - 2022-08-10 18:49:52 --> Security Class Initialized
DEBUG - 2022-08-10 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:49:52 --> Input Class Initialized
INFO - 2022-08-10 18:49:52 --> Language Class Initialized
ERROR - 2022-08-10 18:49:52 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 18:49:55 --> Config Class Initialized
INFO - 2022-08-10 18:49:55 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:49:55 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:49:55 --> Utf8 Class Initialized
INFO - 2022-08-10 18:49:55 --> URI Class Initialized
INFO - 2022-08-10 18:49:55 --> Router Class Initialized
INFO - 2022-08-10 18:49:55 --> Output Class Initialized
INFO - 2022-08-10 18:49:55 --> Security Class Initialized
DEBUG - 2022-08-10 18:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:49:55 --> Input Class Initialized
INFO - 2022-08-10 18:49:55 --> Language Class Initialized
INFO - 2022-08-10 18:49:55 --> Loader Class Initialized
INFO - 2022-08-10 18:49:55 --> Helper loaded: url_helper
INFO - 2022-08-10 18:49:55 --> Controller Class Initialized
DEBUG - 2022-08-10 18:49:55 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:49:55 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:49:55 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:49:55 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:49:55 --> Final output sent to browser
DEBUG - 2022-08-10 18:49:55 --> Total execution time: 0.6600
INFO - 2022-08-10 18:51:05 --> Config Class Initialized
INFO - 2022-08-10 18:51:05 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:51:05 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:51:05 --> Utf8 Class Initialized
INFO - 2022-08-10 18:51:06 --> URI Class Initialized
INFO - 2022-08-10 18:51:06 --> Router Class Initialized
INFO - 2022-08-10 18:51:06 --> Output Class Initialized
INFO - 2022-08-10 18:51:06 --> Security Class Initialized
DEBUG - 2022-08-10 18:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:51:06 --> Input Class Initialized
INFO - 2022-08-10 18:51:06 --> Language Class Initialized
INFO - 2022-08-10 18:51:06 --> Loader Class Initialized
INFO - 2022-08-10 18:51:06 --> Helper loaded: url_helper
INFO - 2022-08-10 18:51:06 --> Controller Class Initialized
DEBUG - 2022-08-10 18:51:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:51:06 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:51:06 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:51:06 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_get' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:51:06 --> Final output sent to browser
DEBUG - 2022-08-10 18:51:06 --> Total execution time: 0.6896
INFO - 2022-08-10 18:53:43 --> Config Class Initialized
INFO - 2022-08-10 18:53:43 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:53:43 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:53:43 --> Utf8 Class Initialized
INFO - 2022-08-10 18:53:43 --> URI Class Initialized
INFO - 2022-08-10 18:53:43 --> Router Class Initialized
INFO - 2022-08-10 18:53:43 --> Output Class Initialized
INFO - 2022-08-10 18:53:43 --> Security Class Initialized
DEBUG - 2022-08-10 18:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:53:43 --> Input Class Initialized
INFO - 2022-08-10 18:53:43 --> Language Class Initialized
INFO - 2022-08-10 18:53:43 --> Loader Class Initialized
INFO - 2022-08-10 18:53:43 --> Helper loaded: url_helper
INFO - 2022-08-10 18:53:43 --> Controller Class Initialized
DEBUG - 2022-08-10 18:53:43 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:53:43 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:53:43 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:53:43 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:53:43 --> Final output sent to browser
DEBUG - 2022-08-10 18:53:43 --> Total execution time: 0.5744
INFO - 2022-08-10 18:55:13 --> Config Class Initialized
INFO - 2022-08-10 18:55:13 --> Hooks Class Initialized
DEBUG - 2022-08-10 18:55:13 --> UTF-8 Support Enabled
INFO - 2022-08-10 18:55:13 --> Utf8 Class Initialized
INFO - 2022-08-10 18:55:13 --> URI Class Initialized
INFO - 2022-08-10 18:55:13 --> Router Class Initialized
INFO - 2022-08-10 18:55:13 --> Output Class Initialized
INFO - 2022-08-10 18:55:13 --> Security Class Initialized
DEBUG - 2022-08-10 18:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 18:55:13 --> Input Class Initialized
INFO - 2022-08-10 18:55:13 --> Language Class Initialized
INFO - 2022-08-10 18:55:13 --> Loader Class Initialized
INFO - 2022-08-10 18:55:13 --> Helper loaded: url_helper
INFO - 2022-08-10 18:55:13 --> Controller Class Initialized
DEBUG - 2022-08-10 18:55:13 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 18:55:13 --> Helper loaded: inflector_helper
INFO - 2022-08-10 18:55:13 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 18:55:13 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 18:55:13 --> Final output sent to browser
DEBUG - 2022-08-10 18:55:13 --> Total execution time: 0.5030
INFO - 2022-08-10 19:01:24 --> Config Class Initialized
INFO - 2022-08-10 19:01:24 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:01:24 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:01:24 --> Utf8 Class Initialized
INFO - 2022-08-10 19:01:24 --> URI Class Initialized
INFO - 2022-08-10 19:01:24 --> Router Class Initialized
INFO - 2022-08-10 19:01:24 --> Output Class Initialized
INFO - 2022-08-10 19:01:24 --> Security Class Initialized
DEBUG - 2022-08-10 19:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:01:24 --> Input Class Initialized
INFO - 2022-08-10 19:01:24 --> Language Class Initialized
ERROR - 2022-08-10 19:01:24 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 19:01:29 --> Config Class Initialized
INFO - 2022-08-10 19:01:30 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:01:30 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:01:30 --> Utf8 Class Initialized
INFO - 2022-08-10 19:01:30 --> URI Class Initialized
DEBUG - 2022-08-10 19:01:30 --> No URI present. Default controller set.
INFO - 2022-08-10 19:01:30 --> Router Class Initialized
INFO - 2022-08-10 19:01:30 --> Output Class Initialized
INFO - 2022-08-10 19:01:30 --> Security Class Initialized
DEBUG - 2022-08-10 19:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:01:30 --> Input Class Initialized
INFO - 2022-08-10 19:01:30 --> Language Class Initialized
INFO - 2022-08-10 19:01:30 --> Loader Class Initialized
INFO - 2022-08-10 19:01:30 --> Helper loaded: url_helper
INFO - 2022-08-10 19:01:30 --> Controller Class Initialized
INFO - 2022-08-10 19:01:30 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 19:01:30 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 19:01:30 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 19:01:30 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 71
ERROR - 2022-08-10 19:01:30 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 19:01:30 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 19:01:30 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 87
INFO - 2022-08-10 19:01:30 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 19:01:30 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 19:01:30 --> Final output sent to browser
DEBUG - 2022-08-10 19:01:30 --> Total execution time: 0.6119
INFO - 2022-08-10 19:01:31 --> Config Class Initialized
INFO - 2022-08-10 19:01:31 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:01:31 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:01:31 --> Utf8 Class Initialized
INFO - 2022-08-10 19:01:31 --> URI Class Initialized
INFO - 2022-08-10 19:01:31 --> Router Class Initialized
INFO - 2022-08-10 19:01:31 --> Output Class Initialized
INFO - 2022-08-10 19:01:31 --> Security Class Initialized
DEBUG - 2022-08-10 19:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:01:31 --> Input Class Initialized
INFO - 2022-08-10 19:01:31 --> Language Class Initialized
ERROR - 2022-08-10 19:01:31 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 19:01:35 --> Config Class Initialized
INFO - 2022-08-10 19:01:35 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:01:35 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:01:35 --> Utf8 Class Initialized
INFO - 2022-08-10 19:01:35 --> URI Class Initialized
INFO - 2022-08-10 19:01:35 --> Router Class Initialized
INFO - 2022-08-10 19:01:35 --> Output Class Initialized
INFO - 2022-08-10 19:01:36 --> Security Class Initialized
DEBUG - 2022-08-10 19:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:01:36 --> Input Class Initialized
INFO - 2022-08-10 19:01:36 --> Language Class Initialized
INFO - 2022-08-10 19:01:36 --> Loader Class Initialized
INFO - 2022-08-10 19:01:36 --> Helper loaded: url_helper
INFO - 2022-08-10 19:01:36 --> Controller Class Initialized
DEBUG - 2022-08-10 19:01:36 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:01:36 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:01:36 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 19:01:36 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 19:01:36 --> Final output sent to browser
DEBUG - 2022-08-10 19:01:36 --> Total execution time: 0.5270
INFO - 2022-08-10 19:01:39 --> Config Class Initialized
INFO - 2022-08-10 19:01:39 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:01:39 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:01:39 --> Utf8 Class Initialized
INFO - 2022-08-10 19:01:39 --> URI Class Initialized
INFO - 2022-08-10 19:01:39 --> Router Class Initialized
INFO - 2022-08-10 19:01:39 --> Output Class Initialized
INFO - 2022-08-10 19:01:39 --> Security Class Initialized
DEBUG - 2022-08-10 19:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:01:39 --> Input Class Initialized
INFO - 2022-08-10 19:01:39 --> Language Class Initialized
ERROR - 2022-08-10 19:01:39 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 19:01:42 --> Config Class Initialized
INFO - 2022-08-10 19:01:42 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:01:42 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:01:42 --> Utf8 Class Initialized
INFO - 2022-08-10 19:01:42 --> URI Class Initialized
INFO - 2022-08-10 19:01:43 --> Router Class Initialized
INFO - 2022-08-10 19:01:43 --> Output Class Initialized
INFO - 2022-08-10 19:01:43 --> Security Class Initialized
DEBUG - 2022-08-10 19:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:01:43 --> Input Class Initialized
INFO - 2022-08-10 19:01:43 --> Language Class Initialized
INFO - 2022-08-10 19:01:43 --> Loader Class Initialized
INFO - 2022-08-10 19:01:43 --> Helper loaded: url_helper
INFO - 2022-08-10 19:01:43 --> Controller Class Initialized
DEBUG - 2022-08-10 19:01:43 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:01:43 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:01:43 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 19:01:43 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 19:01:43 --> Final output sent to browser
DEBUG - 2022-08-10 19:01:43 --> Total execution time: 0.4685
INFO - 2022-08-10 19:03:56 --> Config Class Initialized
INFO - 2022-08-10 19:03:56 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:03:56 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:03:56 --> Utf8 Class Initialized
INFO - 2022-08-10 19:03:56 --> URI Class Initialized
INFO - 2022-08-10 19:03:56 --> Router Class Initialized
INFO - 2022-08-10 19:03:56 --> Output Class Initialized
INFO - 2022-08-10 19:03:56 --> Security Class Initialized
DEBUG - 2022-08-10 19:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:03:56 --> Input Class Initialized
INFO - 2022-08-10 19:03:56 --> Language Class Initialized
INFO - 2022-08-10 19:03:56 --> Loader Class Initialized
INFO - 2022-08-10 19:03:56 --> Helper loaded: url_helper
INFO - 2022-08-10 19:03:56 --> Controller Class Initialized
DEBUG - 2022-08-10 19:03:56 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:03:56 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:03:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:03:57 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:04:02 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:04:02 --> Unable to connect to the database
INFO - 2022-08-10 19:04:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:04:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:04:09 --> Config Class Initialized
INFO - 2022-08-10 19:04:09 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:04:09 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:04:09 --> Utf8 Class Initialized
INFO - 2022-08-10 19:04:09 --> URI Class Initialized
INFO - 2022-08-10 19:04:09 --> Router Class Initialized
INFO - 2022-08-10 19:04:09 --> Output Class Initialized
INFO - 2022-08-10 19:04:09 --> Security Class Initialized
DEBUG - 2022-08-10 19:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:04:09 --> Input Class Initialized
INFO - 2022-08-10 19:04:09 --> Language Class Initialized
INFO - 2022-08-10 19:04:09 --> Loader Class Initialized
INFO - 2022-08-10 19:04:09 --> Helper loaded: url_helper
INFO - 2022-08-10 19:04:09 --> Controller Class Initialized
DEBUG - 2022-08-10 19:04:09 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:04:09 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:04:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:04:09 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:04:14 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2022-08-10 19:04:14 --> Config Class Initialized
INFO - 2022-08-10 19:04:14 --> Hooks Class Initialized
ERROR - 2022-08-10 19:04:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:04:14 --> Unable to connect to the database
INFO - 2022-08-10 19:04:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2022-08-10 19:04:14 --> UTF-8 Support Enabled
ERROR - 2022-08-10 19:04:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:04:14 --> Utf8 Class Initialized
INFO - 2022-08-10 19:04:14 --> URI Class Initialized
INFO - 2022-08-10 19:04:14 --> Router Class Initialized
INFO - 2022-08-10 19:04:14 --> Output Class Initialized
INFO - 2022-08-10 19:04:14 --> Security Class Initialized
DEBUG - 2022-08-10 19:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:04:14 --> Input Class Initialized
INFO - 2022-08-10 19:04:14 --> Language Class Initialized
INFO - 2022-08-10 19:04:14 --> Loader Class Initialized
INFO - 2022-08-10 19:04:15 --> Helper loaded: url_helper
INFO - 2022-08-10 19:04:15 --> Controller Class Initialized
DEBUG - 2022-08-10 19:04:15 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:04:15 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:04:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:04:15 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:04:20 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:04:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:04:20 --> Unable to connect to the database
INFO - 2022-08-10 19:04:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:04:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:04:54 --> Config Class Initialized
INFO - 2022-08-10 19:04:54 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:04:54 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:04:54 --> Utf8 Class Initialized
INFO - 2022-08-10 19:04:54 --> URI Class Initialized
INFO - 2022-08-10 19:04:54 --> Router Class Initialized
INFO - 2022-08-10 19:04:54 --> Output Class Initialized
INFO - 2022-08-10 19:04:54 --> Security Class Initialized
DEBUG - 2022-08-10 19:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:04:54 --> Input Class Initialized
INFO - 2022-08-10 19:04:54 --> Language Class Initialized
INFO - 2022-08-10 19:04:54 --> Loader Class Initialized
INFO - 2022-08-10 19:04:54 --> Helper loaded: url_helper
INFO - 2022-08-10 19:04:54 --> Controller Class Initialized
DEBUG - 2022-08-10 19:04:54 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:04:54 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:04:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:04:54 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:04:59 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:04:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:04:59 --> Unable to connect to the database
INFO - 2022-08-10 19:04:59 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:04:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:06:00 --> Config Class Initialized
INFO - 2022-08-10 19:06:00 --> Config Class Initialized
INFO - 2022-08-10 19:06:00 --> Hooks Class Initialized
INFO - 2022-08-10 19:06:00 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-10 19:06:00 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:06:00 --> Utf8 Class Initialized
INFO - 2022-08-10 19:06:00 --> Utf8 Class Initialized
INFO - 2022-08-10 19:06:00 --> URI Class Initialized
INFO - 2022-08-10 19:06:00 --> URI Class Initialized
INFO - 2022-08-10 19:06:00 --> Router Class Initialized
INFO - 2022-08-10 19:06:00 --> Router Class Initialized
INFO - 2022-08-10 19:06:00 --> Output Class Initialized
INFO - 2022-08-10 19:06:00 --> Output Class Initialized
INFO - 2022-08-10 19:06:00 --> Security Class Initialized
INFO - 2022-08-10 19:06:00 --> Security Class Initialized
DEBUG - 2022-08-10 19:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-10 19:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:06:00 --> Input Class Initialized
INFO - 2022-08-10 19:06:00 --> Input Class Initialized
INFO - 2022-08-10 19:06:00 --> Language Class Initialized
INFO - 2022-08-10 19:06:00 --> Language Class Initialized
INFO - 2022-08-10 19:06:00 --> Loader Class Initialized
INFO - 2022-08-10 19:06:00 --> Loader Class Initialized
INFO - 2022-08-10 19:06:00 --> Helper loaded: url_helper
INFO - 2022-08-10 19:06:00 --> Helper loaded: url_helper
INFO - 2022-08-10 19:06:00 --> Controller Class Initialized
INFO - 2022-08-10 19:06:00 --> Controller Class Initialized
DEBUG - 2022-08-10 19:06:00 --> Config file loaded: /sam_tool/application/config/rest.php
DEBUG - 2022-08-10 19:06:00 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:06:00 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:06:00 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:06:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:06:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:06:01 --> Database Driver Class Initialized
INFO - 2022-08-10 19:06:01 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:06:06 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:06:06 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:06:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:06:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:06:06 --> Unable to connect to the database
ERROR - 2022-08-10 19:06:06 --> Unable to connect to the database
INFO - 2022-08-10 19:06:06 --> Language file loaded: language/english/db_lang.php
INFO - 2022-08-10 19:06:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:06:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
ERROR - 2022-08-10 19:06:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:06:06 --> Config Class Initialized
INFO - 2022-08-10 19:06:06 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:06:06 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:06:06 --> Utf8 Class Initialized
INFO - 2022-08-10 19:06:06 --> URI Class Initialized
INFO - 2022-08-10 19:06:06 --> Router Class Initialized
INFO - 2022-08-10 19:06:06 --> Output Class Initialized
INFO - 2022-08-10 19:06:06 --> Security Class Initialized
DEBUG - 2022-08-10 19:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:06:06 --> Input Class Initialized
INFO - 2022-08-10 19:06:06 --> Language Class Initialized
ERROR - 2022-08-10 19:06:06 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 19:06:08 --> Config Class Initialized
INFO - 2022-08-10 19:06:08 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:06:08 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:06:08 --> Utf8 Class Initialized
INFO - 2022-08-10 19:06:08 --> URI Class Initialized
DEBUG - 2022-08-10 19:06:08 --> No URI present. Default controller set.
INFO - 2022-08-10 19:06:08 --> Router Class Initialized
INFO - 2022-08-10 19:06:08 --> Output Class Initialized
INFO - 2022-08-10 19:06:08 --> Security Class Initialized
DEBUG - 2022-08-10 19:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:06:08 --> Input Class Initialized
INFO - 2022-08-10 19:06:08 --> Language Class Initialized
INFO - 2022-08-10 19:06:08 --> Loader Class Initialized
INFO - 2022-08-10 19:06:08 --> Helper loaded: url_helper
INFO - 2022-08-10 19:06:08 --> Controller Class Initialized
INFO - 2022-08-10 19:06:08 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 19:06:08 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 19:06:08 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 19:06:08 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 71
ERROR - 2022-08-10 19:06:08 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 19:06:08 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 19:06:08 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 87
INFO - 2022-08-10 19:06:08 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 19:06:08 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 19:06:08 --> Final output sent to browser
DEBUG - 2022-08-10 19:06:08 --> Total execution time: 0.5048
INFO - 2022-08-10 19:06:09 --> Config Class Initialized
INFO - 2022-08-10 19:06:09 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:06:09 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:06:09 --> Utf8 Class Initialized
INFO - 2022-08-10 19:06:09 --> URI Class Initialized
INFO - 2022-08-10 19:06:09 --> Router Class Initialized
INFO - 2022-08-10 19:06:09 --> Output Class Initialized
INFO - 2022-08-10 19:06:09 --> Security Class Initialized
DEBUG - 2022-08-10 19:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:06:09 --> Input Class Initialized
INFO - 2022-08-10 19:06:09 --> Language Class Initialized
ERROR - 2022-08-10 19:06:09 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-10 19:06:17 --> Config Class Initialized
INFO - 2022-08-10 19:06:17 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:06:17 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:06:17 --> Utf8 Class Initialized
INFO - 2022-08-10 19:06:17 --> URI Class Initialized
INFO - 2022-08-10 19:06:17 --> Router Class Initialized
INFO - 2022-08-10 19:06:17 --> Output Class Initialized
INFO - 2022-08-10 19:06:17 --> Security Class Initialized
DEBUG - 2022-08-10 19:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:06:17 --> Input Class Initialized
INFO - 2022-08-10 19:06:17 --> Language Class Initialized
INFO - 2022-08-10 19:06:17 --> Loader Class Initialized
INFO - 2022-08-10 19:06:17 --> Helper loaded: url_helper
INFO - 2022-08-10 19:06:17 --> Controller Class Initialized
DEBUG - 2022-08-10 19:06:17 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:06:17 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:06:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:06:17 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:06:22 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:06:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:06:22 --> Unable to connect to the database
INFO - 2022-08-10 19:06:22 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:06:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:07:06 --> Config Class Initialized
INFO - 2022-08-10 19:07:06 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:07:06 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:07:06 --> Utf8 Class Initialized
INFO - 2022-08-10 19:07:06 --> URI Class Initialized
INFO - 2022-08-10 19:07:06 --> Router Class Initialized
INFO - 2022-08-10 19:07:06 --> Output Class Initialized
INFO - 2022-08-10 19:07:06 --> Security Class Initialized
DEBUG - 2022-08-10 19:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:07:06 --> Input Class Initialized
INFO - 2022-08-10 19:07:06 --> Language Class Initialized
INFO - 2022-08-10 19:07:06 --> Loader Class Initialized
INFO - 2022-08-10 19:07:06 --> Helper loaded: url_helper
INFO - 2022-08-10 19:07:06 --> Controller Class Initialized
DEBUG - 2022-08-10 19:07:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:07:06 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:07:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:07:06 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:07:11 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:07:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:07:12 --> Unable to connect to the database
INFO - 2022-08-10 19:07:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:07:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:07:14 --> Config Class Initialized
INFO - 2022-08-10 19:07:14 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:07:14 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:07:14 --> Utf8 Class Initialized
INFO - 2022-08-10 19:07:14 --> URI Class Initialized
INFO - 2022-08-10 19:07:14 --> Router Class Initialized
INFO - 2022-08-10 19:07:14 --> Output Class Initialized
INFO - 2022-08-10 19:07:14 --> Security Class Initialized
DEBUG - 2022-08-10 19:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:07:14 --> Input Class Initialized
INFO - 2022-08-10 19:07:14 --> Language Class Initialized
INFO - 2022-08-10 19:07:14 --> Loader Class Initialized
INFO - 2022-08-10 19:07:14 --> Helper loaded: url_helper
INFO - 2022-08-10 19:07:14 --> Controller Class Initialized
DEBUG - 2022-08-10 19:07:14 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:07:15 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:07:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:07:15 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:07:20 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:07:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:07:20 --> Unable to connect to the database
INFO - 2022-08-10 19:07:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:07:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:08:23 --> Config Class Initialized
INFO - 2022-08-10 19:08:23 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:08:23 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:08:23 --> Utf8 Class Initialized
INFO - 2022-08-10 19:08:23 --> URI Class Initialized
INFO - 2022-08-10 19:08:23 --> Router Class Initialized
INFO - 2022-08-10 19:08:23 --> Output Class Initialized
INFO - 2022-08-10 19:08:23 --> Security Class Initialized
DEBUG - 2022-08-10 19:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:08:23 --> Input Class Initialized
INFO - 2022-08-10 19:08:23 --> Language Class Initialized
INFO - 2022-08-10 19:08:23 --> Loader Class Initialized
INFO - 2022-08-10 19:08:23 --> Helper loaded: url_helper
INFO - 2022-08-10 19:08:23 --> Controller Class Initialized
DEBUG - 2022-08-10 19:08:23 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:08:23 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:08:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:08:24 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:08:29 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:08:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:08:29 --> Unable to connect to the database
INFO - 2022-08-10 19:08:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:08:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:12:14 --> Config Class Initialized
INFO - 2022-08-10 19:12:14 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:12:14 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:12:14 --> Utf8 Class Initialized
INFO - 2022-08-10 19:12:14 --> URI Class Initialized
INFO - 2022-08-10 19:12:14 --> Router Class Initialized
INFO - 2022-08-10 19:12:14 --> Output Class Initialized
INFO - 2022-08-10 19:12:14 --> Security Class Initialized
DEBUG - 2022-08-10 19:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:12:14 --> Input Class Initialized
INFO - 2022-08-10 19:12:14 --> Language Class Initialized
INFO - 2022-08-10 19:12:14 --> Loader Class Initialized
INFO - 2022-08-10 19:12:14 --> Helper loaded: url_helper
INFO - 2022-08-10 19:12:14 --> Controller Class Initialized
DEBUG - 2022-08-10 19:12:14 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:12:14 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:12:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:12:14 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:12:19 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:12:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:12:19 --> Unable to connect to the database
INFO - 2022-08-10 19:12:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:12:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:15:19 --> Config Class Initialized
INFO - 2022-08-10 19:15:20 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:15:20 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:15:20 --> Utf8 Class Initialized
INFO - 2022-08-10 19:15:20 --> URI Class Initialized
INFO - 2022-08-10 19:15:20 --> Router Class Initialized
INFO - 2022-08-10 19:15:20 --> Output Class Initialized
INFO - 2022-08-10 19:15:20 --> Security Class Initialized
DEBUG - 2022-08-10 19:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:15:20 --> Input Class Initialized
INFO - 2022-08-10 19:15:20 --> Language Class Initialized
INFO - 2022-08-10 19:15:20 --> Loader Class Initialized
INFO - 2022-08-10 19:15:20 --> Helper loaded: url_helper
INFO - 2022-08-10 19:15:20 --> Controller Class Initialized
DEBUG - 2022-08-10 19:15:20 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:15:20 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:15:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:15:20 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:15:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:15:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:15:25 --> Unable to connect to the database
INFO - 2022-08-10 19:15:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:15:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:15:47 --> Config Class Initialized
INFO - 2022-08-10 19:15:47 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:15:47 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:15:47 --> Utf8 Class Initialized
INFO - 2022-08-10 19:15:47 --> URI Class Initialized
INFO - 2022-08-10 19:15:47 --> Router Class Initialized
INFO - 2022-08-10 19:15:47 --> Output Class Initialized
INFO - 2022-08-10 19:15:47 --> Security Class Initialized
DEBUG - 2022-08-10 19:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:15:47 --> Input Class Initialized
INFO - 2022-08-10 19:15:47 --> Language Class Initialized
INFO - 2022-08-10 19:15:48 --> Loader Class Initialized
INFO - 2022-08-10 19:15:48 --> Helper loaded: url_helper
INFO - 2022-08-10 19:15:48 --> Controller Class Initialized
DEBUG - 2022-08-10 19:15:48 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:15:48 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:15:48 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2022-08-10 19:15:48 --> Performing LDAP authentication for root
DEBUG - 2022-08-10 19:15:48 --> LDAP Auth: Loading configuration
INFO - 2022-08-10 19:51:10 --> Config Class Initialized
INFO - 2022-08-10 19:51:10 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:51:10 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:51:10 --> Utf8 Class Initialized
INFO - 2022-08-10 19:51:10 --> URI Class Initialized
DEBUG - 2022-08-10 19:51:10 --> No URI present. Default controller set.
INFO - 2022-08-10 19:51:10 --> Router Class Initialized
INFO - 2022-08-10 19:51:10 --> Output Class Initialized
INFO - 2022-08-10 19:51:11 --> Security Class Initialized
DEBUG - 2022-08-10 19:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:51:11 --> Input Class Initialized
INFO - 2022-08-10 19:51:11 --> Language Class Initialized
INFO - 2022-08-10 19:51:11 --> Loader Class Initialized
INFO - 2022-08-10 19:51:11 --> Helper loaded: url_helper
INFO - 2022-08-10 19:51:11 --> Controller Class Initialized
INFO - 2022-08-10 19:51:11 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-10 19:51:11 --> Severity: Notice --> Undefined property: stdClass::$state_id /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 19:51:11 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 70
ERROR - 2022-08-10 19:51:11 --> Severity: Notice --> Undefined property: stdClass::$state_name /sam_tool/application/views/frontend/dashboard.php 71
ERROR - 2022-08-10 19:51:11 --> Severity: Notice --> Undefined property: stdClass::$city_id /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 19:51:11 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 86
ERROR - 2022-08-10 19:51:11 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 87
INFO - 2022-08-10 19:51:11 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-10 19:51:11 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-10 19:51:11 --> Final output sent to browser
DEBUG - 2022-08-10 19:51:11 --> Total execution time: 0.7577
INFO - 2022-08-10 19:52:28 --> Config Class Initialized
INFO - 2022-08-10 19:52:28 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:52:28 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:52:28 --> Utf8 Class Initialized
INFO - 2022-08-10 19:52:28 --> URI Class Initialized
INFO - 2022-08-10 19:52:28 --> Router Class Initialized
INFO - 2022-08-10 19:52:28 --> Output Class Initialized
INFO - 2022-08-10 19:52:28 --> Security Class Initialized
DEBUG - 2022-08-10 19:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:52:28 --> Input Class Initialized
INFO - 2022-08-10 19:52:28 --> Language Class Initialized
INFO - 2022-08-10 19:52:28 --> Loader Class Initialized
INFO - 2022-08-10 19:52:28 --> Helper loaded: url_helper
INFO - 2022-08-10 19:52:28 --> Controller Class Initialized
DEBUG - 2022-08-10 19:52:28 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:52:28 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:52:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:52:28 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:52:33 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:52:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:52:34 --> Unable to connect to the database
INFO - 2022-08-10 19:52:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:52:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:52:50 --> Config Class Initialized
INFO - 2022-08-10 19:52:50 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:52:50 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:52:50 --> Utf8 Class Initialized
INFO - 2022-08-10 19:52:50 --> URI Class Initialized
INFO - 2022-08-10 19:52:50 --> Router Class Initialized
INFO - 2022-08-10 19:52:50 --> Output Class Initialized
INFO - 2022-08-10 19:52:50 --> Security Class Initialized
DEBUG - 2022-08-10 19:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:52:50 --> Input Class Initialized
INFO - 2022-08-10 19:52:50 --> Language Class Initialized
ERROR - 2022-08-10 19:52:50 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-10 19:53:00 --> Config Class Initialized
INFO - 2022-08-10 19:53:00 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:53:00 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:53:00 --> Utf8 Class Initialized
INFO - 2022-08-10 19:53:00 --> URI Class Initialized
INFO - 2022-08-10 19:53:00 --> Router Class Initialized
INFO - 2022-08-10 19:53:00 --> Output Class Initialized
INFO - 2022-08-10 19:53:00 --> Security Class Initialized
DEBUG - 2022-08-10 19:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:53:00 --> Input Class Initialized
INFO - 2022-08-10 19:53:00 --> Language Class Initialized
INFO - 2022-08-10 19:53:00 --> Loader Class Initialized
INFO - 2022-08-10 19:53:01 --> Helper loaded: url_helper
INFO - 2022-08-10 19:53:01 --> Controller Class Initialized
DEBUG - 2022-08-10 19:53:01 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:53:01 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:53:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-10 19:53:01 --> Database Driver Class Initialized
ERROR - 2022-08-10 19:53:06 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:53:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Try again /sam_tool/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-08-10 19:53:06 --> Unable to connect to the database
INFO - 2022-08-10 19:53:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-08-10 19:53:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/system/core/Exceptions.php:271) /sam_tool/system/core/Common.php 570
INFO - 2022-08-10 19:54:44 --> Config Class Initialized
INFO - 2022-08-10 19:54:44 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:54:45 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:54:45 --> Utf8 Class Initialized
INFO - 2022-08-10 19:54:45 --> URI Class Initialized
INFO - 2022-08-10 19:54:45 --> Router Class Initialized
INFO - 2022-08-10 19:54:45 --> Output Class Initialized
INFO - 2022-08-10 19:54:45 --> Security Class Initialized
DEBUG - 2022-08-10 19:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:54:45 --> Input Class Initialized
INFO - 2022-08-10 19:54:45 --> Language Class Initialized
INFO - 2022-08-10 19:54:45 --> Loader Class Initialized
INFO - 2022-08-10 19:54:45 --> Helper loaded: url_helper
INFO - 2022-08-10 19:54:45 --> Controller Class Initialized
DEBUG - 2022-08-10 19:54:45 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:54:45 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:54:45 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 19:54:45 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 19:54:45 --> Final output sent to browser
DEBUG - 2022-08-10 19:54:45 --> Total execution time: 0.7038
INFO - 2022-08-10 19:54:50 --> Config Class Initialized
INFO - 2022-08-10 19:54:50 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:54:50 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:54:50 --> Utf8 Class Initialized
INFO - 2022-08-10 19:54:50 --> URI Class Initialized
INFO - 2022-08-10 19:54:50 --> Router Class Initialized
INFO - 2022-08-10 19:54:50 --> Output Class Initialized
INFO - 2022-08-10 19:54:50 --> Security Class Initialized
DEBUG - 2022-08-10 19:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:54:50 --> Input Class Initialized
INFO - 2022-08-10 19:54:50 --> Language Class Initialized
INFO - 2022-08-10 19:54:50 --> Loader Class Initialized
INFO - 2022-08-10 19:54:50 --> Helper loaded: url_helper
INFO - 2022-08-10 19:54:50 --> Controller Class Initialized
DEBUG - 2022-08-10 19:54:50 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:54:50 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:54:50 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 19:54:50 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 19:54:50 --> Final output sent to browser
DEBUG - 2022-08-10 19:54:50 --> Total execution time: 0.5920
INFO - 2022-08-10 19:56:25 --> Config Class Initialized
INFO - 2022-08-10 19:56:25 --> Hooks Class Initialized
DEBUG - 2022-08-10 19:56:26 --> UTF-8 Support Enabled
INFO - 2022-08-10 19:56:26 --> Utf8 Class Initialized
INFO - 2022-08-10 19:56:26 --> URI Class Initialized
INFO - 2022-08-10 19:56:26 --> Router Class Initialized
INFO - 2022-08-10 19:56:26 --> Output Class Initialized
INFO - 2022-08-10 19:56:26 --> Security Class Initialized
DEBUG - 2022-08-10 19:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-10 19:56:26 --> Input Class Initialized
INFO - 2022-08-10 19:56:26 --> Language Class Initialized
INFO - 2022-08-10 19:56:26 --> Loader Class Initialized
INFO - 2022-08-10 19:56:26 --> Helper loaded: url_helper
INFO - 2022-08-10 19:56:26 --> Controller Class Initialized
DEBUG - 2022-08-10 19:56:26 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-10 19:56:26 --> Helper loaded: inflector_helper
INFO - 2022-08-10 19:56:26 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-10 19:56:26 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Api' does not have a method 'index_post' /sam_tool/application/libraries/REST_Controller.php 739
INFO - 2022-08-10 19:56:26 --> Final output sent to browser
DEBUG - 2022-08-10 19:56:26 --> Total execution time: 0.4998
