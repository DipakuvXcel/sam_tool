<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-29 12:08:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 12:10:20 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 12:10:20 --> {"city_id":3,"state_id":2,"bank_id":1,"type_id":2,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 13:01:14 --> {"city_id":3,"state_id":2,"bank_id":1,"type_id":1,"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 13:01:14 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:05:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:05:20 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:05:20 --> {"city_id":2,"state_id":3,"bank_id":2,"type_id":3,"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 13:05:36 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:11:22 --> {"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 13:11:22 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-29 13:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-29 13:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-29 13:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-29 13:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-29 13:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-29 13:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-29 13:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-29 13:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-29 13:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-29 13:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-29 13:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-29 13:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-29 13:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-29 13:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-29 13:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-29 13:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-29 13:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-29 13:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-29 13:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-29 13:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-29 13:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-29 13:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-29 13:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-29 13:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-29 13:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-29 13:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-29 13:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-29 13:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-29 13:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-29 13:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:20:04 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-29 13:20:04 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-29 13:20:04 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-29 13:20:04 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-29 13:20:04 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-29 13:20:04 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:22:46 --> Severity: Notice --> Undefined index: GetCount /sam_tool/application/views/frontend/dashboard.php 252
ERROR - 2022-08-29 13:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 13:23:13 --> Severity: Notice --> Undefined index: GetCount /sam_tool/application/views/frontend/dashboard.php 252
ERROR - 2022-08-29 13:23:13 --> {"city_id":4,"state_id":2,"bank_id":2,"type_id":1,"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 13:23:17 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:17 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:17 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:17 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-29 13:23:17 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-29 13:23:17 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 218
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 220
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 224
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 228
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 230
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 232
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 234
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 218
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 220
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 224
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 228
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 230
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 232
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 234
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 218
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 220
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 224
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 228
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 230
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 232
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 234
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:18 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 218
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 220
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 224
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 228
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 230
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 232
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 234
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 218
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 220
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 224
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 228
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 230
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 232
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 234
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 218
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 220
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 224
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 228
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 230
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 232
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 234
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 212
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 214
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 218
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 220
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 222
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 224
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 226
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 228
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 230
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 232
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: market_price /sam_tool/application/views/frontend/dashboard.php 234
ERROR - 2022-08-29 13:23:19 --> Severity: Notice --> Undefined index: GetCount /sam_tool/application/views/frontend/dashboard.php 252
ERROR - 2022-08-29 13:23:57 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:57 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:57 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:57 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 204
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/views/frontend/dashboard.php 205
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: locality /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-29 13:23:58 --> Severity: Notice --> Undefined index: GetCount /sam_tool/application/views/frontend/dashboard.php 252
ERROR - 2022-08-29 14:30:15 --> {"city_id":2,"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 14:30:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 14:30:15 --> Severity: Notice --> Undefined index: GetCount /sam_tool/application/views/frontend/dashboard.php 252
ERROR - 2022-08-29 15:22:55 --> {"city_id":1,"state_id":2,"bank_id":1,"type_id":1,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:00:54 --> Severity: error --> Exception: syntax error, unexpected end of file /sam_tool/application/views/frontend/dashboard.php 435
ERROR - 2022-08-29 17:00:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-29 17:01:51 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 320
ERROR - 2022-08-29 17:01:59 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 320
ERROR - 2022-08-29 17:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-29 17:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-29 17:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-29 17:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-29 17:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-29 17:02:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 195
ERROR - 2022-08-29 17:02:14 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 320
ERROR - 2022-08-29 17:04:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 195
ERROR - 2022-08-29 17:04:38 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 320
ERROR - 2022-08-29 17:06:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 195
ERROR - 2022-08-29 17:06:06 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 320
ERROR - 2022-08-29 17:08:06 --> Severity: error --> Exception: syntax error, unexpected ';' /sam_tool/application/views/frontend/dashboard.php 195
ERROR - 2022-08-29 17:11:54 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 320
ERROR - 2022-08-29 17:12:38 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 321
ERROR - 2022-08-29 17:12:54 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 321
ERROR - 2022-08-29 17:13:00 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:13:00 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 321
ERROR - 2022-08-29 17:13:03 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 321
ERROR - 2022-08-29 17:14:33 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 322
ERROR - 2022-08-29 17:14:34 --> 404 Page Not Found: Assets/img
ERROR - 2022-08-29 17:14:39 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:14:39 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 322
ERROR - 2022-08-29 17:14:40 --> 404 Page Not Found: Assets/img
ERROR - 2022-08-29 17:15:54 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 322
ERROR - 2022-08-29 17:15:55 --> 404 Page Not Found: Assets/imgages
ERROR - 2022-08-29 17:16:14 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 322
ERROR - 2022-08-29 17:16:51 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 329
ERROR - 2022-08-29 17:17:00 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 329
ERROR - 2022-08-29 17:17:00 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:17:04 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 329
ERROR - 2022-08-29 17:17:14 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:17:16 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 329
ERROR - 2022-08-29 17:17:17 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:22:40 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:22:40 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:22:40 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:22:42 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:23:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:23:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:23:23 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:23:24 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:23:52 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:23:52 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:23:52 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:23:53 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:24:36 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:24:36 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:24:36 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:24:37 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:25:53 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:25:53 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:25:53 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:25:54 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:25:54 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:25:54 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:25:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:25:55 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:26:22 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:26:22 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:26:22 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:26:22 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:26:23 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:26:26 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:26:26 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:26:26 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:26:27 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:28:47 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:28:47 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:28:48 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:28:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:28:54 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:28:54 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:28:54 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:28:54 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:28:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:29:05 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:29:05 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:29:05 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:29:05 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:29:06 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:30:20 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:30:20 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:30:20 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 283
ERROR - 2022-08-29 17:30:21 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:30:24 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:30:24 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:30:24 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:30:24 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 283
ERROR - 2022-08-29 17:30:24 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:30:29 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:30:29 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:30:30 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 283
ERROR - 2022-08-29 17:30:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:22 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:23 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:24 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:25 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:32:50 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 202
ERROR - 2022-08-29 17:32:50 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 223
ERROR - 2022-08-29 17:32:51 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 250
ERROR - 2022-08-29 17:32:51 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:33:57 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:33:57 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 252
ERROR - 2022-08-29 17:33:58 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:34:38 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:34:38 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:34:38 --> Severity: Notice --> Undefined variable: results /sam_tool/application/views/frontend/dashboard.php 252
ERROR - 2022-08-29 17:38:40 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:41 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:41 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:41 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:41 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:42 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:43 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:44 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:46 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:46 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:47 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:49 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:50 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:50 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:52 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:53 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:38:54 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:38:54 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:42:58 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:43:08 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:43:48 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:43:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:45:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:45:27 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:45:52 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:45:54 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:46:18 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:46:20 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:46:20 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:46:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:46:25 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:46:25 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:47:11 --> Severity: error --> Exception: syntax error, unexpected '{' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:47:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:47:35 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:47:39 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:47:43 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:47:44 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:48:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-29 17:48:32 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:48:37 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:48:38 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:48:39 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:48:39 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:48:42 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:49:56 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:50:01 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:50:06 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:50:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:51:21 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:51:27 --> {"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:51:39 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:52:21 --> 404 Page Not Found: Frontend/favicon.ico
ERROR - 2022-08-29 17:52:23 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:52:25 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:52:32 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:52:38 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:56:47 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:56:47 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:57:32 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 281
ERROR - 2022-08-29 17:57:32 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:58:18 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:58:26 --> {"state_id":1,"type_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 17:58:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:59:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 17:59:17 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:59:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 17:59:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 17:59:17 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 17:59:24 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:00:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:00:05 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:01:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:01:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:01:58 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:01:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:01:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:01:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:01:59 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:01:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:01:59 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:02:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:02:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:02:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:02:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:02:37 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:03:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:03:07 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:03:13 --> {"state_id":5,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:03:15 --> {"state_id":5,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:03:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:03:21 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:03:37 --> {"state_id":4,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:03:52 --> {"city_id":1,"state_id":4,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:04:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:04:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:06:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:06:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:06:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:07:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:07:20 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:07:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:07:23 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:07:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:07:56 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:07:59 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:08:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:08:03 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:08:13 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:08:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:08:17 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:09:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:09:12 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:09:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:09:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:09:32 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:09:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:09:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:09:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:09:48 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:10:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:10:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:10:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:10:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:10:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:10:48 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:10:59 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:11:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:11:01 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:11:09 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-29 18:11:09 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-29 18:11:09 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-29 18:11:09 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-29 18:11:09 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-29 18:11:09 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-29 18:11:11 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:11:16 --> {"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:11:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:11:18 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:11:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:11:34 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:11:42 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:11:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:11:45 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:13:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:13:04 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:13:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:17:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:17:37 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:17:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:17:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:17:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:18 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:18:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:18:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:19:07 --> Severity: error --> Exception: syntax error, unexpected '>' /sam_tool/application/views/frontend/dashboard.php 225
ERROR - 2022-08-29 18:19:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:19:26 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:19:29 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:19:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:19:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:19:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:19:51 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:19:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:19:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:08 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:20:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:13 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:20:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:34 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:20:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:05 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:21:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:21:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:21:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:22:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:06 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:22:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:22:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:22:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:23:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:23:53 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 315
ERROR - 2022-08-29 18:23:53 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:27:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:27:07 --> Severity: Notice --> Undefined variable: total_pages /sam_tool/application/views/frontend/dashboard.php 314
ERROR - 2022-08-29 18:27:07 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:27:10 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:27:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:27:47 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:27:50 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:31:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:39 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 347
ERROR - 2022-08-29 18:31:39 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 347
ERROR - 2022-08-29 18:31:39 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 347
ERROR - 2022-08-29 18:31:39 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 347
ERROR - 2022-08-29 18:31:39 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 347
ERROR - 2022-08-29 18:31:43 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:31:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:31:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:32:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:32:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:32:45 --> {"state_id":1,"bank_id":1,"locality":5,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:32:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:32:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:32:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:33:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:24 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:34:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:38 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:34:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:34:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:35:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:36:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:44:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:45:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:47:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:48:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:48:19 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:48:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:51:42 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:51:47 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:51:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:52:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:52:48 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:52:50 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:52:52 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:52:55 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:52:55 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:52:56 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:53:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:53:24 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:54:33 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:54:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:54:42 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:54:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:55:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:55:14 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:55:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:55:19 --> {"type_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:55:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:55:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:55:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:55:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:55:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:56:00 --> {"city_id":1,"state_id":1,"bank_id":1,"type_id":3,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:56:05 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:56:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:56:05 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-29 18:56:07 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:56:07 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:56:07 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:56:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:56:12 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 349
ERROR - 2022-08-29 18:56:12 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 349
ERROR - 2022-08-29 18:56:12 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 349
ERROR - 2022-08-29 18:56:12 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 349
ERROR - 2022-08-29 18:56:12 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 349
ERROR - 2022-08-29 18:56:17 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:56:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:56:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 18:56:44 --> {"city_id":1,"state_id":1,"bank_id":3,"type_id":4,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 18:56:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:02:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:02:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:02:58 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:02:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:04:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:04:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:04:23 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:04:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:04:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:04:51 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:04:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:05:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:06:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:07:49 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:07:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:07:54 --> {"type_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:07:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:07:59 --> {"bank_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:03 --> {"bank_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:07 --> {"bank_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:12 --> {"bank_id":4,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:17 --> {"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:22 --> {"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:26 --> {"city_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:31 --> {"state_id":4,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:35 --> {"state_id":6,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:40 --> {"state_id":5,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:45 --> {"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:08:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:08:59 --> {"city_id":1,"state_id":1,"bank_id":4,"type_id":3,"locality":6,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:09:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:15:50 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:15:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:16:01 --> {"city_id":2,"state_id":1,"bank_id":3,"type_id":1,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:16:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:16:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:16:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:16:41 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:16:41 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:16:41 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:16:41 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:16:41 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:20:09 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:20:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:20:15 --> {"city_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:20:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:20:20 --> {"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:20:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:20:30 --> {"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:20:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:20:34 --> {"bank_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:20:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:20:40 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:20:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:22:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:22:05 --> {"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:22:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
ERROR - 2022-08-29 19:22:06 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:22:06 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:22:06 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:22:06 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:22:06 --> Severity: Notice --> Undefined variable: result /sam_tool/application/views/frontend/dashboard.php 350
ERROR - 2022-08-29 19:23:04 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-29 19:23:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 90
