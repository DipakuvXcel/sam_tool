<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-19 12:50:32 --> Config Class Initialized
INFO - 2022-08-19 12:50:32 --> Hooks Class Initialized
DEBUG - 2022-08-19 12:50:32 --> UTF-8 Support Enabled
INFO - 2022-08-19 12:50:32 --> Utf8 Class Initialized
INFO - 2022-08-19 12:50:32 --> URI Class Initialized
DEBUG - 2022-08-19 12:50:32 --> No URI present. Default controller set.
INFO - 2022-08-19 12:50:32 --> Router Class Initialized
INFO - 2022-08-19 12:50:32 --> Output Class Initialized
INFO - 2022-08-19 12:50:32 --> Security Class Initialized
DEBUG - 2022-08-19 12:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-19 12:50:32 --> Input Class Initialized
INFO - 2022-08-19 12:50:32 --> Language Class Initialized
ERROR - 2022-08-19 12:50:32 --> Severity: error --> Exception: syntax error, unexpected 'frontend' (T_STRING) /sam_tool/application/controllers/Frontend.php 236
INFO - 2022-08-19 12:50:32 --> Config Class Initialized
INFO - 2022-08-19 12:50:32 --> Hooks Class Initialized
DEBUG - 2022-08-19 12:50:32 --> UTF-8 Support Enabled
INFO - 2022-08-19 12:50:32 --> Utf8 Class Initialized
INFO - 2022-08-19 12:50:32 --> URI Class Initialized
INFO - 2022-08-19 12:50:32 --> Router Class Initialized
INFO - 2022-08-19 12:50:32 --> Output Class Initialized
INFO - 2022-08-19 12:50:32 --> Security Class Initialized
DEBUG - 2022-08-19 12:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-19 12:50:32 --> Input Class Initialized
INFO - 2022-08-19 12:50:32 --> Language Class Initialized
ERROR - 2022-08-19 12:50:32 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-19 13:02:14 --> Config Class Initialized
INFO - 2022-08-19 13:02:14 --> Hooks Class Initialized
DEBUG - 2022-08-19 13:02:14 --> UTF-8 Support Enabled
INFO - 2022-08-19 13:02:14 --> Utf8 Class Initialized
INFO - 2022-08-19 13:02:14 --> URI Class Initialized
DEBUG - 2022-08-19 13:02:15 --> No URI present. Default controller set.
INFO - 2022-08-19 13:02:15 --> Router Class Initialized
INFO - 2022-08-19 13:02:15 --> Output Class Initialized
INFO - 2022-08-19 13:02:15 --> Security Class Initialized
DEBUG - 2022-08-19 13:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-19 13:02:15 --> Input Class Initialized
INFO - 2022-08-19 13:02:15 --> Language Class Initialized
INFO - 2022-08-19 13:02:15 --> Loader Class Initialized
INFO - 2022-08-19 13:02:15 --> Helper loaded: url_helper
INFO - 2022-08-19 13:02:15 --> Controller Class Initialized
INFO - 2022-08-19 13:02:15 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-19 13:02:15 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-19 13:02:15 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-19 13:02:15 --> Final output sent to browser
DEBUG - 2022-08-19 13:02:15 --> Total execution time: 0.8004
INFO - 2022-08-19 13:07:28 --> Config Class Initialized
INFO - 2022-08-19 13:07:28 --> Hooks Class Initialized
DEBUG - 2022-08-19 13:07:28 --> UTF-8 Support Enabled
INFO - 2022-08-19 13:07:28 --> Utf8 Class Initialized
INFO - 2022-08-19 13:07:28 --> URI Class Initialized
DEBUG - 2022-08-19 13:07:28 --> No URI present. Default controller set.
INFO - 2022-08-19 13:07:28 --> Router Class Initialized
INFO - 2022-08-19 13:07:28 --> Output Class Initialized
INFO - 2022-08-19 13:07:28 --> Security Class Initialized
DEBUG - 2022-08-19 13:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-19 13:07:28 --> Input Class Initialized
INFO - 2022-08-19 13:07:28 --> Language Class Initialized
INFO - 2022-08-19 13:07:28 --> Loader Class Initialized
INFO - 2022-08-19 13:07:28 --> Helper loaded: url_helper
INFO - 2022-08-19 13:07:28 --> Controller Class Initialized
INFO - 2022-08-19 13:07:28 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-19 13:07:29 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-19 13:07:29 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-19 13:07:29 --> Final output sent to browser
DEBUG - 2022-08-19 13:07:29 --> Total execution time: 0.5232
INFO - 2022-08-19 13:07:37 --> Config Class Initialized
INFO - 2022-08-19 13:07:37 --> Hooks Class Initialized
DEBUG - 2022-08-19 13:07:37 --> UTF-8 Support Enabled
INFO - 2022-08-19 13:07:37 --> Utf8 Class Initialized
INFO - 2022-08-19 13:07:37 --> URI Class Initialized
INFO - 2022-08-19 13:07:37 --> Router Class Initialized
INFO - 2022-08-19 13:07:37 --> Output Class Initialized
INFO - 2022-08-19 13:07:37 --> Security Class Initialized
DEBUG - 2022-08-19 13:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-19 13:07:37 --> Input Class Initialized
INFO - 2022-08-19 13:07:37 --> Language Class Initialized
INFO - 2022-08-19 13:07:37 --> Loader Class Initialized
INFO - 2022-08-19 13:07:37 --> Helper loaded: url_helper
INFO - 2022-08-19 13:07:37 --> Controller Class Initialized
DEBUG - 2022-08-19 13:07:37 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-19 13:07:37 --> Helper loaded: inflector_helper
INFO - 2022-08-19 13:07:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-19 13:07:37 --> Final output sent to browser
DEBUG - 2022-08-19 13:07:37 --> Total execution time: 0.6506
