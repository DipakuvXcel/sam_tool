<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-05 12:23:36 --> Config Class Initialized
INFO - 2022-08-05 12:23:36 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:23:36 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:23:36 --> Utf8 Class Initialized
INFO - 2022-08-05 12:23:36 --> URI Class Initialized
DEBUG - 2022-08-05 12:23:36 --> No URI present. Default controller set.
INFO - 2022-08-05 12:23:36 --> Router Class Initialized
INFO - 2022-08-05 12:23:36 --> Output Class Initialized
INFO - 2022-08-05 12:23:36 --> Security Class Initialized
DEBUG - 2022-08-05 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:23:36 --> Input Class Initialized
INFO - 2022-08-05 12:23:36 --> Language Class Initialized
INFO - 2022-08-05 12:23:36 --> Loader Class Initialized
INFO - 2022-08-05 12:23:36 --> Helper loaded: url_helper
INFO - 2022-08-05 12:23:36 --> Controller Class Initialized
INFO - 2022-08-05 12:23:36 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-05 12:23:36 --> Severity: Notice --> Undefined variable: total_Commercial /sam_tool/application/views/frontend/dashboard.php 249
ERROR - 2022-08-05 12:23:36 --> Severity: Notice --> Trying to get property 'price' of non-object /sam_tool/application/views/frontend/dashboard.php 249
INFO - 2022-08-05 12:23:36 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:23:36 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 12:23:36 --> Final output sent to browser
DEBUG - 2022-08-05 12:23:36 --> Total execution time: 0.6848
INFO - 2022-08-05 12:23:58 --> Config Class Initialized
INFO - 2022-08-05 12:23:58 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:23:58 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:23:58 --> Utf8 Class Initialized
INFO - 2022-08-05 12:23:58 --> URI Class Initialized
DEBUG - 2022-08-05 12:23:58 --> No URI present. Default controller set.
INFO - 2022-08-05 12:23:58 --> Router Class Initialized
INFO - 2022-08-05 12:23:58 --> Output Class Initialized
INFO - 2022-08-05 12:23:58 --> Security Class Initialized
DEBUG - 2022-08-05 12:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:23:58 --> Input Class Initialized
INFO - 2022-08-05 12:23:58 --> Language Class Initialized
INFO - 2022-08-05 12:23:58 --> Loader Class Initialized
INFO - 2022-08-05 12:23:58 --> Helper loaded: url_helper
INFO - 2022-08-05 12:23:58 --> Controller Class Initialized
INFO - 2022-08-05 12:23:58 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 12:23:58 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:23:58 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 12:23:58 --> Final output sent to browser
DEBUG - 2022-08-05 12:23:58 --> Total execution time: 0.2792
INFO - 2022-08-05 12:24:12 --> Config Class Initialized
INFO - 2022-08-05 12:24:12 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:24:12 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:24:12 --> Utf8 Class Initialized
INFO - 2022-08-05 12:24:12 --> URI Class Initialized
INFO - 2022-08-05 12:24:12 --> Router Class Initialized
INFO - 2022-08-05 12:24:12 --> Output Class Initialized
INFO - 2022-08-05 12:24:12 --> Security Class Initialized
DEBUG - 2022-08-05 12:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:24:12 --> Input Class Initialized
INFO - 2022-08-05 12:24:12 --> Language Class Initialized
INFO - 2022-08-05 12:24:12 --> Loader Class Initialized
INFO - 2022-08-05 12:24:12 --> Helper loaded: url_helper
INFO - 2022-08-05 12:24:12 --> Controller Class Initialized
INFO - 2022-08-05 12:24:12 --> Final output sent to browser
DEBUG - 2022-08-05 12:24:12 --> Total execution time: 0.2136
INFO - 2022-08-05 12:24:12 --> Config Class Initialized
INFO - 2022-08-05 12:24:12 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:24:12 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:24:12 --> Utf8 Class Initialized
INFO - 2022-08-05 12:24:12 --> URI Class Initialized
INFO - 2022-08-05 12:24:12 --> Router Class Initialized
INFO - 2022-08-05 12:24:12 --> Output Class Initialized
INFO - 2022-08-05 12:24:12 --> Security Class Initialized
DEBUG - 2022-08-05 12:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:24:12 --> Input Class Initialized
INFO - 2022-08-05 12:24:12 --> Language Class Initialized
ERROR - 2022-08-05 12:24:12 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-05 12:36:04 --> Config Class Initialized
INFO - 2022-08-05 12:36:04 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:36:04 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:36:04 --> Utf8 Class Initialized
INFO - 2022-08-05 12:36:04 --> URI Class Initialized
INFO - 2022-08-05 12:36:04 --> Router Class Initialized
INFO - 2022-08-05 12:36:04 --> Output Class Initialized
INFO - 2022-08-05 12:36:04 --> Security Class Initialized
DEBUG - 2022-08-05 12:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:36:04 --> Input Class Initialized
INFO - 2022-08-05 12:36:04 --> Language Class Initialized
INFO - 2022-08-05 12:36:04 --> Loader Class Initialized
INFO - 2022-08-05 12:36:04 --> Helper loaded: url_helper
INFO - 2022-08-05 12:36:04 --> Controller Class Initialized
INFO - 2022-08-05 12:36:04 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 12:36:04 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:36:04 --> File loaded: /sam_tool/application/views/frontend/property_details.php
INFO - 2022-08-05 12:36:04 --> Final output sent to browser
DEBUG - 2022-08-05 12:36:04 --> Total execution time: 0.2826
INFO - 2022-08-05 12:36:15 --> Config Class Initialized
INFO - 2022-08-05 12:36:15 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:36:15 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:36:15 --> Utf8 Class Initialized
INFO - 2022-08-05 12:36:15 --> URI Class Initialized
INFO - 2022-08-05 12:36:16 --> Router Class Initialized
INFO - 2022-08-05 12:36:16 --> Output Class Initialized
INFO - 2022-08-05 12:36:16 --> Security Class Initialized
DEBUG - 2022-08-05 12:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:36:16 --> Input Class Initialized
INFO - 2022-08-05 12:36:16 --> Language Class Initialized
INFO - 2022-08-05 12:36:16 --> Loader Class Initialized
INFO - 2022-08-05 12:36:16 --> Helper loaded: url_helper
INFO - 2022-08-05 12:36:16 --> Controller Class Initialized
INFO - 2022-08-05 12:36:16 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 12:36:16 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:36:16 --> File loaded: /sam_tool/application/views/frontend/property_details.php
INFO - 2022-08-05 12:36:16 --> Final output sent to browser
DEBUG - 2022-08-05 12:36:16 --> Total execution time: 0.2490
INFO - 2022-08-05 12:37:12 --> Config Class Initialized
INFO - 2022-08-05 12:37:12 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:37:12 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:37:12 --> Utf8 Class Initialized
INFO - 2022-08-05 12:37:12 --> URI Class Initialized
INFO - 2022-08-05 12:37:12 --> Router Class Initialized
INFO - 2022-08-05 12:37:12 --> Output Class Initialized
INFO - 2022-08-05 12:37:12 --> Security Class Initialized
DEBUG - 2022-08-05 12:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:37:12 --> Input Class Initialized
INFO - 2022-08-05 12:37:12 --> Language Class Initialized
INFO - 2022-08-05 12:37:12 --> Loader Class Initialized
INFO - 2022-08-05 12:37:12 --> Helper loaded: url_helper
INFO - 2022-08-05 12:37:12 --> Controller Class Initialized
INFO - 2022-08-05 12:37:12 --> File loaded: /sam_tool/application/views/frontend/register_cust.php
INFO - 2022-08-05 12:37:12 --> Final output sent to browser
DEBUG - 2022-08-05 12:37:12 --> Total execution time: 0.2054
INFO - 2022-08-05 12:37:12 --> Config Class Initialized
INFO - 2022-08-05 12:37:12 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:37:12 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:37:12 --> Utf8 Class Initialized
INFO - 2022-08-05 12:37:12 --> URI Class Initialized
INFO - 2022-08-05 12:37:12 --> Router Class Initialized
INFO - 2022-08-05 12:37:12 --> Output Class Initialized
INFO - 2022-08-05 12:37:12 --> Security Class Initialized
DEBUG - 2022-08-05 12:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:37:12 --> Input Class Initialized
INFO - 2022-08-05 12:37:12 --> Language Class Initialized
ERROR - 2022-08-05 12:37:12 --> 404 Page Not Found: Frontend/favicon.ico
INFO - 2022-08-05 12:39:14 --> Config Class Initialized
INFO - 2022-08-05 12:39:14 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:39:14 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:39:14 --> Utf8 Class Initialized
INFO - 2022-08-05 12:39:14 --> URI Class Initialized
DEBUG - 2022-08-05 12:39:14 --> No URI present. Default controller set.
INFO - 2022-08-05 12:39:14 --> Router Class Initialized
INFO - 2022-08-05 12:39:14 --> Output Class Initialized
INFO - 2022-08-05 12:39:14 --> Security Class Initialized
DEBUG - 2022-08-05 12:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:39:14 --> Input Class Initialized
INFO - 2022-08-05 12:39:14 --> Language Class Initialized
INFO - 2022-08-05 12:39:14 --> Loader Class Initialized
INFO - 2022-08-05 12:39:14 --> Helper loaded: url_helper
INFO - 2022-08-05 12:39:14 --> Controller Class Initialized
INFO - 2022-08-05 12:39:14 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-05 12:39:14 --> Severity: Notice --> Undefined variable: total_Commercial /sam_tool/application/views/frontend/dashboard.php 249
ERROR - 2022-08-05 12:39:14 --> Severity: Notice --> Trying to get property 'price' of non-object /sam_tool/application/views/frontend/dashboard.php 249
INFO - 2022-08-05 12:39:14 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:39:14 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 12:39:14 --> Final output sent to browser
DEBUG - 2022-08-05 12:39:14 --> Total execution time: 0.3079
INFO - 2022-08-05 12:39:36 --> Config Class Initialized
INFO - 2022-08-05 12:39:36 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:39:36 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:39:36 --> Utf8 Class Initialized
INFO - 2022-08-05 12:39:36 --> URI Class Initialized
INFO - 2022-08-05 12:39:36 --> Router Class Initialized
INFO - 2022-08-05 12:39:36 --> Output Class Initialized
INFO - 2022-08-05 12:39:36 --> Security Class Initialized
DEBUG - 2022-08-05 12:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:39:36 --> Input Class Initialized
INFO - 2022-08-05 12:39:36 --> Language Class Initialized
ERROR - 2022-08-05 12:39:36 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 12:40:15 --> Config Class Initialized
INFO - 2022-08-05 12:40:15 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:40:15 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:40:15 --> Utf8 Class Initialized
INFO - 2022-08-05 12:40:15 --> URI Class Initialized
INFO - 2022-08-05 12:40:15 --> Router Class Initialized
INFO - 2022-08-05 12:40:15 --> Output Class Initialized
INFO - 2022-08-05 12:40:15 --> Security Class Initialized
DEBUG - 2022-08-05 12:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:40:15 --> Input Class Initialized
INFO - 2022-08-05 12:40:15 --> Language Class Initialized
ERROR - 2022-08-05 12:40:15 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 12:41:21 --> Config Class Initialized
INFO - 2022-08-05 12:41:21 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:41:21 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:41:21 --> Utf8 Class Initialized
INFO - 2022-08-05 12:41:21 --> URI Class Initialized
INFO - 2022-08-05 12:41:21 --> Router Class Initialized
INFO - 2022-08-05 12:41:21 --> Output Class Initialized
INFO - 2022-08-05 12:41:21 --> Security Class Initialized
DEBUG - 2022-08-05 12:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:41:21 --> Input Class Initialized
INFO - 2022-08-05 12:41:21 --> Language Class Initialized
ERROR - 2022-08-05 12:41:21 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 12:41:22 --> Config Class Initialized
INFO - 2022-08-05 12:41:22 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:41:22 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:41:22 --> Utf8 Class Initialized
INFO - 2022-08-05 12:41:22 --> URI Class Initialized
DEBUG - 2022-08-05 12:41:22 --> No URI present. Default controller set.
INFO - 2022-08-05 12:41:22 --> Router Class Initialized
INFO - 2022-08-05 12:41:22 --> Output Class Initialized
INFO - 2022-08-05 12:41:22 --> Security Class Initialized
DEBUG - 2022-08-05 12:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:41:22 --> Input Class Initialized
INFO - 2022-08-05 12:41:22 --> Language Class Initialized
INFO - 2022-08-05 12:41:22 --> Loader Class Initialized
INFO - 2022-08-05 12:41:22 --> Helper loaded: url_helper
INFO - 2022-08-05 12:41:22 --> Controller Class Initialized
INFO - 2022-08-05 12:41:22 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-05 12:41:22 --> Severity: Notice --> Undefined variable: total_Commercial /sam_tool/application/views/frontend/dashboard.php 249
ERROR - 2022-08-05 12:41:22 --> Severity: Notice --> Trying to get property 'price' of non-object /sam_tool/application/views/frontend/dashboard.php 249
INFO - 2022-08-05 12:41:22 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:41:22 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 12:41:22 --> Final output sent to browser
DEBUG - 2022-08-05 12:41:22 --> Total execution time: 0.3429
INFO - 2022-08-05 12:41:22 --> Config Class Initialized
INFO - 2022-08-05 12:41:22 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:41:23 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:41:23 --> Utf8 Class Initialized
INFO - 2022-08-05 12:41:23 --> URI Class Initialized
INFO - 2022-08-05 12:41:23 --> Router Class Initialized
INFO - 2022-08-05 12:41:23 --> Output Class Initialized
INFO - 2022-08-05 12:41:23 --> Security Class Initialized
DEBUG - 2022-08-05 12:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:41:23 --> Input Class Initialized
INFO - 2022-08-05 12:41:23 --> Language Class Initialized
ERROR - 2022-08-05 12:41:23 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 12:41:27 --> Config Class Initialized
INFO - 2022-08-05 12:41:27 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:41:27 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:41:27 --> Utf8 Class Initialized
INFO - 2022-08-05 12:41:27 --> URI Class Initialized
DEBUG - 2022-08-05 12:41:27 --> No URI present. Default controller set.
INFO - 2022-08-05 12:41:27 --> Router Class Initialized
INFO - 2022-08-05 12:41:27 --> Output Class Initialized
INFO - 2022-08-05 12:41:27 --> Security Class Initialized
DEBUG - 2022-08-05 12:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:41:27 --> Input Class Initialized
INFO - 2022-08-05 12:41:27 --> Language Class Initialized
INFO - 2022-08-05 12:41:27 --> Loader Class Initialized
INFO - 2022-08-05 12:41:27 --> Helper loaded: url_helper
INFO - 2022-08-05 12:41:27 --> Controller Class Initialized
INFO - 2022-08-05 12:41:27 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-05 12:41:27 --> Severity: Notice --> Undefined variable: total_Commercial /sam_tool/application/views/frontend/dashboard.php 249
ERROR - 2022-08-05 12:41:27 --> Severity: Notice --> Trying to get property 'price' of non-object /sam_tool/application/views/frontend/dashboard.php 249
INFO - 2022-08-05 12:41:27 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:41:27 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 12:41:27 --> Final output sent to browser
DEBUG - 2022-08-05 12:41:27 --> Total execution time: 0.2108
INFO - 2022-08-05 12:41:42 --> Config Class Initialized
INFO - 2022-08-05 12:41:42 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:41:42 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:41:42 --> Utf8 Class Initialized
INFO - 2022-08-05 12:41:42 --> URI Class Initialized
DEBUG - 2022-08-05 12:41:42 --> No URI present. Default controller set.
INFO - 2022-08-05 12:41:42 --> Router Class Initialized
INFO - 2022-08-05 12:41:42 --> Output Class Initialized
INFO - 2022-08-05 12:41:42 --> Security Class Initialized
DEBUG - 2022-08-05 12:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:41:42 --> Input Class Initialized
INFO - 2022-08-05 12:41:42 --> Language Class Initialized
INFO - 2022-08-05 12:41:42 --> Loader Class Initialized
INFO - 2022-08-05 12:41:42 --> Helper loaded: url_helper
INFO - 2022-08-05 12:41:42 --> Controller Class Initialized
INFO - 2022-08-05 12:41:42 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-05 12:41:42 --> Severity: Notice --> Undefined variable: total_Commercial /sam_tool/application/views/frontend/dashboard.php 249
ERROR - 2022-08-05 12:41:42 --> Severity: Notice --> Trying to get property 'price' of non-object /sam_tool/application/views/frontend/dashboard.php 249
INFO - 2022-08-05 12:41:42 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:41:42 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 12:41:42 --> Final output sent to browser
DEBUG - 2022-08-05 12:41:42 --> Total execution time: 0.2668
INFO - 2022-08-05 12:41:45 --> Config Class Initialized
INFO - 2022-08-05 12:41:45 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:41:45 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:41:45 --> Utf8 Class Initialized
INFO - 2022-08-05 12:41:45 --> URI Class Initialized
DEBUG - 2022-08-05 12:41:45 --> No URI present. Default controller set.
INFO - 2022-08-05 12:41:45 --> Router Class Initialized
INFO - 2022-08-05 12:41:45 --> Output Class Initialized
INFO - 2022-08-05 12:41:45 --> Security Class Initialized
DEBUG - 2022-08-05 12:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:41:45 --> Input Class Initialized
INFO - 2022-08-05 12:41:45 --> Language Class Initialized
INFO - 2022-08-05 12:41:45 --> Loader Class Initialized
INFO - 2022-08-05 12:41:45 --> Helper loaded: url_helper
INFO - 2022-08-05 12:41:45 --> Controller Class Initialized
INFO - 2022-08-05 12:41:45 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-05 12:41:45 --> Severity: Notice --> Undefined variable: total_Commercial /sam_tool/application/views/frontend/dashboard.php 249
ERROR - 2022-08-05 12:41:45 --> Severity: Notice --> Trying to get property 'price' of non-object /sam_tool/application/views/frontend/dashboard.php 249
INFO - 2022-08-05 12:41:45 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:41:45 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 12:41:45 --> Final output sent to browser
DEBUG - 2022-08-05 12:41:45 --> Total execution time: 0.2838
INFO - 2022-08-05 12:41:46 --> Config Class Initialized
INFO - 2022-08-05 12:41:46 --> Hooks Class Initialized
DEBUG - 2022-08-05 12:41:46 --> UTF-8 Support Enabled
INFO - 2022-08-05 12:41:46 --> Utf8 Class Initialized
INFO - 2022-08-05 12:41:46 --> URI Class Initialized
DEBUG - 2022-08-05 12:41:46 --> No URI present. Default controller set.
INFO - 2022-08-05 12:41:46 --> Router Class Initialized
INFO - 2022-08-05 12:41:46 --> Output Class Initialized
INFO - 2022-08-05 12:41:46 --> Security Class Initialized
DEBUG - 2022-08-05 12:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 12:41:46 --> Input Class Initialized
INFO - 2022-08-05 12:41:46 --> Language Class Initialized
INFO - 2022-08-05 12:41:46 --> Loader Class Initialized
INFO - 2022-08-05 12:41:46 --> Helper loaded: url_helper
INFO - 2022-08-05 12:41:46 --> Controller Class Initialized
INFO - 2022-08-05 12:41:46 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-05 12:41:46 --> Severity: Notice --> Undefined variable: total_Commercial /sam_tool/application/views/frontend/dashboard.php 249
ERROR - 2022-08-05 12:41:46 --> Severity: Notice --> Trying to get property 'price' of non-object /sam_tool/application/views/frontend/dashboard.php 249
INFO - 2022-08-05 12:41:46 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 12:41:46 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 12:41:46 --> Final output sent to browser
DEBUG - 2022-08-05 12:41:46 --> Total execution time: 0.2894
INFO - 2022-08-05 17:15:32 --> Config Class Initialized
INFO - 2022-08-05 17:15:32 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:15:32 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:15:32 --> Utf8 Class Initialized
INFO - 2022-08-05 17:15:32 --> URI Class Initialized
DEBUG - 2022-08-05 17:15:32 --> No URI present. Default controller set.
INFO - 2022-08-05 17:15:32 --> Router Class Initialized
INFO - 2022-08-05 17:15:32 --> Output Class Initialized
INFO - 2022-08-05 17:15:32 --> Security Class Initialized
DEBUG - 2022-08-05 17:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:15:32 --> Input Class Initialized
INFO - 2022-08-05 17:15:32 --> Language Class Initialized
INFO - 2022-08-05 17:15:32 --> Loader Class Initialized
INFO - 2022-08-05 17:15:32 --> Helper loaded: url_helper
INFO - 2022-08-05 17:15:32 --> Controller Class Initialized
INFO - 2022-08-05 17:15:33 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-05 17:15:33 --> Severity: Notice --> Undefined variable: total_Commercial /sam_tool/application/views/frontend/dashboard.php 248
ERROR - 2022-08-05 17:15:33 --> Severity: Notice --> Trying to get property 'price' of non-object /sam_tool/application/views/frontend/dashboard.php 248
INFO - 2022-08-05 17:15:33 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:15:33 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 17:15:33 --> Final output sent to browser
DEBUG - 2022-08-05 17:15:33 --> Total execution time: 0.4362
INFO - 2022-08-05 17:15:58 --> Config Class Initialized
INFO - 2022-08-05 17:15:58 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:15:58 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:15:58 --> Utf8 Class Initialized
INFO - 2022-08-05 17:15:58 --> URI Class Initialized
INFO - 2022-08-05 17:15:58 --> Router Class Initialized
INFO - 2022-08-05 17:15:58 --> Output Class Initialized
INFO - 2022-08-05 17:15:58 --> Security Class Initialized
DEBUG - 2022-08-05 17:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:15:58 --> Input Class Initialized
INFO - 2022-08-05 17:15:58 --> Language Class Initialized
INFO - 2022-08-05 17:15:58 --> Loader Class Initialized
INFO - 2022-08-05 17:15:58 --> Helper loaded: url_helper
INFO - 2022-08-05 17:15:58 --> Controller Class Initialized
INFO - 2022-08-05 17:15:58 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:15:58 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:15:58 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:15:58 --> Final output sent to browser
DEBUG - 2022-08-05 17:15:58 --> Total execution time: 0.2309
INFO - 2022-08-05 17:16:51 --> Config Class Initialized
INFO - 2022-08-05 17:16:51 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:16:51 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:16:51 --> Utf8 Class Initialized
INFO - 2022-08-05 17:16:51 --> URI Class Initialized
INFO - 2022-08-05 17:16:51 --> Router Class Initialized
INFO - 2022-08-05 17:16:51 --> Output Class Initialized
INFO - 2022-08-05 17:16:51 --> Security Class Initialized
DEBUG - 2022-08-05 17:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:16:51 --> Input Class Initialized
INFO - 2022-08-05 17:16:51 --> Language Class Initialized
INFO - 2022-08-05 17:16:51 --> Loader Class Initialized
INFO - 2022-08-05 17:16:51 --> Helper loaded: url_helper
INFO - 2022-08-05 17:16:51 --> Controller Class Initialized
INFO - 2022-08-05 17:16:51 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:16:51 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:16:51 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:16:51 --> Final output sent to browser
DEBUG - 2022-08-05 17:16:51 --> Total execution time: 0.1632
INFO - 2022-08-05 17:16:52 --> Config Class Initialized
INFO - 2022-08-05 17:16:52 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:16:52 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:16:52 --> Utf8 Class Initialized
INFO - 2022-08-05 17:16:52 --> URI Class Initialized
INFO - 2022-08-05 17:16:52 --> Router Class Initialized
INFO - 2022-08-05 17:16:52 --> Output Class Initialized
INFO - 2022-08-05 17:16:52 --> Security Class Initialized
DEBUG - 2022-08-05 17:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:16:52 --> Input Class Initialized
INFO - 2022-08-05 17:16:52 --> Language Class Initialized
INFO - 2022-08-05 17:16:52 --> Loader Class Initialized
INFO - 2022-08-05 17:16:52 --> Helper loaded: url_helper
INFO - 2022-08-05 17:16:52 --> Controller Class Initialized
INFO - 2022-08-05 17:16:52 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:16:52 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:16:52 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:16:52 --> Final output sent to browser
DEBUG - 2022-08-05 17:16:52 --> Total execution time: 0.1524
INFO - 2022-08-05 17:18:03 --> Config Class Initialized
INFO - 2022-08-05 17:18:03 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:18:04 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:18:04 --> Utf8 Class Initialized
INFO - 2022-08-05 17:18:04 --> URI Class Initialized
INFO - 2022-08-05 17:18:04 --> Router Class Initialized
INFO - 2022-08-05 17:18:04 --> Output Class Initialized
INFO - 2022-08-05 17:18:04 --> Security Class Initialized
DEBUG - 2022-08-05 17:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:18:04 --> Input Class Initialized
INFO - 2022-08-05 17:18:04 --> Language Class Initialized
INFO - 2022-08-05 17:18:04 --> Loader Class Initialized
INFO - 2022-08-05 17:18:04 --> Helper loaded: url_helper
INFO - 2022-08-05 17:18:04 --> Controller Class Initialized
INFO - 2022-08-05 17:18:04 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:18:04 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:18:04 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:18:04 --> Final output sent to browser
DEBUG - 2022-08-05 17:18:04 --> Total execution time: 0.1864
INFO - 2022-08-05 17:18:04 --> Config Class Initialized
INFO - 2022-08-05 17:18:04 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:18:04 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:18:04 --> Utf8 Class Initialized
INFO - 2022-08-05 17:18:04 --> URI Class Initialized
INFO - 2022-08-05 17:18:04 --> Router Class Initialized
INFO - 2022-08-05 17:18:04 --> Output Class Initialized
INFO - 2022-08-05 17:18:04 --> Security Class Initialized
DEBUG - 2022-08-05 17:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:18:04 --> Input Class Initialized
INFO - 2022-08-05 17:18:04 --> Language Class Initialized
INFO - 2022-08-05 17:18:05 --> Loader Class Initialized
INFO - 2022-08-05 17:18:05 --> Helper loaded: url_helper
INFO - 2022-08-05 17:18:05 --> Controller Class Initialized
INFO - 2022-08-05 17:18:05 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:18:05 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:18:05 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:18:05 --> Final output sent to browser
DEBUG - 2022-08-05 17:18:05 --> Total execution time: 0.1976
INFO - 2022-08-05 17:19:10 --> Config Class Initialized
INFO - 2022-08-05 17:19:10 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:19:10 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:19:10 --> Utf8 Class Initialized
INFO - 2022-08-05 17:19:10 --> URI Class Initialized
INFO - 2022-08-05 17:19:10 --> Router Class Initialized
INFO - 2022-08-05 17:19:10 --> Output Class Initialized
INFO - 2022-08-05 17:19:10 --> Security Class Initialized
DEBUG - 2022-08-05 17:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:19:10 --> Input Class Initialized
INFO - 2022-08-05 17:19:10 --> Language Class Initialized
INFO - 2022-08-05 17:19:10 --> Loader Class Initialized
INFO - 2022-08-05 17:19:10 --> Helper loaded: url_helper
INFO - 2022-08-05 17:19:10 --> Controller Class Initialized
INFO - 2022-08-05 17:19:10 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:19:10 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:19:10 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:19:10 --> Final output sent to browser
DEBUG - 2022-08-05 17:19:10 --> Total execution time: 0.1687
INFO - 2022-08-05 17:19:50 --> Config Class Initialized
INFO - 2022-08-05 17:19:50 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:19:50 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:19:50 --> Utf8 Class Initialized
INFO - 2022-08-05 17:19:50 --> URI Class Initialized
INFO - 2022-08-05 17:19:50 --> Router Class Initialized
INFO - 2022-08-05 17:19:51 --> Output Class Initialized
INFO - 2022-08-05 17:19:51 --> Security Class Initialized
DEBUG - 2022-08-05 17:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:19:51 --> Input Class Initialized
INFO - 2022-08-05 17:19:51 --> Language Class Initialized
INFO - 2022-08-05 17:19:51 --> Loader Class Initialized
INFO - 2022-08-05 17:19:51 --> Helper loaded: url_helper
INFO - 2022-08-05 17:19:51 --> Controller Class Initialized
INFO - 2022-08-05 17:19:51 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:19:51 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:19:51 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:19:51 --> Final output sent to browser
DEBUG - 2022-08-05 17:19:51 --> Total execution time: 0.1634
INFO - 2022-08-05 17:20:22 --> Config Class Initialized
INFO - 2022-08-05 17:20:22 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:20:22 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:20:22 --> Utf8 Class Initialized
INFO - 2022-08-05 17:20:22 --> URI Class Initialized
INFO - 2022-08-05 17:20:22 --> Router Class Initialized
INFO - 2022-08-05 17:20:22 --> Output Class Initialized
INFO - 2022-08-05 17:20:22 --> Security Class Initialized
DEBUG - 2022-08-05 17:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:20:22 --> Input Class Initialized
INFO - 2022-08-05 17:20:22 --> Language Class Initialized
INFO - 2022-08-05 17:20:22 --> Loader Class Initialized
INFO - 2022-08-05 17:20:22 --> Helper loaded: url_helper
INFO - 2022-08-05 17:20:22 --> Controller Class Initialized
INFO - 2022-08-05 17:20:22 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:20:22 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:20:22 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:20:22 --> Final output sent to browser
DEBUG - 2022-08-05 17:20:22 --> Total execution time: 0.2485
INFO - 2022-08-05 17:20:23 --> Config Class Initialized
INFO - 2022-08-05 17:20:23 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:20:23 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:20:23 --> Utf8 Class Initialized
INFO - 2022-08-05 17:20:23 --> URI Class Initialized
INFO - 2022-08-05 17:20:23 --> Router Class Initialized
INFO - 2022-08-05 17:20:23 --> Output Class Initialized
INFO - 2022-08-05 17:20:23 --> Security Class Initialized
DEBUG - 2022-08-05 17:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:20:23 --> Input Class Initialized
INFO - 2022-08-05 17:20:23 --> Language Class Initialized
INFO - 2022-08-05 17:20:23 --> Loader Class Initialized
INFO - 2022-08-05 17:20:23 --> Helper loaded: url_helper
INFO - 2022-08-05 17:20:23 --> Controller Class Initialized
INFO - 2022-08-05 17:20:23 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:20:23 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:20:23 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:20:23 --> Final output sent to browser
DEBUG - 2022-08-05 17:20:23 --> Total execution time: 0.1919
INFO - 2022-08-05 17:20:27 --> Config Class Initialized
INFO - 2022-08-05 17:20:27 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:20:27 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:20:27 --> Utf8 Class Initialized
INFO - 2022-08-05 17:20:27 --> URI Class Initialized
INFO - 2022-08-05 17:20:27 --> Router Class Initialized
INFO - 2022-08-05 17:20:27 --> Output Class Initialized
INFO - 2022-08-05 17:20:27 --> Security Class Initialized
DEBUG - 2022-08-05 17:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:20:27 --> Input Class Initialized
INFO - 2022-08-05 17:20:27 --> Language Class Initialized
ERROR - 2022-08-05 17:20:27 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 17:22:04 --> Config Class Initialized
INFO - 2022-08-05 17:22:04 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:22:04 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:22:04 --> Utf8 Class Initialized
INFO - 2022-08-05 17:22:04 --> URI Class Initialized
INFO - 2022-08-05 17:22:04 --> Router Class Initialized
INFO - 2022-08-05 17:22:04 --> Output Class Initialized
INFO - 2022-08-05 17:22:04 --> Security Class Initialized
DEBUG - 2022-08-05 17:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:22:04 --> Input Class Initialized
INFO - 2022-08-05 17:22:04 --> Language Class Initialized
INFO - 2022-08-05 17:22:04 --> Loader Class Initialized
INFO - 2022-08-05 17:22:04 --> Helper loaded: url_helper
INFO - 2022-08-05 17:22:04 --> Controller Class Initialized
INFO - 2022-08-05 17:22:04 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:22:04 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:22:04 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:22:04 --> Final output sent to browser
DEBUG - 2022-08-05 17:22:04 --> Total execution time: 0.1593
INFO - 2022-08-05 17:22:53 --> Config Class Initialized
INFO - 2022-08-05 17:22:53 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:22:53 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:22:53 --> Utf8 Class Initialized
INFO - 2022-08-05 17:22:53 --> URI Class Initialized
INFO - 2022-08-05 17:22:53 --> Router Class Initialized
INFO - 2022-08-05 17:22:53 --> Output Class Initialized
INFO - 2022-08-05 17:22:53 --> Security Class Initialized
DEBUG - 2022-08-05 17:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:22:53 --> Input Class Initialized
INFO - 2022-08-05 17:22:53 --> Language Class Initialized
INFO - 2022-08-05 17:22:53 --> Loader Class Initialized
INFO - 2022-08-05 17:22:53 --> Helper loaded: url_helper
INFO - 2022-08-05 17:22:53 --> Controller Class Initialized
INFO - 2022-08-05 17:22:53 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:22:53 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:22:53 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:22:53 --> Final output sent to browser
DEBUG - 2022-08-05 17:22:53 --> Total execution time: 0.2063
INFO - 2022-08-05 17:22:55 --> Config Class Initialized
INFO - 2022-08-05 17:22:55 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:22:55 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:22:55 --> Utf8 Class Initialized
INFO - 2022-08-05 17:22:55 --> URI Class Initialized
INFO - 2022-08-05 17:22:55 --> Router Class Initialized
INFO - 2022-08-05 17:22:55 --> Output Class Initialized
INFO - 2022-08-05 17:22:55 --> Security Class Initialized
DEBUG - 2022-08-05 17:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:22:55 --> Input Class Initialized
INFO - 2022-08-05 17:22:55 --> Language Class Initialized
INFO - 2022-08-05 17:22:55 --> Loader Class Initialized
INFO - 2022-08-05 17:22:55 --> Helper loaded: url_helper
INFO - 2022-08-05 17:22:55 --> Controller Class Initialized
INFO - 2022-08-05 17:22:55 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:22:55 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:22:55 --> File loaded: /sam_tool/application/views/frontend/property_details.php
INFO - 2022-08-05 17:22:56 --> Final output sent to browser
DEBUG - 2022-08-05 17:22:56 --> Total execution time: 0.2078
INFO - 2022-08-05 17:23:17 --> Config Class Initialized
INFO - 2022-08-05 17:23:17 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:23:17 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:23:17 --> Utf8 Class Initialized
INFO - 2022-08-05 17:23:17 --> URI Class Initialized
INFO - 2022-08-05 17:23:17 --> Router Class Initialized
INFO - 2022-08-05 17:23:17 --> Output Class Initialized
INFO - 2022-08-05 17:23:17 --> Security Class Initialized
DEBUG - 2022-08-05 17:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:23:17 --> Input Class Initialized
INFO - 2022-08-05 17:23:17 --> Language Class Initialized
INFO - 2022-08-05 17:23:17 --> Loader Class Initialized
INFO - 2022-08-05 17:23:17 --> Helper loaded: url_helper
INFO - 2022-08-05 17:23:17 --> Controller Class Initialized
INFO - 2022-08-05 17:23:17 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:23:17 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:23:17 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:23:17 --> Final output sent to browser
DEBUG - 2022-08-05 17:23:17 --> Total execution time: 0.1488
INFO - 2022-08-05 17:23:50 --> Config Class Initialized
INFO - 2022-08-05 17:23:50 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:23:50 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:23:50 --> Utf8 Class Initialized
INFO - 2022-08-05 17:23:50 --> URI Class Initialized
INFO - 2022-08-05 17:23:50 --> Router Class Initialized
INFO - 2022-08-05 17:23:50 --> Output Class Initialized
INFO - 2022-08-05 17:23:50 --> Security Class Initialized
DEBUG - 2022-08-05 17:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:23:50 --> Input Class Initialized
INFO - 2022-08-05 17:23:50 --> Language Class Initialized
INFO - 2022-08-05 17:23:50 --> Loader Class Initialized
INFO - 2022-08-05 17:23:50 --> Helper loaded: url_helper
INFO - 2022-08-05 17:23:50 --> Controller Class Initialized
INFO - 2022-08-05 17:23:50 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:23:50 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:23:50 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:23:50 --> Final output sent to browser
DEBUG - 2022-08-05 17:23:50 --> Total execution time: 0.1708
INFO - 2022-08-05 17:23:59 --> Config Class Initialized
INFO - 2022-08-05 17:23:59 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:23:59 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:23:59 --> Utf8 Class Initialized
INFO - 2022-08-05 17:23:59 --> URI Class Initialized
INFO - 2022-08-05 17:23:59 --> Router Class Initialized
INFO - 2022-08-05 17:23:59 --> Output Class Initialized
INFO - 2022-08-05 17:23:59 --> Security Class Initialized
DEBUG - 2022-08-05 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:23:59 --> Input Class Initialized
INFO - 2022-08-05 17:23:59 --> Language Class Initialized
INFO - 2022-08-05 17:24:00 --> Loader Class Initialized
INFO - 2022-08-05 17:24:00 --> Helper loaded: url_helper
INFO - 2022-08-05 17:24:00 --> Controller Class Initialized
INFO - 2022-08-05 17:24:00 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:24:00 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:24:00 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:24:00 --> Final output sent to browser
DEBUG - 2022-08-05 17:24:00 --> Total execution time: 0.1690
INFO - 2022-08-05 17:25:24 --> Config Class Initialized
INFO - 2022-08-05 17:25:24 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:25:24 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:25:24 --> Utf8 Class Initialized
INFO - 2022-08-05 17:25:24 --> URI Class Initialized
INFO - 2022-08-05 17:25:24 --> Router Class Initialized
INFO - 2022-08-05 17:25:24 --> Output Class Initialized
INFO - 2022-08-05 17:25:24 --> Security Class Initialized
DEBUG - 2022-08-05 17:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:25:24 --> Input Class Initialized
INFO - 2022-08-05 17:25:24 --> Language Class Initialized
ERROR - 2022-08-05 17:25:24 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 17:25:29 --> Config Class Initialized
INFO - 2022-08-05 17:25:29 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:25:30 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:25:30 --> Utf8 Class Initialized
INFO - 2022-08-05 17:25:30 --> URI Class Initialized
INFO - 2022-08-05 17:25:30 --> Router Class Initialized
INFO - 2022-08-05 17:25:30 --> Output Class Initialized
INFO - 2022-08-05 17:25:30 --> Security Class Initialized
DEBUG - 2022-08-05 17:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:25:30 --> Input Class Initialized
INFO - 2022-08-05 17:25:30 --> Language Class Initialized
INFO - 2022-08-05 17:25:30 --> Loader Class Initialized
INFO - 2022-08-05 17:25:30 --> Helper loaded: url_helper
INFO - 2022-08-05 17:25:30 --> Controller Class Initialized
INFO - 2022-08-05 17:25:30 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 17:25:30 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 17:25:30 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 17:25:30 --> Final output sent to browser
DEBUG - 2022-08-05 17:25:30 --> Total execution time: 0.1878
INFO - 2022-08-05 17:25:30 --> Config Class Initialized
INFO - 2022-08-05 17:25:30 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:25:30 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:25:30 --> Utf8 Class Initialized
INFO - 2022-08-05 17:25:30 --> URI Class Initialized
INFO - 2022-08-05 17:25:30 --> Router Class Initialized
INFO - 2022-08-05 17:25:30 --> Output Class Initialized
INFO - 2022-08-05 17:25:30 --> Security Class Initialized
DEBUG - 2022-08-05 17:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:25:30 --> Input Class Initialized
INFO - 2022-08-05 17:25:30 --> Language Class Initialized
ERROR - 2022-08-05 17:25:30 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 17:25:55 --> Config Class Initialized
INFO - 2022-08-05 17:25:55 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:25:55 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:25:55 --> Utf8 Class Initialized
INFO - 2022-08-05 17:25:55 --> URI Class Initialized
INFO - 2022-08-05 17:25:55 --> Router Class Initialized
INFO - 2022-08-05 17:25:55 --> Output Class Initialized
INFO - 2022-08-05 17:25:55 --> Security Class Initialized
DEBUG - 2022-08-05 17:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:25:55 --> Input Class Initialized
INFO - 2022-08-05 17:25:55 --> Language Class Initialized
ERROR - 2022-08-05 17:25:55 --> 404 Page Not Found: Frontend/save_property_details
INFO - 2022-08-05 17:25:55 --> Config Class Initialized
INFO - 2022-08-05 17:25:55 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:25:55 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:25:55 --> Utf8 Class Initialized
INFO - 2022-08-05 17:25:55 --> URI Class Initialized
INFO - 2022-08-05 17:25:55 --> Router Class Initialized
INFO - 2022-08-05 17:25:55 --> Output Class Initialized
INFO - 2022-08-05 17:25:55 --> Security Class Initialized
DEBUG - 2022-08-05 17:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:25:55 --> Input Class Initialized
INFO - 2022-08-05 17:25:55 --> Language Class Initialized
ERROR - 2022-08-05 17:25:55 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-05 17:27:21 --> Config Class Initialized
INFO - 2022-08-05 17:27:21 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:27:21 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:27:21 --> Utf8 Class Initialized
INFO - 2022-08-05 17:27:21 --> URI Class Initialized
INFO - 2022-08-05 17:27:21 --> Router Class Initialized
INFO - 2022-08-05 17:27:21 --> Output Class Initialized
INFO - 2022-08-05 17:27:21 --> Security Class Initialized
DEBUG - 2022-08-05 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:27:21 --> Input Class Initialized
INFO - 2022-08-05 17:27:21 --> Language Class Initialized
ERROR - 2022-08-05 17:27:21 --> 404 Page Not Found: Frontend/save_property_details
INFO - 2022-08-05 17:27:23 --> Config Class Initialized
INFO - 2022-08-05 17:27:23 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:27:23 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:27:23 --> Utf8 Class Initialized
INFO - 2022-08-05 17:27:23 --> URI Class Initialized
INFO - 2022-08-05 17:27:23 --> Router Class Initialized
INFO - 2022-08-05 17:27:23 --> Output Class Initialized
INFO - 2022-08-05 17:27:23 --> Security Class Initialized
DEBUG - 2022-08-05 17:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:27:24 --> Input Class Initialized
INFO - 2022-08-05 17:27:24 --> Language Class Initialized
ERROR - 2022-08-05 17:27:24 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 17:27:33 --> Config Class Initialized
INFO - 2022-08-05 17:27:33 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:27:33 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:27:33 --> Utf8 Class Initialized
INFO - 2022-08-05 17:27:33 --> URI Class Initialized
INFO - 2022-08-05 17:27:33 --> Router Class Initialized
INFO - 2022-08-05 17:27:33 --> Output Class Initialized
INFO - 2022-08-05 17:27:33 --> Security Class Initialized
DEBUG - 2022-08-05 17:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:27:33 --> Input Class Initialized
INFO - 2022-08-05 17:27:33 --> Language Class Initialized
ERROR - 2022-08-05 17:27:33 --> 404 Page Not Found: Frontend/save_property_details
INFO - 2022-08-05 17:27:49 --> Config Class Initialized
INFO - 2022-08-05 17:27:49 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:27:49 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:27:49 --> Utf8 Class Initialized
INFO - 2022-08-05 17:27:49 --> URI Class Initialized
INFO - 2022-08-05 17:27:49 --> Router Class Initialized
INFO - 2022-08-05 17:27:49 --> Output Class Initialized
INFO - 2022-08-05 17:27:49 --> Security Class Initialized
DEBUG - 2022-08-05 17:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:27:49 --> Input Class Initialized
INFO - 2022-08-05 17:27:49 --> Language Class Initialized
INFO - 2022-08-05 17:27:49 --> Loader Class Initialized
INFO - 2022-08-05 17:27:49 --> Helper loaded: url_helper
INFO - 2022-08-05 17:27:49 --> Controller Class Initialized
ERROR - 2022-08-05 17:27:49 --> Severity: Notice --> Undefined index: city_name /sam_tool/application/controllers/Api.php 35
ERROR - 2022-08-05 17:27:49 --> Severity: Notice --> Undefined index: state_name /sam_tool/application/controllers/Api.php 36
ERROR - 2022-08-05 17:27:49 --> Severity: Notice --> Undefined index: bank_name /sam_tool/application/controllers/Api.php 37
ERROR - 2022-08-05 17:27:49 --> Severity: Notice --> Undefined index: property_name /sam_tool/application/controllers/Api.php 38
ERROR - 2022-08-05 17:27:49 --> Severity: Notice --> Undefined index: area_name /sam_tool/application/controllers/Api.php 39
INFO - 2022-08-05 17:27:49 --> Final output sent to browser
DEBUG - 2022-08-05 17:27:49 --> Total execution time: 0.2053
INFO - 2022-08-05 17:27:54 --> Config Class Initialized
INFO - 2022-08-05 17:27:54 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:27:54 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:27:54 --> Utf8 Class Initialized
INFO - 2022-08-05 17:27:54 --> URI Class Initialized
INFO - 2022-08-05 17:27:54 --> Router Class Initialized
INFO - 2022-08-05 17:27:54 --> Output Class Initialized
INFO - 2022-08-05 17:27:54 --> Security Class Initialized
DEBUG - 2022-08-05 17:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:27:54 --> Input Class Initialized
INFO - 2022-08-05 17:27:54 --> Language Class Initialized
ERROR - 2022-08-05 17:27:54 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-05 17:28:05 --> Config Class Initialized
INFO - 2022-08-05 17:28:05 --> Hooks Class Initialized
DEBUG - 2022-08-05 17:28:05 --> UTF-8 Support Enabled
INFO - 2022-08-05 17:28:05 --> Utf8 Class Initialized
INFO - 2022-08-05 17:28:05 --> URI Class Initialized
INFO - 2022-08-05 17:28:05 --> Router Class Initialized
INFO - 2022-08-05 17:28:05 --> Output Class Initialized
INFO - 2022-08-05 17:28:05 --> Security Class Initialized
DEBUG - 2022-08-05 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 17:28:05 --> Input Class Initialized
INFO - 2022-08-05 17:28:05 --> Language Class Initialized
ERROR - 2022-08-05 17:28:05 --> 404 Page Not Found: Frontend/save_property_details
INFO - 2022-08-05 18:25:12 --> Config Class Initialized
INFO - 2022-08-05 18:25:12 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:25:12 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:25:12 --> Utf8 Class Initialized
INFO - 2022-08-05 18:25:12 --> URI Class Initialized
DEBUG - 2022-08-05 18:25:12 --> No URI present. Default controller set.
INFO - 2022-08-05 18:25:12 --> Router Class Initialized
INFO - 2022-08-05 18:25:12 --> Output Class Initialized
INFO - 2022-08-05 18:25:13 --> Security Class Initialized
DEBUG - 2022-08-05 18:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:25:13 --> Input Class Initialized
INFO - 2022-08-05 18:25:13 --> Language Class Initialized
INFO - 2022-08-05 18:25:13 --> Loader Class Initialized
INFO - 2022-08-05 18:25:13 --> Helper loaded: url_helper
INFO - 2022-08-05 18:25:13 --> Controller Class Initialized
INFO - 2022-08-05 18:25:13 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:25:13 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:25:13 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-05 18:25:13 --> Final output sent to browser
DEBUG - 2022-08-05 18:25:13 --> Total execution time: 0.8208
INFO - 2022-08-05 18:26:15 --> Config Class Initialized
INFO - 2022-08-05 18:26:15 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:26:16 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:26:16 --> Utf8 Class Initialized
INFO - 2022-08-05 18:26:16 --> URI Class Initialized
INFO - 2022-08-05 18:26:16 --> Router Class Initialized
INFO - 2022-08-05 18:26:16 --> Output Class Initialized
INFO - 2022-08-05 18:26:16 --> Security Class Initialized
DEBUG - 2022-08-05 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:26:16 --> Input Class Initialized
INFO - 2022-08-05 18:26:16 --> Language Class Initialized
INFO - 2022-08-05 18:26:16 --> Loader Class Initialized
INFO - 2022-08-05 18:26:16 --> Helper loaded: url_helper
INFO - 2022-08-05 18:26:16 --> Controller Class Initialized
INFO - 2022-08-05 18:26:16 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:26:16 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:26:16 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:26:16 --> Final output sent to browser
DEBUG - 2022-08-05 18:26:16 --> Total execution time: 0.7339
INFO - 2022-08-05 18:26:16 --> Config Class Initialized
INFO - 2022-08-05 18:26:16 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:26:16 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:26:16 --> Utf8 Class Initialized
INFO - 2022-08-05 18:26:16 --> URI Class Initialized
INFO - 2022-08-05 18:26:17 --> Router Class Initialized
INFO - 2022-08-05 18:26:17 --> Output Class Initialized
INFO - 2022-08-05 18:26:17 --> Security Class Initialized
DEBUG - 2022-08-05 18:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:26:17 --> Input Class Initialized
INFO - 2022-08-05 18:26:17 --> Language Class Initialized
INFO - 2022-08-05 18:26:17 --> Loader Class Initialized
INFO - 2022-08-05 18:26:17 --> Helper loaded: url_helper
INFO - 2022-08-05 18:26:17 --> Controller Class Initialized
INFO - 2022-08-05 18:26:17 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:26:17 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:26:17 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:26:17 --> Final output sent to browser
DEBUG - 2022-08-05 18:26:17 --> Total execution time: 0.7215
INFO - 2022-08-05 18:27:05 --> Config Class Initialized
INFO - 2022-08-05 18:27:05 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:27:05 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:27:05 --> Utf8 Class Initialized
INFO - 2022-08-05 18:27:05 --> URI Class Initialized
INFO - 2022-08-05 18:27:05 --> Router Class Initialized
INFO - 2022-08-05 18:27:05 --> Output Class Initialized
INFO - 2022-08-05 18:27:05 --> Security Class Initialized
DEBUG - 2022-08-05 18:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:27:05 --> Input Class Initialized
INFO - 2022-08-05 18:27:05 --> Language Class Initialized
INFO - 2022-08-05 18:27:05 --> Loader Class Initialized
INFO - 2022-08-05 18:27:05 --> Helper loaded: url_helper
INFO - 2022-08-05 18:27:05 --> Controller Class Initialized
INFO - 2022-08-05 18:27:05 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:27:05 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:27:05 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:27:06 --> Final output sent to browser
DEBUG - 2022-08-05 18:27:06 --> Total execution time: 0.7647
INFO - 2022-08-05 18:27:06 --> Config Class Initialized
INFO - 2022-08-05 18:27:06 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:27:06 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:27:06 --> Utf8 Class Initialized
INFO - 2022-08-05 18:27:06 --> URI Class Initialized
INFO - 2022-08-05 18:27:06 --> Router Class Initialized
INFO - 2022-08-05 18:27:06 --> Output Class Initialized
INFO - 2022-08-05 18:27:06 --> Security Class Initialized
DEBUG - 2022-08-05 18:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:27:06 --> Input Class Initialized
INFO - 2022-08-05 18:27:06 --> Language Class Initialized
INFO - 2022-08-05 18:27:06 --> Loader Class Initialized
INFO - 2022-08-05 18:27:06 --> Helper loaded: url_helper
INFO - 2022-08-05 18:27:06 --> Controller Class Initialized
INFO - 2022-08-05 18:27:06 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:27:06 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:27:06 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:27:06 --> Final output sent to browser
DEBUG - 2022-08-05 18:27:06 --> Total execution time: 0.5808
INFO - 2022-08-05 18:27:27 --> Config Class Initialized
INFO - 2022-08-05 18:27:27 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:27:27 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:27:27 --> Utf8 Class Initialized
INFO - 2022-08-05 18:27:27 --> URI Class Initialized
INFO - 2022-08-05 18:27:27 --> Router Class Initialized
INFO - 2022-08-05 18:27:28 --> Output Class Initialized
INFO - 2022-08-05 18:27:28 --> Security Class Initialized
DEBUG - 2022-08-05 18:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:27:28 --> Input Class Initialized
INFO - 2022-08-05 18:27:28 --> Language Class Initialized
INFO - 2022-08-05 18:27:28 --> Loader Class Initialized
INFO - 2022-08-05 18:27:28 --> Helper loaded: url_helper
INFO - 2022-08-05 18:27:28 --> Controller Class Initialized
INFO - 2022-08-05 18:27:28 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:27:28 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:27:28 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:27:28 --> Final output sent to browser
DEBUG - 2022-08-05 18:27:28 --> Total execution time: 0.8254
INFO - 2022-08-05 18:27:28 --> Config Class Initialized
INFO - 2022-08-05 18:27:28 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:27:29 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:27:29 --> Utf8 Class Initialized
INFO - 2022-08-05 18:27:29 --> URI Class Initialized
INFO - 2022-08-05 18:27:29 --> Router Class Initialized
INFO - 2022-08-05 18:27:29 --> Output Class Initialized
INFO - 2022-08-05 18:27:29 --> Security Class Initialized
DEBUG - 2022-08-05 18:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:27:29 --> Input Class Initialized
INFO - 2022-08-05 18:27:29 --> Language Class Initialized
INFO - 2022-08-05 18:27:29 --> Loader Class Initialized
INFO - 2022-08-05 18:27:29 --> Helper loaded: url_helper
INFO - 2022-08-05 18:27:29 --> Controller Class Initialized
INFO - 2022-08-05 18:27:29 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:27:29 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:27:29 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:27:29 --> Final output sent to browser
DEBUG - 2022-08-05 18:27:29 --> Total execution time: 0.9711
INFO - 2022-08-05 18:27:38 --> Config Class Initialized
INFO - 2022-08-05 18:27:38 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:27:38 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:27:38 --> Utf8 Class Initialized
INFO - 2022-08-05 18:27:38 --> URI Class Initialized
INFO - 2022-08-05 18:27:38 --> Router Class Initialized
INFO - 2022-08-05 18:27:38 --> Output Class Initialized
INFO - 2022-08-05 18:27:38 --> Security Class Initialized
DEBUG - 2022-08-05 18:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:27:38 --> Input Class Initialized
INFO - 2022-08-05 18:27:38 --> Language Class Initialized
INFO - 2022-08-05 18:27:39 --> Loader Class Initialized
INFO - 2022-08-05 18:27:39 --> Helper loaded: url_helper
INFO - 2022-08-05 18:27:39 --> Controller Class Initialized
INFO - 2022-08-05 18:27:39 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:27:39 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:27:39 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:27:39 --> Final output sent to browser
DEBUG - 2022-08-05 18:27:39 --> Total execution time: 0.7935
INFO - 2022-08-05 18:27:39 --> Config Class Initialized
INFO - 2022-08-05 18:27:39 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:27:39 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:27:39 --> Utf8 Class Initialized
INFO - 2022-08-05 18:27:39 --> URI Class Initialized
INFO - 2022-08-05 18:27:39 --> Router Class Initialized
INFO - 2022-08-05 18:27:39 --> Output Class Initialized
INFO - 2022-08-05 18:27:39 --> Security Class Initialized
DEBUG - 2022-08-05 18:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:27:39 --> Input Class Initialized
INFO - 2022-08-05 18:27:39 --> Language Class Initialized
INFO - 2022-08-05 18:27:39 --> Loader Class Initialized
INFO - 2022-08-05 18:27:40 --> Helper loaded: url_helper
INFO - 2022-08-05 18:27:40 --> Controller Class Initialized
INFO - 2022-08-05 18:27:40 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:27:40 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:27:40 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:27:40 --> Final output sent to browser
DEBUG - 2022-08-05 18:27:40 --> Total execution time: 0.6062
INFO - 2022-08-05 18:30:18 --> Config Class Initialized
INFO - 2022-08-05 18:30:18 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:30:18 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:30:18 --> Utf8 Class Initialized
INFO - 2022-08-05 18:30:18 --> URI Class Initialized
INFO - 2022-08-05 18:30:19 --> Router Class Initialized
INFO - 2022-08-05 18:30:19 --> Output Class Initialized
INFO - 2022-08-05 18:30:19 --> Security Class Initialized
DEBUG - 2022-08-05 18:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:30:19 --> Input Class Initialized
INFO - 2022-08-05 18:30:19 --> Language Class Initialized
INFO - 2022-08-05 18:30:19 --> Loader Class Initialized
INFO - 2022-08-05 18:30:19 --> Helper loaded: url_helper
INFO - 2022-08-05 18:30:19 --> Controller Class Initialized
INFO - 2022-08-05 18:30:19 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:30:19 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:30:19 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:30:19 --> Final output sent to browser
DEBUG - 2022-08-05 18:30:19 --> Total execution time: 0.8825
INFO - 2022-08-05 18:30:19 --> Config Class Initialized
INFO - 2022-08-05 18:30:19 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:30:20 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:30:20 --> Utf8 Class Initialized
INFO - 2022-08-05 18:30:20 --> URI Class Initialized
INFO - 2022-08-05 18:30:20 --> Router Class Initialized
INFO - 2022-08-05 18:30:20 --> Output Class Initialized
INFO - 2022-08-05 18:30:20 --> Security Class Initialized
DEBUG - 2022-08-05 18:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:30:20 --> Input Class Initialized
INFO - 2022-08-05 18:30:20 --> Language Class Initialized
INFO - 2022-08-05 18:30:20 --> Loader Class Initialized
INFO - 2022-08-05 18:30:20 --> Helper loaded: url_helper
INFO - 2022-08-05 18:30:20 --> Controller Class Initialized
INFO - 2022-08-05 18:30:20 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:30:20 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:30:20 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:30:20 --> Final output sent to browser
DEBUG - 2022-08-05 18:30:20 --> Total execution time: 0.6490
INFO - 2022-08-05 18:30:48 --> Config Class Initialized
INFO - 2022-08-05 18:30:48 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:30:48 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:30:48 --> Utf8 Class Initialized
INFO - 2022-08-05 18:30:49 --> URI Class Initialized
INFO - 2022-08-05 18:30:49 --> Router Class Initialized
INFO - 2022-08-05 18:30:49 --> Output Class Initialized
INFO - 2022-08-05 18:30:49 --> Security Class Initialized
DEBUG - 2022-08-05 18:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:30:49 --> Input Class Initialized
INFO - 2022-08-05 18:30:49 --> Language Class Initialized
INFO - 2022-08-05 18:30:49 --> Loader Class Initialized
INFO - 2022-08-05 18:30:49 --> Helper loaded: url_helper
INFO - 2022-08-05 18:30:49 --> Controller Class Initialized
INFO - 2022-08-05 18:30:49 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:30:49 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:30:49 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:30:49 --> Final output sent to browser
DEBUG - 2022-08-05 18:30:49 --> Total execution time: 0.8027
INFO - 2022-08-05 18:30:49 --> Config Class Initialized
INFO - 2022-08-05 18:30:49 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:30:50 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:30:50 --> Utf8 Class Initialized
INFO - 2022-08-05 18:30:50 --> URI Class Initialized
INFO - 2022-08-05 18:30:50 --> Router Class Initialized
INFO - 2022-08-05 18:30:50 --> Output Class Initialized
INFO - 2022-08-05 18:30:50 --> Security Class Initialized
DEBUG - 2022-08-05 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:30:50 --> Input Class Initialized
INFO - 2022-08-05 18:30:50 --> Language Class Initialized
INFO - 2022-08-05 18:30:50 --> Loader Class Initialized
INFO - 2022-08-05 18:30:50 --> Helper loaded: url_helper
INFO - 2022-08-05 18:30:50 --> Controller Class Initialized
INFO - 2022-08-05 18:30:50 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:30:50 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:30:50 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:30:50 --> Final output sent to browser
DEBUG - 2022-08-05 18:30:50 --> Total execution time: 0.4638
INFO - 2022-08-05 18:31:55 --> Config Class Initialized
INFO - 2022-08-05 18:31:55 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:31:55 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:31:55 --> Utf8 Class Initialized
INFO - 2022-08-05 18:31:56 --> URI Class Initialized
INFO - 2022-08-05 18:31:56 --> Router Class Initialized
INFO - 2022-08-05 18:31:56 --> Output Class Initialized
INFO - 2022-08-05 18:31:56 --> Security Class Initialized
DEBUG - 2022-08-05 18:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:31:56 --> Input Class Initialized
INFO - 2022-08-05 18:31:56 --> Language Class Initialized
INFO - 2022-08-05 18:31:56 --> Loader Class Initialized
INFO - 2022-08-05 18:31:56 --> Helper loaded: url_helper
INFO - 2022-08-05 18:31:56 --> Controller Class Initialized
INFO - 2022-08-05 18:31:56 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:31:56 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:31:56 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:31:56 --> Final output sent to browser
DEBUG - 2022-08-05 18:31:56 --> Total execution time: 0.6404
INFO - 2022-08-05 18:31:56 --> Config Class Initialized
INFO - 2022-08-05 18:31:56 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:31:56 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:31:56 --> Utf8 Class Initialized
INFO - 2022-08-05 18:31:56 --> URI Class Initialized
INFO - 2022-08-05 18:31:56 --> Router Class Initialized
INFO - 2022-08-05 18:31:56 --> Output Class Initialized
INFO - 2022-08-05 18:31:56 --> Security Class Initialized
DEBUG - 2022-08-05 18:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:31:56 --> Input Class Initialized
INFO - 2022-08-05 18:31:56 --> Language Class Initialized
INFO - 2022-08-05 18:31:57 --> Loader Class Initialized
INFO - 2022-08-05 18:31:57 --> Helper loaded: url_helper
INFO - 2022-08-05 18:31:57 --> Controller Class Initialized
INFO - 2022-08-05 18:31:57 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:31:57 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:31:57 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:31:57 --> Final output sent to browser
DEBUG - 2022-08-05 18:31:57 --> Total execution time: 0.5662
INFO - 2022-08-05 18:32:04 --> Config Class Initialized
INFO - 2022-08-05 18:32:04 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:32:04 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:32:04 --> Utf8 Class Initialized
INFO - 2022-08-05 18:32:04 --> URI Class Initialized
INFO - 2022-08-05 18:32:04 --> Router Class Initialized
INFO - 2022-08-05 18:32:04 --> Output Class Initialized
INFO - 2022-08-05 18:32:04 --> Security Class Initialized
DEBUG - 2022-08-05 18:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:32:05 --> Input Class Initialized
INFO - 2022-08-05 18:32:05 --> Language Class Initialized
INFO - 2022-08-05 18:32:05 --> Loader Class Initialized
INFO - 2022-08-05 18:32:05 --> Helper loaded: url_helper
INFO - 2022-08-05 18:32:05 --> Controller Class Initialized
INFO - 2022-08-05 18:32:05 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:32:05 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:32:05 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:32:05 --> Final output sent to browser
DEBUG - 2022-08-05 18:32:05 --> Total execution time: 0.6753
INFO - 2022-08-05 18:32:05 --> Config Class Initialized
INFO - 2022-08-05 18:32:05 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:32:05 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:32:05 --> Utf8 Class Initialized
INFO - 2022-08-05 18:32:05 --> URI Class Initialized
INFO - 2022-08-05 18:32:05 --> Router Class Initialized
INFO - 2022-08-05 18:32:05 --> Output Class Initialized
INFO - 2022-08-05 18:32:05 --> Security Class Initialized
DEBUG - 2022-08-05 18:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:32:05 --> Input Class Initialized
INFO - 2022-08-05 18:32:05 --> Language Class Initialized
INFO - 2022-08-05 18:32:05 --> Loader Class Initialized
INFO - 2022-08-05 18:32:06 --> Helper loaded: url_helper
INFO - 2022-08-05 18:32:06 --> Controller Class Initialized
INFO - 2022-08-05 18:32:06 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 18:32:06 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 18:32:06 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 18:32:06 --> Final output sent to browser
DEBUG - 2022-08-05 18:32:06 --> Total execution time: 0.6677
INFO - 2022-08-05 18:34:12 --> Config Class Initialized
INFO - 2022-08-05 18:34:12 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:34:12 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:34:12 --> Utf8 Class Initialized
INFO - 2022-08-05 18:34:12 --> URI Class Initialized
INFO - 2022-08-05 18:34:12 --> Router Class Initialized
INFO - 2022-08-05 18:34:12 --> Output Class Initialized
INFO - 2022-08-05 18:34:12 --> Security Class Initialized
DEBUG - 2022-08-05 18:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:34:12 --> Input Class Initialized
INFO - 2022-08-05 18:34:13 --> Language Class Initialized
INFO - 2022-08-05 18:34:13 --> Loader Class Initialized
INFO - 2022-08-05 18:34:13 --> Helper loaded: url_helper
INFO - 2022-08-05 18:34:13 --> Controller Class Initialized
INFO - 2022-08-05 18:34:13 --> Final output sent to browser
DEBUG - 2022-08-05 18:34:13 --> Total execution time: 0.5217
INFO - 2022-08-05 18:34:13 --> Config Class Initialized
INFO - 2022-08-05 18:34:13 --> Hooks Class Initialized
DEBUG - 2022-08-05 18:34:13 --> UTF-8 Support Enabled
INFO - 2022-08-05 18:34:13 --> Utf8 Class Initialized
INFO - 2022-08-05 18:34:13 --> URI Class Initialized
INFO - 2022-08-05 18:34:13 --> Router Class Initialized
INFO - 2022-08-05 18:34:13 --> Output Class Initialized
INFO - 2022-08-05 18:34:13 --> Security Class Initialized
DEBUG - 2022-08-05 18:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 18:34:13 --> Input Class Initialized
INFO - 2022-08-05 18:34:13 --> Language Class Initialized
ERROR - 2022-08-05 18:34:13 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-05 19:09:30 --> Config Class Initialized
INFO - 2022-08-05 19:09:30 --> Hooks Class Initialized
DEBUG - 2022-08-05 19:09:30 --> UTF-8 Support Enabled
INFO - 2022-08-05 19:09:30 --> Utf8 Class Initialized
INFO - 2022-08-05 19:09:31 --> URI Class Initialized
INFO - 2022-08-05 19:09:31 --> Router Class Initialized
INFO - 2022-08-05 19:09:31 --> Output Class Initialized
INFO - 2022-08-05 19:09:31 --> Security Class Initialized
DEBUG - 2022-08-05 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 19:09:31 --> Input Class Initialized
INFO - 2022-08-05 19:09:31 --> Language Class Initialized
INFO - 2022-08-05 19:09:31 --> Loader Class Initialized
INFO - 2022-08-05 19:09:31 --> Helper loaded: url_helper
INFO - 2022-08-05 19:09:31 --> Controller Class Initialized
INFO - 2022-08-05 19:09:31 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 19:09:31 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 19:09:31 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 19:09:31 --> Final output sent to browser
DEBUG - 2022-08-05 19:09:31 --> Total execution time: 0.5693
INFO - 2022-08-05 19:09:31 --> Config Class Initialized
INFO - 2022-08-05 19:09:31 --> Hooks Class Initialized
DEBUG - 2022-08-05 19:09:31 --> UTF-8 Support Enabled
INFO - 2022-08-05 19:09:31 --> Utf8 Class Initialized
INFO - 2022-08-05 19:09:31 --> URI Class Initialized
INFO - 2022-08-05 19:09:31 --> Router Class Initialized
INFO - 2022-08-05 19:09:31 --> Output Class Initialized
INFO - 2022-08-05 19:09:31 --> Security Class Initialized
DEBUG - 2022-08-05 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 19:09:32 --> Input Class Initialized
INFO - 2022-08-05 19:09:32 --> Language Class Initialized
INFO - 2022-08-05 19:09:32 --> Loader Class Initialized
INFO - 2022-08-05 19:09:32 --> Helper loaded: url_helper
INFO - 2022-08-05 19:09:32 --> Controller Class Initialized
INFO - 2022-08-05 19:09:32 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 19:09:32 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 19:09:32 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 19:09:32 --> Final output sent to browser
DEBUG - 2022-08-05 19:09:32 --> Total execution time: 0.6225
INFO - 2022-08-05 19:10:49 --> Config Class Initialized
INFO - 2022-08-05 19:10:49 --> Hooks Class Initialized
DEBUG - 2022-08-05 19:10:49 --> UTF-8 Support Enabled
INFO - 2022-08-05 19:10:50 --> Utf8 Class Initialized
INFO - 2022-08-05 19:10:50 --> URI Class Initialized
INFO - 2022-08-05 19:10:50 --> Router Class Initialized
INFO - 2022-08-05 19:10:50 --> Output Class Initialized
INFO - 2022-08-05 19:10:50 --> Security Class Initialized
DEBUG - 2022-08-05 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 19:10:50 --> Input Class Initialized
INFO - 2022-08-05 19:10:50 --> Language Class Initialized
INFO - 2022-08-05 19:10:50 --> Loader Class Initialized
INFO - 2022-08-05 19:10:50 --> Helper loaded: url_helper
INFO - 2022-08-05 19:10:50 --> Controller Class Initialized
INFO - 2022-08-05 19:10:50 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 19:10:50 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 19:10:50 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 19:10:50 --> Final output sent to browser
DEBUG - 2022-08-05 19:10:50 --> Total execution time: 0.5500
INFO - 2022-08-05 19:10:50 --> Config Class Initialized
INFO - 2022-08-05 19:10:50 --> Hooks Class Initialized
DEBUG - 2022-08-05 19:10:50 --> UTF-8 Support Enabled
INFO - 2022-08-05 19:10:50 --> Utf8 Class Initialized
INFO - 2022-08-05 19:10:50 --> URI Class Initialized
INFO - 2022-08-05 19:10:50 --> Router Class Initialized
INFO - 2022-08-05 19:10:50 --> Output Class Initialized
INFO - 2022-08-05 19:10:51 --> Security Class Initialized
DEBUG - 2022-08-05 19:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-05 19:10:51 --> Input Class Initialized
INFO - 2022-08-05 19:10:51 --> Language Class Initialized
INFO - 2022-08-05 19:10:51 --> Loader Class Initialized
INFO - 2022-08-05 19:10:51 --> Helper loaded: url_helper
INFO - 2022-08-05 19:10:51 --> Controller Class Initialized
INFO - 2022-08-05 19:10:51 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-05 19:10:51 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-05 19:10:51 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-05 19:10:51 --> Final output sent to browser
DEBUG - 2022-08-05 19:10:51 --> Total execution time: 0.6015
