ERROR - 2022-08-24 17:54:31 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 17:55:17 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 17:55:18 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 17:57:48 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /sam_tool/application/controllers/Sam.php 45
ERROR - 2022-08-24 17:57:51 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 17:57:54 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /sam_tool/application/controllers/Sam.php 45
ERROR - 2022-08-24 17:58:39 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 17:58:41 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 18:12:31 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 18:12:39 --> Severity: error --> Exception: Call to undefined function set_output() /sam_tool/application/controllers/Sam.php 49
ERROR - 2022-08-24 18:13:58 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 18:20:44 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 18:21:46 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 18:21:48 --> Severity: error --> Exception: Call to undefined function search() /sam_tool/application/controllers/Sam.php 47
ERROR - 2022-08-24 18:22:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:71) /sam_tool/system/core/Common.php 570
ERROR - 2022-08-24 18:36:58 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 18:37:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 18:44:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:41) /sam_tool/application/controllers/Sam.php 43
ERROR - 2022-08-24 18:44:35 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 18:44:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:41) /sam_tool/application/controllers/Sam.php 43
INFO - 2022-08-24 18:49:03 --> Config Class Initialized
INFO - 2022-08-24 18:49:03 --> Hooks Class Initialized
DEBUG - 2022-08-24 18:49:03 --> UTF-8 Support Enabled
INFO - 2022-08-24 18:49:03 --> Utf8 Class Initialized
INFO - 2022-08-24 18:49:03 --> URI Class Initialized
INFO - 2022-08-24 18:49:03 --> Router Class Initialized
INFO - 2022-08-24 18:49:03 --> Output Class Initialized
INFO - 2022-08-24 18:49:03 --> Security Class Initialized
DEBUG - 2022-08-24 18:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 18:49:03 --> Input Class Initialized
INFO - 2022-08-24 18:49:03 --> Language Class Initialized
ERROR - 2022-08-24 18:49:03 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-24 18:49:05 --> Config Class Initialized
INFO - 2022-08-24 18:49:05 --> Hooks Class Initialized
DEBUG - 2022-08-24 18:49:05 --> UTF-8 Support Enabled
INFO - 2022-08-24 18:49:05 --> Utf8 Class Initialized
INFO - 2022-08-24 18:49:05 --> URI Class Initialized
DEBUG - 2022-08-24 18:49:05 --> No URI present. Default controller set.
INFO - 2022-08-24 18:49:05 --> Router Class Initialized
INFO - 2022-08-24 18:49:05 --> Output Class Initialized
INFO - 2022-08-24 18:49:05 --> Security Class Initialized
DEBUG - 2022-08-24 18:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 18:49:05 --> Input Class Initialized
INFO - 2022-08-24 18:49:05 --> Language Class Initialized
INFO - 2022-08-24 18:49:05 --> Loader Class Initialized
INFO - 2022-08-24 18:49:05 --> Helper loaded: url_helper
INFO - 2022-08-24 18:49:05 --> Controller Class Initialized
INFO - 2022-08-24 18:49:05 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-24 18:49:05 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-24 18:49:05 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-24 18:49:05 --> Final output sent to browser
DEBUG - 2022-08-24 18:49:05 --> Total execution time: 0.5256
INFO - 2022-08-24 18:49:06 --> Config Class Initialized
INFO - 2022-08-24 18:49:06 --> Hooks Class Initialized
DEBUG - 2022-08-24 18:49:06 --> UTF-8 Support Enabled
INFO - 2022-08-24 18:49:06 --> Utf8 Class Initialized
INFO - 2022-08-24 18:49:06 --> URI Class Initialized
INFO - 2022-08-24 18:49:06 --> Router Class Initialized
INFO - 2022-08-24 18:49:06 --> Output Class Initialized
INFO - 2022-08-24 18:49:06 --> Security Class Initialized
DEBUG - 2022-08-24 18:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 18:49:06 --> Input Class Initialized
INFO - 2022-08-24 18:49:06 --> Language Class Initialized
ERROR - 2022-08-24 18:49:06 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-24 18:49:09 --> Config Class Initialized
INFO - 2022-08-24 18:49:09 --> Hooks Class Initialized
DEBUG - 2022-08-24 18:49:09 --> UTF-8 Support Enabled
INFO - 2022-08-24 18:49:09 --> Utf8 Class Initialized
INFO - 2022-08-24 18:49:09 --> URI Class Initialized
INFO - 2022-08-24 18:49:09 --> Router Class Initialized
INFO - 2022-08-24 18:49:09 --> Output Class Initialized
INFO - 2022-08-24 18:49:09 --> Security Class Initialized
DEBUG - 2022-08-24 18:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 18:49:09 --> Input Class Initialized
INFO - 2022-08-24 18:49:09 --> Language Class Initialized
INFO - 2022-08-24 18:49:09 --> Loader Class Initialized
INFO - 2022-08-24 18:49:09 --> Helper loaded: url_helper
INFO - 2022-08-24 18:49:09 --> Controller Class Initialized
DEBUG - 2022-08-24 18:49:09 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 18:49:09 --> Helper loaded: inflector_helper
INFO - 2022-08-24 18:49:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 18:49:09 --> Final output sent to browser
DEBUG - 2022-08-24 18:49:09 --> Total execution time: 0.4972
INFO - 2022-08-24 18:50:20 --> Config Class Initialized
INFO - 2022-08-24 18:50:20 --> Hooks Class Initialized
DEBUG - 2022-08-24 18:50:20 --> UTF-8 Support Enabled
INFO - 2022-08-24 18:50:20 --> Utf8 Class Initialized
INFO - 2022-08-24 18:50:20 --> URI Class Initialized
INFO - 2022-08-24 18:50:20 --> Router Class Initialized
INFO - 2022-08-24 18:50:20 --> Output Class Initialized
INFO - 2022-08-24 18:50:20 --> Security Class Initialized
DEBUG - 2022-08-24 18:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 18:50:20 --> Input Class Initialized
INFO - 2022-08-24 18:50:20 --> Language Class Initialized
INFO - 2022-08-24 18:50:21 --> Loader Class Initialized
INFO - 2022-08-24 18:50:21 --> Helper loaded: url_helper
INFO - 2022-08-24 18:50:21 --> Controller Class Initialized
DEBUG - 2022-08-24 18:50:21 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 18:50:21 --> Helper loaded: inflector_helper
INFO - 2022-08-24 18:50:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 18:50:21 --> Final output sent to browser
DEBUG - 2022-08-24 18:50:21 --> Total execution time: 0.5039
INFO - 2022-08-24 18:54:21 --> Config Class Initialized
INFO - 2022-08-24 18:54:21 --> Hooks Class Initialized
DEBUG - 2022-08-24 18:54:21 --> UTF-8 Support Enabled
INFO - 2022-08-24 18:54:21 --> Utf8 Class Initialized
INFO - 2022-08-24 18:54:21 --> URI Class Initialized
INFO - 2022-08-24 18:54:21 --> Router Class Initialized
INFO - 2022-08-24 18:54:21 --> Output Class Initialized
INFO - 2022-08-24 18:54:21 --> Security Class Initialized
DEBUG - 2022-08-24 18:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 18:54:21 --> Input Class Initialized
INFO - 2022-08-24 18:54:21 --> Language Class Initialized
INFO - 2022-08-24 18:54:21 --> Loader Class Initialized
INFO - 2022-08-24 18:54:21 --> Helper loaded: url_helper
INFO - 2022-08-24 18:54:21 --> Controller Class Initialized
DEBUG - 2022-08-24 18:54:21 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 18:54:22 --> Helper loaded: inflector_helper
INFO - 2022-08-24 18:54:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 18:54:22 --> Final output sent to browser
DEBUG - 2022-08-24 18:54:22 --> Total execution time: 0.5188
INFO - 2022-08-24 18:54:32 --> Config Class Initialized
INFO - 2022-08-24 18:54:32 --> Hooks Class Initialized
DEBUG - 2022-08-24 18:54:32 --> UTF-8 Support Enabled
INFO - 2022-08-24 18:54:32 --> Utf8 Class Initialized
INFO - 2022-08-24 18:54:32 --> URI Class Initialized
INFO - 2022-08-24 18:54:32 --> Router Class Initialized
INFO - 2022-08-24 18:54:32 --> Output Class Initialized
INFO - 2022-08-24 18:54:32 --> Security Class Initialized
DEBUG - 2022-08-24 18:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 18:54:32 --> Input Class Initialized
INFO - 2022-08-24 18:54:32 --> Language Class Initialized
INFO - 2022-08-24 18:54:32 --> Loader Class Initialized
INFO - 2022-08-24 18:54:32 --> Helper loaded: url_helper
INFO - 2022-08-24 18:54:32 --> Controller Class Initialized
DEBUG - 2022-08-24 18:54:32 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 18:54:32 --> Helper loaded: inflector_helper
INFO - 2022-08-24 18:54:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 18:54:32 --> Final output sent to browser
DEBUG - 2022-08-24 18:54:32 --> Total execution time: 0.5594
INFO - 2022-08-24 18:54:53 --> Config Class Initialized
INFO - 2022-08-24 18:54:53 --> Hooks Class Initialized
DEBUG - 2022-08-24 18:54:53 --> UTF-8 Support Enabled
INFO - 2022-08-24 18:54:53 --> Utf8 Class Initialized
INFO - 2022-08-24 18:54:53 --> URI Class Initialized
INFO - 2022-08-24 18:54:53 --> Router Class Initialized
INFO - 2022-08-24 18:54:53 --> Output Class Initialized
INFO - 2022-08-24 18:54:53 --> Security Class Initialized
DEBUG - 2022-08-24 18:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 18:54:53 --> Input Class Initialized
INFO - 2022-08-24 18:54:53 --> Language Class Initialized
INFO - 2022-08-24 18:54:53 --> Loader Class Initialized
INFO - 2022-08-24 18:54:53 --> Helper loaded: url_helper
INFO - 2022-08-24 18:54:53 --> Controller Class Initialized
DEBUG - 2022-08-24 18:54:53 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 18:54:53 --> Helper loaded: inflector_helper
INFO - 2022-08-24 18:54:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 18:54:53 --> Final output sent to browser
DEBUG - 2022-08-24 18:54:53 --> Total execution time: 0.4231
INFO - 2022-08-24 19:09:12 --> Config Class Initialized
INFO - 2022-08-24 19:09:12 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:09:12 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:09:12 --> Utf8 Class Initialized
INFO - 2022-08-24 19:09:12 --> URI Class Initialized
INFO - 2022-08-24 19:09:12 --> Router Class Initialized
INFO - 2022-08-24 19:09:12 --> Output Class Initialized
INFO - 2022-08-24 19:09:12 --> Security Class Initialized
DEBUG - 2022-08-24 19:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:09:12 --> Input Class Initialized
INFO - 2022-08-24 19:09:12 --> Language Class Initialized
ERROR - 2022-08-24 19:09:12 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-24 19:09:39 --> Config Class Initialized
INFO - 2022-08-24 19:09:39 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:09:39 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:09:39 --> Utf8 Class Initialized
INFO - 2022-08-24 19:09:39 --> URI Class Initialized
DEBUG - 2022-08-24 19:09:39 --> No URI present. Default controller set.
INFO - 2022-08-24 19:09:39 --> Router Class Initialized
INFO - 2022-08-24 19:09:39 --> Output Class Initialized
INFO - 2022-08-24 19:09:39 --> Security Class Initialized
DEBUG - 2022-08-24 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:09:39 --> Input Class Initialized
INFO - 2022-08-24 19:09:39 --> Language Class Initialized
INFO - 2022-08-24 19:09:39 --> Loader Class Initialized
INFO - 2022-08-24 19:09:39 --> Helper loaded: url_helper
INFO - 2022-08-24 19:09:39 --> Controller Class Initialized
INFO - 2022-08-24 19:09:39 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-24 19:09:39 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-24 19:09:39 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-24 19:09:39 --> Final output sent to browser
DEBUG - 2022-08-24 19:09:39 --> Total execution time: 0.6350
INFO - 2022-08-24 19:09:40 --> Config Class Initialized
INFO - 2022-08-24 19:09:40 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:09:40 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:09:40 --> Utf8 Class Initialized
INFO - 2022-08-24 19:09:40 --> URI Class Initialized
INFO - 2022-08-24 19:09:41 --> Router Class Initialized
INFO - 2022-08-24 19:09:41 --> Output Class Initialized
INFO - 2022-08-24 19:09:41 --> Security Class Initialized
DEBUG - 2022-08-24 19:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:09:41 --> Input Class Initialized
INFO - 2022-08-24 19:09:41 --> Language Class Initialized
ERROR - 2022-08-24 19:09:41 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-24 19:09:44 --> Config Class Initialized
INFO - 2022-08-24 19:09:44 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:09:44 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:09:44 --> Utf8 Class Initialized
INFO - 2022-08-24 19:09:44 --> URI Class Initialized
INFO - 2022-08-24 19:09:44 --> Router Class Initialized
INFO - 2022-08-24 19:09:44 --> Output Class Initialized
INFO - 2022-08-24 19:09:44 --> Security Class Initialized
DEBUG - 2022-08-24 19:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:09:44 --> Input Class Initialized
INFO - 2022-08-24 19:09:44 --> Language Class Initialized
ERROR - 2022-08-24 19:09:44 --> Severity: error --> Exception: syntax error, unexpected ''batch_number'' (T_CONSTANT_ENCAPSED_STRING) /sam_tool/application/controllers/Sam.php 42
INFO - 2022-08-24 19:10:02 --> Config Class Initialized
INFO - 2022-08-24 19:10:02 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:10:02 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:10:02 --> Utf8 Class Initialized
INFO - 2022-08-24 19:10:02 --> URI Class Initialized
INFO - 2022-08-24 19:10:02 --> Router Class Initialized
INFO - 2022-08-24 19:10:02 --> Output Class Initialized
INFO - 2022-08-24 19:10:02 --> Security Class Initialized
DEBUG - 2022-08-24 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:10:02 --> Input Class Initialized
INFO - 2022-08-24 19:10:02 --> Language Class Initialized
ERROR - 2022-08-24 19:10:02 --> Severity: error --> Exception: syntax error, unexpected ''batch_number'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /sam_tool/application/controllers/Sam.php 42
INFO - 2022-08-24 19:10:15 --> Config Class Initialized
INFO - 2022-08-24 19:10:15 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:10:15 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:10:15 --> Utf8 Class Initialized
INFO - 2022-08-24 19:10:15 --> URI Class Initialized
INFO - 2022-08-24 19:10:15 --> Router Class Initialized
INFO - 2022-08-24 19:10:15 --> Output Class Initialized
INFO - 2022-08-24 19:10:15 --> Security Class Initialized
DEBUG - 2022-08-24 19:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:10:15 --> Input Class Initialized
INFO - 2022-08-24 19:10:15 --> Language Class Initialized
INFO - 2022-08-24 19:10:15 --> Loader Class Initialized
INFO - 2022-08-24 19:10:15 --> Helper loaded: url_helper
INFO - 2022-08-24 19:10:15 --> Controller Class Initialized
DEBUG - 2022-08-24 19:10:15 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 19:10:15 --> Helper loaded: inflector_helper
INFO - 2022-08-24 19:10:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 19:10:15 --> Final output sent to browser
DEBUG - 2022-08-24 19:10:15 --> Total execution time: 0.7931
INFO - 2022-08-24 19:10:59 --> Config Class Initialized
INFO - 2022-08-24 19:10:59 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:10:59 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:10:59 --> Utf8 Class Initialized
INFO - 2022-08-24 19:10:59 --> URI Class Initialized
INFO - 2022-08-24 19:10:59 --> Router Class Initialized
INFO - 2022-08-24 19:10:59 --> Output Class Initialized
INFO - 2022-08-24 19:10:59 --> Security Class Initialized
DEBUG - 2022-08-24 19:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:10:59 --> Input Class Initialized
INFO - 2022-08-24 19:11:00 --> Language Class Initialized
INFO - 2022-08-24 19:11:00 --> Loader Class Initialized
INFO - 2022-08-24 19:11:00 --> Helper loaded: url_helper
INFO - 2022-08-24 19:11:00 --> Controller Class Initialized
DEBUG - 2022-08-24 19:11:00 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 19:11:00 --> Helper loaded: inflector_helper
INFO - 2022-08-24 19:11:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 19:11:00 --> Final output sent to browser
DEBUG - 2022-08-24 19:11:00 --> Total execution time: 0.7233
INFO - 2022-08-24 19:11:03 --> Config Class Initialized
INFO - 2022-08-24 19:11:03 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:11:03 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:11:03 --> Utf8 Class Initialized
INFO - 2022-08-24 19:11:03 --> URI Class Initialized
INFO - 2022-08-24 19:11:03 --> Router Class Initialized
INFO - 2022-08-24 19:11:03 --> Output Class Initialized
INFO - 2022-08-24 19:11:03 --> Security Class Initialized
DEBUG - 2022-08-24 19:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:11:03 --> Input Class Initialized
INFO - 2022-08-24 19:11:03 --> Language Class Initialized
ERROR - 2022-08-24 19:11:03 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-24 19:11:03 --> Config Class Initialized
INFO - 2022-08-24 19:11:03 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:11:04 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:11:04 --> Utf8 Class Initialized
INFO - 2022-08-24 19:11:04 --> URI Class Initialized
DEBUG - 2022-08-24 19:11:04 --> No URI present. Default controller set.
INFO - 2022-08-24 19:11:04 --> Router Class Initialized
INFO - 2022-08-24 19:11:04 --> Output Class Initialized
INFO - 2022-08-24 19:11:04 --> Security Class Initialized
DEBUG - 2022-08-24 19:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:11:04 --> Input Class Initialized
INFO - 2022-08-24 19:11:04 --> Language Class Initialized
INFO - 2022-08-24 19:11:04 --> Loader Class Initialized
INFO - 2022-08-24 19:11:04 --> Helper loaded: url_helper
INFO - 2022-08-24 19:11:04 --> Controller Class Initialized
INFO - 2022-08-24 19:11:04 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-24 19:11:04 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-24 19:11:04 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-24 19:11:04 --> Final output sent to browser
DEBUG - 2022-08-24 19:11:04 --> Total execution time: 0.5069
INFO - 2022-08-24 19:11:05 --> Config Class Initialized
INFO - 2022-08-24 19:11:05 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:11:05 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:11:05 --> Utf8 Class Initialized
INFO - 2022-08-24 19:11:05 --> URI Class Initialized
INFO - 2022-08-24 19:11:05 --> Router Class Initialized
INFO - 2022-08-24 19:11:05 --> Output Class Initialized
INFO - 2022-08-24 19:11:05 --> Security Class Initialized
DEBUG - 2022-08-24 19:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:11:05 --> Input Class Initialized
INFO - 2022-08-24 19:11:05 --> Language Class Initialized
ERROR - 2022-08-24 19:11:05 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-24 19:11:09 --> Config Class Initialized
INFO - 2022-08-24 19:11:09 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:11:09 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:11:09 --> Utf8 Class Initialized
INFO - 2022-08-24 19:11:09 --> URI Class Initialized
INFO - 2022-08-24 19:11:09 --> Router Class Initialized
INFO - 2022-08-24 19:11:10 --> Output Class Initialized
INFO - 2022-08-24 19:11:10 --> Security Class Initialized
DEBUG - 2022-08-24 19:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:11:10 --> Input Class Initialized
INFO - 2022-08-24 19:11:10 --> Language Class Initialized
INFO - 2022-08-24 19:11:10 --> Loader Class Initialized
INFO - 2022-08-24 19:11:10 --> Helper loaded: url_helper
INFO - 2022-08-24 19:11:10 --> Controller Class Initialized
DEBUG - 2022-08-24 19:11:10 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 19:11:10 --> Helper loaded: inflector_helper
INFO - 2022-08-24 19:11:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 19:11:10 --> Final output sent to browser
DEBUG - 2022-08-24 19:11:10 --> Total execution time: 0.7587
INFO - 2022-08-24 19:12:20 --> Config Class Initialized
INFO - 2022-08-24 19:12:20 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:12:20 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:12:20 --> Utf8 Class Initialized
INFO - 2022-08-24 19:12:20 --> URI Class Initialized
INFO - 2022-08-24 19:12:20 --> Router Class Initialized
INFO - 2022-08-24 19:12:20 --> Output Class Initialized
INFO - 2022-08-24 19:12:20 --> Security Class Initialized
DEBUG - 2022-08-24 19:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:12:20 --> Input Class Initialized
INFO - 2022-08-24 19:12:20 --> Language Class Initialized
INFO - 2022-08-24 19:12:21 --> Loader Class Initialized
INFO - 2022-08-24 19:12:21 --> Helper loaded: url_helper
INFO - 2022-08-24 19:12:21 --> Controller Class Initialized
DEBUG - 2022-08-24 19:12:21 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 19:12:21 --> Helper loaded: inflector_helper
INFO - 2022-08-24 19:12:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 19:12:21 --> Final output sent to browser
DEBUG - 2022-08-24 19:12:21 --> Total execution time: 0.8738
INFO - 2022-08-24 19:24:12 --> Config Class Initialized
INFO - 2022-08-24 19:24:12 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:24:12 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:24:12 --> Utf8 Class Initialized
INFO - 2022-08-24 19:24:12 --> URI Class Initialized
INFO - 2022-08-24 19:24:12 --> Router Class Initialized
INFO - 2022-08-24 19:24:12 --> Output Class Initialized
INFO - 2022-08-24 19:24:12 --> Security Class Initialized
DEBUG - 2022-08-24 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:24:12 --> Input Class Initialized
INFO - 2022-08-24 19:24:12 --> Language Class Initialized
ERROR - 2022-08-24 19:24:12 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-24 19:24:34 --> Config Class Initialized
INFO - 2022-08-24 19:24:34 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:24:34 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:24:34 --> Utf8 Class Initialized
INFO - 2022-08-24 19:24:34 --> URI Class Initialized
INFO - 2022-08-24 19:24:34 --> Router Class Initialized
INFO - 2022-08-24 19:24:34 --> Output Class Initialized
INFO - 2022-08-24 19:24:34 --> Security Class Initialized
DEBUG - 2022-08-24 19:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:24:34 --> Input Class Initialized
INFO - 2022-08-24 19:24:34 --> Language Class Initialized
INFO - 2022-08-24 19:24:34 --> Loader Class Initialized
INFO - 2022-08-24 19:24:34 --> Helper loaded: url_helper
INFO - 2022-08-24 19:24:34 --> Controller Class Initialized
DEBUG - 2022-08-24 19:24:34 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 19:24:34 --> Helper loaded: inflector_helper
INFO - 2022-08-24 19:24:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-24 19:24:34 --> Final output sent to browser
DEBUG - 2022-08-24 19:24:34 --> Total execution time: 0.2632
INFO - 2022-08-24 19:30:21 --> Config Class Initialized
INFO - 2022-08-24 19:30:21 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:30:21 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:30:21 --> Utf8 Class Initialized
INFO - 2022-08-24 19:30:21 --> URI Class Initialized
INFO - 2022-08-24 19:30:21 --> Router Class Initialized
INFO - 2022-08-24 19:30:21 --> Output Class Initialized
INFO - 2022-08-24 19:30:21 --> Security Class Initialized
DEBUG - 2022-08-24 19:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:30:21 --> Input Class Initialized
INFO - 2022-08-24 19:30:21 --> Language Class Initialized
ERROR - 2022-08-24 19:30:21 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-24 19:30:28 --> Config Class Initialized
INFO - 2022-08-24 19:30:28 --> Hooks Class Initialized
DEBUG - 2022-08-24 19:30:28 --> UTF-8 Support Enabled
INFO - 2022-08-24 19:30:28 --> Utf8 Class Initialized
INFO - 2022-08-24 19:30:28 --> URI Class Initialized
INFO - 2022-08-24 19:30:28 --> Router Class Initialized
INFO - 2022-08-24 19:30:28 --> Output Class Initialized
INFO - 2022-08-24 19:30:28 --> Security Class Initialized
DEBUG - 2022-08-24 19:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-24 19:30:28 --> Input Class Initialized
INFO - 2022-08-24 19:30:28 --> Language Class Initialized
INFO - 2022-08-24 19:30:29 --> Loader Class Initialized
INFO - 2022-08-24 19:30:29 --> Helper loaded: url_helper
INFO - 2022-08-24 19:30:29 --> Controller Class Initialized
DEBUG - 2022-08-24 19:30:29 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-24 19:30:29 --> Helper loaded: inflector_helper
INFO - 2022-08-24 19:30:29 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-24 19:30:29 --> {"city_id":3,"state_id":3,"bank_id":5,"type_id":3,"locality":3,"batch_size":5,"batch_number":1}
INFO - 2022-08-24 19:30:29 --> Final output sent to browser
DEBUG - 2022-08-24 19:30:29 --> Total execution time: 0.2304
ERROR - 2022-08-24 19:31:10 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-24 19:31:14 --> {"city_id":3,"state_id":3,"bank_id":5,"type_id":2,"locality":3,"batch_size":5,"batch_number":1}
ERROR - 2022-08-24 19:32:24 --> {"city_id":3,"state_id":3,"bank_id":5,"type_id":2,"locality":3,"batch_size":5,"batch_number":1}
ERROR - 2022-08-24 19:32:24 --> {"city_id":3,"state_id":3,"bank_id":5,"type_id":2,"locality":3,"batch_size":5,"batch_number":1}
ERROR - 2022-08-24 19:32:58 --> {"city_id":3,"state_id":3,"bank_id":5,"type_id":2,"locality":3,"batch_size":5,"batch_number":1}
ERROR - 2022-08-24 19:32:58 --> Resource id #35
