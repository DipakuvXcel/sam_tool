<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-04 11:52:34 --> Config Class Initialized
INFO - 2022-08-04 11:52:34 --> Hooks Class Initialized
DEBUG - 2022-08-04 11:52:34 --> UTF-8 Support Enabled
INFO - 2022-08-04 11:52:34 --> Utf8 Class Initialized
INFO - 2022-08-04 11:52:34 --> URI Class Initialized
DEBUG - 2022-08-04 11:52:34 --> No URI present. Default controller set.
INFO - 2022-08-04 11:52:34 --> Router Class Initialized
INFO - 2022-08-04 11:52:34 --> Output Class Initialized
INFO - 2022-08-04 11:52:34 --> Security Class Initialized
DEBUG - 2022-08-04 11:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 11:52:34 --> Input Class Initialized
INFO - 2022-08-04 11:52:34 --> Language Class Initialized
INFO - 2022-08-04 11:52:34 --> Loader Class Initialized
INFO - 2022-08-04 11:52:34 --> Helper loaded: url_helper
INFO - 2022-08-04 11:52:34 --> Controller Class Initialized
INFO - 2022-08-04 11:52:34 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-04 11:52:34 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-04 11:52:34 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-04 11:52:34 --> Final output sent to browser
DEBUG - 2022-08-04 11:52:34 --> Total execution time: 0.4072
INFO - 2022-08-04 12:12:59 --> Config Class Initialized
INFO - 2022-08-04 12:12:59 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:12:59 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:12:59 --> Utf8 Class Initialized
INFO - 2022-08-04 12:12:59 --> URI Class Initialized
INFO - 2022-08-04 12:12:59 --> Router Class Initialized
INFO - 2022-08-04 12:12:59 --> Output Class Initialized
INFO - 2022-08-04 12:12:59 --> Security Class Initialized
DEBUG - 2022-08-04 12:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:12:59 --> Input Class Initialized
INFO - 2022-08-04 12:12:59 --> Language Class Initialized
INFO - 2022-08-04 12:12:59 --> Loader Class Initialized
INFO - 2022-08-04 12:12:59 --> Helper loaded: url_helper
INFO - 2022-08-04 12:12:59 --> Controller Class Initialized
INFO - 2022-08-04 12:12:59 --> File loaded: /sam_tool/application/views/frontend/register_cust.php
INFO - 2022-08-04 12:12:59 --> Final output sent to browser
DEBUG - 2022-08-04 12:12:59 --> Total execution time: 0.2033
INFO - 2022-08-04 12:12:59 --> Config Class Initialized
INFO - 2022-08-04 12:12:59 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:12:59 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:12:59 --> Utf8 Class Initialized
INFO - 2022-08-04 12:12:59 --> URI Class Initialized
INFO - 2022-08-04 12:12:59 --> Router Class Initialized
INFO - 2022-08-04 12:12:59 --> Output Class Initialized
INFO - 2022-08-04 12:12:59 --> Security Class Initialized
DEBUG - 2022-08-04 12:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:12:59 --> Input Class Initialized
INFO - 2022-08-04 12:12:59 --> Language Class Initialized
ERROR - 2022-08-04 12:12:59 --> 404 Page Not Found: Frontend/favicon.ico
INFO - 2022-08-04 12:47:32 --> Config Class Initialized
INFO - 2022-08-04 12:47:32 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:47:32 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:47:32 --> Utf8 Class Initialized
INFO - 2022-08-04 12:47:32 --> URI Class Initialized
INFO - 2022-08-04 12:47:32 --> Router Class Initialized
INFO - 2022-08-04 12:47:32 --> Output Class Initialized
INFO - 2022-08-04 12:47:32 --> Security Class Initialized
DEBUG - 2022-08-04 12:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:47:32 --> Input Class Initialized
INFO - 2022-08-04 12:47:32 --> Language Class Initialized
INFO - 2022-08-04 12:47:33 --> Loader Class Initialized
INFO - 2022-08-04 12:47:33 --> Helper loaded: url_helper
INFO - 2022-08-04 12:47:33 --> Controller Class Initialized
INFO - 2022-08-04 12:47:33 --> Final output sent to browser
DEBUG - 2022-08-04 12:47:33 --> Total execution time: 0.8491
INFO - 2022-08-04 12:47:33 --> Config Class Initialized
INFO - 2022-08-04 12:47:33 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:47:33 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:47:33 --> Utf8 Class Initialized
INFO - 2022-08-04 12:47:33 --> URI Class Initialized
INFO - 2022-08-04 12:47:33 --> Router Class Initialized
INFO - 2022-08-04 12:47:33 --> Output Class Initialized
INFO - 2022-08-04 12:47:33 --> Security Class Initialized
DEBUG - 2022-08-04 12:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:47:33 --> Input Class Initialized
INFO - 2022-08-04 12:47:33 --> Language Class Initialized
ERROR - 2022-08-04 12:47:33 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-04 12:47:46 --> Config Class Initialized
INFO - 2022-08-04 12:47:46 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:47:46 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:47:46 --> Utf8 Class Initialized
INFO - 2022-08-04 12:47:46 --> URI Class Initialized
INFO - 2022-08-04 12:47:46 --> Router Class Initialized
INFO - 2022-08-04 12:47:46 --> Output Class Initialized
INFO - 2022-08-04 12:47:46 --> Security Class Initialized
DEBUG - 2022-08-04 12:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:47:46 --> Input Class Initialized
INFO - 2022-08-04 12:47:46 --> Language Class Initialized
INFO - 2022-08-04 12:47:46 --> Loader Class Initialized
INFO - 2022-08-04 12:47:46 --> Helper loaded: url_helper
INFO - 2022-08-04 12:47:46 --> Controller Class Initialized
INFO - 2022-08-04 12:47:46 --> Final output sent to browser
DEBUG - 2022-08-04 12:47:46 --> Total execution time: 0.5075
INFO - 2022-08-04 12:47:46 --> Config Class Initialized
INFO - 2022-08-04 12:47:46 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:47:46 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:47:46 --> Utf8 Class Initialized
INFO - 2022-08-04 12:47:46 --> URI Class Initialized
INFO - 2022-08-04 12:47:46 --> Router Class Initialized
INFO - 2022-08-04 12:47:46 --> Output Class Initialized
INFO - 2022-08-04 12:47:46 --> Security Class Initialized
DEBUG - 2022-08-04 12:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:47:47 --> Input Class Initialized
INFO - 2022-08-04 12:47:47 --> Language Class Initialized
ERROR - 2022-08-04 12:47:47 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-04 12:47:57 --> Config Class Initialized
INFO - 2022-08-04 12:47:57 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:47:57 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:47:57 --> Utf8 Class Initialized
INFO - 2022-08-04 12:47:57 --> URI Class Initialized
INFO - 2022-08-04 12:47:57 --> Router Class Initialized
INFO - 2022-08-04 12:47:57 --> Output Class Initialized
INFO - 2022-08-04 12:47:58 --> Security Class Initialized
DEBUG - 2022-08-04 12:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:47:58 --> Input Class Initialized
INFO - 2022-08-04 12:47:58 --> Language Class Initialized
INFO - 2022-08-04 12:47:58 --> Loader Class Initialized
INFO - 2022-08-04 12:47:58 --> Helper loaded: url_helper
INFO - 2022-08-04 12:47:58 --> Controller Class Initialized
INFO - 2022-08-04 12:47:58 --> Final output sent to browser
DEBUG - 2022-08-04 12:47:58 --> Total execution time: 0.6498
INFO - 2022-08-04 12:47:58 --> Config Class Initialized
INFO - 2022-08-04 12:47:58 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:47:58 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:47:58 --> Utf8 Class Initialized
INFO - 2022-08-04 12:47:58 --> URI Class Initialized
INFO - 2022-08-04 12:47:58 --> Router Class Initialized
INFO - 2022-08-04 12:47:58 --> Output Class Initialized
INFO - 2022-08-04 12:47:58 --> Security Class Initialized
DEBUG - 2022-08-04 12:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:47:58 --> Input Class Initialized
INFO - 2022-08-04 12:47:58 --> Language Class Initialized
ERROR - 2022-08-04 12:47:58 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-04 12:48:03 --> Config Class Initialized
INFO - 2022-08-04 12:48:03 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:48:03 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:48:03 --> Utf8 Class Initialized
INFO - 2022-08-04 12:48:04 --> URI Class Initialized
INFO - 2022-08-04 12:48:04 --> Router Class Initialized
INFO - 2022-08-04 12:48:04 --> Output Class Initialized
INFO - 2022-08-04 12:48:04 --> Security Class Initialized
DEBUG - 2022-08-04 12:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:48:04 --> Input Class Initialized
INFO - 2022-08-04 12:48:04 --> Language Class Initialized
INFO - 2022-08-04 12:48:04 --> Loader Class Initialized
INFO - 2022-08-04 12:48:04 --> Helper loaded: url_helper
INFO - 2022-08-04 12:48:04 --> Controller Class Initialized
INFO - 2022-08-04 12:48:04 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-04 12:48:04 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-04 12:48:04 --> File loaded: /sam_tool/application/views/frontend/property_details.php
INFO - 2022-08-04 12:48:04 --> Final output sent to browser
DEBUG - 2022-08-04 12:48:04 --> Total execution time: 0.7050
INFO - 2022-08-04 12:48:24 --> Config Class Initialized
INFO - 2022-08-04 12:48:24 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:48:24 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:48:25 --> Utf8 Class Initialized
INFO - 2022-08-04 12:48:25 --> URI Class Initialized
INFO - 2022-08-04 12:48:25 --> Router Class Initialized
INFO - 2022-08-04 12:48:25 --> Output Class Initialized
INFO - 2022-08-04 12:48:25 --> Security Class Initialized
DEBUG - 2022-08-04 12:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:48:25 --> Input Class Initialized
INFO - 2022-08-04 12:48:25 --> Language Class Initialized
INFO - 2022-08-04 12:48:25 --> Loader Class Initialized
INFO - 2022-08-04 12:48:25 --> Helper loaded: url_helper
INFO - 2022-08-04 12:48:25 --> Controller Class Initialized
INFO - 2022-08-04 12:48:25 --> Final output sent to browser
DEBUG - 2022-08-04 12:48:25 --> Total execution time: 0.5017
INFO - 2022-08-04 12:48:40 --> Config Class Initialized
INFO - 2022-08-04 12:48:40 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:48:41 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:48:41 --> Utf8 Class Initialized
INFO - 2022-08-04 12:48:41 --> URI Class Initialized
INFO - 2022-08-04 12:48:41 --> Router Class Initialized
INFO - 2022-08-04 12:48:41 --> Output Class Initialized
INFO - 2022-08-04 12:48:41 --> Security Class Initialized
DEBUG - 2022-08-04 12:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:48:41 --> Input Class Initialized
INFO - 2022-08-04 12:48:41 --> Language Class Initialized
INFO - 2022-08-04 12:48:41 --> Loader Class Initialized
INFO - 2022-08-04 12:48:41 --> Helper loaded: url_helper
INFO - 2022-08-04 12:48:41 --> Controller Class Initialized
INFO - 2022-08-04 12:48:41 --> Final output sent to browser
DEBUG - 2022-08-04 12:48:41 --> Total execution time: 0.6199
INFO - 2022-08-04 12:48:47 --> Config Class Initialized
INFO - 2022-08-04 12:48:47 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:48:47 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:48:47 --> Utf8 Class Initialized
INFO - 2022-08-04 12:48:47 --> URI Class Initialized
INFO - 2022-08-04 12:48:47 --> Router Class Initialized
INFO - 2022-08-04 12:48:47 --> Output Class Initialized
INFO - 2022-08-04 12:48:48 --> Security Class Initialized
DEBUG - 2022-08-04 12:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:48:48 --> Input Class Initialized
INFO - 2022-08-04 12:48:48 --> Language Class Initialized
INFO - 2022-08-04 12:48:48 --> Loader Class Initialized
INFO - 2022-08-04 12:48:48 --> Helper loaded: url_helper
INFO - 2022-08-04 12:48:48 --> Controller Class Initialized
INFO - 2022-08-04 12:48:48 --> Final output sent to browser
DEBUG - 2022-08-04 12:48:48 --> Total execution time: 0.7069
INFO - 2022-08-04 12:48:48 --> Config Class Initialized
INFO - 2022-08-04 12:48:48 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:48:48 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:48:48 --> Utf8 Class Initialized
INFO - 2022-08-04 12:48:48 --> URI Class Initialized
INFO - 2022-08-04 12:48:48 --> Router Class Initialized
INFO - 2022-08-04 12:48:48 --> Output Class Initialized
INFO - 2022-08-04 12:48:48 --> Security Class Initialized
DEBUG - 2022-08-04 12:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:48:48 --> Input Class Initialized
INFO - 2022-08-04 12:48:48 --> Language Class Initialized
ERROR - 2022-08-04 12:48:48 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-04 12:48:57 --> Config Class Initialized
INFO - 2022-08-04 12:48:57 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:48:57 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:48:57 --> Utf8 Class Initialized
INFO - 2022-08-04 12:48:57 --> URI Class Initialized
INFO - 2022-08-04 12:48:57 --> Router Class Initialized
INFO - 2022-08-04 12:48:57 --> Output Class Initialized
INFO - 2022-08-04 12:48:57 --> Security Class Initialized
DEBUG - 2022-08-04 12:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:48:57 --> Input Class Initialized
INFO - 2022-08-04 12:48:58 --> Language Class Initialized
INFO - 2022-08-04 12:48:58 --> Loader Class Initialized
INFO - 2022-08-04 12:48:58 --> Helper loaded: url_helper
INFO - 2022-08-04 12:48:58 --> Controller Class Initialized
INFO - 2022-08-04 12:48:58 --> Final output sent to browser
DEBUG - 2022-08-04 12:48:58 --> Total execution time: 0.5868
INFO - 2022-08-04 12:48:58 --> Config Class Initialized
INFO - 2022-08-04 12:48:58 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:48:58 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:48:58 --> Utf8 Class Initialized
INFO - 2022-08-04 12:48:58 --> URI Class Initialized
INFO - 2022-08-04 12:48:58 --> Router Class Initialized
INFO - 2022-08-04 12:48:58 --> Output Class Initialized
INFO - 2022-08-04 12:48:58 --> Security Class Initialized
DEBUG - 2022-08-04 12:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:48:58 --> Input Class Initialized
INFO - 2022-08-04 12:48:58 --> Language Class Initialized
ERROR - 2022-08-04 12:48:58 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-04 12:56:46 --> Config Class Initialized
INFO - 2022-08-04 12:56:46 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:56:46 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:56:46 --> Utf8 Class Initialized
INFO - 2022-08-04 12:56:46 --> URI Class Initialized
DEBUG - 2022-08-04 12:56:46 --> No URI present. Default controller set.
INFO - 2022-08-04 12:56:46 --> Router Class Initialized
INFO - 2022-08-04 12:56:46 --> Output Class Initialized
INFO - 2022-08-04 12:56:46 --> Security Class Initialized
DEBUG - 2022-08-04 12:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:56:46 --> Input Class Initialized
INFO - 2022-08-04 12:56:46 --> Language Class Initialized
INFO - 2022-08-04 12:56:46 --> Loader Class Initialized
INFO - 2022-08-04 12:56:46 --> Helper loaded: url_helper
INFO - 2022-08-04 12:56:46 --> Controller Class Initialized
INFO - 2022-08-04 12:56:46 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-04 12:56:46 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-04 12:56:46 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-04 12:56:46 --> Final output sent to browser
DEBUG - 2022-08-04 12:56:46 --> Total execution time: 0.7251
INFO - 2022-08-04 12:56:59 --> Config Class Initialized
INFO - 2022-08-04 12:56:59 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:57:00 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:57:00 --> Utf8 Class Initialized
INFO - 2022-08-04 12:57:00 --> URI Class Initialized
INFO - 2022-08-04 12:57:00 --> Router Class Initialized
INFO - 2022-08-04 12:57:00 --> Output Class Initialized
INFO - 2022-08-04 12:57:00 --> Security Class Initialized
DEBUG - 2022-08-04 12:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:57:00 --> Input Class Initialized
INFO - 2022-08-04 12:57:00 --> Language Class Initialized
INFO - 2022-08-04 12:57:00 --> Loader Class Initialized
INFO - 2022-08-04 12:57:00 --> Helper loaded: url_helper
INFO - 2022-08-04 12:57:00 --> Controller Class Initialized
INFO - 2022-08-04 12:57:00 --> File loaded: /sam_tool/application/views/frontend/register_cust.php
INFO - 2022-08-04 12:57:00 --> Final output sent to browser
DEBUG - 2022-08-04 12:57:00 --> Total execution time: 0.4871
INFO - 2022-08-04 12:57:00 --> Config Class Initialized
INFO - 2022-08-04 12:57:00 --> Hooks Class Initialized
DEBUG - 2022-08-04 12:57:00 --> UTF-8 Support Enabled
INFO - 2022-08-04 12:57:00 --> Utf8 Class Initialized
INFO - 2022-08-04 12:57:00 --> URI Class Initialized
INFO - 2022-08-04 12:57:00 --> Router Class Initialized
INFO - 2022-08-04 12:57:00 --> Output Class Initialized
INFO - 2022-08-04 12:57:00 --> Security Class Initialized
DEBUG - 2022-08-04 12:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 12:57:00 --> Input Class Initialized
INFO - 2022-08-04 12:57:00 --> Language Class Initialized
ERROR - 2022-08-04 12:57:01 --> 404 Page Not Found: Frontend/favicon.ico
INFO - 2022-08-04 13:07:51 --> Config Class Initialized
INFO - 2022-08-04 13:07:51 --> Hooks Class Initialized
DEBUG - 2022-08-04 13:07:51 --> UTF-8 Support Enabled
INFO - 2022-08-04 13:07:51 --> Utf8 Class Initialized
INFO - 2022-08-04 13:07:51 --> URI Class Initialized
DEBUG - 2022-08-04 13:07:51 --> No URI present. Default controller set.
INFO - 2022-08-04 13:07:51 --> Router Class Initialized
INFO - 2022-08-04 13:07:51 --> Output Class Initialized
INFO - 2022-08-04 13:07:51 --> Security Class Initialized
DEBUG - 2022-08-04 13:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 13:07:51 --> Input Class Initialized
INFO - 2022-08-04 13:07:51 --> Language Class Initialized
INFO - 2022-08-04 13:07:51 --> Loader Class Initialized
INFO - 2022-08-04 13:07:51 --> Helper loaded: url_helper
INFO - 2022-08-04 13:07:51 --> Controller Class Initialized
INFO - 2022-08-04 13:07:52 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-04 13:07:52 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-04 13:07:52 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-04 13:07:52 --> Final output sent to browser
DEBUG - 2022-08-04 13:07:52 --> Total execution time: 0.6988
INFO - 2022-08-04 18:38:56 --> Config Class Initialized
INFO - 2022-08-04 18:38:56 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:38:56 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:38:56 --> Utf8 Class Initialized
INFO - 2022-08-04 18:38:56 --> URI Class Initialized
INFO - 2022-08-04 18:38:56 --> Router Class Initialized
INFO - 2022-08-04 18:38:56 --> Output Class Initialized
INFO - 2022-08-04 18:38:56 --> Security Class Initialized
DEBUG - 2022-08-04 18:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:38:56 --> Input Class Initialized
INFO - 2022-08-04 18:38:56 --> Language Class Initialized
ERROR - 2022-08-04 18:38:56 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) /sam_tool/application/controllers/Frontend.php 331
INFO - 2022-08-04 18:39:10 --> Config Class Initialized
INFO - 2022-08-04 18:39:10 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:39:10 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:39:10 --> Utf8 Class Initialized
INFO - 2022-08-04 18:39:10 --> URI Class Initialized
INFO - 2022-08-04 18:39:10 --> Router Class Initialized
INFO - 2022-08-04 18:39:10 --> Output Class Initialized
INFO - 2022-08-04 18:39:10 --> Security Class Initialized
DEBUG - 2022-08-04 18:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:39:10 --> Input Class Initialized
INFO - 2022-08-04 18:39:10 --> Language Class Initialized
ERROR - 2022-08-04 18:39:11 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) /sam_tool/application/controllers/Frontend.php 331
INFO - 2022-08-04 18:39:26 --> Config Class Initialized
INFO - 2022-08-04 18:39:26 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:39:26 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:39:26 --> Utf8 Class Initialized
INFO - 2022-08-04 18:39:26 --> URI Class Initialized
INFO - 2022-08-04 18:39:26 --> Router Class Initialized
INFO - 2022-08-04 18:39:26 --> Output Class Initialized
INFO - 2022-08-04 18:39:26 --> Security Class Initialized
DEBUG - 2022-08-04 18:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:39:26 --> Input Class Initialized
INFO - 2022-08-04 18:39:26 --> Language Class Initialized
INFO - 2022-08-04 18:39:26 --> Loader Class Initialized
INFO - 2022-08-04 18:39:26 --> Helper loaded: url_helper
INFO - 2022-08-04 18:39:26 --> Controller Class Initialized
INFO - 2022-08-04 18:39:26 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-04 18:39:26 --> Severity: Notice --> Undefined property: CI_Loader::$session /sam_tool/application/views/frontend/add_property_details.php 52
ERROR - 2022-08-04 18:39:26 --> Severity: error --> Exception: Call to a member function flashdata() on null /sam_tool/application/views/frontend/add_property_details.php 52
INFO - 2022-08-04 18:40:30 --> Config Class Initialized
INFO - 2022-08-04 18:40:30 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:40:30 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:40:30 --> Utf8 Class Initialized
INFO - 2022-08-04 18:40:30 --> URI Class Initialized
INFO - 2022-08-04 18:40:30 --> Router Class Initialized
INFO - 2022-08-04 18:40:30 --> Output Class Initialized
INFO - 2022-08-04 18:40:30 --> Security Class Initialized
DEBUG - 2022-08-04 18:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:40:30 --> Input Class Initialized
INFO - 2022-08-04 18:40:30 --> Language Class Initialized
INFO - 2022-08-04 18:40:30 --> Loader Class Initialized
INFO - 2022-08-04 18:40:30 --> Helper loaded: url_helper
INFO - 2022-08-04 18:40:30 --> Controller Class Initialized
ERROR - 2022-08-04 18:40:30 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /sam_tool/application/views/frontend/add_property_details.php 58
INFO - 2022-08-04 18:40:42 --> Config Class Initialized
INFO - 2022-08-04 18:40:42 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:40:42 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:40:42 --> Utf8 Class Initialized
INFO - 2022-08-04 18:40:42 --> URI Class Initialized
INFO - 2022-08-04 18:40:42 --> Router Class Initialized
INFO - 2022-08-04 18:40:42 --> Output Class Initialized
INFO - 2022-08-04 18:40:42 --> Security Class Initialized
DEBUG - 2022-08-04 18:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:40:42 --> Input Class Initialized
INFO - 2022-08-04 18:40:42 --> Language Class Initialized
INFO - 2022-08-04 18:40:42 --> Loader Class Initialized
INFO - 2022-08-04 18:40:42 --> Helper loaded: url_helper
INFO - 2022-08-04 18:40:42 --> Controller Class Initialized
INFO - 2022-08-04 18:40:42 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-04 18:40:42 --> Severity: Notice --> Undefined property: CI_Loader::$session /sam_tool/application/views/frontend/add_property_details.php 56
ERROR - 2022-08-04 18:40:42 --> Severity: error --> Exception: Call to a member function flashdata() on null /sam_tool/application/views/frontend/add_property_details.php 56
INFO - 2022-08-04 18:41:08 --> Config Class Initialized
INFO - 2022-08-04 18:41:08 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:41:08 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:41:08 --> Utf8 Class Initialized
INFO - 2022-08-04 18:41:09 --> URI Class Initialized
INFO - 2022-08-04 18:41:09 --> Router Class Initialized
INFO - 2022-08-04 18:41:09 --> Output Class Initialized
INFO - 2022-08-04 18:41:09 --> Security Class Initialized
DEBUG - 2022-08-04 18:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:41:09 --> Input Class Initialized
INFO - 2022-08-04 18:41:09 --> Language Class Initialized
INFO - 2022-08-04 18:41:09 --> Loader Class Initialized
INFO - 2022-08-04 18:41:09 --> Helper loaded: url_helper
INFO - 2022-08-04 18:41:09 --> Controller Class Initialized
INFO - 2022-08-04 18:41:09 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-04 18:41:09 --> Severity: Notice --> Undefined property: CI_Loader::$session /sam_tool/application/views/frontend/add_property_details.php 56
ERROR - 2022-08-04 18:41:09 --> Severity: error --> Exception: Call to a member function flashdata() on null /sam_tool/application/views/frontend/add_property_details.php 56
INFO - 2022-08-04 18:41:33 --> Config Class Initialized
INFO - 2022-08-04 18:41:33 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:41:33 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:41:33 --> Utf8 Class Initialized
INFO - 2022-08-04 18:41:34 --> URI Class Initialized
INFO - 2022-08-04 18:41:34 --> Router Class Initialized
INFO - 2022-08-04 18:41:34 --> Output Class Initialized
INFO - 2022-08-04 18:41:34 --> Security Class Initialized
DEBUG - 2022-08-04 18:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:41:34 --> Input Class Initialized
INFO - 2022-08-04 18:41:34 --> Language Class Initialized
INFO - 2022-08-04 18:41:34 --> Loader Class Initialized
INFO - 2022-08-04 18:41:34 --> Helper loaded: url_helper
INFO - 2022-08-04 18:41:34 --> Controller Class Initialized
INFO - 2022-08-04 18:41:34 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-04 18:41:34 --> Severity: error --> Exception: Call to undefined function set_value() /sam_tool/application/views/frontend/add_property_details.php 64
INFO - 2022-08-04 18:41:51 --> Config Class Initialized
INFO - 2022-08-04 18:41:51 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:41:51 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:41:51 --> Utf8 Class Initialized
INFO - 2022-08-04 18:41:51 --> URI Class Initialized
INFO - 2022-08-04 18:41:51 --> Router Class Initialized
INFO - 2022-08-04 18:41:51 --> Output Class Initialized
INFO - 2022-08-04 18:41:51 --> Security Class Initialized
DEBUG - 2022-08-04 18:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:41:51 --> Input Class Initialized
INFO - 2022-08-04 18:41:51 --> Language Class Initialized
INFO - 2022-08-04 18:41:51 --> Loader Class Initialized
INFO - 2022-08-04 18:41:51 --> Helper loaded: url_helper
INFO - 2022-08-04 18:41:51 --> Controller Class Initialized
INFO - 2022-08-04 18:41:51 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-04 18:41:51 --> Severity: Notice --> Undefined variable: state /sam_tool/application/views/frontend/add_property_details.php 95
ERROR - 2022-08-04 18:41:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/add_property_details.php 95
ERROR - 2022-08-04 18:41:51 --> Severity: error --> Exception: Call to undefined function set_value() /sam_tool/application/views/frontend/add_property_details.php 100
INFO - 2022-08-04 18:46:57 --> Config Class Initialized
INFO - 2022-08-04 18:46:57 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:46:57 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:46:57 --> Utf8 Class Initialized
INFO - 2022-08-04 18:46:57 --> URI Class Initialized
INFO - 2022-08-04 18:46:57 --> Router Class Initialized
INFO - 2022-08-04 18:46:57 --> Output Class Initialized
INFO - 2022-08-04 18:46:57 --> Security Class Initialized
DEBUG - 2022-08-04 18:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:46:57 --> Input Class Initialized
INFO - 2022-08-04 18:46:57 --> Language Class Initialized
INFO - 2022-08-04 18:46:57 --> Loader Class Initialized
INFO - 2022-08-04 18:46:57 --> Helper loaded: url_helper
INFO - 2022-08-04 18:46:57 --> Controller Class Initialized
INFO - 2022-08-04 18:46:57 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-04 18:46:57 --> Severity: Notice --> Undefined variable: state /sam_tool/application/views/frontend/add_property_details.php 95
ERROR - 2022-08-04 18:46:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/add_property_details.php 95
ERROR - 2022-08-04 18:46:57 --> Severity: error --> Exception: Call to undefined function set_value() /sam_tool/application/views/frontend/add_property_details.php 100
INFO - 2022-08-04 18:55:43 --> Config Class Initialized
INFO - 2022-08-04 18:55:43 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:55:43 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:55:43 --> Utf8 Class Initialized
INFO - 2022-08-04 18:55:43 --> URI Class Initialized
INFO - 2022-08-04 18:55:43 --> Router Class Initialized
INFO - 2022-08-04 18:55:43 --> Output Class Initialized
INFO - 2022-08-04 18:55:43 --> Security Class Initialized
DEBUG - 2022-08-04 18:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:55:43 --> Input Class Initialized
INFO - 2022-08-04 18:55:43 --> Language Class Initialized
INFO - 2022-08-04 18:55:43 --> Loader Class Initialized
INFO - 2022-08-04 18:55:43 --> Helper loaded: url_helper
INFO - 2022-08-04 18:55:43 --> Controller Class Initialized
INFO - 2022-08-04 18:55:43 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
ERROR - 2022-08-04 18:55:43 --> Severity: error --> Exception: Call to undefined function set_value() /sam_tool/application/views/frontend/add_property_details.php 95
INFO - 2022-08-04 18:55:57 --> Config Class Initialized
INFO - 2022-08-04 18:55:57 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:55:57 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:55:57 --> Utf8 Class Initialized
INFO - 2022-08-04 18:55:57 --> URI Class Initialized
INFO - 2022-08-04 18:55:57 --> Router Class Initialized
INFO - 2022-08-04 18:55:57 --> Output Class Initialized
INFO - 2022-08-04 18:55:57 --> Security Class Initialized
DEBUG - 2022-08-04 18:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:55:57 --> Input Class Initialized
INFO - 2022-08-04 18:55:57 --> Language Class Initialized
INFO - 2022-08-04 18:55:57 --> Loader Class Initialized
INFO - 2022-08-04 18:55:57 --> Helper loaded: url_helper
INFO - 2022-08-04 18:55:57 --> Controller Class Initialized
INFO - 2022-08-04 18:55:57 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-04 18:55:57 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-04 18:55:57 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-04 18:55:57 --> Final output sent to browser
DEBUG - 2022-08-04 18:55:57 --> Total execution time: 0.2117
INFO - 2022-08-04 18:56:11 --> Config Class Initialized
INFO - 2022-08-04 18:56:11 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:56:11 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:56:11 --> Utf8 Class Initialized
INFO - 2022-08-04 18:56:11 --> URI Class Initialized
INFO - 2022-08-04 18:56:11 --> Router Class Initialized
INFO - 2022-08-04 18:56:11 --> Output Class Initialized
INFO - 2022-08-04 18:56:11 --> Security Class Initialized
DEBUG - 2022-08-04 18:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:56:11 --> Input Class Initialized
INFO - 2022-08-04 18:56:11 --> Language Class Initialized
INFO - 2022-08-04 18:56:11 --> Loader Class Initialized
INFO - 2022-08-04 18:56:11 --> Helper loaded: url_helper
INFO - 2022-08-04 18:56:11 --> Controller Class Initialized
INFO - 2022-08-04 18:56:11 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-04 18:56:11 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-04 18:56:11 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-04 18:56:11 --> Final output sent to browser
DEBUG - 2022-08-04 18:56:11 --> Total execution time: 0.1698
INFO - 2022-08-04 18:56:37 --> Config Class Initialized
INFO - 2022-08-04 18:56:37 --> Hooks Class Initialized
DEBUG - 2022-08-04 18:56:37 --> UTF-8 Support Enabled
INFO - 2022-08-04 18:56:37 --> Utf8 Class Initialized
INFO - 2022-08-04 18:56:37 --> URI Class Initialized
INFO - 2022-08-04 18:56:37 --> Router Class Initialized
INFO - 2022-08-04 18:56:37 --> Output Class Initialized
INFO - 2022-08-04 18:56:37 --> Security Class Initialized
DEBUG - 2022-08-04 18:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-04 18:56:37 --> Input Class Initialized
INFO - 2022-08-04 18:56:37 --> Language Class Initialized
INFO - 2022-08-04 18:56:37 --> Loader Class Initialized
INFO - 2022-08-04 18:56:37 --> Helper loaded: url_helper
INFO - 2022-08-04 18:56:37 --> Controller Class Initialized
INFO - 2022-08-04 18:56:37 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-04 18:56:37 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-04 18:56:37 --> File loaded: /sam_tool/application/views/frontend/add_property_details.php
INFO - 2022-08-04 18:56:37 --> Final output sent to browser
DEBUG - 2022-08-04 18:56:37 --> Total execution time: 0.1692
