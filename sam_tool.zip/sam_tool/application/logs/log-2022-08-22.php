<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-22 00:35:48 --> Config Class Initialized
INFO - 2022-08-22 00:35:48 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:35:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:35:48 --> Utf8 Class Initialized
INFO - 2022-08-22 00:35:48 --> URI Class Initialized
DEBUG - 2022-08-22 00:35:48 --> No URI present. Default controller set.
INFO - 2022-08-22 00:35:48 --> Router Class Initialized
INFO - 2022-08-22 00:35:48 --> Output Class Initialized
INFO - 2022-08-22 00:35:48 --> Security Class Initialized
DEBUG - 2022-08-22 00:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:35:48 --> Input Class Initialized
INFO - 2022-08-22 00:35:48 --> Language Class Initialized
INFO - 2022-08-22 00:35:48 --> Loader Class Initialized
INFO - 2022-08-22 00:35:49 --> Helper loaded: url_helper
INFO - 2022-08-22 00:35:49 --> Controller Class Initialized
INFO - 2022-08-22 00:35:49 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 00:35:49 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 00:35:49 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 00:35:49 --> Final output sent to browser
DEBUG - 2022-08-22 00:35:49 --> Total execution time: 0.4687
INFO - 2022-08-22 00:38:00 --> Config Class Initialized
INFO - 2022-08-22 00:38:00 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:38:00 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:38:00 --> Utf8 Class Initialized
INFO - 2022-08-22 00:38:00 --> URI Class Initialized
DEBUG - 2022-08-22 00:38:00 --> No URI present. Default controller set.
INFO - 2022-08-22 00:38:00 --> Router Class Initialized
INFO - 2022-08-22 00:38:00 --> Output Class Initialized
INFO - 2022-08-22 00:38:00 --> Security Class Initialized
DEBUG - 2022-08-22 00:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:38:00 --> Input Class Initialized
INFO - 2022-08-22 00:38:00 --> Language Class Initialized
INFO - 2022-08-22 00:38:00 --> Loader Class Initialized
INFO - 2022-08-22 00:38:00 --> Helper loaded: url_helper
INFO - 2022-08-22 00:38:00 --> Controller Class Initialized
INFO - 2022-08-22 00:38:00 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 00:38:00 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 00:38:00 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 00:38:00 --> Final output sent to browser
DEBUG - 2022-08-22 00:38:00 --> Total execution time: 0.3737
INFO - 2022-08-22 00:38:03 --> Config Class Initialized
INFO - 2022-08-22 00:38:04 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:38:04 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:38:04 --> Utf8 Class Initialized
INFO - 2022-08-22 00:38:04 --> URI Class Initialized
INFO - 2022-08-22 00:38:04 --> Router Class Initialized
INFO - 2022-08-22 00:38:04 --> Output Class Initialized
INFO - 2022-08-22 00:38:04 --> Security Class Initialized
DEBUG - 2022-08-22 00:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:38:04 --> Input Class Initialized
INFO - 2022-08-22 00:38:04 --> Language Class Initialized
INFO - 2022-08-22 00:38:04 --> Loader Class Initialized
INFO - 2022-08-22 00:38:04 --> Helper loaded: url_helper
INFO - 2022-08-22 00:38:04 --> Controller Class Initialized
DEBUG - 2022-08-22 00:38:04 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:38:04 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:38:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:38:04 --> Final output sent to browser
DEBUG - 2022-08-22 00:38:04 --> Total execution time: 0.4211
INFO - 2022-08-22 00:38:04 --> Config Class Initialized
INFO - 2022-08-22 00:38:04 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:38:04 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:38:04 --> Utf8 Class Initialized
INFO - 2022-08-22 00:38:04 --> URI Class Initialized
INFO - 2022-08-22 00:38:04 --> Router Class Initialized
INFO - 2022-08-22 00:38:04 --> Output Class Initialized
INFO - 2022-08-22 00:38:04 --> Security Class Initialized
DEBUG - 2022-08-22 00:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:38:04 --> Input Class Initialized
INFO - 2022-08-22 00:38:04 --> Language Class Initialized
ERROR - 2022-08-22 00:38:04 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-22 00:38:19 --> Config Class Initialized
INFO - 2022-08-22 00:38:19 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:38:19 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:38:19 --> Utf8 Class Initialized
INFO - 2022-08-22 00:38:19 --> URI Class Initialized
DEBUG - 2022-08-22 00:38:19 --> No URI present. Default controller set.
INFO - 2022-08-22 00:38:19 --> Router Class Initialized
INFO - 2022-08-22 00:38:19 --> Output Class Initialized
INFO - 2022-08-22 00:38:19 --> Security Class Initialized
DEBUG - 2022-08-22 00:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:38:19 --> Input Class Initialized
INFO - 2022-08-22 00:38:19 --> Language Class Initialized
INFO - 2022-08-22 00:38:19 --> Loader Class Initialized
INFO - 2022-08-22 00:38:19 --> Helper loaded: url_helper
INFO - 2022-08-22 00:38:19 --> Controller Class Initialized
INFO - 2022-08-22 00:38:19 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 00:38:19 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 00:38:19 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 00:38:19 --> Final output sent to browser
DEBUG - 2022-08-22 00:38:19 --> Total execution time: 0.3302
INFO - 2022-08-22 00:38:30 --> Config Class Initialized
INFO - 2022-08-22 00:38:30 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:38:30 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:38:30 --> Utf8 Class Initialized
INFO - 2022-08-22 00:38:30 --> URI Class Initialized
INFO - 2022-08-22 00:38:30 --> Router Class Initialized
INFO - 2022-08-22 00:38:30 --> Output Class Initialized
INFO - 2022-08-22 00:38:30 --> Security Class Initialized
DEBUG - 2022-08-22 00:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:38:30 --> Input Class Initialized
INFO - 2022-08-22 00:38:30 --> Language Class Initialized
INFO - 2022-08-22 00:38:30 --> Loader Class Initialized
INFO - 2022-08-22 00:38:30 --> Helper loaded: url_helper
INFO - 2022-08-22 00:38:30 --> Controller Class Initialized
DEBUG - 2022-08-22 00:38:30 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:38:30 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:38:31 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 00:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/controllers/Sam.php 56
ERROR - 2022-08-22 00:38:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/controllers/Sam.php 67
INFO - 2022-08-22 00:38:45 --> Config Class Initialized
INFO - 2022-08-22 00:38:45 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:38:45 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:38:45 --> Utf8 Class Initialized
INFO - 2022-08-22 00:38:45 --> URI Class Initialized
INFO - 2022-08-22 00:38:45 --> Router Class Initialized
INFO - 2022-08-22 00:38:45 --> Output Class Initialized
INFO - 2022-08-22 00:38:45 --> Security Class Initialized
DEBUG - 2022-08-22 00:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:38:45 --> Input Class Initialized
INFO - 2022-08-22 00:38:45 --> Language Class Initialized
ERROR - 2022-08-22 00:38:45 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-22 00:38:52 --> Final output sent to browser
DEBUG - 2022-08-22 00:38:52 --> Total execution time: 21.3419
INFO - 2022-08-22 00:39:30 --> Config Class Initialized
INFO - 2022-08-22 00:39:30 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:39:30 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:39:30 --> Utf8 Class Initialized
INFO - 2022-08-22 00:39:30 --> URI Class Initialized
INFO - 2022-08-22 00:39:30 --> Router Class Initialized
INFO - 2022-08-22 00:39:30 --> Output Class Initialized
INFO - 2022-08-22 00:39:30 --> Security Class Initialized
DEBUG - 2022-08-22 00:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:39:30 --> Input Class Initialized
INFO - 2022-08-22 00:39:30 --> Language Class Initialized
INFO - 2022-08-22 00:39:30 --> Loader Class Initialized
INFO - 2022-08-22 00:39:30 --> Helper loaded: url_helper
INFO - 2022-08-22 00:39:30 --> Controller Class Initialized
DEBUG - 2022-08-22 00:39:30 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:39:30 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:39:30 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 00:39:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/controllers/Sam.php 56
ERROR - 2022-08-22 00:39:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/controllers/Sam.php 67
INFO - 2022-08-22 00:39:52 --> Final output sent to browser
DEBUG - 2022-08-22 00:39:52 --> Total execution time: 21.4546
INFO - 2022-08-22 00:40:28 --> Config Class Initialized
INFO - 2022-08-22 00:40:28 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:40:28 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:40:28 --> Utf8 Class Initialized
INFO - 2022-08-22 00:40:28 --> URI Class Initialized
INFO - 2022-08-22 00:40:28 --> Router Class Initialized
INFO - 2022-08-22 00:40:28 --> Output Class Initialized
INFO - 2022-08-22 00:40:28 --> Security Class Initialized
DEBUG - 2022-08-22 00:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:40:28 --> Input Class Initialized
INFO - 2022-08-22 00:40:28 --> Language Class Initialized
INFO - 2022-08-22 00:40:28 --> Loader Class Initialized
INFO - 2022-08-22 00:40:28 --> Helper loaded: url_helper
INFO - 2022-08-22 00:40:28 --> Controller Class Initialized
DEBUG - 2022-08-22 00:40:28 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:40:28 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:40:28 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 00:40:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/controllers/Sam.php 56
ERROR - 2022-08-22 00:40:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/controllers/Sam.php 66
INFO - 2022-08-22 00:40:49 --> Final output sent to browser
DEBUG - 2022-08-22 00:40:49 --> Total execution time: 21.4368
INFO - 2022-08-22 00:41:29 --> Config Class Initialized
INFO - 2022-08-22 00:41:29 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:41:29 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:41:29 --> Utf8 Class Initialized
INFO - 2022-08-22 00:41:29 --> URI Class Initialized
INFO - 2022-08-22 00:41:29 --> Router Class Initialized
INFO - 2022-08-22 00:41:29 --> Output Class Initialized
INFO - 2022-08-22 00:41:29 --> Security Class Initialized
DEBUG - 2022-08-22 00:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:41:29 --> Input Class Initialized
INFO - 2022-08-22 00:41:29 --> Language Class Initialized
INFO - 2022-08-22 00:41:29 --> Loader Class Initialized
INFO - 2022-08-22 00:41:29 --> Helper loaded: url_helper
INFO - 2022-08-22 00:41:29 --> Controller Class Initialized
DEBUG - 2022-08-22 00:41:29 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:41:29 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:41:29 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 00:41:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/controllers/Sam.php 58
INFO - 2022-08-22 00:41:50 --> Final output sent to browser
DEBUG - 2022-08-22 00:41:50 --> Total execution time: 21.2758
INFO - 2022-08-22 00:42:03 --> Config Class Initialized
INFO - 2022-08-22 00:42:03 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:42:03 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:42:03 --> Utf8 Class Initialized
INFO - 2022-08-22 00:42:03 --> URI Class Initialized
INFO - 2022-08-22 00:42:03 --> Router Class Initialized
INFO - 2022-08-22 00:42:03 --> Output Class Initialized
INFO - 2022-08-22 00:42:03 --> Security Class Initialized
DEBUG - 2022-08-22 00:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:42:03 --> Input Class Initialized
INFO - 2022-08-22 00:42:03 --> Language Class Initialized
INFO - 2022-08-22 00:42:03 --> Loader Class Initialized
INFO - 2022-08-22 00:42:03 --> Helper loaded: url_helper
INFO - 2022-08-22 00:42:03 --> Controller Class Initialized
DEBUG - 2022-08-22 00:42:03 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:42:03 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:42:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:42:24 --> Final output sent to browser
DEBUG - 2022-08-22 00:42:24 --> Total execution time: 21.4321
INFO - 2022-08-22 00:43:50 --> Config Class Initialized
INFO - 2022-08-22 00:43:50 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:43:50 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:43:50 --> Utf8 Class Initialized
INFO - 2022-08-22 00:43:50 --> URI Class Initialized
INFO - 2022-08-22 00:43:50 --> Router Class Initialized
INFO - 2022-08-22 00:43:50 --> Output Class Initialized
INFO - 2022-08-22 00:43:50 --> Security Class Initialized
DEBUG - 2022-08-22 00:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:43:50 --> Input Class Initialized
INFO - 2022-08-22 00:43:50 --> Language Class Initialized
ERROR - 2022-08-22 00:43:50 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) or const (T_CONST) /sam_tool/application/controllers/Sam.php 67
INFO - 2022-08-22 00:46:51 --> Config Class Initialized
INFO - 2022-08-22 00:46:51 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:46:51 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:46:51 --> Utf8 Class Initialized
INFO - 2022-08-22 00:46:51 --> URI Class Initialized
INFO - 2022-08-22 00:46:51 --> Router Class Initialized
INFO - 2022-08-22 00:46:51 --> Output Class Initialized
INFO - 2022-08-22 00:46:51 --> Security Class Initialized
DEBUG - 2022-08-22 00:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:46:51 --> Input Class Initialized
INFO - 2022-08-22 00:46:51 --> Language Class Initialized
INFO - 2022-08-22 00:46:52 --> Loader Class Initialized
INFO - 2022-08-22 00:46:52 --> Helper loaded: url_helper
INFO - 2022-08-22 00:46:52 --> Controller Class Initialized
DEBUG - 2022-08-22 00:46:52 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:46:52 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:46:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:46:52 --> Final output sent to browser
DEBUG - 2022-08-22 00:46:52 --> Total execution time: 0.5235
INFO - 2022-08-22 00:47:46 --> Config Class Initialized
INFO - 2022-08-22 00:47:46 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:47:46 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:47:46 --> Utf8 Class Initialized
INFO - 2022-08-22 00:47:46 --> URI Class Initialized
INFO - 2022-08-22 00:47:46 --> Router Class Initialized
INFO - 2022-08-22 00:47:47 --> Output Class Initialized
INFO - 2022-08-22 00:47:47 --> Security Class Initialized
DEBUG - 2022-08-22 00:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:47:47 --> Input Class Initialized
INFO - 2022-08-22 00:47:47 --> Language Class Initialized
INFO - 2022-08-22 00:47:47 --> Loader Class Initialized
INFO - 2022-08-22 00:47:47 --> Helper loaded: url_helper
INFO - 2022-08-22 00:47:47 --> Controller Class Initialized
DEBUG - 2022-08-22 00:47:47 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:47:47 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:47:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:47:47 --> Final output sent to browser
DEBUG - 2022-08-22 00:47:47 --> Total execution time: 0.3799
INFO - 2022-08-22 00:47:57 --> Config Class Initialized
INFO - 2022-08-22 00:47:57 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:47:57 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:47:57 --> Utf8 Class Initialized
INFO - 2022-08-22 00:47:57 --> URI Class Initialized
INFO - 2022-08-22 00:47:57 --> Router Class Initialized
INFO - 2022-08-22 00:47:57 --> Output Class Initialized
INFO - 2022-08-22 00:47:57 --> Security Class Initialized
DEBUG - 2022-08-22 00:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:47:57 --> Input Class Initialized
INFO - 2022-08-22 00:47:57 --> Language Class Initialized
INFO - 2022-08-22 00:47:57 --> Loader Class Initialized
INFO - 2022-08-22 00:47:57 --> Helper loaded: url_helper
INFO - 2022-08-22 00:47:57 --> Controller Class Initialized
DEBUG - 2022-08-22 00:47:57 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:47:57 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:47:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:47:57 --> Final output sent to browser
DEBUG - 2022-08-22 00:47:57 --> Total execution time: 0.3231
INFO - 2022-08-22 00:48:38 --> Config Class Initialized
INFO - 2022-08-22 00:48:38 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:48:38 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:48:38 --> Utf8 Class Initialized
INFO - 2022-08-22 00:48:38 --> URI Class Initialized
INFO - 2022-08-22 00:48:38 --> Router Class Initialized
INFO - 2022-08-22 00:48:38 --> Output Class Initialized
INFO - 2022-08-22 00:48:38 --> Security Class Initialized
DEBUG - 2022-08-22 00:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:48:38 --> Input Class Initialized
INFO - 2022-08-22 00:48:38 --> Language Class Initialized
INFO - 2022-08-22 00:48:38 --> Loader Class Initialized
INFO - 2022-08-22 00:48:38 --> Helper loaded: url_helper
INFO - 2022-08-22 00:48:38 --> Controller Class Initialized
DEBUG - 2022-08-22 00:48:38 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:48:38 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:48:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:48:38 --> Final output sent to browser
DEBUG - 2022-08-22 00:48:38 --> Total execution time: 0.2438
INFO - 2022-08-22 00:48:40 --> Config Class Initialized
INFO - 2022-08-22 00:48:40 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:48:40 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:48:40 --> Utf8 Class Initialized
INFO - 2022-08-22 00:48:40 --> URI Class Initialized
INFO - 2022-08-22 00:48:40 --> Router Class Initialized
INFO - 2022-08-22 00:48:40 --> Output Class Initialized
INFO - 2022-08-22 00:48:40 --> Security Class Initialized
DEBUG - 2022-08-22 00:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:48:40 --> Input Class Initialized
INFO - 2022-08-22 00:48:40 --> Language Class Initialized
INFO - 2022-08-22 00:48:41 --> Loader Class Initialized
INFO - 2022-08-22 00:48:41 --> Helper loaded: url_helper
INFO - 2022-08-22 00:48:41 --> Controller Class Initialized
DEBUG - 2022-08-22 00:48:41 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:48:41 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:48:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:48:41 --> Final output sent to browser
DEBUG - 2022-08-22 00:48:41 --> Total execution time: 0.4933
INFO - 2022-08-22 00:48:41 --> Config Class Initialized
INFO - 2022-08-22 00:48:41 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:48:41 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:48:41 --> Utf8 Class Initialized
INFO - 2022-08-22 00:48:41 --> URI Class Initialized
INFO - 2022-08-22 00:48:41 --> Router Class Initialized
INFO - 2022-08-22 00:48:41 --> Output Class Initialized
INFO - 2022-08-22 00:48:41 --> Security Class Initialized
DEBUG - 2022-08-22 00:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:48:41 --> Input Class Initialized
INFO - 2022-08-22 00:48:41 --> Language Class Initialized
INFO - 2022-08-22 00:48:41 --> Loader Class Initialized
INFO - 2022-08-22 00:48:41 --> Helper loaded: url_helper
INFO - 2022-08-22 00:48:41 --> Controller Class Initialized
DEBUG - 2022-08-22 00:48:41 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:48:41 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:48:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:48:41 --> Final output sent to browser
DEBUG - 2022-08-22 00:48:41 --> Total execution time: 0.3676
INFO - 2022-08-22 00:48:43 --> Config Class Initialized
INFO - 2022-08-22 00:48:43 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:48:43 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:48:43 --> Utf8 Class Initialized
INFO - 2022-08-22 00:48:43 --> URI Class Initialized
INFO - 2022-08-22 00:48:43 --> Router Class Initialized
INFO - 2022-08-22 00:48:43 --> Output Class Initialized
INFO - 2022-08-22 00:48:43 --> Security Class Initialized
DEBUG - 2022-08-22 00:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:48:43 --> Input Class Initialized
INFO - 2022-08-22 00:48:43 --> Language Class Initialized
INFO - 2022-08-22 00:48:43 --> Loader Class Initialized
INFO - 2022-08-22 00:48:43 --> Helper loaded: url_helper
INFO - 2022-08-22 00:48:43 --> Controller Class Initialized
DEBUG - 2022-08-22 00:48:43 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:48:44 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:48:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:48:44 --> Final output sent to browser
DEBUG - 2022-08-22 00:48:44 --> Total execution time: 0.3361
INFO - 2022-08-22 00:48:57 --> Config Class Initialized
INFO - 2022-08-22 00:48:57 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:48:57 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:48:57 --> Utf8 Class Initialized
INFO - 2022-08-22 00:48:57 --> URI Class Initialized
INFO - 2022-08-22 00:48:57 --> Router Class Initialized
INFO - 2022-08-22 00:48:57 --> Output Class Initialized
INFO - 2022-08-22 00:48:57 --> Security Class Initialized
DEBUG - 2022-08-22 00:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:48:57 --> Input Class Initialized
INFO - 2022-08-22 00:48:57 --> Language Class Initialized
INFO - 2022-08-22 00:48:57 --> Loader Class Initialized
INFO - 2022-08-22 00:48:57 --> Helper loaded: url_helper
INFO - 2022-08-22 00:48:57 --> Controller Class Initialized
DEBUG - 2022-08-22 00:48:57 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:48:57 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:48:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:48:57 --> Final output sent to browser
DEBUG - 2022-08-22 00:48:57 --> Total execution time: 0.3494
INFO - 2022-08-22 00:49:44 --> Config Class Initialized
INFO - 2022-08-22 00:49:44 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:49:44 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:49:44 --> Utf8 Class Initialized
INFO - 2022-08-22 00:49:44 --> URI Class Initialized
INFO - 2022-08-22 00:49:44 --> Router Class Initialized
INFO - 2022-08-22 00:49:44 --> Output Class Initialized
INFO - 2022-08-22 00:49:44 --> Security Class Initialized
DEBUG - 2022-08-22 00:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:49:44 --> Input Class Initialized
INFO - 2022-08-22 00:49:44 --> Language Class Initialized
ERROR - 2022-08-22 00:49:44 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-22 00:49:55 --> Config Class Initialized
INFO - 2022-08-22 00:49:55 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:49:55 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:49:55 --> Utf8 Class Initialized
INFO - 2022-08-22 00:49:55 --> URI Class Initialized
INFO - 2022-08-22 00:49:55 --> Router Class Initialized
INFO - 2022-08-22 00:49:55 --> Output Class Initialized
INFO - 2022-08-22 00:49:55 --> Security Class Initialized
DEBUG - 2022-08-22 00:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:49:55 --> Input Class Initialized
INFO - 2022-08-22 00:49:55 --> Language Class Initialized
INFO - 2022-08-22 00:49:55 --> Loader Class Initialized
INFO - 2022-08-22 00:49:55 --> Helper loaded: url_helper
INFO - 2022-08-22 00:49:55 --> Controller Class Initialized
DEBUG - 2022-08-22 00:49:55 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:49:55 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:49:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:49:55 --> Final output sent to browser
DEBUG - 2022-08-22 00:49:55 --> Total execution time: 0.2535
INFO - 2022-08-22 00:50:29 --> Config Class Initialized
INFO - 2022-08-22 00:50:29 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:50:29 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:50:29 --> Utf8 Class Initialized
INFO - 2022-08-22 00:50:29 --> URI Class Initialized
INFO - 2022-08-22 00:50:29 --> Router Class Initialized
INFO - 2022-08-22 00:50:29 --> Output Class Initialized
INFO - 2022-08-22 00:50:29 --> Security Class Initialized
DEBUG - 2022-08-22 00:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:50:29 --> Input Class Initialized
INFO - 2022-08-22 00:50:29 --> Language Class Initialized
INFO - 2022-08-22 00:50:29 --> Loader Class Initialized
INFO - 2022-08-22 00:50:29 --> Helper loaded: url_helper
INFO - 2022-08-22 00:50:29 --> Controller Class Initialized
DEBUG - 2022-08-22 00:50:29 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:50:29 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:50:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:50:29 --> Final output sent to browser
DEBUG - 2022-08-22 00:50:29 --> Total execution time: 0.3454
INFO - 2022-08-22 00:50:30 --> Config Class Initialized
INFO - 2022-08-22 00:50:30 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:50:30 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:50:30 --> Utf8 Class Initialized
INFO - 2022-08-22 00:50:30 --> URI Class Initialized
INFO - 2022-08-22 00:50:30 --> Router Class Initialized
INFO - 2022-08-22 00:50:30 --> Output Class Initialized
INFO - 2022-08-22 00:50:30 --> Security Class Initialized
DEBUG - 2022-08-22 00:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:50:30 --> Input Class Initialized
INFO - 2022-08-22 00:50:30 --> Language Class Initialized
INFO - 2022-08-22 00:50:30 --> Loader Class Initialized
INFO - 2022-08-22 00:50:30 --> Helper loaded: url_helper
INFO - 2022-08-22 00:50:30 --> Controller Class Initialized
DEBUG - 2022-08-22 00:50:30 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:50:30 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:50:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:50:30 --> Final output sent to browser
DEBUG - 2022-08-22 00:50:30 --> Total execution time: 0.2667
INFO - 2022-08-22 00:50:49 --> Config Class Initialized
INFO - 2022-08-22 00:50:49 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:50:49 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:50:49 --> Utf8 Class Initialized
INFO - 2022-08-22 00:50:49 --> URI Class Initialized
INFO - 2022-08-22 00:50:49 --> Router Class Initialized
INFO - 2022-08-22 00:50:49 --> Output Class Initialized
INFO - 2022-08-22 00:50:49 --> Security Class Initialized
DEBUG - 2022-08-22 00:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:50:49 --> Input Class Initialized
INFO - 2022-08-22 00:50:49 --> Language Class Initialized
INFO - 2022-08-22 00:50:49 --> Loader Class Initialized
INFO - 2022-08-22 00:50:49 --> Helper loaded: url_helper
INFO - 2022-08-22 00:50:49 --> Controller Class Initialized
DEBUG - 2022-08-22 00:50:49 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:50:49 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:50:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:50:49 --> Final output sent to browser
DEBUG - 2022-08-22 00:50:49 --> Total execution time: 0.3131
INFO - 2022-08-22 00:51:04 --> Config Class Initialized
INFO - 2022-08-22 00:51:04 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:51:04 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:51:04 --> Utf8 Class Initialized
INFO - 2022-08-22 00:51:04 --> URI Class Initialized
INFO - 2022-08-22 00:51:04 --> Router Class Initialized
INFO - 2022-08-22 00:51:04 --> Output Class Initialized
INFO - 2022-08-22 00:51:04 --> Security Class Initialized
DEBUG - 2022-08-22 00:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:51:04 --> Input Class Initialized
INFO - 2022-08-22 00:51:04 --> Language Class Initialized
ERROR - 2022-08-22 00:51:04 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-22 00:52:07 --> Config Class Initialized
INFO - 2022-08-22 00:52:07 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:52:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:52:07 --> Utf8 Class Initialized
INFO - 2022-08-22 00:52:07 --> URI Class Initialized
INFO - 2022-08-22 00:52:07 --> Router Class Initialized
INFO - 2022-08-22 00:52:07 --> Output Class Initialized
INFO - 2022-08-22 00:52:07 --> Security Class Initialized
DEBUG - 2022-08-22 00:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:52:07 --> Input Class Initialized
INFO - 2022-08-22 00:52:07 --> Language Class Initialized
INFO - 2022-08-22 00:52:07 --> Loader Class Initialized
INFO - 2022-08-22 00:52:07 --> Helper loaded: url_helper
INFO - 2022-08-22 00:52:07 --> Controller Class Initialized
DEBUG - 2022-08-22 00:52:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:52:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:52:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:52:07 --> Config Class Initialized
INFO - 2022-08-22 00:52:07 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:52:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:52:07 --> Utf8 Class Initialized
INFO - 2022-08-22 00:52:07 --> URI Class Initialized
INFO - 2022-08-22 00:52:07 --> Router Class Initialized
INFO - 2022-08-22 00:52:07 --> Output Class Initialized
INFO - 2022-08-22 00:52:07 --> Security Class Initialized
DEBUG - 2022-08-22 00:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:52:07 --> Input Class Initialized
INFO - 2022-08-22 00:52:07 --> Language Class Initialized
INFO - 2022-08-22 00:52:07 --> Loader Class Initialized
INFO - 2022-08-22 00:52:08 --> Helper loaded: url_helper
INFO - 2022-08-22 00:52:08 --> Controller Class Initialized
DEBUG - 2022-08-22 00:52:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:52:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:52:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:52:08 --> Config Class Initialized
INFO - 2022-08-22 00:52:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:52:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:52:08 --> Utf8 Class Initialized
INFO - 2022-08-22 00:52:08 --> URI Class Initialized
INFO - 2022-08-22 00:52:08 --> Router Class Initialized
INFO - 2022-08-22 00:52:08 --> Output Class Initialized
INFO - 2022-08-22 00:52:08 --> Security Class Initialized
DEBUG - 2022-08-22 00:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:52:08 --> Input Class Initialized
INFO - 2022-08-22 00:52:08 --> Language Class Initialized
INFO - 2022-08-22 00:52:08 --> Loader Class Initialized
INFO - 2022-08-22 00:52:08 --> Helper loaded: url_helper
INFO - 2022-08-22 00:52:08 --> Controller Class Initialized
DEBUG - 2022-08-22 00:52:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:52:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:52:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:52:08 --> Config Class Initialized
INFO - 2022-08-22 00:52:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:52:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:52:08 --> Utf8 Class Initialized
INFO - 2022-08-22 00:52:08 --> URI Class Initialized
INFO - 2022-08-22 00:52:08 --> Router Class Initialized
INFO - 2022-08-22 00:52:08 --> Output Class Initialized
INFO - 2022-08-22 00:52:08 --> Security Class Initialized
DEBUG - 2022-08-22 00:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:52:08 --> Input Class Initialized
INFO - 2022-08-22 00:52:08 --> Language Class Initialized
INFO - 2022-08-22 00:52:08 --> Loader Class Initialized
INFO - 2022-08-22 00:52:08 --> Helper loaded: url_helper
INFO - 2022-08-22 00:52:08 --> Controller Class Initialized
DEBUG - 2022-08-22 00:52:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:52:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:52:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:52:09 --> Config Class Initialized
INFO - 2022-08-22 00:52:09 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:52:09 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:52:09 --> Utf8 Class Initialized
INFO - 2022-08-22 00:52:09 --> URI Class Initialized
INFO - 2022-08-22 00:52:09 --> Router Class Initialized
INFO - 2022-08-22 00:52:09 --> Output Class Initialized
INFO - 2022-08-22 00:52:09 --> Security Class Initialized
DEBUG - 2022-08-22 00:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:52:09 --> Input Class Initialized
INFO - 2022-08-22 00:52:09 --> Language Class Initialized
INFO - 2022-08-22 00:52:09 --> Loader Class Initialized
INFO - 2022-08-22 00:52:09 --> Helper loaded: url_helper
INFO - 2022-08-22 00:52:09 --> Controller Class Initialized
DEBUG - 2022-08-22 00:52:09 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:52:09 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:52:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:53:07 --> Final output sent to browser
DEBUG - 2022-08-22 00:53:07 --> Total execution time: 60.2175
INFO - 2022-08-22 00:53:07 --> Config Class Initialized
INFO - 2022-08-22 00:53:07 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:53:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:53:07 --> Utf8 Class Initialized
INFO - 2022-08-22 00:53:07 --> URI Class Initialized
INFO - 2022-08-22 00:53:07 --> Router Class Initialized
INFO - 2022-08-22 00:53:07 --> Output Class Initialized
INFO - 2022-08-22 00:53:07 --> Security Class Initialized
DEBUG - 2022-08-22 00:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:53:07 --> Input Class Initialized
INFO - 2022-08-22 00:53:07 --> Language Class Initialized
INFO - 2022-08-22 00:53:07 --> Loader Class Initialized
INFO - 2022-08-22 00:53:08 --> Helper loaded: url_helper
INFO - 2022-08-22 00:53:08 --> Controller Class Initialized
DEBUG - 2022-08-22 00:53:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:53:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:53:08 --> Final output sent to browser
DEBUG - 2022-08-22 00:53:08 --> Total execution time: 60.3962
INFO - 2022-08-22 00:53:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:53:08 --> Final output sent to browser
DEBUG - 2022-08-22 00:53:08 --> Total execution time: 0.4097
INFO - 2022-08-22 00:53:08 --> Final output sent to browser
DEBUG - 2022-08-22 00:53:08 --> Total execution time: 58.7217
INFO - 2022-08-22 00:53:08 --> Final output sent to browser
INFO - 2022-08-22 00:53:08 --> Config Class Initialized
DEBUG - 2022-08-22 00:53:08 --> Total execution time: 59.7733
INFO - 2022-08-22 00:53:08 --> Hooks Class Initialized
INFO - 2022-08-22 00:53:08 --> Final output sent to browser
DEBUG - 2022-08-22 00:53:08 --> Total execution time: 60.0920
DEBUG - 2022-08-22 00:53:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:53:08 --> Config Class Initialized
INFO - 2022-08-22 00:53:08 --> Utf8 Class Initialized
INFO - 2022-08-22 00:53:08 --> Hooks Class Initialized
INFO - 2022-08-22 00:53:08 --> URI Class Initialized
DEBUG - 2022-08-22 00:53:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:53:08 --> Router Class Initialized
INFO - 2022-08-22 00:53:08 --> Utf8 Class Initialized
INFO - 2022-08-22 00:53:08 --> URI Class Initialized
INFO - 2022-08-22 00:53:08 --> Output Class Initialized
INFO - 2022-08-22 00:53:08 --> Router Class Initialized
INFO - 2022-08-22 00:53:08 --> Security Class Initialized
DEBUG - 2022-08-22 00:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:53:08 --> Output Class Initialized
INFO - 2022-08-22 00:53:08 --> Input Class Initialized
INFO - 2022-08-22 00:53:08 --> Security Class Initialized
INFO - 2022-08-22 00:53:08 --> Language Class Initialized
DEBUG - 2022-08-22 00:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:53:08 --> Input Class Initialized
INFO - 2022-08-22 00:53:08 --> Language Class Initialized
INFO - 2022-08-22 00:53:08 --> Loader Class Initialized
INFO - 2022-08-22 00:53:08 --> Helper loaded: url_helper
INFO - 2022-08-22 00:53:08 --> Controller Class Initialized
INFO - 2022-08-22 00:53:08 --> Loader Class Initialized
DEBUG - 2022-08-22 00:53:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:53:08 --> Helper loaded: url_helper
INFO - 2022-08-22 00:53:08 --> Controller Class Initialized
DEBUG - 2022-08-22 00:53:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:53:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:53:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:53:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:53:08 --> Final output sent to browser
INFO - 2022-08-22 00:53:08 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2022-08-22 00:53:08 --> Total execution time: 0.3523
INFO - 2022-08-22 00:53:08 --> Final output sent to browser
DEBUG - 2022-08-22 00:53:08 --> Total execution time: 0.2890
INFO - 2022-08-22 00:54:13 --> Config Class Initialized
INFO - 2022-08-22 00:54:13 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:54:13 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:54:13 --> Utf8 Class Initialized
INFO - 2022-08-22 00:54:13 --> URI Class Initialized
INFO - 2022-08-22 00:54:13 --> Router Class Initialized
INFO - 2022-08-22 00:54:13 --> Output Class Initialized
INFO - 2022-08-22 00:54:13 --> Security Class Initialized
DEBUG - 2022-08-22 00:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:54:13 --> Input Class Initialized
INFO - 2022-08-22 00:54:13 --> Language Class Initialized
INFO - 2022-08-22 00:54:13 --> Loader Class Initialized
INFO - 2022-08-22 00:54:13 --> Helper loaded: url_helper
INFO - 2022-08-22 00:54:13 --> Controller Class Initialized
DEBUG - 2022-08-22 00:54:13 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:54:13 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:54:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:54:13 --> Final output sent to browser
DEBUG - 2022-08-22 00:54:13 --> Total execution time: 0.5358
INFO - 2022-08-22 00:54:15 --> Config Class Initialized
INFO - 2022-08-22 00:54:15 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:54:15 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:54:15 --> Utf8 Class Initialized
INFO - 2022-08-22 00:54:15 --> URI Class Initialized
INFO - 2022-08-22 00:54:15 --> Router Class Initialized
INFO - 2022-08-22 00:54:15 --> Output Class Initialized
INFO - 2022-08-22 00:54:15 --> Security Class Initialized
DEBUG - 2022-08-22 00:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:54:16 --> Input Class Initialized
INFO - 2022-08-22 00:54:16 --> Language Class Initialized
ERROR - 2022-08-22 00:54:16 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-22 00:54:23 --> Config Class Initialized
INFO - 2022-08-22 00:54:23 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:54:24 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:54:24 --> Utf8 Class Initialized
INFO - 2022-08-22 00:54:24 --> URI Class Initialized
DEBUG - 2022-08-22 00:54:24 --> No URI present. Default controller set.
INFO - 2022-08-22 00:54:24 --> Router Class Initialized
INFO - 2022-08-22 00:54:24 --> Output Class Initialized
INFO - 2022-08-22 00:54:24 --> Security Class Initialized
DEBUG - 2022-08-22 00:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:54:24 --> Input Class Initialized
INFO - 2022-08-22 00:54:24 --> Language Class Initialized
INFO - 2022-08-22 00:54:24 --> Loader Class Initialized
INFO - 2022-08-22 00:54:24 --> Helper loaded: url_helper
INFO - 2022-08-22 00:54:24 --> Controller Class Initialized
INFO - 2022-08-22 00:54:24 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 00:54:24 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 00:54:24 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 00:54:24 --> Final output sent to browser
DEBUG - 2022-08-22 00:54:24 --> Total execution time: 0.4533
INFO - 2022-08-22 00:54:24 --> Config Class Initialized
INFO - 2022-08-22 00:54:24 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:54:24 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:54:24 --> Utf8 Class Initialized
INFO - 2022-08-22 00:54:24 --> URI Class Initialized
INFO - 2022-08-22 00:54:24 --> Router Class Initialized
INFO - 2022-08-22 00:54:24 --> Output Class Initialized
INFO - 2022-08-22 00:54:24 --> Security Class Initialized
DEBUG - 2022-08-22 00:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:54:24 --> Input Class Initialized
INFO - 2022-08-22 00:54:24 --> Language Class Initialized
ERROR - 2022-08-22 00:54:25 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-22 00:54:30 --> Config Class Initialized
INFO - 2022-08-22 00:54:30 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:54:30 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:54:30 --> Utf8 Class Initialized
INFO - 2022-08-22 00:54:30 --> URI Class Initialized
INFO - 2022-08-22 00:54:30 --> Router Class Initialized
INFO - 2022-08-22 00:54:30 --> Output Class Initialized
INFO - 2022-08-22 00:54:30 --> Security Class Initialized
DEBUG - 2022-08-22 00:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:54:30 --> Input Class Initialized
INFO - 2022-08-22 00:54:30 --> Language Class Initialized
INFO - 2022-08-22 00:54:30 --> Loader Class Initialized
INFO - 2022-08-22 00:54:30 --> Helper loaded: url_helper
INFO - 2022-08-22 00:54:30 --> Controller Class Initialized
DEBUG - 2022-08-22 00:54:30 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:54:30 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:54:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:54:30 --> Final output sent to browser
DEBUG - 2022-08-22 00:54:30 --> Total execution time: 0.3539
INFO - 2022-08-22 00:57:51 --> Config Class Initialized
INFO - 2022-08-22 00:57:51 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:57:51 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:57:51 --> Utf8 Class Initialized
INFO - 2022-08-22 00:57:51 --> URI Class Initialized
INFO - 2022-08-22 00:57:51 --> Router Class Initialized
INFO - 2022-08-22 00:57:51 --> Output Class Initialized
INFO - 2022-08-22 00:57:51 --> Security Class Initialized
DEBUG - 2022-08-22 00:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:57:51 --> Input Class Initialized
INFO - 2022-08-22 00:57:51 --> Language Class Initialized
INFO - 2022-08-22 00:57:52 --> Loader Class Initialized
INFO - 2022-08-22 00:57:52 --> Helper loaded: url_helper
INFO - 2022-08-22 00:57:52 --> Controller Class Initialized
DEBUG - 2022-08-22 00:57:52 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:57:52 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:57:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:57:52 --> Final output sent to browser
DEBUG - 2022-08-22 00:57:52 --> Total execution time: 0.3240
INFO - 2022-08-22 00:57:54 --> Config Class Initialized
INFO - 2022-08-22 00:57:54 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:57:55 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:57:55 --> Utf8 Class Initialized
INFO - 2022-08-22 00:57:55 --> URI Class Initialized
INFO - 2022-08-22 00:57:55 --> Router Class Initialized
INFO - 2022-08-22 00:57:55 --> Output Class Initialized
INFO - 2022-08-22 00:57:55 --> Security Class Initialized
DEBUG - 2022-08-22 00:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:57:55 --> Input Class Initialized
INFO - 2022-08-22 00:57:55 --> Language Class Initialized
ERROR - 2022-08-22 00:57:55 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-22 00:58:04 --> Config Class Initialized
INFO - 2022-08-22 00:58:04 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:58:04 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:58:04 --> Utf8 Class Initialized
INFO - 2022-08-22 00:58:04 --> URI Class Initialized
INFO - 2022-08-22 00:58:04 --> Router Class Initialized
INFO - 2022-08-22 00:58:04 --> Output Class Initialized
INFO - 2022-08-22 00:58:04 --> Security Class Initialized
DEBUG - 2022-08-22 00:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:58:04 --> Input Class Initialized
INFO - 2022-08-22 00:58:04 --> Language Class Initialized
INFO - 2022-08-22 00:58:04 --> Loader Class Initialized
INFO - 2022-08-22 00:58:04 --> Helper loaded: url_helper
INFO - 2022-08-22 00:58:04 --> Controller Class Initialized
DEBUG - 2022-08-22 00:58:04 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 00:58:04 --> Helper loaded: inflector_helper
INFO - 2022-08-22 00:58:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 00:58:04 --> Final output sent to browser
DEBUG - 2022-08-22 00:58:04 --> Total execution time: 0.5232
INFO - 2022-08-22 00:59:55 --> Config Class Initialized
INFO - 2022-08-22 00:59:55 --> Hooks Class Initialized
DEBUG - 2022-08-22 00:59:55 --> UTF-8 Support Enabled
INFO - 2022-08-22 00:59:55 --> Utf8 Class Initialized
INFO - 2022-08-22 00:59:55 --> URI Class Initialized
INFO - 2022-08-22 00:59:55 --> Router Class Initialized
INFO - 2022-08-22 00:59:55 --> Output Class Initialized
INFO - 2022-08-22 00:59:55 --> Security Class Initialized
DEBUG - 2022-08-22 00:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 00:59:55 --> Input Class Initialized
INFO - 2022-08-22 00:59:55 --> Language Class Initialized
ERROR - 2022-08-22 00:59:55 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-22 01:01:38 --> Config Class Initialized
INFO - 2022-08-22 01:01:38 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:01:38 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:01:38 --> Utf8 Class Initialized
INFO - 2022-08-22 01:01:38 --> URI Class Initialized
INFO - 2022-08-22 01:01:38 --> Router Class Initialized
INFO - 2022-08-22 01:01:38 --> Output Class Initialized
INFO - 2022-08-22 01:01:38 --> Security Class Initialized
DEBUG - 2022-08-22 01:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:01:38 --> Input Class Initialized
INFO - 2022-08-22 01:01:39 --> Language Class Initialized
INFO - 2022-08-22 01:01:39 --> Loader Class Initialized
INFO - 2022-08-22 01:01:39 --> Helper loaded: url_helper
INFO - 2022-08-22 01:01:39 --> Controller Class Initialized
DEBUG - 2022-08-22 01:01:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:01:39 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:01:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:01:39 --> Final output sent to browser
DEBUG - 2022-08-22 01:01:39 --> Total execution time: 0.3519
INFO - 2022-08-22 01:01:47 --> Config Class Initialized
INFO - 2022-08-22 01:01:47 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:01:47 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:01:47 --> Utf8 Class Initialized
INFO - 2022-08-22 01:01:47 --> URI Class Initialized
INFO - 2022-08-22 01:01:47 --> Router Class Initialized
INFO - 2022-08-22 01:01:47 --> Output Class Initialized
INFO - 2022-08-22 01:01:47 --> Security Class Initialized
DEBUG - 2022-08-22 01:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:01:47 --> Input Class Initialized
INFO - 2022-08-22 01:01:47 --> Language Class Initialized
INFO - 2022-08-22 01:01:47 --> Loader Class Initialized
INFO - 2022-08-22 01:01:47 --> Helper loaded: url_helper
INFO - 2022-08-22 01:01:47 --> Controller Class Initialized
DEBUG - 2022-08-22 01:01:47 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:01:47 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:01:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:01:47 --> Final output sent to browser
DEBUG - 2022-08-22 01:01:47 --> Total execution time: 0.2880
INFO - 2022-08-22 01:02:46 --> Config Class Initialized
INFO - 2022-08-22 01:02:46 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:02:46 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:02:46 --> Utf8 Class Initialized
INFO - 2022-08-22 01:02:46 --> URI Class Initialized
INFO - 2022-08-22 01:02:46 --> Router Class Initialized
INFO - 2022-08-22 01:02:46 --> Output Class Initialized
INFO - 2022-08-22 01:02:46 --> Security Class Initialized
DEBUG - 2022-08-22 01:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:02:46 --> Input Class Initialized
INFO - 2022-08-22 01:02:46 --> Language Class Initialized
INFO - 2022-08-22 01:02:46 --> Loader Class Initialized
INFO - 2022-08-22 01:02:46 --> Helper loaded: url_helper
INFO - 2022-08-22 01:02:46 --> Controller Class Initialized
DEBUG - 2022-08-22 01:02:46 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:02:46 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:02:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:02:46 --> Final output sent to browser
DEBUG - 2022-08-22 01:02:46 --> Total execution time: 0.2855
INFO - 2022-08-22 01:02:56 --> Config Class Initialized
INFO - 2022-08-22 01:02:56 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:02:56 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:02:56 --> Utf8 Class Initialized
INFO - 2022-08-22 01:02:56 --> URI Class Initialized
INFO - 2022-08-22 01:02:56 --> Router Class Initialized
INFO - 2022-08-22 01:02:56 --> Output Class Initialized
INFO - 2022-08-22 01:02:56 --> Security Class Initialized
DEBUG - 2022-08-22 01:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:02:56 --> Input Class Initialized
INFO - 2022-08-22 01:02:56 --> Language Class Initialized
INFO - 2022-08-22 01:02:56 --> Loader Class Initialized
INFO - 2022-08-22 01:02:56 --> Helper loaded: url_helper
INFO - 2022-08-22 01:02:56 --> Controller Class Initialized
DEBUG - 2022-08-22 01:02:56 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:02:56 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:02:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:02:56 --> Final output sent to browser
DEBUG - 2022-08-22 01:02:56 --> Total execution time: 0.2283
INFO - 2022-08-22 01:03:02 --> Config Class Initialized
INFO - 2022-08-22 01:03:02 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:03:02 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:03:02 --> Utf8 Class Initialized
INFO - 2022-08-22 01:03:02 --> URI Class Initialized
INFO - 2022-08-22 01:03:02 --> Router Class Initialized
INFO - 2022-08-22 01:03:02 --> Output Class Initialized
INFO - 2022-08-22 01:03:02 --> Security Class Initialized
DEBUG - 2022-08-22 01:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:03:02 --> Input Class Initialized
INFO - 2022-08-22 01:03:02 --> Language Class Initialized
INFO - 2022-08-22 01:03:02 --> Loader Class Initialized
INFO - 2022-08-22 01:03:02 --> Helper loaded: url_helper
INFO - 2022-08-22 01:03:02 --> Controller Class Initialized
DEBUG - 2022-08-22 01:03:02 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:03:02 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:03:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:03:02 --> Final output sent to browser
DEBUG - 2022-08-22 01:03:02 --> Total execution time: 0.2728
INFO - 2022-08-22 01:03:08 --> Config Class Initialized
INFO - 2022-08-22 01:03:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:03:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:03:08 --> Utf8 Class Initialized
INFO - 2022-08-22 01:03:08 --> URI Class Initialized
INFO - 2022-08-22 01:03:08 --> Router Class Initialized
INFO - 2022-08-22 01:03:08 --> Output Class Initialized
INFO - 2022-08-22 01:03:08 --> Security Class Initialized
DEBUG - 2022-08-22 01:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:03:08 --> Input Class Initialized
INFO - 2022-08-22 01:03:08 --> Language Class Initialized
INFO - 2022-08-22 01:03:08 --> Loader Class Initialized
INFO - 2022-08-22 01:03:08 --> Helper loaded: url_helper
INFO - 2022-08-22 01:03:08 --> Controller Class Initialized
DEBUG - 2022-08-22 01:03:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:03:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:03:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:03:08 --> Final output sent to browser
DEBUG - 2022-08-22 01:03:08 --> Total execution time: 0.2205
INFO - 2022-08-22 01:06:07 --> Config Class Initialized
INFO - 2022-08-22 01:06:07 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:06:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:06:07 --> Utf8 Class Initialized
INFO - 2022-08-22 01:06:07 --> URI Class Initialized
INFO - 2022-08-22 01:06:07 --> Router Class Initialized
INFO - 2022-08-22 01:06:07 --> Output Class Initialized
INFO - 2022-08-22 01:06:07 --> Security Class Initialized
DEBUG - 2022-08-22 01:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:06:07 --> Input Class Initialized
INFO - 2022-08-22 01:06:07 --> Language Class Initialized
ERROR - 2022-08-22 01:06:07 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' /sam_tool/application/controllers/Sam.php 59
INFO - 2022-08-22 01:06:35 --> Config Class Initialized
INFO - 2022-08-22 01:06:35 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:06:35 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:06:35 --> Utf8 Class Initialized
INFO - 2022-08-22 01:06:35 --> URI Class Initialized
INFO - 2022-08-22 01:06:35 --> Router Class Initialized
INFO - 2022-08-22 01:06:35 --> Output Class Initialized
INFO - 2022-08-22 01:06:35 --> Security Class Initialized
DEBUG - 2022-08-22 01:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:06:35 --> Input Class Initialized
INFO - 2022-08-22 01:06:35 --> Language Class Initialized
ERROR - 2022-08-22 01:06:35 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' /sam_tool/application/controllers/Sam.php 59
INFO - 2022-08-22 01:07:24 --> Config Class Initialized
INFO - 2022-08-22 01:07:24 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:07:24 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:07:24 --> Utf8 Class Initialized
INFO - 2022-08-22 01:07:24 --> URI Class Initialized
INFO - 2022-08-22 01:07:24 --> Router Class Initialized
INFO - 2022-08-22 01:07:25 --> Output Class Initialized
INFO - 2022-08-22 01:07:25 --> Security Class Initialized
DEBUG - 2022-08-22 01:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:07:25 --> Input Class Initialized
INFO - 2022-08-22 01:07:25 --> Language Class Initialized
ERROR - 2022-08-22 01:07:25 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' /sam_tool/application/controllers/Sam.php 61
INFO - 2022-08-22 01:07:39 --> Config Class Initialized
INFO - 2022-08-22 01:07:39 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:07:39 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:07:39 --> Utf8 Class Initialized
INFO - 2022-08-22 01:07:40 --> URI Class Initialized
INFO - 2022-08-22 01:07:40 --> Router Class Initialized
INFO - 2022-08-22 01:07:40 --> Output Class Initialized
INFO - 2022-08-22 01:07:40 --> Security Class Initialized
DEBUG - 2022-08-22 01:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:07:40 --> Input Class Initialized
INFO - 2022-08-22 01:07:40 --> Language Class Initialized
INFO - 2022-08-22 01:07:40 --> Loader Class Initialized
INFO - 2022-08-22 01:07:40 --> Helper loaded: url_helper
INFO - 2022-08-22 01:07:40 --> Controller Class Initialized
DEBUG - 2022-08-22 01:07:40 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:07:40 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:07:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:07:40 --> Final output sent to browser
DEBUG - 2022-08-22 01:07:40 --> Total execution time: 0.3427
INFO - 2022-08-22 01:07:45 --> Config Class Initialized
INFO - 2022-08-22 01:07:45 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:07:45 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:07:45 --> Utf8 Class Initialized
INFO - 2022-08-22 01:07:45 --> URI Class Initialized
INFO - 2022-08-22 01:07:45 --> Router Class Initialized
INFO - 2022-08-22 01:07:45 --> Output Class Initialized
INFO - 2022-08-22 01:07:45 --> Security Class Initialized
DEBUG - 2022-08-22 01:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:07:45 --> Input Class Initialized
INFO - 2022-08-22 01:07:45 --> Language Class Initialized
INFO - 2022-08-22 01:07:45 --> Loader Class Initialized
INFO - 2022-08-22 01:07:45 --> Helper loaded: url_helper
INFO - 2022-08-22 01:07:45 --> Controller Class Initialized
DEBUG - 2022-08-22 01:07:45 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:07:45 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:07:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:07:45 --> Final output sent to browser
DEBUG - 2022-08-22 01:07:45 --> Total execution time: 0.2674
INFO - 2022-08-22 01:10:00 --> Config Class Initialized
INFO - 2022-08-22 01:10:00 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:10:00 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:10:00 --> Utf8 Class Initialized
INFO - 2022-08-22 01:10:00 --> URI Class Initialized
INFO - 2022-08-22 01:10:00 --> Router Class Initialized
INFO - 2022-08-22 01:10:00 --> Output Class Initialized
INFO - 2022-08-22 01:10:00 --> Security Class Initialized
DEBUG - 2022-08-22 01:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:10:00 --> Input Class Initialized
INFO - 2022-08-22 01:10:00 --> Language Class Initialized
INFO - 2022-08-22 01:10:00 --> Loader Class Initialized
INFO - 2022-08-22 01:10:00 --> Helper loaded: url_helper
INFO - 2022-08-22 01:10:00 --> Controller Class Initialized
DEBUG - 2022-08-22 01:10:00 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:10:00 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:10:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:10:34 --> Config Class Initialized
INFO - 2022-08-22 01:10:34 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:10:34 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:10:34 --> Utf8 Class Initialized
INFO - 2022-08-22 01:10:34 --> URI Class Initialized
DEBUG - 2022-08-22 01:10:34 --> No URI present. Default controller set.
INFO - 2022-08-22 01:10:34 --> Router Class Initialized
INFO - 2022-08-22 01:10:34 --> Output Class Initialized
INFO - 2022-08-22 01:10:34 --> Security Class Initialized
DEBUG - 2022-08-22 01:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:10:34 --> Input Class Initialized
INFO - 2022-08-22 01:10:34 --> Language Class Initialized
INFO - 2022-08-22 01:10:34 --> Loader Class Initialized
INFO - 2022-08-22 01:10:34 --> Helper loaded: url_helper
INFO - 2022-08-22 01:10:34 --> Controller Class Initialized
INFO - 2022-08-22 01:10:34 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 01:10:34 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 01:10:34 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 01:10:34 --> Final output sent to browser
DEBUG - 2022-08-22 01:10:34 --> Total execution time: 0.3137
INFO - 2022-08-22 01:10:40 --> Config Class Initialized
INFO - 2022-08-22 01:10:40 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:10:40 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:10:40 --> Utf8 Class Initialized
INFO - 2022-08-22 01:10:40 --> URI Class Initialized
INFO - 2022-08-22 01:10:40 --> Router Class Initialized
INFO - 2022-08-22 01:10:40 --> Output Class Initialized
INFO - 2022-08-22 01:10:40 --> Security Class Initialized
DEBUG - 2022-08-22 01:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:10:40 --> Input Class Initialized
INFO - 2022-08-22 01:10:40 --> Language Class Initialized
INFO - 2022-08-22 01:10:40 --> Loader Class Initialized
INFO - 2022-08-22 01:10:40 --> Helper loaded: url_helper
INFO - 2022-08-22 01:10:40 --> Controller Class Initialized
DEBUG - 2022-08-22 01:10:40 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:10:40 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:10:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:10:40 --> Final output sent to browser
DEBUG - 2022-08-22 01:10:40 --> Total execution time: 0.2757
INFO - 2022-08-22 01:14:37 --> Config Class Initialized
INFO - 2022-08-22 01:14:37 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:14:37 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:14:37 --> Utf8 Class Initialized
INFO - 2022-08-22 01:14:37 --> URI Class Initialized
INFO - 2022-08-22 01:14:37 --> Router Class Initialized
INFO - 2022-08-22 01:14:37 --> Output Class Initialized
INFO - 2022-08-22 01:14:37 --> Security Class Initialized
DEBUG - 2022-08-22 01:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:14:37 --> Input Class Initialized
INFO - 2022-08-22 01:14:37 --> Language Class Initialized
ERROR - 2022-08-22 01:14:37 --> Severity: error --> Exception: syntax error, unexpected ')' /sam_tool/application/controllers/Sam.php 80
INFO - 2022-08-22 01:14:50 --> Config Class Initialized
INFO - 2022-08-22 01:14:50 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:14:50 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:14:50 --> Utf8 Class Initialized
INFO - 2022-08-22 01:14:50 --> URI Class Initialized
INFO - 2022-08-22 01:14:50 --> Router Class Initialized
INFO - 2022-08-22 01:14:50 --> Output Class Initialized
INFO - 2022-08-22 01:14:50 --> Security Class Initialized
DEBUG - 2022-08-22 01:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:14:50 --> Input Class Initialized
INFO - 2022-08-22 01:14:50 --> Language Class Initialized
INFO - 2022-08-22 01:14:50 --> Loader Class Initialized
INFO - 2022-08-22 01:14:50 --> Helper loaded: url_helper
INFO - 2022-08-22 01:14:50 --> Controller Class Initialized
DEBUG - 2022-08-22 01:14:50 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:14:50 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:14:50 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:14:50 --> Severity: error --> Exception: Call to undefined method stdClass::initialize() /sam_tool/application/controllers/Sam.php 51
INFO - 2022-08-22 01:15:40 --> Config Class Initialized
INFO - 2022-08-22 01:15:40 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:15:40 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:15:40 --> Utf8 Class Initialized
INFO - 2022-08-22 01:15:40 --> URI Class Initialized
INFO - 2022-08-22 01:15:40 --> Router Class Initialized
INFO - 2022-08-22 01:15:40 --> Output Class Initialized
INFO - 2022-08-22 01:15:40 --> Security Class Initialized
DEBUG - 2022-08-22 01:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:15:40 --> Input Class Initialized
INFO - 2022-08-22 01:15:40 --> Language Class Initialized
INFO - 2022-08-22 01:15:40 --> Loader Class Initialized
INFO - 2022-08-22 01:15:40 --> Helper loaded: url_helper
INFO - 2022-08-22 01:15:40 --> Controller Class Initialized
DEBUG - 2022-08-22 01:15:40 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:15:40 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:15:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:15:40 --> Final output sent to browser
DEBUG - 2022-08-22 01:15:40 --> Total execution time: 0.3082
INFO - 2022-08-22 01:19:33 --> Config Class Initialized
INFO - 2022-08-22 01:19:33 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:19:33 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:19:33 --> Utf8 Class Initialized
INFO - 2022-08-22 01:19:33 --> URI Class Initialized
INFO - 2022-08-22 01:19:33 --> Router Class Initialized
INFO - 2022-08-22 01:19:33 --> Output Class Initialized
INFO - 2022-08-22 01:19:33 --> Security Class Initialized
DEBUG - 2022-08-22 01:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:19:33 --> Input Class Initialized
INFO - 2022-08-22 01:19:33 --> Language Class Initialized
INFO - 2022-08-22 01:19:33 --> Loader Class Initialized
INFO - 2022-08-22 01:19:33 --> Helper loaded: url_helper
INFO - 2022-08-22 01:19:33 --> Controller Class Initialized
DEBUG - 2022-08-22 01:19:33 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:19:33 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:19:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:19:33 --> Final output sent to browser
DEBUG - 2022-08-22 01:19:33 --> Total execution time: 0.3131
INFO - 2022-08-22 01:19:45 --> Config Class Initialized
INFO - 2022-08-22 01:19:45 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:19:45 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:19:45 --> Utf8 Class Initialized
INFO - 2022-08-22 01:19:45 --> URI Class Initialized
INFO - 2022-08-22 01:19:45 --> Router Class Initialized
INFO - 2022-08-22 01:19:45 --> Output Class Initialized
INFO - 2022-08-22 01:19:45 --> Security Class Initialized
DEBUG - 2022-08-22 01:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:19:45 --> Input Class Initialized
INFO - 2022-08-22 01:19:45 --> Language Class Initialized
INFO - 2022-08-22 01:19:45 --> Loader Class Initialized
INFO - 2022-08-22 01:19:45 --> Helper loaded: url_helper
INFO - 2022-08-22 01:19:45 --> Controller Class Initialized
DEBUG - 2022-08-22 01:19:45 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:19:45 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:19:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:19:45 --> Final output sent to browser
DEBUG - 2022-08-22 01:19:45 --> Total execution time: 0.3078
INFO - 2022-08-22 01:19:55 --> Config Class Initialized
INFO - 2022-08-22 01:19:55 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:19:55 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:19:55 --> Utf8 Class Initialized
INFO - 2022-08-22 01:19:55 --> URI Class Initialized
INFO - 2022-08-22 01:19:55 --> Router Class Initialized
INFO - 2022-08-22 01:19:55 --> Output Class Initialized
INFO - 2022-08-22 01:19:55 --> Security Class Initialized
DEBUG - 2022-08-22 01:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:19:55 --> Input Class Initialized
INFO - 2022-08-22 01:19:55 --> Language Class Initialized
INFO - 2022-08-22 01:19:55 --> Loader Class Initialized
INFO - 2022-08-22 01:19:55 --> Helper loaded: url_helper
INFO - 2022-08-22 01:19:55 --> Controller Class Initialized
DEBUG - 2022-08-22 01:19:55 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:19:55 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:19:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:19:55 --> Final output sent to browser
DEBUG - 2022-08-22 01:19:55 --> Total execution time: 0.2949
INFO - 2022-08-22 01:20:54 --> Config Class Initialized
INFO - 2022-08-22 01:20:54 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:20:54 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:20:54 --> Utf8 Class Initialized
INFO - 2022-08-22 01:20:54 --> URI Class Initialized
INFO - 2022-08-22 01:20:54 --> Router Class Initialized
INFO - 2022-08-22 01:20:54 --> Output Class Initialized
INFO - 2022-08-22 01:20:54 --> Security Class Initialized
DEBUG - 2022-08-22 01:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:20:54 --> Input Class Initialized
INFO - 2022-08-22 01:20:54 --> Language Class Initialized
ERROR - 2022-08-22 01:20:54 --> Severity: error --> Exception: syntax error, unexpected ';' /sam_tool/application/controllers/Sam.php 72
INFO - 2022-08-22 01:21:08 --> Config Class Initialized
INFO - 2022-08-22 01:21:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:21:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:21:08 --> Utf8 Class Initialized
INFO - 2022-08-22 01:21:08 --> URI Class Initialized
INFO - 2022-08-22 01:21:08 --> Router Class Initialized
INFO - 2022-08-22 01:21:08 --> Output Class Initialized
INFO - 2022-08-22 01:21:08 --> Security Class Initialized
DEBUG - 2022-08-22 01:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:21:08 --> Input Class Initialized
INFO - 2022-08-22 01:21:08 --> Language Class Initialized
INFO - 2022-08-22 01:21:08 --> Loader Class Initialized
INFO - 2022-08-22 01:21:08 --> Helper loaded: url_helper
INFO - 2022-08-22 01:21:08 --> Controller Class Initialized
DEBUG - 2022-08-22 01:21:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:21:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:21:08 --> Final output sent to browser
DEBUG - 2022-08-22 01:21:08 --> Total execution time: 0.2601
INFO - 2022-08-22 01:21:16 --> Config Class Initialized
INFO - 2022-08-22 01:21:16 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:21:16 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:21:16 --> Utf8 Class Initialized
INFO - 2022-08-22 01:21:16 --> URI Class Initialized
INFO - 2022-08-22 01:21:16 --> Router Class Initialized
INFO - 2022-08-22 01:21:16 --> Output Class Initialized
INFO - 2022-08-22 01:21:16 --> Security Class Initialized
DEBUG - 2022-08-22 01:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:21:16 --> Input Class Initialized
INFO - 2022-08-22 01:21:16 --> Language Class Initialized
INFO - 2022-08-22 01:21:16 --> Loader Class Initialized
INFO - 2022-08-22 01:21:16 --> Helper loaded: url_helper
INFO - 2022-08-22 01:21:16 --> Controller Class Initialized
DEBUG - 2022-08-22 01:21:16 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:21:16 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:21:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:21:16 --> Final output sent to browser
DEBUG - 2022-08-22 01:21:16 --> Total execution time: 0.2843
INFO - 2022-08-22 01:21:26 --> Config Class Initialized
INFO - 2022-08-22 01:21:26 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:21:26 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:21:26 --> Utf8 Class Initialized
INFO - 2022-08-22 01:21:26 --> URI Class Initialized
INFO - 2022-08-22 01:21:26 --> Router Class Initialized
INFO - 2022-08-22 01:21:26 --> Output Class Initialized
INFO - 2022-08-22 01:21:26 --> Security Class Initialized
DEBUG - 2022-08-22 01:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:21:26 --> Input Class Initialized
INFO - 2022-08-22 01:21:26 --> Language Class Initialized
INFO - 2022-08-22 01:21:26 --> Loader Class Initialized
INFO - 2022-08-22 01:21:26 --> Helper loaded: url_helper
INFO - 2022-08-22 01:21:26 --> Controller Class Initialized
DEBUG - 2022-08-22 01:21:26 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:21:26 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:21:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:21:26 --> Final output sent to browser
DEBUG - 2022-08-22 01:21:26 --> Total execution time: 0.2208
INFO - 2022-08-22 01:21:50 --> Config Class Initialized
INFO - 2022-08-22 01:21:50 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:21:50 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:21:50 --> Utf8 Class Initialized
INFO - 2022-08-22 01:21:50 --> URI Class Initialized
INFO - 2022-08-22 01:21:50 --> Router Class Initialized
INFO - 2022-08-22 01:21:50 --> Output Class Initialized
INFO - 2022-08-22 01:21:50 --> Security Class Initialized
DEBUG - 2022-08-22 01:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:21:50 --> Input Class Initialized
INFO - 2022-08-22 01:21:50 --> Language Class Initialized
INFO - 2022-08-22 01:21:50 --> Loader Class Initialized
INFO - 2022-08-22 01:21:50 --> Helper loaded: url_helper
INFO - 2022-08-22 01:21:50 --> Controller Class Initialized
DEBUG - 2022-08-22 01:21:50 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:21:50 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:21:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:21:50 --> Final output sent to browser
DEBUG - 2022-08-22 01:21:50 --> Total execution time: 0.2800
INFO - 2022-08-22 01:21:51 --> Config Class Initialized
INFO - 2022-08-22 01:21:51 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:21:51 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:21:51 --> Utf8 Class Initialized
INFO - 2022-08-22 01:21:51 --> URI Class Initialized
INFO - 2022-08-22 01:21:51 --> Router Class Initialized
INFO - 2022-08-22 01:21:51 --> Output Class Initialized
INFO - 2022-08-22 01:21:51 --> Security Class Initialized
DEBUG - 2022-08-22 01:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:21:51 --> Input Class Initialized
INFO - 2022-08-22 01:21:51 --> Language Class Initialized
INFO - 2022-08-22 01:21:51 --> Loader Class Initialized
INFO - 2022-08-22 01:21:51 --> Helper loaded: url_helper
INFO - 2022-08-22 01:21:51 --> Controller Class Initialized
DEBUG - 2022-08-22 01:21:51 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:21:51 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:21:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:21:51 --> Final output sent to browser
DEBUG - 2022-08-22 01:21:51 --> Total execution time: 0.2467
INFO - 2022-08-22 01:21:52 --> Config Class Initialized
INFO - 2022-08-22 01:21:52 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:21:52 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:21:52 --> Utf8 Class Initialized
INFO - 2022-08-22 01:21:52 --> URI Class Initialized
INFO - 2022-08-22 01:21:52 --> Router Class Initialized
INFO - 2022-08-22 01:21:52 --> Output Class Initialized
INFO - 2022-08-22 01:21:52 --> Security Class Initialized
DEBUG - 2022-08-22 01:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:21:52 --> Input Class Initialized
INFO - 2022-08-22 01:21:52 --> Language Class Initialized
INFO - 2022-08-22 01:21:52 --> Loader Class Initialized
INFO - 2022-08-22 01:21:52 --> Helper loaded: url_helper
INFO - 2022-08-22 01:21:52 --> Controller Class Initialized
DEBUG - 2022-08-22 01:21:52 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:21:52 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:21:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:21:52 --> Final output sent to browser
DEBUG - 2022-08-22 01:21:52 --> Total execution time: 0.2761
INFO - 2022-08-22 01:22:28 --> Config Class Initialized
INFO - 2022-08-22 01:22:28 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:22:28 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:22:28 --> Utf8 Class Initialized
INFO - 2022-08-22 01:22:28 --> URI Class Initialized
INFO - 2022-08-22 01:22:28 --> Router Class Initialized
INFO - 2022-08-22 01:22:28 --> Output Class Initialized
INFO - 2022-08-22 01:22:28 --> Security Class Initialized
DEBUG - 2022-08-22 01:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:22:28 --> Input Class Initialized
INFO - 2022-08-22 01:22:28 --> Language Class Initialized
INFO - 2022-08-22 01:22:28 --> Loader Class Initialized
INFO - 2022-08-22 01:22:28 --> Helper loaded: url_helper
INFO - 2022-08-22 01:22:28 --> Controller Class Initialized
DEBUG - 2022-08-22 01:22:28 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:22:28 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:22:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:22:28 --> Final output sent to browser
DEBUG - 2022-08-22 01:22:28 --> Total execution time: 0.2446
INFO - 2022-08-22 01:22:34 --> Config Class Initialized
INFO - 2022-08-22 01:22:34 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:22:34 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:22:34 --> Utf8 Class Initialized
INFO - 2022-08-22 01:22:34 --> URI Class Initialized
INFO - 2022-08-22 01:22:34 --> Router Class Initialized
INFO - 2022-08-22 01:22:34 --> Output Class Initialized
INFO - 2022-08-22 01:22:34 --> Security Class Initialized
DEBUG - 2022-08-22 01:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:22:34 --> Input Class Initialized
INFO - 2022-08-22 01:22:34 --> Language Class Initialized
INFO - 2022-08-22 01:22:34 --> Loader Class Initialized
INFO - 2022-08-22 01:22:35 --> Helper loaded: url_helper
INFO - 2022-08-22 01:22:35 --> Controller Class Initialized
DEBUG - 2022-08-22 01:22:35 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:22:35 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:22:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:22:35 --> Final output sent to browser
DEBUG - 2022-08-22 01:22:35 --> Total execution time: 0.3055
INFO - 2022-08-22 01:22:39 --> Config Class Initialized
INFO - 2022-08-22 01:22:39 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:22:39 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:22:39 --> Utf8 Class Initialized
INFO - 2022-08-22 01:22:39 --> URI Class Initialized
INFO - 2022-08-22 01:22:39 --> Router Class Initialized
INFO - 2022-08-22 01:22:39 --> Output Class Initialized
INFO - 2022-08-22 01:22:39 --> Security Class Initialized
DEBUG - 2022-08-22 01:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:22:39 --> Input Class Initialized
INFO - 2022-08-22 01:22:39 --> Language Class Initialized
INFO - 2022-08-22 01:22:39 --> Loader Class Initialized
INFO - 2022-08-22 01:22:39 --> Helper loaded: url_helper
INFO - 2022-08-22 01:22:39 --> Controller Class Initialized
DEBUG - 2022-08-22 01:22:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:22:39 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:22:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:22:39 --> Final output sent to browser
DEBUG - 2022-08-22 01:22:39 --> Total execution time: 0.2471
INFO - 2022-08-22 01:22:50 --> Config Class Initialized
INFO - 2022-08-22 01:22:50 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:22:50 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:22:50 --> Utf8 Class Initialized
INFO - 2022-08-22 01:22:50 --> URI Class Initialized
INFO - 2022-08-22 01:22:50 --> Router Class Initialized
INFO - 2022-08-22 01:22:50 --> Output Class Initialized
INFO - 2022-08-22 01:22:50 --> Security Class Initialized
DEBUG - 2022-08-22 01:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:22:50 --> Input Class Initialized
INFO - 2022-08-22 01:22:50 --> Language Class Initialized
INFO - 2022-08-22 01:22:50 --> Loader Class Initialized
INFO - 2022-08-22 01:22:50 --> Helper loaded: url_helper
INFO - 2022-08-22 01:22:50 --> Controller Class Initialized
DEBUG - 2022-08-22 01:22:50 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:22:50 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:22:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:22:50 --> Final output sent to browser
DEBUG - 2022-08-22 01:22:50 --> Total execution time: 0.2538
INFO - 2022-08-22 01:22:53 --> Config Class Initialized
INFO - 2022-08-22 01:22:53 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:22:53 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:22:53 --> Utf8 Class Initialized
INFO - 2022-08-22 01:22:54 --> URI Class Initialized
INFO - 2022-08-22 01:22:54 --> Router Class Initialized
INFO - 2022-08-22 01:22:54 --> Output Class Initialized
INFO - 2022-08-22 01:22:54 --> Security Class Initialized
DEBUG - 2022-08-22 01:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:22:54 --> Input Class Initialized
INFO - 2022-08-22 01:22:54 --> Language Class Initialized
INFO - 2022-08-22 01:22:54 --> Loader Class Initialized
INFO - 2022-08-22 01:22:54 --> Helper loaded: url_helper
INFO - 2022-08-22 01:22:54 --> Controller Class Initialized
DEBUG - 2022-08-22 01:22:54 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:22:54 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:22:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:22:54 --> Final output sent to browser
DEBUG - 2022-08-22 01:22:54 --> Total execution time: 0.2522
INFO - 2022-08-22 01:23:08 --> Config Class Initialized
INFO - 2022-08-22 01:23:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:23:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:23:08 --> Utf8 Class Initialized
INFO - 2022-08-22 01:23:08 --> URI Class Initialized
INFO - 2022-08-22 01:23:08 --> Router Class Initialized
INFO - 2022-08-22 01:23:08 --> Output Class Initialized
INFO - 2022-08-22 01:23:08 --> Security Class Initialized
DEBUG - 2022-08-22 01:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:23:08 --> Input Class Initialized
INFO - 2022-08-22 01:23:08 --> Language Class Initialized
INFO - 2022-08-22 01:23:08 --> Loader Class Initialized
INFO - 2022-08-22 01:23:08 --> Helper loaded: url_helper
INFO - 2022-08-22 01:23:08 --> Controller Class Initialized
DEBUG - 2022-08-22 01:23:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:23:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:23:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:23:08 --> Final output sent to browser
DEBUG - 2022-08-22 01:23:08 --> Total execution time: 0.2640
INFO - 2022-08-22 01:24:33 --> Config Class Initialized
INFO - 2022-08-22 01:24:33 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:24:34 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:24:34 --> Utf8 Class Initialized
INFO - 2022-08-22 01:24:34 --> URI Class Initialized
INFO - 2022-08-22 01:24:34 --> Router Class Initialized
INFO - 2022-08-22 01:24:34 --> Output Class Initialized
INFO - 2022-08-22 01:24:34 --> Security Class Initialized
DEBUG - 2022-08-22 01:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:24:34 --> Input Class Initialized
INFO - 2022-08-22 01:24:34 --> Language Class Initialized
INFO - 2022-08-22 01:24:34 --> Loader Class Initialized
INFO - 2022-08-22 01:24:34 --> Helper loaded: url_helper
INFO - 2022-08-22 01:24:34 --> Controller Class Initialized
DEBUG - 2022-08-22 01:24:34 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:24:34 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:24:34 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:24:34 --> Severity: error --> Exception: Call to undefined method stdClass::format() /sam_tool/application/controllers/Sam.php 51
INFO - 2022-08-22 01:26:19 --> Config Class Initialized
INFO - 2022-08-22 01:26:19 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:26:19 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:26:19 --> Utf8 Class Initialized
INFO - 2022-08-22 01:26:19 --> URI Class Initialized
INFO - 2022-08-22 01:26:19 --> Router Class Initialized
INFO - 2022-08-22 01:26:19 --> Output Class Initialized
INFO - 2022-08-22 01:26:19 --> Security Class Initialized
DEBUG - 2022-08-22 01:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:26:19 --> Input Class Initialized
INFO - 2022-08-22 01:26:19 --> Language Class Initialized
INFO - 2022-08-22 01:26:19 --> Loader Class Initialized
INFO - 2022-08-22 01:26:19 --> Helper loaded: url_helper
INFO - 2022-08-22 01:26:19 --> Controller Class Initialized
DEBUG - 2022-08-22 01:26:19 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:26:19 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:26:19 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:26:19 --> Severity: error --> Exception: Call to undefined method stdClass::post() /sam_tool/application/controllers/Sam.php 52
INFO - 2022-08-22 01:27:06 --> Config Class Initialized
INFO - 2022-08-22 01:27:06 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:27:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:27:06 --> Utf8 Class Initialized
INFO - 2022-08-22 01:27:06 --> URI Class Initialized
INFO - 2022-08-22 01:27:06 --> Router Class Initialized
INFO - 2022-08-22 01:27:06 --> Output Class Initialized
INFO - 2022-08-22 01:27:06 --> Security Class Initialized
DEBUG - 2022-08-22 01:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:27:06 --> Input Class Initialized
INFO - 2022-08-22 01:27:06 --> Language Class Initialized
ERROR - 2022-08-22 01:27:06 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /sam_tool/application/controllers/Sam.php 52
INFO - 2022-08-22 01:27:25 --> Config Class Initialized
INFO - 2022-08-22 01:27:25 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:27:25 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:27:25 --> Utf8 Class Initialized
INFO - 2022-08-22 01:27:25 --> URI Class Initialized
INFO - 2022-08-22 01:27:25 --> Router Class Initialized
INFO - 2022-08-22 01:27:26 --> Output Class Initialized
INFO - 2022-08-22 01:27:26 --> Security Class Initialized
DEBUG - 2022-08-22 01:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:27:26 --> Input Class Initialized
INFO - 2022-08-22 01:27:26 --> Language Class Initialized
ERROR - 2022-08-22 01:27:26 --> Severity: error --> Exception: syntax error, unexpected ',' /sam_tool/application/controllers/Sam.php 52
INFO - 2022-08-22 01:27:41 --> Config Class Initialized
INFO - 2022-08-22 01:27:41 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:27:41 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:27:41 --> Utf8 Class Initialized
INFO - 2022-08-22 01:27:41 --> URI Class Initialized
INFO - 2022-08-22 01:27:41 --> Router Class Initialized
INFO - 2022-08-22 01:27:41 --> Output Class Initialized
INFO - 2022-08-22 01:27:41 --> Security Class Initialized
DEBUG - 2022-08-22 01:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:27:41 --> Input Class Initialized
INFO - 2022-08-22 01:27:41 --> Language Class Initialized
INFO - 2022-08-22 01:27:41 --> Loader Class Initialized
INFO - 2022-08-22 01:27:41 --> Helper loaded: url_helper
INFO - 2022-08-22 01:27:41 --> Controller Class Initialized
DEBUG - 2022-08-22 01:27:41 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:27:41 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:27:41 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:27:41 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/controllers/Sam.php 52
ERROR - 2022-08-22 01:27:41 --> Severity: Warning --> A non-numeric value encountered /sam_tool/application/controllers/Sam.php 52
ERROR - 2022-08-22 01:27:41 --> Severity: Warning --> Division by zero /sam_tool/application/controllers/Sam.php 52
ERROR - 2022-08-22 01:27:41 --> Severity: Notice --> Undefined property: stdClass::$NAN /sam_tool/application/controllers/Sam.php 52
INFO - 2022-08-22 01:27:41 --> Final output sent to browser
DEBUG - 2022-08-22 01:27:41 --> Total execution time: 0.2471
INFO - 2022-08-22 01:27:48 --> Config Class Initialized
INFO - 2022-08-22 01:27:48 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:27:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:27:48 --> Utf8 Class Initialized
INFO - 2022-08-22 01:27:48 --> URI Class Initialized
INFO - 2022-08-22 01:27:48 --> Router Class Initialized
INFO - 2022-08-22 01:27:48 --> Output Class Initialized
INFO - 2022-08-22 01:27:48 --> Security Class Initialized
DEBUG - 2022-08-22 01:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:27:48 --> Input Class Initialized
INFO - 2022-08-22 01:27:48 --> Language Class Initialized
ERROR - 2022-08-22 01:27:48 --> Severity: error --> Exception: syntax error, unexpected '$params' (T_VARIABLE) /sam_tool/application/controllers/Sam.php 52
INFO - 2022-08-22 01:29:12 --> Config Class Initialized
INFO - 2022-08-22 01:29:12 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:29:12 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:29:12 --> Utf8 Class Initialized
INFO - 2022-08-22 01:29:12 --> URI Class Initialized
INFO - 2022-08-22 01:29:12 --> Router Class Initialized
INFO - 2022-08-22 01:29:13 --> Output Class Initialized
INFO - 2022-08-22 01:29:13 --> Security Class Initialized
DEBUG - 2022-08-22 01:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:29:13 --> Input Class Initialized
INFO - 2022-08-22 01:29:13 --> Language Class Initialized
INFO - 2022-08-22 01:29:13 --> Loader Class Initialized
INFO - 2022-08-22 01:29:13 --> Helper loaded: url_helper
INFO - 2022-08-22 01:29:13 --> Controller Class Initialized
DEBUG - 2022-08-22 01:29:13 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:29:13 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:29:13 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:29:13 --> Severity: Notice --> Undefined property: stdClass::$http://host.docker.internal:3000/sam/v1/property/search /sam_tool/application/controllers/Sam.php 52
INFO - 2022-08-22 01:29:13 --> Final output sent to browser
DEBUG - 2022-08-22 01:29:13 --> Total execution time: 0.2561
INFO - 2022-08-22 01:29:38 --> Config Class Initialized
INFO - 2022-08-22 01:29:38 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:29:38 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:29:38 --> Utf8 Class Initialized
INFO - 2022-08-22 01:29:38 --> URI Class Initialized
INFO - 2022-08-22 01:29:38 --> Router Class Initialized
INFO - 2022-08-22 01:29:38 --> Output Class Initialized
INFO - 2022-08-22 01:29:38 --> Security Class Initialized
DEBUG - 2022-08-22 01:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:29:38 --> Input Class Initialized
INFO - 2022-08-22 01:29:38 --> Language Class Initialized
INFO - 2022-08-22 01:29:39 --> Loader Class Initialized
INFO - 2022-08-22 01:29:39 --> Helper loaded: url_helper
INFO - 2022-08-22 01:29:39 --> Controller Class Initialized
DEBUG - 2022-08-22 01:29:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:29:39 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:29:39 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:29:39 --> Severity: Notice --> Undefined property: stdClass::$sam/v1/property/search /sam_tool/application/controllers/Sam.php 52
INFO - 2022-08-22 01:29:39 --> Final output sent to browser
DEBUG - 2022-08-22 01:29:39 --> Total execution time: 0.3060
INFO - 2022-08-22 01:31:48 --> Config Class Initialized
INFO - 2022-08-22 01:31:48 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:31:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:31:48 --> Utf8 Class Initialized
INFO - 2022-08-22 01:31:48 --> URI Class Initialized
INFO - 2022-08-22 01:31:48 --> Router Class Initialized
INFO - 2022-08-22 01:31:48 --> Output Class Initialized
INFO - 2022-08-22 01:31:48 --> Security Class Initialized
DEBUG - 2022-08-22 01:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:31:48 --> Input Class Initialized
INFO - 2022-08-22 01:31:48 --> Language Class Initialized
INFO - 2022-08-22 01:31:48 --> Loader Class Initialized
INFO - 2022-08-22 01:31:48 --> Helper loaded: url_helper
INFO - 2022-08-22 01:31:48 --> Controller Class Initialized
DEBUG - 2022-08-22 01:31:48 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:31:48 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:31:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:31:48 --> Final output sent to browser
DEBUG - 2022-08-22 01:31:48 --> Total execution time: 0.2959
INFO - 2022-08-22 01:31:55 --> Config Class Initialized
INFO - 2022-08-22 01:31:55 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:31:55 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:31:55 --> Utf8 Class Initialized
INFO - 2022-08-22 01:31:55 --> URI Class Initialized
INFO - 2022-08-22 01:31:55 --> Router Class Initialized
INFO - 2022-08-22 01:31:55 --> Output Class Initialized
INFO - 2022-08-22 01:31:55 --> Security Class Initialized
DEBUG - 2022-08-22 01:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:31:55 --> Input Class Initialized
INFO - 2022-08-22 01:31:55 --> Language Class Initialized
INFO - 2022-08-22 01:31:55 --> Loader Class Initialized
INFO - 2022-08-22 01:31:55 --> Helper loaded: url_helper
INFO - 2022-08-22 01:31:55 --> Controller Class Initialized
DEBUG - 2022-08-22 01:31:55 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:31:55 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:31:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:31:55 --> Final output sent to browser
DEBUG - 2022-08-22 01:31:55 --> Total execution time: 0.2638
INFO - 2022-08-22 01:32:04 --> Config Class Initialized
INFO - 2022-08-22 01:32:04 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:32:04 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:32:04 --> Utf8 Class Initialized
INFO - 2022-08-22 01:32:04 --> URI Class Initialized
INFO - 2022-08-22 01:32:04 --> Router Class Initialized
INFO - 2022-08-22 01:32:04 --> Output Class Initialized
INFO - 2022-08-22 01:32:04 --> Security Class Initialized
DEBUG - 2022-08-22 01:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:32:04 --> Input Class Initialized
INFO - 2022-08-22 01:32:05 --> Language Class Initialized
INFO - 2022-08-22 01:32:05 --> Loader Class Initialized
INFO - 2022-08-22 01:32:05 --> Helper loaded: url_helper
INFO - 2022-08-22 01:32:05 --> Controller Class Initialized
DEBUG - 2022-08-22 01:32:05 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:32:05 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:32:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:32:05 --> Final output sent to browser
DEBUG - 2022-08-22 01:32:05 --> Total execution time: 0.3650
INFO - 2022-08-22 01:35:07 --> Config Class Initialized
INFO - 2022-08-22 01:35:07 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:35:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:35:07 --> Utf8 Class Initialized
INFO - 2022-08-22 01:35:07 --> URI Class Initialized
INFO - 2022-08-22 01:35:07 --> Router Class Initialized
INFO - 2022-08-22 01:35:07 --> Output Class Initialized
INFO - 2022-08-22 01:35:07 --> Security Class Initialized
DEBUG - 2022-08-22 01:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:35:07 --> Input Class Initialized
INFO - 2022-08-22 01:35:07 --> Language Class Initialized
INFO - 2022-08-22 01:35:07 --> Loader Class Initialized
INFO - 2022-08-22 01:35:07 --> Helper loaded: url_helper
INFO - 2022-08-22 01:35:07 --> Controller Class Initialized
DEBUG - 2022-08-22 01:35:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:35:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:35:07 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:35:07 --> Unable to load the requested class: Rest
INFO - 2022-08-22 01:40:05 --> Config Class Initialized
INFO - 2022-08-22 01:40:05 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:40:05 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:40:05 --> Utf8 Class Initialized
INFO - 2022-08-22 01:40:05 --> URI Class Initialized
INFO - 2022-08-22 01:40:05 --> Router Class Initialized
INFO - 2022-08-22 01:40:05 --> Output Class Initialized
INFO - 2022-08-22 01:40:05 --> Security Class Initialized
DEBUG - 2022-08-22 01:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:40:05 --> Input Class Initialized
INFO - 2022-08-22 01:40:05 --> Language Class Initialized
INFO - 2022-08-22 01:40:05 --> Loader Class Initialized
INFO - 2022-08-22 01:40:05 --> Helper loaded: url_helper
INFO - 2022-08-22 01:40:05 --> Controller Class Initialized
DEBUG - 2022-08-22 01:40:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:40:06 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:40:06 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:40:06 --> Severity: error --> Exception: Cannot instantiate abstract class REST_Controller /sam_tool/system/core/Loader.php 1284
INFO - 2022-08-22 01:40:30 --> Config Class Initialized
INFO - 2022-08-22 01:40:30 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:40:30 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:40:30 --> Utf8 Class Initialized
INFO - 2022-08-22 01:40:30 --> URI Class Initialized
INFO - 2022-08-22 01:40:30 --> Router Class Initialized
INFO - 2022-08-22 01:40:31 --> Output Class Initialized
INFO - 2022-08-22 01:40:31 --> Security Class Initialized
DEBUG - 2022-08-22 01:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:40:31 --> Input Class Initialized
INFO - 2022-08-22 01:40:31 --> Language Class Initialized
INFO - 2022-08-22 01:40:31 --> Loader Class Initialized
INFO - 2022-08-22 01:40:31 --> Helper loaded: url_helper
INFO - 2022-08-22 01:40:31 --> Controller Class Initialized
DEBUG - 2022-08-22 01:40:31 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:40:31 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:40:31 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:40:31 --> Severity: error --> Exception: Cannot instantiate abstract class REST_Controller /sam_tool/system/core/Loader.php 1284
INFO - 2022-08-22 01:40:47 --> Config Class Initialized
INFO - 2022-08-22 01:40:47 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:40:47 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:40:47 --> Utf8 Class Initialized
INFO - 2022-08-22 01:40:47 --> URI Class Initialized
INFO - 2022-08-22 01:40:47 --> Router Class Initialized
INFO - 2022-08-22 01:40:47 --> Output Class Initialized
INFO - 2022-08-22 01:40:47 --> Security Class Initialized
DEBUG - 2022-08-22 01:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:40:47 --> Input Class Initialized
INFO - 2022-08-22 01:40:47 --> Language Class Initialized
INFO - 2022-08-22 01:40:47 --> Loader Class Initialized
INFO - 2022-08-22 01:40:47 --> Helper loaded: url_helper
INFO - 2022-08-22 01:40:47 --> Controller Class Initialized
DEBUG - 2022-08-22 01:40:47 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:40:47 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:40:47 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:40:47 --> Severity: error --> Exception: Cannot instantiate abstract class REST_Controller /sam_tool/system/core/Loader.php 1284
INFO - 2022-08-22 01:41:15 --> Config Class Initialized
INFO - 2022-08-22 01:41:15 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:41:15 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:41:15 --> Utf8 Class Initialized
INFO - 2022-08-22 01:41:15 --> URI Class Initialized
INFO - 2022-08-22 01:41:15 --> Router Class Initialized
INFO - 2022-08-22 01:41:15 --> Output Class Initialized
INFO - 2022-08-22 01:41:15 --> Security Class Initialized
DEBUG - 2022-08-22 01:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:41:15 --> Input Class Initialized
INFO - 2022-08-22 01:41:15 --> Language Class Initialized
INFO - 2022-08-22 01:41:15 --> Loader Class Initialized
INFO - 2022-08-22 01:41:15 --> Helper loaded: url_helper
INFO - 2022-08-22 01:41:15 --> Controller Class Initialized
DEBUG - 2022-08-22 01:41:15 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:41:15 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:41:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:41:15 --> Final output sent to browser
DEBUG - 2022-08-22 01:41:15 --> Total execution time: 0.2453
INFO - 2022-08-22 01:41:50 --> Config Class Initialized
INFO - 2022-08-22 01:41:50 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:41:50 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:41:50 --> Utf8 Class Initialized
INFO - 2022-08-22 01:41:50 --> URI Class Initialized
INFO - 2022-08-22 01:41:50 --> Router Class Initialized
INFO - 2022-08-22 01:41:50 --> Output Class Initialized
INFO - 2022-08-22 01:41:50 --> Security Class Initialized
DEBUG - 2022-08-22 01:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:41:50 --> Input Class Initialized
INFO - 2022-08-22 01:41:50 --> Language Class Initialized
INFO - 2022-08-22 01:41:50 --> Loader Class Initialized
INFO - 2022-08-22 01:41:51 --> Helper loaded: url_helper
INFO - 2022-08-22 01:41:51 --> Controller Class Initialized
DEBUG - 2022-08-22 01:41:51 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:41:51 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:41:51 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 01:41:51 --> Severity: Notice --> Undefined variable: result /sam_tool/application/controllers/Sam.php 71
INFO - 2022-08-22 01:41:51 --> Final output sent to browser
DEBUG - 2022-08-22 01:41:51 --> Total execution time: 0.2609
INFO - 2022-08-22 01:42:03 --> Config Class Initialized
INFO - 2022-08-22 01:42:03 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:42:03 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:42:03 --> Utf8 Class Initialized
INFO - 2022-08-22 01:42:03 --> URI Class Initialized
INFO - 2022-08-22 01:42:03 --> Router Class Initialized
INFO - 2022-08-22 01:42:03 --> Output Class Initialized
INFO - 2022-08-22 01:42:03 --> Security Class Initialized
DEBUG - 2022-08-22 01:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:42:03 --> Input Class Initialized
INFO - 2022-08-22 01:42:03 --> Language Class Initialized
INFO - 2022-08-22 01:42:03 --> Loader Class Initialized
INFO - 2022-08-22 01:42:03 --> Helper loaded: url_helper
INFO - 2022-08-22 01:42:03 --> Controller Class Initialized
DEBUG - 2022-08-22 01:42:03 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:42:03 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:42:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:42:03 --> Final output sent to browser
DEBUG - 2022-08-22 01:42:03 --> Total execution time: 0.2183
INFO - 2022-08-22 01:42:10 --> Config Class Initialized
INFO - 2022-08-22 01:42:10 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:42:10 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:42:10 --> Utf8 Class Initialized
INFO - 2022-08-22 01:42:10 --> URI Class Initialized
INFO - 2022-08-22 01:42:10 --> Router Class Initialized
INFO - 2022-08-22 01:42:10 --> Output Class Initialized
INFO - 2022-08-22 01:42:10 --> Security Class Initialized
DEBUG - 2022-08-22 01:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:42:10 --> Input Class Initialized
INFO - 2022-08-22 01:42:10 --> Language Class Initialized
INFO - 2022-08-22 01:42:10 --> Loader Class Initialized
INFO - 2022-08-22 01:42:10 --> Helper loaded: url_helper
INFO - 2022-08-22 01:42:10 --> Controller Class Initialized
DEBUG - 2022-08-22 01:42:10 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:42:10 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:42:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:42:10 --> Final output sent to browser
DEBUG - 2022-08-22 01:42:10 --> Total execution time: 0.2876
INFO - 2022-08-22 01:42:29 --> Config Class Initialized
INFO - 2022-08-22 01:42:29 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:42:29 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:42:29 --> Utf8 Class Initialized
INFO - 2022-08-22 01:42:29 --> URI Class Initialized
INFO - 2022-08-22 01:42:29 --> Router Class Initialized
INFO - 2022-08-22 01:42:29 --> Output Class Initialized
INFO - 2022-08-22 01:42:29 --> Security Class Initialized
DEBUG - 2022-08-22 01:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:42:29 --> Input Class Initialized
INFO - 2022-08-22 01:42:29 --> Language Class Initialized
INFO - 2022-08-22 01:42:29 --> Loader Class Initialized
INFO - 2022-08-22 01:42:29 --> Helper loaded: url_helper
INFO - 2022-08-22 01:42:29 --> Controller Class Initialized
DEBUG - 2022-08-22 01:42:29 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:42:30 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:42:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:42:30 --> Final output sent to browser
DEBUG - 2022-08-22 01:42:30 --> Total execution time: 0.2340
INFO - 2022-08-22 01:45:08 --> Config Class Initialized
INFO - 2022-08-22 01:45:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:45:09 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:45:09 --> Utf8 Class Initialized
INFO - 2022-08-22 01:45:09 --> URI Class Initialized
INFO - 2022-08-22 01:45:09 --> Router Class Initialized
INFO - 2022-08-22 01:45:09 --> Output Class Initialized
INFO - 2022-08-22 01:45:09 --> Security Class Initialized
DEBUG - 2022-08-22 01:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:45:09 --> Input Class Initialized
INFO - 2022-08-22 01:45:09 --> Language Class Initialized
INFO - 2022-08-22 01:45:09 --> Loader Class Initialized
INFO - 2022-08-22 01:45:09 --> Helper loaded: url_helper
INFO - 2022-08-22 01:45:09 --> Controller Class Initialized
DEBUG - 2022-08-22 01:45:09 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:45:09 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:45:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:45:09 --> Final output sent to browser
DEBUG - 2022-08-22 01:45:09 --> Total execution time: 0.2910
INFO - 2022-08-22 01:45:12 --> Config Class Initialized
INFO - 2022-08-22 01:45:12 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:45:12 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:45:12 --> Utf8 Class Initialized
INFO - 2022-08-22 01:45:12 --> URI Class Initialized
INFO - 2022-08-22 01:45:12 --> Router Class Initialized
INFO - 2022-08-22 01:45:12 --> Output Class Initialized
INFO - 2022-08-22 01:45:12 --> Security Class Initialized
DEBUG - 2022-08-22 01:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:45:12 --> Input Class Initialized
INFO - 2022-08-22 01:45:12 --> Language Class Initialized
ERROR - 2022-08-22 01:45:12 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-22 01:45:13 --> Config Class Initialized
INFO - 2022-08-22 01:45:13 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:45:13 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:45:13 --> Utf8 Class Initialized
INFO - 2022-08-22 01:45:13 --> URI Class Initialized
DEBUG - 2022-08-22 01:45:13 --> No URI present. Default controller set.
INFO - 2022-08-22 01:45:13 --> Router Class Initialized
INFO - 2022-08-22 01:45:13 --> Output Class Initialized
INFO - 2022-08-22 01:45:13 --> Security Class Initialized
DEBUG - 2022-08-22 01:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:45:13 --> Input Class Initialized
INFO - 2022-08-22 01:45:13 --> Language Class Initialized
INFO - 2022-08-22 01:45:13 --> Loader Class Initialized
INFO - 2022-08-22 01:45:13 --> Helper loaded: url_helper
INFO - 2022-08-22 01:45:13 --> Controller Class Initialized
INFO - 2022-08-22 01:45:13 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 01:45:13 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 01:45:13 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 01:45:13 --> Final output sent to browser
DEBUG - 2022-08-22 01:45:13 --> Total execution time: 0.3126
INFO - 2022-08-22 01:45:37 --> Config Class Initialized
INFO - 2022-08-22 01:45:37 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:45:37 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:45:37 --> Utf8 Class Initialized
INFO - 2022-08-22 01:45:37 --> URI Class Initialized
DEBUG - 2022-08-22 01:45:37 --> No URI present. Default controller set.
INFO - 2022-08-22 01:45:37 --> Router Class Initialized
INFO - 2022-08-22 01:45:37 --> Output Class Initialized
INFO - 2022-08-22 01:45:37 --> Security Class Initialized
DEBUG - 2022-08-22 01:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:45:37 --> Input Class Initialized
INFO - 2022-08-22 01:45:37 --> Language Class Initialized
INFO - 2022-08-22 01:45:37 --> Loader Class Initialized
INFO - 2022-08-22 01:45:37 --> Helper loaded: url_helper
INFO - 2022-08-22 01:45:37 --> Controller Class Initialized
INFO - 2022-08-22 01:45:37 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 01:45:37 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 01:45:37 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 01:45:37 --> Final output sent to browser
DEBUG - 2022-08-22 01:45:37 --> Total execution time: 0.2270
INFO - 2022-08-22 01:45:37 --> Config Class Initialized
INFO - 2022-08-22 01:45:37 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:45:37 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:45:37 --> Utf8 Class Initialized
INFO - 2022-08-22 01:45:37 --> URI Class Initialized
INFO - 2022-08-22 01:45:37 --> Router Class Initialized
INFO - 2022-08-22 01:45:37 --> Output Class Initialized
INFO - 2022-08-22 01:45:37 --> Security Class Initialized
DEBUG - 2022-08-22 01:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:45:37 --> Input Class Initialized
INFO - 2022-08-22 01:45:38 --> Language Class Initialized
ERROR - 2022-08-22 01:45:38 --> 404 Page Not Found: Theme/assets
INFO - 2022-08-22 01:45:42 --> Config Class Initialized
INFO - 2022-08-22 01:45:42 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:45:42 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:45:42 --> Utf8 Class Initialized
INFO - 2022-08-22 01:45:42 --> URI Class Initialized
INFO - 2022-08-22 01:45:42 --> Router Class Initialized
INFO - 2022-08-22 01:45:42 --> Output Class Initialized
INFO - 2022-08-22 01:45:42 --> Security Class Initialized
DEBUG - 2022-08-22 01:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:45:42 --> Input Class Initialized
INFO - 2022-08-22 01:45:42 --> Language Class Initialized
INFO - 2022-08-22 01:45:42 --> Loader Class Initialized
INFO - 2022-08-22 01:45:42 --> Helper loaded: url_helper
INFO - 2022-08-22 01:45:42 --> Controller Class Initialized
DEBUG - 2022-08-22 01:45:42 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:45:42 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:45:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:45:42 --> Final output sent to browser
DEBUG - 2022-08-22 01:45:42 --> Total execution time: 0.2492
INFO - 2022-08-22 01:48:27 --> Config Class Initialized
INFO - 2022-08-22 01:48:27 --> Hooks Class Initialized
DEBUG - 2022-08-22 01:48:27 --> UTF-8 Support Enabled
INFO - 2022-08-22 01:48:27 --> Utf8 Class Initialized
INFO - 2022-08-22 01:48:27 --> URI Class Initialized
INFO - 2022-08-22 01:48:27 --> Router Class Initialized
INFO - 2022-08-22 01:48:27 --> Output Class Initialized
INFO - 2022-08-22 01:48:27 --> Security Class Initialized
DEBUG - 2022-08-22 01:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 01:48:27 --> Input Class Initialized
INFO - 2022-08-22 01:48:27 --> Language Class Initialized
INFO - 2022-08-22 01:48:27 --> Loader Class Initialized
INFO - 2022-08-22 01:48:27 --> Helper loaded: url_helper
INFO - 2022-08-22 01:48:27 --> Controller Class Initialized
DEBUG - 2022-08-22 01:48:27 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 01:48:27 --> Helper loaded: inflector_helper
INFO - 2022-08-22 01:48:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 01:48:27 --> Final output sent to browser
DEBUG - 2022-08-22 01:48:27 --> Total execution time: 0.3151
INFO - 2022-08-22 12:06:04 --> Config Class Initialized
INFO - 2022-08-22 12:06:04 --> Hooks Class Initialized
DEBUG - 2022-08-22 12:06:04 --> UTF-8 Support Enabled
INFO - 2022-08-22 12:06:04 --> Utf8 Class Initialized
INFO - 2022-08-22 12:06:04 --> URI Class Initialized
DEBUG - 2022-08-22 12:06:04 --> No URI present. Default controller set.
INFO - 2022-08-22 12:06:04 --> Router Class Initialized
INFO - 2022-08-22 12:06:04 --> Output Class Initialized
INFO - 2022-08-22 12:06:04 --> Security Class Initialized
DEBUG - 2022-08-22 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 12:06:04 --> Input Class Initialized
INFO - 2022-08-22 12:06:04 --> Language Class Initialized
INFO - 2022-08-22 12:06:04 --> Loader Class Initialized
INFO - 2022-08-22 12:06:04 --> Helper loaded: url_helper
INFO - 2022-08-22 12:06:04 --> Controller Class Initialized
INFO - 2022-08-22 12:06:04 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 12:06:04 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 12:06:04 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 12:06:04 --> Final output sent to browser
DEBUG - 2022-08-22 12:06:04 --> Total execution time: 0.7830
INFO - 2022-08-22 12:06:11 --> Config Class Initialized
INFO - 2022-08-22 12:06:11 --> Hooks Class Initialized
DEBUG - 2022-08-22 12:06:11 --> UTF-8 Support Enabled
INFO - 2022-08-22 12:06:11 --> Utf8 Class Initialized
INFO - 2022-08-22 12:06:11 --> URI Class Initialized
INFO - 2022-08-22 12:06:11 --> Router Class Initialized
INFO - 2022-08-22 12:06:11 --> Output Class Initialized
INFO - 2022-08-22 12:06:11 --> Security Class Initialized
DEBUG - 2022-08-22 12:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 12:06:12 --> Input Class Initialized
INFO - 2022-08-22 12:06:12 --> Language Class Initialized
INFO - 2022-08-22 12:06:12 --> Loader Class Initialized
INFO - 2022-08-22 12:06:12 --> Helper loaded: url_helper
INFO - 2022-08-22 12:06:12 --> Controller Class Initialized
DEBUG - 2022-08-22 12:06:12 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 12:06:12 --> Helper loaded: inflector_helper
INFO - 2022-08-22 12:06:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 12:06:12 --> Final output sent to browser
DEBUG - 2022-08-22 12:06:12 --> Total execution time: 0.6888
INFO - 2022-08-22 12:06:12 --> Config Class Initialized
INFO - 2022-08-22 12:06:12 --> Hooks Class Initialized
DEBUG - 2022-08-22 12:06:12 --> UTF-8 Support Enabled
INFO - 2022-08-22 12:06:12 --> Utf8 Class Initialized
INFO - 2022-08-22 12:06:12 --> URI Class Initialized
INFO - 2022-08-22 12:06:12 --> Router Class Initialized
INFO - 2022-08-22 12:06:12 --> Output Class Initialized
INFO - 2022-08-22 12:06:12 --> Security Class Initialized
DEBUG - 2022-08-22 12:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 12:06:12 --> Input Class Initialized
INFO - 2022-08-22 12:06:12 --> Language Class Initialized
ERROR - 2022-08-22 12:06:12 --> 404 Page Not Found: Faviconico/index
INFO - 2022-08-22 12:06:36 --> Config Class Initialized
INFO - 2022-08-22 12:06:36 --> Hooks Class Initialized
DEBUG - 2022-08-22 12:06:36 --> UTF-8 Support Enabled
INFO - 2022-08-22 12:06:36 --> Utf8 Class Initialized
INFO - 2022-08-22 12:06:36 --> URI Class Initialized
INFO - 2022-08-22 12:06:36 --> Router Class Initialized
INFO - 2022-08-22 12:06:36 --> Output Class Initialized
INFO - 2022-08-22 12:06:36 --> Security Class Initialized
DEBUG - 2022-08-22 12:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 12:06:36 --> Input Class Initialized
INFO - 2022-08-22 12:06:36 --> Language Class Initialized
INFO - 2022-08-22 12:06:36 --> Loader Class Initialized
INFO - 2022-08-22 12:06:36 --> Helper loaded: url_helper
INFO - 2022-08-22 12:06:36 --> Controller Class Initialized
DEBUG - 2022-08-22 12:06:36 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 12:06:36 --> Helper loaded: inflector_helper
INFO - 2022-08-22 12:06:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 12:06:36 --> Final output sent to browser
DEBUG - 2022-08-22 12:06:36 --> Total execution time: 0.4990
INFO - 2022-08-22 12:32:36 --> Config Class Initialized
INFO - 2022-08-22 12:32:36 --> Hooks Class Initialized
DEBUG - 2022-08-22 12:32:36 --> UTF-8 Support Enabled
INFO - 2022-08-22 12:32:36 --> Utf8 Class Initialized
INFO - 2022-08-22 12:32:36 --> URI Class Initialized
INFO - 2022-08-22 12:32:36 --> Router Class Initialized
INFO - 2022-08-22 12:32:37 --> Output Class Initialized
INFO - 2022-08-22 12:32:37 --> Security Class Initialized
DEBUG - 2022-08-22 12:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 12:32:37 --> Input Class Initialized
INFO - 2022-08-22 12:32:37 --> Language Class Initialized
INFO - 2022-08-22 12:32:37 --> Loader Class Initialized
INFO - 2022-08-22 12:32:37 --> Helper loaded: url_helper
INFO - 2022-08-22 12:32:37 --> Controller Class Initialized
DEBUG - 2022-08-22 12:32:37 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 12:32:37 --> Helper loaded: inflector_helper
INFO - 2022-08-22 12:32:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 12:32:37 --> Final output sent to browser
DEBUG - 2022-08-22 12:32:37 --> Total execution time: 1.0600
INFO - 2022-08-22 12:32:48 --> Config Class Initialized
INFO - 2022-08-22 12:32:48 --> Hooks Class Initialized
DEBUG - 2022-08-22 12:32:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 12:32:48 --> Utf8 Class Initialized
INFO - 2022-08-22 12:32:48 --> URI Class Initialized
INFO - 2022-08-22 12:32:48 --> Router Class Initialized
INFO - 2022-08-22 12:32:48 --> Output Class Initialized
INFO - 2022-08-22 12:32:49 --> Security Class Initialized
DEBUG - 2022-08-22 12:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 12:32:49 --> Input Class Initialized
INFO - 2022-08-22 12:32:49 --> Language Class Initialized
INFO - 2022-08-22 12:32:49 --> Loader Class Initialized
INFO - 2022-08-22 12:32:49 --> Helper loaded: url_helper
INFO - 2022-08-22 12:32:49 --> Controller Class Initialized
DEBUG - 2022-08-22 12:32:49 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 12:32:49 --> Helper loaded: inflector_helper
INFO - 2022-08-22 12:32:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 12:32:49 --> Final output sent to browser
DEBUG - 2022-08-22 12:32:49 --> Total execution time: 0.6909
INFO - 2022-08-22 13:50:56 --> Config Class Initialized
INFO - 2022-08-22 13:50:56 --> Hooks Class Initialized
DEBUG - 2022-08-22 13:50:56 --> UTF-8 Support Enabled
INFO - 2022-08-22 13:50:56 --> Utf8 Class Initialized
INFO - 2022-08-22 13:50:56 --> URI Class Initialized
INFO - 2022-08-22 13:50:56 --> Router Class Initialized
INFO - 2022-08-22 13:50:56 --> Output Class Initialized
INFO - 2022-08-22 13:50:57 --> Security Class Initialized
DEBUG - 2022-08-22 13:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 13:50:57 --> Input Class Initialized
INFO - 2022-08-22 13:50:57 --> Language Class Initialized
INFO - 2022-08-22 13:50:57 --> Loader Class Initialized
INFO - 2022-08-22 13:50:57 --> Helper loaded: url_helper
INFO - 2022-08-22 13:50:57 --> Controller Class Initialized
DEBUG - 2022-08-22 13:50:57 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 13:50:57 --> Helper loaded: inflector_helper
INFO - 2022-08-22 13:50:57 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 13:50:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 13:50:57 --> Final output sent to browser
DEBUG - 2022-08-22 13:50:57 --> Total execution time: 1.4570
INFO - 2022-08-22 13:51:32 --> Config Class Initialized
INFO - 2022-08-22 13:51:32 --> Hooks Class Initialized
DEBUG - 2022-08-22 13:51:32 --> UTF-8 Support Enabled
INFO - 2022-08-22 13:51:32 --> Utf8 Class Initialized
INFO - 2022-08-22 13:51:32 --> URI Class Initialized
INFO - 2022-08-22 13:51:33 --> Router Class Initialized
INFO - 2022-08-22 13:51:33 --> Output Class Initialized
INFO - 2022-08-22 13:51:33 --> Security Class Initialized
DEBUG - 2022-08-22 13:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 13:51:33 --> Input Class Initialized
INFO - 2022-08-22 13:51:33 --> Language Class Initialized
INFO - 2022-08-22 13:51:33 --> Loader Class Initialized
INFO - 2022-08-22 13:51:33 --> Helper loaded: url_helper
INFO - 2022-08-22 13:51:33 --> Controller Class Initialized
DEBUG - 2022-08-22 13:51:33 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 13:51:33 --> Helper loaded: inflector_helper
INFO - 2022-08-22 13:51:33 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 13:51:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 13:51:33 --> Final output sent to browser
DEBUG - 2022-08-22 13:51:33 --> Total execution time: 1.3206
INFO - 2022-08-22 13:52:34 --> Config Class Initialized
INFO - 2022-08-22 13:52:34 --> Hooks Class Initialized
DEBUG - 2022-08-22 13:52:34 --> UTF-8 Support Enabled
INFO - 2022-08-22 13:52:34 --> Utf8 Class Initialized
INFO - 2022-08-22 13:52:34 --> URI Class Initialized
INFO - 2022-08-22 13:52:34 --> Router Class Initialized
INFO - 2022-08-22 13:52:35 --> Output Class Initialized
INFO - 2022-08-22 13:52:35 --> Security Class Initialized
DEBUG - 2022-08-22 13:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 13:52:35 --> Input Class Initialized
INFO - 2022-08-22 13:52:35 --> Language Class Initialized
INFO - 2022-08-22 13:52:35 --> Loader Class Initialized
INFO - 2022-08-22 13:52:35 --> Helper loaded: url_helper
INFO - 2022-08-22 13:52:35 --> Controller Class Initialized
DEBUG - 2022-08-22 13:52:35 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 13:52:35 --> Helper loaded: inflector_helper
INFO - 2022-08-22 13:52:35 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 13:52:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 13:52:35 --> Final output sent to browser
DEBUG - 2022-08-22 13:52:35 --> Total execution time: 1.1543
INFO - 2022-08-22 13:53:19 --> Config Class Initialized
INFO - 2022-08-22 13:53:19 --> Hooks Class Initialized
DEBUG - 2022-08-22 13:53:19 --> UTF-8 Support Enabled
INFO - 2022-08-22 13:53:19 --> Utf8 Class Initialized
INFO - 2022-08-22 13:53:19 --> URI Class Initialized
INFO - 2022-08-22 13:53:19 --> Router Class Initialized
INFO - 2022-08-22 13:53:19 --> Output Class Initialized
INFO - 2022-08-22 13:53:19 --> Security Class Initialized
DEBUG - 2022-08-22 13:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 13:53:19 --> Input Class Initialized
INFO - 2022-08-22 13:53:19 --> Language Class Initialized
ERROR - 2022-08-22 13:53:19 --> Severity: error --> Exception: syntax error, unexpected '$result' (T_VARIABLE), expecting ')' /sam_tool/application/controllers/Sam.php 55
INFO - 2022-08-22 13:53:35 --> Config Class Initialized
INFO - 2022-08-22 13:53:35 --> Hooks Class Initialized
DEBUG - 2022-08-22 13:53:36 --> UTF-8 Support Enabled
INFO - 2022-08-22 13:53:36 --> Utf8 Class Initialized
INFO - 2022-08-22 13:53:36 --> URI Class Initialized
INFO - 2022-08-22 13:53:36 --> Router Class Initialized
INFO - 2022-08-22 13:53:36 --> Output Class Initialized
INFO - 2022-08-22 13:53:36 --> Security Class Initialized
DEBUG - 2022-08-22 13:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 13:53:36 --> Input Class Initialized
INFO - 2022-08-22 13:53:36 --> Language Class Initialized
INFO - 2022-08-22 13:53:36 --> Loader Class Initialized
INFO - 2022-08-22 13:53:36 --> Helper loaded: url_helper
INFO - 2022-08-22 13:53:36 --> Controller Class Initialized
DEBUG - 2022-08-22 13:53:36 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 13:53:37 --> Helper loaded: inflector_helper
INFO - 2022-08-22 13:53:37 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 13:53:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 13:53:37 --> Final output sent to browser
DEBUG - 2022-08-22 13:53:37 --> Total execution time: 1.4415
INFO - 2022-08-22 13:54:06 --> Config Class Initialized
INFO - 2022-08-22 13:54:06 --> Hooks Class Initialized
DEBUG - 2022-08-22 13:54:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 13:54:06 --> Utf8 Class Initialized
INFO - 2022-08-22 13:54:06 --> URI Class Initialized
INFO - 2022-08-22 13:54:07 --> Router Class Initialized
INFO - 2022-08-22 13:54:07 --> Output Class Initialized
INFO - 2022-08-22 13:54:07 --> Security Class Initialized
DEBUG - 2022-08-22 13:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 13:54:07 --> Input Class Initialized
INFO - 2022-08-22 13:54:07 --> Language Class Initialized
INFO - 2022-08-22 13:54:07 --> Loader Class Initialized
INFO - 2022-08-22 13:54:07 --> Helper loaded: url_helper
INFO - 2022-08-22 13:54:07 --> Controller Class Initialized
DEBUG - 2022-08-22 13:54:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 13:54:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 13:54:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 13:54:07 --> Final output sent to browser
DEBUG - 2022-08-22 13:54:07 --> Total execution time: 1.3130
INFO - 2022-08-22 13:55:26 --> Config Class Initialized
INFO - 2022-08-22 13:55:26 --> Hooks Class Initialized
DEBUG - 2022-08-22 13:55:26 --> UTF-8 Support Enabled
INFO - 2022-08-22 13:55:26 --> Utf8 Class Initialized
INFO - 2022-08-22 13:55:26 --> URI Class Initialized
INFO - 2022-08-22 13:55:26 --> Router Class Initialized
INFO - 2022-08-22 13:55:26 --> Output Class Initialized
INFO - 2022-08-22 13:55:26 --> Security Class Initialized
DEBUG - 2022-08-22 13:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 13:55:26 --> Input Class Initialized
INFO - 2022-08-22 13:55:26 --> Language Class Initialized
INFO - 2022-08-22 13:55:26 --> Loader Class Initialized
INFO - 2022-08-22 13:55:26 --> Helper loaded: url_helper
INFO - 2022-08-22 13:55:26 --> Controller Class Initialized
DEBUG - 2022-08-22 13:55:26 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 13:55:26 --> Helper loaded: inflector_helper
INFO - 2022-08-22 13:55:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 13:55:26 --> Final output sent to browser
DEBUG - 2022-08-22 13:55:26 --> Total execution time: 0.2371
INFO - 2022-08-22 13:55:34 --> Config Class Initialized
INFO - 2022-08-22 13:55:34 --> Hooks Class Initialized
DEBUG - 2022-08-22 13:55:34 --> UTF-8 Support Enabled
INFO - 2022-08-22 13:55:34 --> Utf8 Class Initialized
INFO - 2022-08-22 13:55:34 --> URI Class Initialized
INFO - 2022-08-22 13:55:34 --> Router Class Initialized
INFO - 2022-08-22 13:55:34 --> Output Class Initialized
INFO - 2022-08-22 13:55:34 --> Security Class Initialized
DEBUG - 2022-08-22 13:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 13:55:34 --> Input Class Initialized
INFO - 2022-08-22 13:55:34 --> Language Class Initialized
INFO - 2022-08-22 13:55:34 --> Loader Class Initialized
INFO - 2022-08-22 13:55:34 --> Helper loaded: url_helper
INFO - 2022-08-22 13:55:34 --> Controller Class Initialized
DEBUG - 2022-08-22 13:55:34 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 13:55:34 --> Helper loaded: inflector_helper
INFO - 2022-08-22 13:55:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 13:55:34 --> Final output sent to browser
DEBUG - 2022-08-22 13:55:35 --> Total execution time: 0.2183
INFO - 2022-08-22 14:00:46 --> Config Class Initialized
INFO - 2022-08-22 14:00:46 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:00:46 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:00:46 --> Utf8 Class Initialized
INFO - 2022-08-22 14:00:46 --> URI Class Initialized
INFO - 2022-08-22 14:00:46 --> Router Class Initialized
INFO - 2022-08-22 14:00:46 --> Output Class Initialized
INFO - 2022-08-22 14:00:46 --> Security Class Initialized
DEBUG - 2022-08-22 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:00:46 --> Input Class Initialized
INFO - 2022-08-22 14:00:46 --> Language Class Initialized
INFO - 2022-08-22 14:00:46 --> Loader Class Initialized
INFO - 2022-08-22 14:00:46 --> Helper loaded: url_helper
INFO - 2022-08-22 14:00:46 --> Controller Class Initialized
DEBUG - 2022-08-22 14:00:46 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 14:00:46 --> Helper loaded: inflector_helper
INFO - 2022-08-22 14:00:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 14:00:46 --> Final output sent to browser
DEBUG - 2022-08-22 14:00:46 --> Total execution time: 0.3546
INFO - 2022-08-22 14:00:49 --> Config Class Initialized
INFO - 2022-08-22 14:00:49 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:00:49 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:00:49 --> Utf8 Class Initialized
INFO - 2022-08-22 14:00:49 --> URI Class Initialized
DEBUG - 2022-08-22 14:00:49 --> No URI present. Default controller set.
INFO - 2022-08-22 14:00:49 --> Router Class Initialized
INFO - 2022-08-22 14:00:49 --> Output Class Initialized
INFO - 2022-08-22 14:00:49 --> Security Class Initialized
DEBUG - 2022-08-22 14:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:00:49 --> Input Class Initialized
INFO - 2022-08-22 14:00:49 --> Language Class Initialized
INFO - 2022-08-22 14:00:49 --> Loader Class Initialized
INFO - 2022-08-22 14:00:49 --> Helper loaded: url_helper
INFO - 2022-08-22 14:00:49 --> Controller Class Initialized
INFO - 2022-08-22 14:00:49 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 14:00:49 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 14:00:49 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 14:00:49 --> Final output sent to browser
DEBUG - 2022-08-22 14:00:49 --> Total execution time: 0.4046
INFO - 2022-08-22 14:00:53 --> Config Class Initialized
INFO - 2022-08-22 14:00:53 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:00:53 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:00:53 --> Utf8 Class Initialized
INFO - 2022-08-22 14:00:53 --> URI Class Initialized
DEBUG - 2022-08-22 14:00:53 --> No URI present. Default controller set.
INFO - 2022-08-22 14:00:53 --> Router Class Initialized
INFO - 2022-08-22 14:00:53 --> Output Class Initialized
INFO - 2022-08-22 14:00:54 --> Security Class Initialized
DEBUG - 2022-08-22 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:00:54 --> Input Class Initialized
INFO - 2022-08-22 14:00:54 --> Language Class Initialized
INFO - 2022-08-22 14:00:54 --> Loader Class Initialized
INFO - 2022-08-22 14:00:54 --> Helper loaded: url_helper
INFO - 2022-08-22 14:00:54 --> Controller Class Initialized
INFO - 2022-08-22 14:00:54 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 14:00:54 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 14:00:54 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 14:00:54 --> Final output sent to browser
DEBUG - 2022-08-22 14:00:54 --> Total execution time: 0.2544
INFO - 2022-08-22 14:03:30 --> Config Class Initialized
INFO - 2022-08-22 14:03:30 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:03:30 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:03:30 --> Utf8 Class Initialized
INFO - 2022-08-22 14:03:30 --> URI Class Initialized
DEBUG - 2022-08-22 14:03:30 --> No URI present. Default controller set.
INFO - 2022-08-22 14:03:30 --> Router Class Initialized
INFO - 2022-08-22 14:03:30 --> Output Class Initialized
INFO - 2022-08-22 14:03:30 --> Security Class Initialized
DEBUG - 2022-08-22 14:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:03:30 --> Input Class Initialized
INFO - 2022-08-22 14:03:30 --> Language Class Initialized
INFO - 2022-08-22 14:03:31 --> Loader Class Initialized
INFO - 2022-08-22 14:03:31 --> Helper loaded: url_helper
INFO - 2022-08-22 14:03:31 --> Controller Class Initialized
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 14:03:31 --> Final output sent to browser
DEBUG - 2022-08-22 14:03:31 --> Total execution time: 0.2678
INFO - 2022-08-22 14:03:31 --> Config Class Initialized
INFO - 2022-08-22 14:03:31 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:03:31 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:03:31 --> Utf8 Class Initialized
INFO - 2022-08-22 14:03:31 --> URI Class Initialized
DEBUG - 2022-08-22 14:03:31 --> No URI present. Default controller set.
INFO - 2022-08-22 14:03:31 --> Router Class Initialized
INFO - 2022-08-22 14:03:31 --> Output Class Initialized
INFO - 2022-08-22 14:03:31 --> Security Class Initialized
DEBUG - 2022-08-22 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:03:31 --> Input Class Initialized
INFO - 2022-08-22 14:03:31 --> Language Class Initialized
INFO - 2022-08-22 14:03:31 --> Config Class Initialized
INFO - 2022-08-22 14:03:31 --> Hooks Class Initialized
INFO - 2022-08-22 14:03:31 --> Loader Class Initialized
INFO - 2022-08-22 14:03:31 --> Helper loaded: url_helper
DEBUG - 2022-08-22 14:03:31 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:03:31 --> Controller Class Initialized
INFO - 2022-08-22 14:03:31 --> Utf8 Class Initialized
INFO - 2022-08-22 14:03:31 --> URI Class Initialized
DEBUG - 2022-08-22 14:03:31 --> No URI present. Default controller set.
INFO - 2022-08-22 14:03:31 --> Router Class Initialized
INFO - 2022-08-22 14:03:31 --> Output Class Initialized
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 14:03:31 --> Security Class Initialized
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
DEBUG - 2022-08-22 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:03:31 --> Input Class Initialized
INFO - 2022-08-22 14:03:31 --> Language Class Initialized
INFO - 2022-08-22 14:03:31 --> Loader Class Initialized
INFO - 2022-08-22 14:03:31 --> Config Class Initialized
INFO - 2022-08-22 14:03:31 --> Hooks Class Initialized
INFO - 2022-08-22 14:03:31 --> Helper loaded: url_helper
INFO - 2022-08-22 14:03:31 --> Controller Class Initialized
DEBUG - 2022-08-22 14:03:31 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:03:31 --> Utf8 Class Initialized
INFO - 2022-08-22 14:03:31 --> URI Class Initialized
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
DEBUG - 2022-08-22 14:03:31 --> No URI present. Default controller set.
INFO - 2022-08-22 14:03:31 --> Router Class Initialized
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 14:03:31 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 14:03:31 --> Output Class Initialized
INFO - 2022-08-22 14:03:31 --> Security Class Initialized
DEBUG - 2022-08-22 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:03:31 --> Input Class Initialized
INFO - 2022-08-22 14:03:31 --> Language Class Initialized
INFO - 2022-08-22 14:03:31 --> Loader Class Initialized
INFO - 2022-08-22 14:03:32 --> Helper loaded: url_helper
INFO - 2022-08-22 14:03:32 --> Controller Class Initialized
INFO - 2022-08-22 14:03:32 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 14:03:32 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 14:03:32 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 14:03:32 --> Final output sent to browser
DEBUG - 2022-08-22 14:03:32 --> Total execution time: 0.3365
INFO - 2022-08-22 14:06:39 --> Config Class Initialized
INFO - 2022-08-22 14:06:39 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:06:39 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:06:39 --> Utf8 Class Initialized
INFO - 2022-08-22 14:06:39 --> URI Class Initialized
INFO - 2022-08-22 14:06:39 --> Router Class Initialized
INFO - 2022-08-22 14:06:39 --> Output Class Initialized
INFO - 2022-08-22 14:06:39 --> Security Class Initialized
DEBUG - 2022-08-22 14:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:06:39 --> Input Class Initialized
INFO - 2022-08-22 14:06:39 --> Language Class Initialized
INFO - 2022-08-22 14:06:39 --> Loader Class Initialized
INFO - 2022-08-22 14:06:39 --> Helper loaded: url_helper
INFO - 2022-08-22 14:06:39 --> Controller Class Initialized
DEBUG - 2022-08-22 14:06:39 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 14:06:39 --> Helper loaded: inflector_helper
INFO - 2022-08-22 14:06:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 14:06:39 --> Final output sent to browser
DEBUG - 2022-08-22 14:06:39 --> Total execution time: 0.3105
INFO - 2022-08-22 14:55:48 --> Config Class Initialized
INFO - 2022-08-22 14:55:48 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:55:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:55:48 --> Utf8 Class Initialized
INFO - 2022-08-22 14:55:48 --> URI Class Initialized
DEBUG - 2022-08-22 14:55:48 --> No URI present. Default controller set.
INFO - 2022-08-22 14:55:48 --> Router Class Initialized
INFO - 2022-08-22 14:55:48 --> Output Class Initialized
INFO - 2022-08-22 14:55:48 --> Security Class Initialized
DEBUG - 2022-08-22 14:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:55:48 --> Input Class Initialized
INFO - 2022-08-22 14:55:48 --> Language Class Initialized
INFO - 2022-08-22 14:55:48 --> Loader Class Initialized
INFO - 2022-08-22 14:55:48 --> Helper loaded: url_helper
INFO - 2022-08-22 14:55:48 --> Controller Class Initialized
INFO - 2022-08-22 14:55:48 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 14:55:48 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 14:55:48 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 14:55:48 --> Final output sent to browser
DEBUG - 2022-08-22 14:55:48 --> Total execution time: 0.3791
INFO - 2022-08-22 14:55:54 --> Config Class Initialized
INFO - 2022-08-22 14:55:54 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:55:54 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:55:54 --> Utf8 Class Initialized
INFO - 2022-08-22 14:55:54 --> URI Class Initialized
INFO - 2022-08-22 14:55:54 --> Router Class Initialized
INFO - 2022-08-22 14:55:54 --> Output Class Initialized
INFO - 2022-08-22 14:55:54 --> Security Class Initialized
DEBUG - 2022-08-22 14:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:55:54 --> Input Class Initialized
INFO - 2022-08-22 14:55:54 --> Language Class Initialized
INFO - 2022-08-22 14:55:54 --> Loader Class Initialized
INFO - 2022-08-22 14:55:54 --> Helper loaded: url_helper
INFO - 2022-08-22 14:55:54 --> Controller Class Initialized
DEBUG - 2022-08-22 14:55:54 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 14:55:54 --> Helper loaded: inflector_helper
INFO - 2022-08-22 14:55:54 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 14:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 14:55:54 --> Final output sent to browser
DEBUG - 2022-08-22 14:55:54 --> Total execution time: 0.3111
INFO - 2022-08-22 14:56:12 --> Config Class Initialized
INFO - 2022-08-22 14:56:12 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:56:12 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:56:12 --> Utf8 Class Initialized
INFO - 2022-08-22 14:56:12 --> URI Class Initialized
INFO - 2022-08-22 14:56:12 --> Router Class Initialized
INFO - 2022-08-22 14:56:12 --> Output Class Initialized
INFO - 2022-08-22 14:56:12 --> Security Class Initialized
DEBUG - 2022-08-22 14:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:56:12 --> Input Class Initialized
INFO - 2022-08-22 14:56:12 --> Language Class Initialized
INFO - 2022-08-22 14:56:12 --> Loader Class Initialized
INFO - 2022-08-22 14:56:12 --> Helper loaded: url_helper
INFO - 2022-08-22 14:56:12 --> Controller Class Initialized
DEBUG - 2022-08-22 14:56:12 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 14:56:12 --> Helper loaded: inflector_helper
INFO - 2022-08-22 14:56:12 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 14:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 14:56:12 --> Final output sent to browser
DEBUG - 2022-08-22 14:56:12 --> Total execution time: 0.3348
INFO - 2022-08-22 14:56:13 --> Config Class Initialized
INFO - 2022-08-22 14:56:13 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:56:13 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:56:13 --> Utf8 Class Initialized
INFO - 2022-08-22 14:56:13 --> URI Class Initialized
INFO - 2022-08-22 14:56:13 --> Router Class Initialized
INFO - 2022-08-22 14:56:13 --> Output Class Initialized
INFO - 2022-08-22 14:56:13 --> Security Class Initialized
DEBUG - 2022-08-22 14:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:56:13 --> Input Class Initialized
INFO - 2022-08-22 14:56:13 --> Language Class Initialized
INFO - 2022-08-22 14:56:13 --> Loader Class Initialized
INFO - 2022-08-22 14:56:13 --> Helper loaded: url_helper
INFO - 2022-08-22 14:56:13 --> Controller Class Initialized
DEBUG - 2022-08-22 14:56:13 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 14:56:13 --> Helper loaded: inflector_helper
INFO - 2022-08-22 14:56:13 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2022-08-22 14:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 14:56:13 --> Final output sent to browser
DEBUG - 2022-08-22 14:56:13 --> Total execution time: 0.2568
INFO - 2022-08-22 14:56:48 --> Config Class Initialized
INFO - 2022-08-22 14:56:48 --> Hooks Class Initialized
DEBUG - 2022-08-22 14:56:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 14:56:48 --> Utf8 Class Initialized
INFO - 2022-08-22 14:56:48 --> URI Class Initialized
INFO - 2022-08-22 14:56:48 --> Router Class Initialized
INFO - 2022-08-22 14:56:48 --> Output Class Initialized
INFO - 2022-08-22 14:56:48 --> Security Class Initialized
DEBUG - 2022-08-22 14:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 14:56:48 --> Input Class Initialized
INFO - 2022-08-22 14:56:48 --> Language Class Initialized
INFO - 2022-08-22 14:56:48 --> Loader Class Initialized
INFO - 2022-08-22 14:56:48 --> Helper loaded: url_helper
INFO - 2022-08-22 14:56:48 --> Controller Class Initialized
DEBUG - 2022-08-22 14:56:48 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 14:56:48 --> Helper loaded: inflector_helper
INFO - 2022-08-22 14:56:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 14:56:48 --> Final output sent to browser
DEBUG - 2022-08-22 14:56:48 --> Total execution time: 0.2475
INFO - 2022-08-22 16:18:44 --> Config Class Initialized
INFO - 2022-08-22 16:18:44 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:18:44 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:18:44 --> Utf8 Class Initialized
INFO - 2022-08-22 16:18:44 --> URI Class Initialized
DEBUG - 2022-08-22 16:18:44 --> No URI present. Default controller set.
INFO - 2022-08-22 16:18:44 --> Router Class Initialized
INFO - 2022-08-22 16:18:44 --> Output Class Initialized
INFO - 2022-08-22 16:18:44 --> Security Class Initialized
DEBUG - 2022-08-22 16:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:18:44 --> Input Class Initialized
INFO - 2022-08-22 16:18:44 --> Language Class Initialized
INFO - 2022-08-22 16:18:44 --> Loader Class Initialized
INFO - 2022-08-22 16:18:44 --> Helper loaded: url_helper
ERROR - 2022-08-22 16:18:44 --> Severity: error --> Exception: syntax error, unexpected end of file /sam_tool/application/libraries/Rest.php 551
INFO - 2022-08-22 16:19:06 --> Config Class Initialized
INFO - 2022-08-22 16:19:06 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:19:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:19:06 --> Utf8 Class Initialized
INFO - 2022-08-22 16:19:06 --> URI Class Initialized
DEBUG - 2022-08-22 16:19:06 --> No URI present. Default controller set.
INFO - 2022-08-22 16:19:06 --> Router Class Initialized
INFO - 2022-08-22 16:19:06 --> Output Class Initialized
INFO - 2022-08-22 16:19:06 --> Security Class Initialized
DEBUG - 2022-08-22 16:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:19:06 --> Input Class Initialized
INFO - 2022-08-22 16:19:06 --> Language Class Initialized
INFO - 2022-08-22 16:19:06 --> Loader Class Initialized
INFO - 2022-08-22 16:19:06 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:19:06 --> REST Class Initialized
ERROR - 2022-08-22 16:19:06 --> Severity: error --> Exception: Call to undefined method CI_Loader::spark() /sam_tool/application/libraries/Rest.php 67
INFO - 2022-08-22 16:20:43 --> Config Class Initialized
INFO - 2022-08-22 16:20:43 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:20:43 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:20:43 --> Utf8 Class Initialized
INFO - 2022-08-22 16:20:43 --> URI Class Initialized
DEBUG - 2022-08-22 16:20:43 --> No URI present. Default controller set.
INFO - 2022-08-22 16:20:43 --> Router Class Initialized
INFO - 2022-08-22 16:20:44 --> Output Class Initialized
INFO - 2022-08-22 16:20:44 --> Security Class Initialized
DEBUG - 2022-08-22 16:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:20:44 --> Input Class Initialized
INFO - 2022-08-22 16:20:44 --> Language Class Initialized
INFO - 2022-08-22 16:20:44 --> Loader Class Initialized
INFO - 2022-08-22 16:20:44 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:20:44 --> REST Class Initialized
ERROR - 2022-08-22 16:20:44 --> Severity: error --> Exception: Call to undefined method CI_Loader::spark() /sam_tool/application/libraries/Rest.php 67
INFO - 2022-08-22 16:21:15 --> Config Class Initialized
INFO - 2022-08-22 16:21:15 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:21:15 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:21:15 --> Utf8 Class Initialized
INFO - 2022-08-22 16:21:15 --> URI Class Initialized
DEBUG - 2022-08-22 16:21:15 --> No URI present. Default controller set.
INFO - 2022-08-22 16:21:15 --> Router Class Initialized
INFO - 2022-08-22 16:21:15 --> Output Class Initialized
INFO - 2022-08-22 16:21:15 --> Security Class Initialized
DEBUG - 2022-08-22 16:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:21:16 --> Input Class Initialized
INFO - 2022-08-22 16:21:16 --> Language Class Initialized
INFO - 2022-08-22 16:21:16 --> Loader Class Initialized
INFO - 2022-08-22 16:21:16 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:21:16 --> REST Class Initialized
INFO - 2022-08-22 16:21:16 --> Controller Class Initialized
INFO - 2022-08-22 16:21:16 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 16:21:16 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 16:21:16 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 16:21:16 --> Final output sent to browser
DEBUG - 2022-08-22 16:21:16 --> Total execution time: 0.3272
ERROR - 2022-08-22 16:21:16 --> Severity: Notice --> Undefined property: Frontend::$curl /sam_tool/application/libraries/Rest.php 75
INFO - 2022-08-22 16:21:20 --> Config Class Initialized
INFO - 2022-08-22 16:21:20 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:21:20 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:21:20 --> Utf8 Class Initialized
INFO - 2022-08-22 16:21:20 --> URI Class Initialized
INFO - 2022-08-22 16:21:20 --> Router Class Initialized
INFO - 2022-08-22 16:21:20 --> Output Class Initialized
INFO - 2022-08-22 16:21:20 --> Security Class Initialized
DEBUG - 2022-08-22 16:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:21:20 --> Input Class Initialized
INFO - 2022-08-22 16:21:20 --> Language Class Initialized
INFO - 2022-08-22 16:21:20 --> Loader Class Initialized
INFO - 2022-08-22 16:21:21 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:21:21 --> REST Class Initialized
ERROR - 2022-08-22 16:21:21 --> Severity: Notice --> Undefined property: Sam::$curl /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:21:21 --> Severity: error --> Exception: Call to a member function set_defaults() on null /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:21:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 16:23:57 --> Config Class Initialized
INFO - 2022-08-22 16:23:57 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:23:57 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:23:57 --> Utf8 Class Initialized
INFO - 2022-08-22 16:23:57 --> URI Class Initialized
INFO - 2022-08-22 16:23:57 --> Router Class Initialized
INFO - 2022-08-22 16:23:57 --> Output Class Initialized
INFO - 2022-08-22 16:23:57 --> Security Class Initialized
DEBUG - 2022-08-22 16:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:23:57 --> Input Class Initialized
INFO - 2022-08-22 16:23:57 --> Language Class Initialized
INFO - 2022-08-22 16:23:57 --> Loader Class Initialized
INFO - 2022-08-22 16:23:57 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:23:57 --> REST Class Initialized
ERROR - 2022-08-22 16:23:57 --> Severity: Notice --> Undefined property: Sam::$curl /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:23:57 --> Severity: error --> Exception: Call to a member function set_defaults() on null /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:23:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 16:25:16 --> Config Class Initialized
INFO - 2022-08-22 16:25:16 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:25:16 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:25:16 --> Utf8 Class Initialized
INFO - 2022-08-22 16:25:16 --> URI Class Initialized
INFO - 2022-08-22 16:25:16 --> Router Class Initialized
INFO - 2022-08-22 16:25:16 --> Output Class Initialized
INFO - 2022-08-22 16:25:16 --> Security Class Initialized
DEBUG - 2022-08-22 16:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:25:16 --> Input Class Initialized
INFO - 2022-08-22 16:25:16 --> Language Class Initialized
INFO - 2022-08-22 16:25:16 --> Loader Class Initialized
INFO - 2022-08-22 16:25:16 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:25:16 --> REST Class Initialized
ERROR - 2022-08-22 16:25:16 --> Severity: Notice --> Undefined property: Sam::$curl /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:25:16 --> Severity: error --> Exception: Call to a member function set_defaults() on null /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:25:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 16:25:20 --> Config Class Initialized
INFO - 2022-08-22 16:25:20 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:25:20 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:25:20 --> Utf8 Class Initialized
INFO - 2022-08-22 16:25:20 --> URI Class Initialized
DEBUG - 2022-08-22 16:25:20 --> No URI present. Default controller set.
INFO - 2022-08-22 16:25:20 --> Router Class Initialized
INFO - 2022-08-22 16:25:20 --> Output Class Initialized
INFO - 2022-08-22 16:25:20 --> Security Class Initialized
DEBUG - 2022-08-22 16:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:25:20 --> Input Class Initialized
INFO - 2022-08-22 16:25:20 --> Language Class Initialized
INFO - 2022-08-22 16:25:20 --> Loader Class Initialized
INFO - 2022-08-22 16:25:20 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:25:20 --> REST Class Initialized
INFO - 2022-08-22 16:25:20 --> Controller Class Initialized
INFO - 2022-08-22 16:25:20 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 16:25:20 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 16:25:20 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 16:25:20 --> Final output sent to browser
DEBUG - 2022-08-22 16:25:20 --> Total execution time: 0.3255
ERROR - 2022-08-22 16:25:20 --> Severity: Notice --> Undefined property: Frontend::$curl /sam_tool/application/libraries/Rest.php 75
INFO - 2022-08-22 16:26:14 --> Config Class Initialized
INFO - 2022-08-22 16:26:14 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:26:14 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:26:14 --> Utf8 Class Initialized
INFO - 2022-08-22 16:26:14 --> URI Class Initialized
INFO - 2022-08-22 16:26:14 --> Router Class Initialized
INFO - 2022-08-22 16:26:14 --> Output Class Initialized
INFO - 2022-08-22 16:26:14 --> Security Class Initialized
DEBUG - 2022-08-22 16:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:26:14 --> Input Class Initialized
INFO - 2022-08-22 16:26:14 --> Language Class Initialized
INFO - 2022-08-22 16:26:14 --> Loader Class Initialized
INFO - 2022-08-22 16:26:14 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:26:14 --> REST Class Initialized
ERROR - 2022-08-22 16:26:14 --> Severity: Notice --> Undefined property: Sam::$curl /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:26:14 --> Severity: error --> Exception: Call to a member function set_defaults() on null /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:26:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 16:26:45 --> Config Class Initialized
INFO - 2022-08-22 16:26:45 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:26:45 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:26:45 --> Utf8 Class Initialized
INFO - 2022-08-22 16:26:45 --> URI Class Initialized
INFO - 2022-08-22 16:26:45 --> Router Class Initialized
INFO - 2022-08-22 16:26:45 --> Output Class Initialized
INFO - 2022-08-22 16:26:45 --> Security Class Initialized
DEBUG - 2022-08-22 16:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:26:45 --> Input Class Initialized
INFO - 2022-08-22 16:26:45 --> Language Class Initialized
INFO - 2022-08-22 16:26:45 --> Loader Class Initialized
INFO - 2022-08-22 16:26:45 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:26:45 --> REST Class Initialized
ERROR - 2022-08-22 16:26:45 --> Severity: Notice --> Undefined property: Sam::$curl /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:26:45 --> Severity: error --> Exception: Call to a member function set_defaults() on null /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:26:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 16:27:02 --> Config Class Initialized
INFO - 2022-08-22 16:27:02 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:27:02 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:27:02 --> Utf8 Class Initialized
INFO - 2022-08-22 16:27:02 --> URI Class Initialized
DEBUG - 2022-08-22 16:27:02 --> No URI present. Default controller set.
INFO - 2022-08-22 16:27:02 --> Router Class Initialized
INFO - 2022-08-22 16:27:02 --> Output Class Initialized
INFO - 2022-08-22 16:27:02 --> Security Class Initialized
DEBUG - 2022-08-22 16:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:27:02 --> Input Class Initialized
INFO - 2022-08-22 16:27:02 --> Language Class Initialized
INFO - 2022-08-22 16:27:02 --> Loader Class Initialized
INFO - 2022-08-22 16:27:02 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:27:02 --> REST Class Initialized
INFO - 2022-08-22 16:27:02 --> Controller Class Initialized
INFO - 2022-08-22 16:27:02 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 16:27:02 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 16:27:02 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 16:27:02 --> Final output sent to browser
DEBUG - 2022-08-22 16:27:02 --> Total execution time: 0.2370
ERROR - 2022-08-22 16:27:02 --> Severity: Notice --> Undefined property: Frontend::$curl /sam_tool/application/libraries/Rest.php 75
INFO - 2022-08-22 16:28:06 --> Config Class Initialized
INFO - 2022-08-22 16:28:06 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:28:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:28:06 --> Utf8 Class Initialized
INFO - 2022-08-22 16:28:06 --> URI Class Initialized
INFO - 2022-08-22 16:28:06 --> Router Class Initialized
INFO - 2022-08-22 16:28:06 --> Output Class Initialized
INFO - 2022-08-22 16:28:06 --> Security Class Initialized
DEBUG - 2022-08-22 16:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:28:06 --> Input Class Initialized
INFO - 2022-08-22 16:28:06 --> Language Class Initialized
INFO - 2022-08-22 16:28:06 --> Loader Class Initialized
INFO - 2022-08-22 16:28:06 --> Helper loaded: url_helper
DEBUG - 2022-08-22 16:28:06 --> REST Class Initialized
ERROR - 2022-08-22 16:28:06 --> Severity: Notice --> Undefined property: Sam::$curl /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:28:07 --> Severity: error --> Exception: Call to a member function set_defaults() on null /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:28:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 16:32:53 --> Config Class Initialized
INFO - 2022-08-22 16:32:53 --> Hooks Class Initialized
DEBUG - 2022-08-22 16:32:53 --> UTF-8 Support Enabled
INFO - 2022-08-22 16:32:53 --> Utf8 Class Initialized
INFO - 2022-08-22 16:32:53 --> URI Class Initialized
INFO - 2022-08-22 16:32:53 --> Router Class Initialized
INFO - 2022-08-22 16:32:53 --> Output Class Initialized
INFO - 2022-08-22 16:32:53 --> Security Class Initialized
DEBUG - 2022-08-22 16:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 16:32:53 --> Input Class Initialized
INFO - 2022-08-22 16:32:53 --> Language Class Initialized
INFO - 2022-08-22 16:32:53 --> Loader Class Initialized
INFO - 2022-08-22 16:32:53 --> Helper loaded: url_helper
ERROR - 2022-08-22 16:32:53 --> Severity: Notice --> Trying to get property 'curl' of non-object /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:32:53 --> Severity: error --> Exception: Call to a member function set_defaults() on null /sam_tool/application/libraries/Rest.php 75
ERROR - 2022-08-22 16:32:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 17:00:21 --> Config Class Initialized
INFO - 2022-08-22 17:00:21 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:00:21 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:00:21 --> Utf8 Class Initialized
INFO - 2022-08-22 17:00:21 --> URI Class Initialized
INFO - 2022-08-22 17:00:21 --> Router Class Initialized
INFO - 2022-08-22 17:00:21 --> Output Class Initialized
INFO - 2022-08-22 17:00:21 --> Security Class Initialized
DEBUG - 2022-08-22 17:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:00:21 --> Input Class Initialized
INFO - 2022-08-22 17:00:21 --> Language Class Initialized
INFO - 2022-08-22 17:00:21 --> Loader Class Initialized
INFO - 2022-08-22 17:00:22 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:00:22 --> Unable to load the requested class: Rest
ERROR - 2022-08-22 17:00:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 17:00:49 --> Config Class Initialized
INFO - 2022-08-22 17:00:49 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:00:49 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:00:49 --> Utf8 Class Initialized
INFO - 2022-08-22 17:00:49 --> URI Class Initialized
INFO - 2022-08-22 17:00:49 --> Router Class Initialized
INFO - 2022-08-22 17:00:50 --> Output Class Initialized
INFO - 2022-08-22 17:00:50 --> Security Class Initialized
DEBUG - 2022-08-22 17:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:00:50 --> Input Class Initialized
INFO - 2022-08-22 17:00:50 --> Language Class Initialized
INFO - 2022-08-22 17:00:50 --> Loader Class Initialized
INFO - 2022-08-22 17:00:50 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:00:50 --> Unable to load the requested class: Rest
ERROR - 2022-08-22 17:00:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 17:00:56 --> Config Class Initialized
INFO - 2022-08-22 17:00:56 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:00:56 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:00:56 --> Utf8 Class Initialized
INFO - 2022-08-22 17:00:56 --> URI Class Initialized
INFO - 2022-08-22 17:00:56 --> Router Class Initialized
INFO - 2022-08-22 17:00:56 --> Output Class Initialized
INFO - 2022-08-22 17:00:56 --> Security Class Initialized
DEBUG - 2022-08-22 17:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:00:56 --> Input Class Initialized
INFO - 2022-08-22 17:00:56 --> Language Class Initialized
INFO - 2022-08-22 17:00:56 --> Loader Class Initialized
INFO - 2022-08-22 17:00:56 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:00:56 --> Unable to load the requested class: Rest
ERROR - 2022-08-22 17:00:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 17:01:17 --> Config Class Initialized
INFO - 2022-08-22 17:01:17 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:01:17 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:01:17 --> Utf8 Class Initialized
INFO - 2022-08-22 17:01:17 --> URI Class Initialized
INFO - 2022-08-22 17:01:17 --> Router Class Initialized
INFO - 2022-08-22 17:01:17 --> Output Class Initialized
INFO - 2022-08-22 17:01:17 --> Security Class Initialized
DEBUG - 2022-08-22 17:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:01:17 --> Input Class Initialized
INFO - 2022-08-22 17:01:17 --> Language Class Initialized
INFO - 2022-08-22 17:01:17 --> Loader Class Initialized
INFO - 2022-08-22 17:01:17 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:01:17 --> Unable to load the requested class: Rest
ERROR - 2022-08-22 17:01:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Sam.php:1) /sam_tool/system/core/Common.php 570
INFO - 2022-08-22 17:01:35 --> Config Class Initialized
INFO - 2022-08-22 17:01:35 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:01:35 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:01:35 --> Utf8 Class Initialized
INFO - 2022-08-22 17:01:35 --> URI Class Initialized
INFO - 2022-08-22 17:01:36 --> Router Class Initialized
INFO - 2022-08-22 17:01:36 --> Output Class Initialized
INFO - 2022-08-22 17:01:36 --> Security Class Initialized
DEBUG - 2022-08-22 17:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:01:36 --> Input Class Initialized
INFO - 2022-08-22 17:01:36 --> Language Class Initialized
INFO - 2022-08-22 17:01:36 --> Loader Class Initialized
INFO - 2022-08-22 17:01:36 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:01:36 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:02:04 --> Config Class Initialized
INFO - 2022-08-22 17:02:04 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:02:04 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:02:04 --> Utf8 Class Initialized
INFO - 2022-08-22 17:02:04 --> URI Class Initialized
INFO - 2022-08-22 17:02:04 --> Router Class Initialized
INFO - 2022-08-22 17:02:04 --> Output Class Initialized
INFO - 2022-08-22 17:02:05 --> Security Class Initialized
DEBUG - 2022-08-22 17:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:02:05 --> Input Class Initialized
INFO - 2022-08-22 17:02:05 --> Language Class Initialized
INFO - 2022-08-22 17:02:05 --> Loader Class Initialized
INFO - 2022-08-22 17:02:05 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:02:05 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:02:08 --> Config Class Initialized
INFO - 2022-08-22 17:02:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:02:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:02:08 --> Utf8 Class Initialized
INFO - 2022-08-22 17:02:08 --> URI Class Initialized
DEBUG - 2022-08-22 17:02:08 --> No URI present. Default controller set.
INFO - 2022-08-22 17:02:08 --> Router Class Initialized
INFO - 2022-08-22 17:02:08 --> Output Class Initialized
INFO - 2022-08-22 17:02:08 --> Security Class Initialized
DEBUG - 2022-08-22 17:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:02:08 --> Input Class Initialized
INFO - 2022-08-22 17:02:08 --> Language Class Initialized
INFO - 2022-08-22 17:02:08 --> Loader Class Initialized
INFO - 2022-08-22 17:02:08 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:02:08 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:02:08 --> Config Class Initialized
INFO - 2022-08-22 17:02:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:02:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:02:08 --> Utf8 Class Initialized
INFO - 2022-08-22 17:02:08 --> URI Class Initialized
DEBUG - 2022-08-22 17:02:08 --> No URI present. Default controller set.
INFO - 2022-08-22 17:02:08 --> Router Class Initialized
INFO - 2022-08-22 17:02:08 --> Output Class Initialized
INFO - 2022-08-22 17:02:08 --> Security Class Initialized
DEBUG - 2022-08-22 17:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:02:08 --> Input Class Initialized
INFO - 2022-08-22 17:02:08 --> Language Class Initialized
INFO - 2022-08-22 17:02:08 --> Loader Class Initialized
INFO - 2022-08-22 17:02:08 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:02:08 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:03:29 --> Config Class Initialized
INFO - 2022-08-22 17:03:29 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:03:29 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:03:29 --> Utf8 Class Initialized
INFO - 2022-08-22 17:03:29 --> URI Class Initialized
DEBUG - 2022-08-22 17:03:29 --> No URI present. Default controller set.
INFO - 2022-08-22 17:03:29 --> Router Class Initialized
INFO - 2022-08-22 17:03:29 --> Output Class Initialized
INFO - 2022-08-22 17:03:29 --> Security Class Initialized
DEBUG - 2022-08-22 17:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:03:29 --> Input Class Initialized
INFO - 2022-08-22 17:03:29 --> Language Class Initialized
INFO - 2022-08-22 17:03:29 --> Loader Class Initialized
INFO - 2022-08-22 17:03:29 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:03:29 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:03:45 --> Config Class Initialized
INFO - 2022-08-22 17:03:45 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:03:45 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:03:45 --> Utf8 Class Initialized
INFO - 2022-08-22 17:03:45 --> URI Class Initialized
DEBUG - 2022-08-22 17:03:45 --> No URI present. Default controller set.
INFO - 2022-08-22 17:03:45 --> Router Class Initialized
INFO - 2022-08-22 17:03:45 --> Output Class Initialized
INFO - 2022-08-22 17:03:45 --> Security Class Initialized
DEBUG - 2022-08-22 17:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:03:45 --> Input Class Initialized
INFO - 2022-08-22 17:03:45 --> Language Class Initialized
INFO - 2022-08-22 17:03:45 --> Loader Class Initialized
INFO - 2022-08-22 17:03:45 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:03:45 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:03:47 --> Config Class Initialized
INFO - 2022-08-22 17:03:47 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:03:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:03:48 --> Utf8 Class Initialized
INFO - 2022-08-22 17:03:48 --> URI Class Initialized
DEBUG - 2022-08-22 17:03:48 --> No URI present. Default controller set.
INFO - 2022-08-22 17:03:48 --> Router Class Initialized
INFO - 2022-08-22 17:03:48 --> Output Class Initialized
INFO - 2022-08-22 17:03:48 --> Security Class Initialized
DEBUG - 2022-08-22 17:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:03:48 --> Input Class Initialized
INFO - 2022-08-22 17:03:48 --> Language Class Initialized
INFO - 2022-08-22 17:03:48 --> Loader Class Initialized
INFO - 2022-08-22 17:03:48 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:03:48 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:03:48 --> Config Class Initialized
INFO - 2022-08-22 17:03:48 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:03:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:03:48 --> Utf8 Class Initialized
INFO - 2022-08-22 17:03:48 --> URI Class Initialized
DEBUG - 2022-08-22 17:03:48 --> No URI present. Default controller set.
INFO - 2022-08-22 17:03:48 --> Router Class Initialized
INFO - 2022-08-22 17:03:48 --> Output Class Initialized
INFO - 2022-08-22 17:03:48 --> Security Class Initialized
DEBUG - 2022-08-22 17:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:03:48 --> Input Class Initialized
INFO - 2022-08-22 17:03:48 --> Language Class Initialized
INFO - 2022-08-22 17:03:48 --> Loader Class Initialized
INFO - 2022-08-22 17:03:48 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:03:48 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:03:48 --> Config Class Initialized
INFO - 2022-08-22 17:03:48 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:03:48 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:03:48 --> Utf8 Class Initialized
INFO - 2022-08-22 17:03:48 --> URI Class Initialized
DEBUG - 2022-08-22 17:03:48 --> No URI present. Default controller set.
INFO - 2022-08-22 17:03:48 --> Router Class Initialized
INFO - 2022-08-22 17:03:48 --> Output Class Initialized
INFO - 2022-08-22 17:03:48 --> Security Class Initialized
DEBUG - 2022-08-22 17:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:03:48 --> Input Class Initialized
INFO - 2022-08-22 17:03:48 --> Language Class Initialized
INFO - 2022-08-22 17:03:48 --> Loader Class Initialized
INFO - 2022-08-22 17:03:48 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:03:48 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:05:03 --> Config Class Initialized
INFO - 2022-08-22 17:05:03 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:05:03 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:05:03 --> Utf8 Class Initialized
INFO - 2022-08-22 17:05:03 --> URI Class Initialized
DEBUG - 2022-08-22 17:05:03 --> No URI present. Default controller set.
INFO - 2022-08-22 17:05:03 --> Router Class Initialized
INFO - 2022-08-22 17:05:03 --> Output Class Initialized
INFO - 2022-08-22 17:05:03 --> Security Class Initialized
DEBUG - 2022-08-22 17:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:05:03 --> Input Class Initialized
INFO - 2022-08-22 17:05:03 --> Language Class Initialized
INFO - 2022-08-22 17:05:03 --> Loader Class Initialized
INFO - 2022-08-22 17:05:03 --> Helper loaded: url_helper
ERROR - 2022-08-22 17:05:03 --> Unable to load the requested class: Rest
INFO - 2022-08-22 17:11:11 --> Config Class Initialized
INFO - 2022-08-22 17:11:11 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:11:11 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:11:11 --> Utf8 Class Initialized
INFO - 2022-08-22 17:11:11 --> URI Class Initialized
DEBUG - 2022-08-22 17:11:11 --> No URI present. Default controller set.
INFO - 2022-08-22 17:11:11 --> Router Class Initialized
INFO - 2022-08-22 17:11:12 --> Output Class Initialized
INFO - 2022-08-22 17:11:12 --> Security Class Initialized
DEBUG - 2022-08-22 17:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:11:12 --> Input Class Initialized
INFO - 2022-08-22 17:11:12 --> Language Class Initialized
INFO - 2022-08-22 17:11:12 --> Loader Class Initialized
INFO - 2022-08-22 17:11:12 --> Helper loaded: url_helper
INFO - 2022-08-22 17:11:12 --> Controller Class Initialized
INFO - 2022-08-22 17:11:12 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 17:11:12 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 17:11:12 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 17:11:12 --> Final output sent to browser
DEBUG - 2022-08-22 17:11:12 --> Total execution time: 0.3291
INFO - 2022-08-22 17:11:16 --> Config Class Initialized
INFO - 2022-08-22 17:11:16 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:11:16 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:11:16 --> Utf8 Class Initialized
INFO - 2022-08-22 17:11:16 --> URI Class Initialized
INFO - 2022-08-22 17:11:16 --> Router Class Initialized
INFO - 2022-08-22 17:11:16 --> Output Class Initialized
INFO - 2022-08-22 17:11:16 --> Security Class Initialized
DEBUG - 2022-08-22 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:11:16 --> Input Class Initialized
INFO - 2022-08-22 17:11:16 --> Language Class Initialized
INFO - 2022-08-22 17:11:16 --> Loader Class Initialized
INFO - 2022-08-22 17:11:16 --> Helper loaded: url_helper
INFO - 2022-08-22 17:11:16 --> Controller Class Initialized
DEBUG - 2022-08-22 17:11:16 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:11:16 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:11:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:11:16 --> Final output sent to browser
DEBUG - 2022-08-22 17:11:16 --> Total execution time: 0.2977
INFO - 2022-08-22 17:11:27 --> Config Class Initialized
INFO - 2022-08-22 17:11:27 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:11:27 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:11:27 --> Utf8 Class Initialized
INFO - 2022-08-22 17:11:28 --> URI Class Initialized
INFO - 2022-08-22 17:11:28 --> Router Class Initialized
INFO - 2022-08-22 17:11:28 --> Output Class Initialized
INFO - 2022-08-22 17:11:28 --> Security Class Initialized
DEBUG - 2022-08-22 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:11:28 --> Input Class Initialized
INFO - 2022-08-22 17:11:28 --> Language Class Initialized
INFO - 2022-08-22 17:11:28 --> Loader Class Initialized
INFO - 2022-08-22 17:11:28 --> Helper loaded: url_helper
INFO - 2022-08-22 17:11:28 --> Controller Class Initialized
DEBUG - 2022-08-22 17:11:28 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:11:28 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:11:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:11:28 --> Final output sent to browser
DEBUG - 2022-08-22 17:11:28 --> Total execution time: 0.2871
INFO - 2022-08-22 17:12:42 --> Config Class Initialized
INFO - 2022-08-22 17:12:42 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:12:42 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:12:42 --> Utf8 Class Initialized
INFO - 2022-08-22 17:12:42 --> URI Class Initialized
DEBUG - 2022-08-22 17:12:42 --> No URI present. Default controller set.
INFO - 2022-08-22 17:12:42 --> Router Class Initialized
INFO - 2022-08-22 17:12:42 --> Output Class Initialized
INFO - 2022-08-22 17:12:42 --> Security Class Initialized
DEBUG - 2022-08-22 17:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:12:42 --> Input Class Initialized
INFO - 2022-08-22 17:12:42 --> Language Class Initialized
INFO - 2022-08-22 17:12:42 --> Loader Class Initialized
INFO - 2022-08-22 17:12:42 --> Helper loaded: url_helper
INFO - 2022-08-22 17:12:42 --> Controller Class Initialized
INFO - 2022-08-22 17:12:43 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 17:12:43 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 17:12:43 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 17:12:43 --> Final output sent to browser
DEBUG - 2022-08-22 17:12:43 --> Total execution time: 0.2559
INFO - 2022-08-22 17:13:10 --> Config Class Initialized
INFO - 2022-08-22 17:13:10 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:13:10 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:13:10 --> Utf8 Class Initialized
INFO - 2022-08-22 17:13:10 --> URI Class Initialized
INFO - 2022-08-22 17:13:10 --> Router Class Initialized
INFO - 2022-08-22 17:13:10 --> Output Class Initialized
INFO - 2022-08-22 17:13:10 --> Security Class Initialized
DEBUG - 2022-08-22 17:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:13:10 --> Input Class Initialized
INFO - 2022-08-22 17:13:10 --> Language Class Initialized
INFO - 2022-08-22 17:13:11 --> Loader Class Initialized
INFO - 2022-08-22 17:13:11 --> Helper loaded: url_helper
INFO - 2022-08-22 17:13:11 --> Controller Class Initialized
DEBUG - 2022-08-22 17:13:11 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:13:11 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:13:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:13:11 --> Final output sent to browser
DEBUG - 2022-08-22 17:13:11 --> Total execution time: 0.2485
INFO - 2022-08-22 17:32:15 --> Config Class Initialized
INFO - 2022-08-22 17:32:15 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:32:15 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:32:15 --> Utf8 Class Initialized
INFO - 2022-08-22 17:32:15 --> URI Class Initialized
DEBUG - 2022-08-22 17:32:15 --> No URI present. Default controller set.
INFO - 2022-08-22 17:32:15 --> Router Class Initialized
INFO - 2022-08-22 17:32:15 --> Output Class Initialized
INFO - 2022-08-22 17:32:15 --> Security Class Initialized
DEBUG - 2022-08-22 17:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:32:15 --> Input Class Initialized
INFO - 2022-08-22 17:32:15 --> Language Class Initialized
INFO - 2022-08-22 17:32:15 --> Loader Class Initialized
INFO - 2022-08-22 17:32:15 --> Helper loaded: url_helper
INFO - 2022-08-22 17:32:15 --> Controller Class Initialized
INFO - 2022-08-22 17:32:15 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 17:32:15 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 17:32:15 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 17:32:15 --> Final output sent to browser
DEBUG - 2022-08-22 17:32:15 --> Total execution time: 0.2942
INFO - 2022-08-22 17:32:18 --> Config Class Initialized
INFO - 2022-08-22 17:32:18 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:32:18 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:32:18 --> Utf8 Class Initialized
INFO - 2022-08-22 17:32:18 --> URI Class Initialized
INFO - 2022-08-22 17:32:18 --> Router Class Initialized
INFO - 2022-08-22 17:32:18 --> Output Class Initialized
INFO - 2022-08-22 17:32:18 --> Security Class Initialized
DEBUG - 2022-08-22 17:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:32:18 --> Input Class Initialized
INFO - 2022-08-22 17:32:18 --> Language Class Initialized
INFO - 2022-08-22 17:32:18 --> Loader Class Initialized
INFO - 2022-08-22 17:32:19 --> Helper loaded: url_helper
INFO - 2022-08-22 17:32:19 --> Controller Class Initialized
DEBUG - 2022-08-22 17:32:19 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:32:19 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:32:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:32:19 --> Final output sent to browser
DEBUG - 2022-08-22 17:32:19 --> Total execution time: 0.3103
INFO - 2022-08-22 17:33:05 --> Config Class Initialized
INFO - 2022-08-22 17:33:05 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:33:05 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:33:05 --> Utf8 Class Initialized
INFO - 2022-08-22 17:33:05 --> URI Class Initialized
INFO - 2022-08-22 17:33:05 --> Router Class Initialized
INFO - 2022-08-22 17:33:05 --> Output Class Initialized
INFO - 2022-08-22 17:33:05 --> Security Class Initialized
DEBUG - 2022-08-22 17:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:33:05 --> Input Class Initialized
INFO - 2022-08-22 17:33:05 --> Language Class Initialized
INFO - 2022-08-22 17:33:05 --> Loader Class Initialized
INFO - 2022-08-22 17:33:05 --> Helper loaded: url_helper
INFO - 2022-08-22 17:33:05 --> Controller Class Initialized
DEBUG - 2022-08-22 17:33:05 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:33:05 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:33:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:33:05 --> Config Class Initialized
INFO - 2022-08-22 17:33:05 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:33:05 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:33:05 --> Utf8 Class Initialized
INFO - 2022-08-22 17:33:05 --> URI Class Initialized
INFO - 2022-08-22 17:33:05 --> Router Class Initialized
INFO - 2022-08-22 17:33:05 --> Output Class Initialized
INFO - 2022-08-22 17:33:05 --> Security Class Initialized
DEBUG - 2022-08-22 17:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:33:05 --> Input Class Initialized
INFO - 2022-08-22 17:33:05 --> Language Class Initialized
INFO - 2022-08-22 17:33:05 --> Loader Class Initialized
INFO - 2022-08-22 17:33:05 --> Helper loaded: url_helper
INFO - 2022-08-22 17:33:05 --> Controller Class Initialized
DEBUG - 2022-08-22 17:33:05 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:33:05 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:33:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:33:06 --> Config Class Initialized
INFO - 2022-08-22 17:33:06 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:33:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:33:06 --> Utf8 Class Initialized
INFO - 2022-08-22 17:33:06 --> URI Class Initialized
INFO - 2022-08-22 17:33:06 --> Router Class Initialized
INFO - 2022-08-22 17:33:06 --> Output Class Initialized
INFO - 2022-08-22 17:33:06 --> Security Class Initialized
DEBUG - 2022-08-22 17:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:33:06 --> Input Class Initialized
INFO - 2022-08-22 17:33:06 --> Language Class Initialized
INFO - 2022-08-22 17:33:06 --> Loader Class Initialized
INFO - 2022-08-22 17:33:06 --> Helper loaded: url_helper
INFO - 2022-08-22 17:33:06 --> Controller Class Initialized
DEBUG - 2022-08-22 17:33:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:33:06 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:33:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:33:07 --> Config Class Initialized
INFO - 2022-08-22 17:33:07 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:33:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:33:07 --> Utf8 Class Initialized
INFO - 2022-08-22 17:33:07 --> URI Class Initialized
INFO - 2022-08-22 17:33:07 --> Router Class Initialized
INFO - 2022-08-22 17:33:07 --> Output Class Initialized
INFO - 2022-08-22 17:33:07 --> Security Class Initialized
DEBUG - 2022-08-22 17:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:33:07 --> Input Class Initialized
INFO - 2022-08-22 17:33:07 --> Language Class Initialized
INFO - 2022-08-22 17:33:07 --> Loader Class Initialized
INFO - 2022-08-22 17:33:07 --> Helper loaded: url_helper
INFO - 2022-08-22 17:33:07 --> Controller Class Initialized
DEBUG - 2022-08-22 17:33:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:33:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:33:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:33:08 --> Config Class Initialized
INFO - 2022-08-22 17:33:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:33:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:33:08 --> Utf8 Class Initialized
INFO - 2022-08-22 17:33:08 --> URI Class Initialized
INFO - 2022-08-22 17:33:08 --> Router Class Initialized
INFO - 2022-08-22 17:33:08 --> Output Class Initialized
INFO - 2022-08-22 17:33:08 --> Security Class Initialized
DEBUG - 2022-08-22 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:33:08 --> Input Class Initialized
INFO - 2022-08-22 17:33:08 --> Language Class Initialized
INFO - 2022-08-22 17:33:08 --> Loader Class Initialized
INFO - 2022-08-22 17:33:08 --> Helper loaded: url_helper
INFO - 2022-08-22 17:33:08 --> Controller Class Initialized
DEBUG - 2022-08-22 17:33:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:33:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:33:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:34:05 --> Final output sent to browser
DEBUG - 2022-08-22 17:34:05 --> Total execution time: 60.3510
INFO - 2022-08-22 17:34:05 --> Config Class Initialized
INFO - 2022-08-22 17:34:05 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:34:05 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:34:05 --> Utf8 Class Initialized
INFO - 2022-08-22 17:34:05 --> URI Class Initialized
INFO - 2022-08-22 17:34:05 --> Router Class Initialized
INFO - 2022-08-22 17:34:05 --> Output Class Initialized
INFO - 2022-08-22 17:34:05 --> Security Class Initialized
DEBUG - 2022-08-22 17:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:34:05 --> Input Class Initialized
INFO - 2022-08-22 17:34:05 --> Language Class Initialized
INFO - 2022-08-22 17:34:05 --> Final output sent to browser
DEBUG - 2022-08-22 17:34:05 --> Total execution time: 60.2495
INFO - 2022-08-22 17:34:05 --> Loader Class Initialized
INFO - 2022-08-22 17:34:05 --> Helper loaded: url_helper
INFO - 2022-08-22 17:34:05 --> Controller Class Initialized
DEBUG - 2022-08-22 17:34:05 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:34:06 --> Config Class Initialized
INFO - 2022-08-22 17:34:06 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:34:06 --> Hooks Class Initialized
INFO - 2022-08-22 17:34:06 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2022-08-22 17:34:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:34:06 --> Utf8 Class Initialized
INFO - 2022-08-22 17:34:06 --> URI Class Initialized
INFO - 2022-08-22 17:34:06 --> Router Class Initialized
INFO - 2022-08-22 17:34:06 --> Output Class Initialized
INFO - 2022-08-22 17:34:06 --> Security Class Initialized
DEBUG - 2022-08-22 17:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:34:06 --> Input Class Initialized
INFO - 2022-08-22 17:34:06 --> Language Class Initialized
INFO - 2022-08-22 17:34:06 --> Loader Class Initialized
INFO - 2022-08-22 17:34:06 --> Helper loaded: url_helper
INFO - 2022-08-22 17:34:06 --> Controller Class Initialized
DEBUG - 2022-08-22 17:34:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:34:06 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:34:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:34:06 --> Final output sent to browser
DEBUG - 2022-08-22 17:34:06 --> Total execution time: 60.3121
INFO - 2022-08-22 17:34:06 --> Config Class Initialized
INFO - 2022-08-22 17:34:06 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:34:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:34:06 --> Utf8 Class Initialized
INFO - 2022-08-22 17:34:06 --> URI Class Initialized
INFO - 2022-08-22 17:34:06 --> Router Class Initialized
INFO - 2022-08-22 17:34:07 --> Output Class Initialized
INFO - 2022-08-22 17:34:07 --> Security Class Initialized
DEBUG - 2022-08-22 17:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:34:07 --> Input Class Initialized
INFO - 2022-08-22 17:34:07 --> Language Class Initialized
INFO - 2022-08-22 17:34:07 --> Loader Class Initialized
INFO - 2022-08-22 17:34:07 --> Helper loaded: url_helper
INFO - 2022-08-22 17:34:07 --> Controller Class Initialized
DEBUG - 2022-08-22 17:34:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:34:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:34:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:34:07 --> Final output sent to browser
DEBUG - 2022-08-22 17:34:07 --> Total execution time: 60.3259
INFO - 2022-08-22 17:34:07 --> Config Class Initialized
INFO - 2022-08-22 17:34:07 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:34:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:34:07 --> Utf8 Class Initialized
INFO - 2022-08-22 17:34:07 --> URI Class Initialized
INFO - 2022-08-22 17:34:08 --> Router Class Initialized
INFO - 2022-08-22 17:34:08 --> Output Class Initialized
INFO - 2022-08-22 17:34:08 --> Security Class Initialized
DEBUG - 2022-08-22 17:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:34:08 --> Input Class Initialized
INFO - 2022-08-22 17:34:08 --> Language Class Initialized
INFO - 2022-08-22 17:34:08 --> Loader Class Initialized
INFO - 2022-08-22 17:34:08 --> Helper loaded: url_helper
INFO - 2022-08-22 17:34:08 --> Controller Class Initialized
DEBUG - 2022-08-22 17:34:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:34:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:34:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:34:08 --> Final output sent to browser
DEBUG - 2022-08-22 17:34:08 --> Total execution time: 60.3158
INFO - 2022-08-22 17:34:08 --> Config Class Initialized
INFO - 2022-08-22 17:34:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:34:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:34:08 --> Utf8 Class Initialized
INFO - 2022-08-22 17:34:08 --> URI Class Initialized
INFO - 2022-08-22 17:34:09 --> Router Class Initialized
INFO - 2022-08-22 17:34:09 --> Output Class Initialized
INFO - 2022-08-22 17:34:09 --> Security Class Initialized
DEBUG - 2022-08-22 17:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:34:09 --> Input Class Initialized
INFO - 2022-08-22 17:34:09 --> Language Class Initialized
INFO - 2022-08-22 17:34:09 --> Loader Class Initialized
INFO - 2022-08-22 17:34:09 --> Helper loaded: url_helper
INFO - 2022-08-22 17:34:09 --> Controller Class Initialized
DEBUG - 2022-08-22 17:34:09 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:34:09 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:34:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:35:06 --> Final output sent to browser
DEBUG - 2022-08-22 17:35:06 --> Total execution time: 60.2725
INFO - 2022-08-22 17:35:06 --> Config Class Initialized
INFO - 2022-08-22 17:35:06 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:35:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:35:06 --> Utf8 Class Initialized
INFO - 2022-08-22 17:35:06 --> URI Class Initialized
INFO - 2022-08-22 17:35:06 --> Router Class Initialized
INFO - 2022-08-22 17:35:06 --> Output Class Initialized
INFO - 2022-08-22 17:35:06 --> Security Class Initialized
DEBUG - 2022-08-22 17:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:35:06 --> Input Class Initialized
INFO - 2022-08-22 17:35:06 --> Language Class Initialized
INFO - 2022-08-22 17:35:06 --> Loader Class Initialized
INFO - 2022-08-22 17:35:06 --> Final output sent to browser
DEBUG - 2022-08-22 17:35:06 --> Total execution time: 60.3087
INFO - 2022-08-22 17:35:06 --> Helper loaded: url_helper
INFO - 2022-08-22 17:35:06 --> Controller Class Initialized
DEBUG - 2022-08-22 17:35:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:35:06 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:35:06 --> Config Class Initialized
INFO - 2022-08-22 17:35:06 --> Hooks Class Initialized
INFO - 2022-08-22 17:35:06 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2022-08-22 17:35:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:35:06 --> Utf8 Class Initialized
INFO - 2022-08-22 17:35:06 --> URI Class Initialized
INFO - 2022-08-22 17:35:06 --> Router Class Initialized
INFO - 2022-08-22 17:35:06 --> Output Class Initialized
INFO - 2022-08-22 17:35:06 --> Security Class Initialized
DEBUG - 2022-08-22 17:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:35:06 --> Input Class Initialized
INFO - 2022-08-22 17:35:06 --> Language Class Initialized
INFO - 2022-08-22 17:35:06 --> Loader Class Initialized
INFO - 2022-08-22 17:35:06 --> Helper loaded: url_helper
INFO - 2022-08-22 17:35:06 --> Controller Class Initialized
DEBUG - 2022-08-22 17:35:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:35:06 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:35:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:35:07 --> Final output sent to browser
DEBUG - 2022-08-22 17:35:07 --> Total execution time: 60.2483
INFO - 2022-08-22 17:35:07 --> Config Class Initialized
INFO - 2022-08-22 17:35:07 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:35:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:35:07 --> Utf8 Class Initialized
INFO - 2022-08-22 17:35:07 --> URI Class Initialized
INFO - 2022-08-22 17:35:07 --> Router Class Initialized
INFO - 2022-08-22 17:35:07 --> Output Class Initialized
INFO - 2022-08-22 17:35:07 --> Security Class Initialized
DEBUG - 2022-08-22 17:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:35:07 --> Input Class Initialized
INFO - 2022-08-22 17:35:07 --> Language Class Initialized
INFO - 2022-08-22 17:35:07 --> Loader Class Initialized
INFO - 2022-08-22 17:35:07 --> Helper loaded: url_helper
INFO - 2022-08-22 17:35:07 --> Controller Class Initialized
DEBUG - 2022-08-22 17:35:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:35:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:35:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:35:08 --> Final output sent to browser
DEBUG - 2022-08-22 17:35:08 --> Total execution time: 60.2350
INFO - 2022-08-22 17:35:08 --> Config Class Initialized
INFO - 2022-08-22 17:35:08 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:35:08 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:35:08 --> Utf8 Class Initialized
INFO - 2022-08-22 17:35:08 --> URI Class Initialized
INFO - 2022-08-22 17:35:08 --> Router Class Initialized
INFO - 2022-08-22 17:35:08 --> Output Class Initialized
INFO - 2022-08-22 17:35:08 --> Security Class Initialized
DEBUG - 2022-08-22 17:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:35:08 --> Input Class Initialized
INFO - 2022-08-22 17:35:08 --> Language Class Initialized
INFO - 2022-08-22 17:35:08 --> Loader Class Initialized
INFO - 2022-08-22 17:35:08 --> Helper loaded: url_helper
INFO - 2022-08-22 17:35:08 --> Controller Class Initialized
DEBUG - 2022-08-22 17:35:08 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:35:08 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:35:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:35:09 --> Final output sent to browser
DEBUG - 2022-08-22 17:35:09 --> Total execution time: 60.2692
INFO - 2022-08-22 17:35:09 --> Config Class Initialized
INFO - 2022-08-22 17:35:09 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:35:09 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:35:09 --> Utf8 Class Initialized
INFO - 2022-08-22 17:35:09 --> URI Class Initialized
INFO - 2022-08-22 17:35:09 --> Router Class Initialized
INFO - 2022-08-22 17:35:09 --> Output Class Initialized
INFO - 2022-08-22 17:35:09 --> Security Class Initialized
DEBUG - 2022-08-22 17:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:35:09 --> Input Class Initialized
INFO - 2022-08-22 17:35:09 --> Language Class Initialized
INFO - 2022-08-22 17:35:09 --> Loader Class Initialized
INFO - 2022-08-22 17:35:09 --> Helper loaded: url_helper
INFO - 2022-08-22 17:35:09 --> Controller Class Initialized
DEBUG - 2022-08-22 17:35:09 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:35:09 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:35:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:36:06 --> Final output sent to browser
DEBUG - 2022-08-22 17:36:06 --> Total execution time: 60.3493
INFO - 2022-08-22 17:36:06 --> Config Class Initialized
INFO - 2022-08-22 17:36:06 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:36:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:36:06 --> Utf8 Class Initialized
INFO - 2022-08-22 17:36:06 --> URI Class Initialized
INFO - 2022-08-22 17:36:06 --> Router Class Initialized
INFO - 2022-08-22 17:36:06 --> Output Class Initialized
INFO - 2022-08-22 17:36:06 --> Final output sent to browser
INFO - 2022-08-22 17:36:06 --> Security Class Initialized
DEBUG - 2022-08-22 17:36:06 --> Total execution time: 60.3192
DEBUG - 2022-08-22 17:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:36:06 --> Input Class Initialized
INFO - 2022-08-22 17:36:06 --> Language Class Initialized
INFO - 2022-08-22 17:36:06 --> Loader Class Initialized
INFO - 2022-08-22 17:36:06 --> Config Class Initialized
INFO - 2022-08-22 17:36:06 --> Hooks Class Initialized
INFO - 2022-08-22 17:36:06 --> Helper loaded: url_helper
INFO - 2022-08-22 17:36:06 --> Controller Class Initialized
DEBUG - 2022-08-22 17:36:06 --> Config file loaded: /sam_tool/application/config/rest.php
DEBUG - 2022-08-22 17:36:06 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:36:06 --> Utf8 Class Initialized
INFO - 2022-08-22 17:36:06 --> URI Class Initialized
INFO - 2022-08-22 17:36:06 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:36:06 --> Router Class Initialized
INFO - 2022-08-22 17:36:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:36:06 --> Output Class Initialized
INFO - 2022-08-22 17:36:06 --> Final output sent to browser
DEBUG - 2022-08-22 17:36:06 --> Total execution time: 0.3306
INFO - 2022-08-22 17:36:06 --> Security Class Initialized
DEBUG - 2022-08-22 17:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:36:06 --> Input Class Initialized
INFO - 2022-08-22 17:36:06 --> Language Class Initialized
INFO - 2022-08-22 17:36:06 --> Loader Class Initialized
INFO - 2022-08-22 17:36:06 --> Config Class Initialized
INFO - 2022-08-22 17:36:06 --> Hooks Class Initialized
INFO - 2022-08-22 17:36:06 --> Helper loaded: url_helper
INFO - 2022-08-22 17:36:06 --> Controller Class Initialized
DEBUG - 2022-08-22 17:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-22 17:36:06 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:36:06 --> Utf8 Class Initialized
INFO - 2022-08-22 17:36:06 --> URI Class Initialized
INFO - 2022-08-22 17:36:06 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:36:06 --> Router Class Initialized
INFO - 2022-08-22 17:36:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:36:07 --> Output Class Initialized
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 0.3092
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
INFO - 2022-08-22 17:36:07 --> Security Class Initialized
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 59.8221
DEBUG - 2022-08-22 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:36:07 --> Input Class Initialized
INFO - 2022-08-22 17:36:07 --> Language Class Initialized
INFO - 2022-08-22 17:36:07 --> Config Class Initialized
INFO - 2022-08-22 17:36:07 --> Hooks Class Initialized
INFO - 2022-08-22 17:36:07 --> Loader Class Initialized
INFO - 2022-08-22 17:36:07 --> Config Class Initialized
INFO - 2022-08-22 17:36:07 --> Hooks Class Initialized
INFO - 2022-08-22 17:36:07 --> Helper loaded: url_helper
INFO - 2022-08-22 17:36:07 --> Controller Class Initialized
DEBUG - 2022-08-22 17:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-22 17:36:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:36:07 --> Utf8 Class Initialized
INFO - 2022-08-22 17:36:07 --> URI Class Initialized
DEBUG - 2022-08-22 17:36:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:36:07 --> Utf8 Class Initialized
INFO - 2022-08-22 17:36:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:36:07 --> URI Class Initialized
INFO - 2022-08-22 17:36:07 --> Router Class Initialized
INFO - 2022-08-22 17:36:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:36:07 --> Output Class Initialized
INFO - 2022-08-22 17:36:07 --> Router Class Initialized
INFO - 2022-08-22 17:36:07 --> Security Class Initialized
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 0.3308
INFO - 2022-08-22 17:36:07 --> Output Class Initialized
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
DEBUG - 2022-08-22 17:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 58.9988
INFO - 2022-08-22 17:36:07 --> Input Class Initialized
INFO - 2022-08-22 17:36:07 --> Security Class Initialized
INFO - 2022-08-22 17:36:07 --> Language Class Initialized
DEBUG - 2022-08-22 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:36:07 --> Input Class Initialized
INFO - 2022-08-22 17:36:07 --> Language Class Initialized
INFO - 2022-08-22 17:36:07 --> Loader Class Initialized
INFO - 2022-08-22 17:36:07 --> Config Class Initialized
INFO - 2022-08-22 17:36:07 --> Hooks Class Initialized
INFO - 2022-08-22 17:36:07 --> Config Class Initialized
INFO - 2022-08-22 17:36:07 --> Loader Class Initialized
INFO - 2022-08-22 17:36:07 --> Helper loaded: url_helper
INFO - 2022-08-22 17:36:07 --> Hooks Class Initialized
INFO - 2022-08-22 17:36:07 --> Controller Class Initialized
DEBUG - 2022-08-22 17:36:07 --> Config file loaded: /sam_tool/application/config/rest.php
DEBUG - 2022-08-22 17:36:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:36:07 --> Helper loaded: url_helper
INFO - 2022-08-22 17:36:07 --> Utf8 Class Initialized
INFO - 2022-08-22 17:36:07 --> Controller Class Initialized
DEBUG - 2022-08-22 17:36:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:36:07 --> URI Class Initialized
DEBUG - 2022-08-22 17:36:07 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:36:07 --> Utf8 Class Initialized
INFO - 2022-08-22 17:36:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:36:07 --> URI Class Initialized
INFO - 2022-08-22 17:36:07 --> Router Class Initialized
INFO - 2022-08-22 17:36:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:36:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:36:07 --> Router Class Initialized
INFO - 2022-08-22 17:36:07 --> Output Class Initialized
INFO - 2022-08-22 17:36:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 0.3371
INFO - 2022-08-22 17:36:07 --> Security Class Initialized
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
INFO - 2022-08-22 17:36:07 --> Output Class Initialized
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 58.1942
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
DEBUG - 2022-08-22 17:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 0.3428
INFO - 2022-08-22 17:36:07 --> Input Class Initialized
INFO - 2022-08-22 17:36:07 --> Security Class Initialized
DEBUG - 2022-08-22 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:36:07 --> Language Class Initialized
INFO - 2022-08-22 17:36:07 --> Input Class Initialized
INFO - 2022-08-22 17:36:07 --> Language Class Initialized
INFO - 2022-08-22 17:36:07 --> Loader Class Initialized
INFO - 2022-08-22 17:36:07 --> Loader Class Initialized
INFO - 2022-08-22 17:36:07 --> Helper loaded: url_helper
INFO - 2022-08-22 17:36:07 --> Controller Class Initialized
DEBUG - 2022-08-22 17:36:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:36:07 --> Helper loaded: url_helper
INFO - 2022-08-22 17:36:07 --> Controller Class Initialized
DEBUG - 2022-08-22 17:36:07 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:36:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:36:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:36:07 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
INFO - 2022-08-22 17:36:07 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 0.3026
INFO - 2022-08-22 17:36:07 --> Final output sent to browser
DEBUG - 2022-08-22 17:36:07 --> Total execution time: 0.3062
INFO - 2022-08-22 17:43:26 --> Config Class Initialized
INFO - 2022-08-22 17:43:26 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:43:27 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:43:27 --> Utf8 Class Initialized
INFO - 2022-08-22 17:43:27 --> URI Class Initialized
INFO - 2022-08-22 17:43:27 --> Router Class Initialized
INFO - 2022-08-22 17:43:27 --> Output Class Initialized
INFO - 2022-08-22 17:43:27 --> Security Class Initialized
DEBUG - 2022-08-22 17:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:43:27 --> Input Class Initialized
INFO - 2022-08-22 17:43:27 --> Language Class Initialized
INFO - 2022-08-22 17:43:27 --> Loader Class Initialized
INFO - 2022-08-22 17:43:27 --> Helper loaded: url_helper
INFO - 2022-08-22 17:43:27 --> Controller Class Initialized
DEBUG - 2022-08-22 17:43:27 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:43:27 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:43:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:43:27 --> Final output sent to browser
DEBUG - 2022-08-22 17:43:27 --> Total execution time: 0.3940
INFO - 2022-08-22 17:43:35 --> Config Class Initialized
INFO - 2022-08-22 17:43:35 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:43:35 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:43:35 --> Utf8 Class Initialized
INFO - 2022-08-22 17:43:35 --> URI Class Initialized
INFO - 2022-08-22 17:43:35 --> Router Class Initialized
INFO - 2022-08-22 17:43:35 --> Output Class Initialized
INFO - 2022-08-22 17:43:35 --> Security Class Initialized
DEBUG - 2022-08-22 17:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:43:35 --> Input Class Initialized
INFO - 2022-08-22 17:43:35 --> Language Class Initialized
INFO - 2022-08-22 17:43:35 --> Loader Class Initialized
INFO - 2022-08-22 17:43:35 --> Helper loaded: url_helper
INFO - 2022-08-22 17:43:35 --> Controller Class Initialized
DEBUG - 2022-08-22 17:43:35 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:43:35 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:43:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:43:35 --> Final output sent to browser
DEBUG - 2022-08-22 17:43:35 --> Total execution time: 0.3222
INFO - 2022-08-22 17:43:44 --> Config Class Initialized
INFO - 2022-08-22 17:43:44 --> Hooks Class Initialized
DEBUG - 2022-08-22 17:43:44 --> UTF-8 Support Enabled
INFO - 2022-08-22 17:43:44 --> Utf8 Class Initialized
INFO - 2022-08-22 17:43:44 --> URI Class Initialized
INFO - 2022-08-22 17:43:44 --> Router Class Initialized
INFO - 2022-08-22 17:43:44 --> Output Class Initialized
INFO - 2022-08-22 17:43:44 --> Security Class Initialized
DEBUG - 2022-08-22 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 17:43:44 --> Input Class Initialized
INFO - 2022-08-22 17:43:44 --> Language Class Initialized
INFO - 2022-08-22 17:43:45 --> Loader Class Initialized
INFO - 2022-08-22 17:43:45 --> Helper loaded: url_helper
INFO - 2022-08-22 17:43:45 --> Controller Class Initialized
DEBUG - 2022-08-22 17:43:45 --> Config file loaded: /sam_tool/application/config/rest.php
INFO - 2022-08-22 17:43:45 --> Helper loaded: inflector_helper
INFO - 2022-08-22 17:43:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2022-08-22 17:43:45 --> Final output sent to browser
DEBUG - 2022-08-22 17:43:45 --> Total execution time: 0.3463
INFO - 2022-08-22 18:39:16 --> Config Class Initialized
INFO - 2022-08-22 18:39:16 --> Hooks Class Initialized
DEBUG - 2022-08-22 18:39:16 --> UTF-8 Support Enabled
INFO - 2022-08-22 18:39:16 --> Utf8 Class Initialized
INFO - 2022-08-22 18:39:16 --> URI Class Initialized
DEBUG - 2022-08-22 18:39:16 --> No URI present. Default controller set.
INFO - 2022-08-22 18:39:16 --> Router Class Initialized
INFO - 2022-08-22 18:39:16 --> Output Class Initialized
INFO - 2022-08-22 18:39:16 --> Security Class Initialized
DEBUG - 2022-08-22 18:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-22 18:39:16 --> Input Class Initialized
INFO - 2022-08-22 18:39:16 --> Language Class Initialized
INFO - 2022-08-22 18:39:16 --> Loader Class Initialized
INFO - 2022-08-22 18:39:17 --> Helper loaded: url_helper
INFO - 2022-08-22 18:39:17 --> Controller Class Initialized
INFO - 2022-08-22 18:39:17 --> File loaded: /sam_tool/application/views/frontend/_includes/header.php
INFO - 2022-08-22 18:39:17 --> File loaded: /sam_tool/application/views/frontend/_includes/footer.php
INFO - 2022-08-22 18:39:17 --> File loaded: /sam_tool/application/views/frontend/dashboard.php
INFO - 2022-08-22 18:39:17 --> Final output sent to browser
DEBUG - 2022-08-22 18:39:17 --> Total execution time: 1.0003
