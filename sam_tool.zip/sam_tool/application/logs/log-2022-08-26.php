<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-26 12:38:23 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:38:23 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:38:23 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:38:23 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:38:23 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:38:23 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:38:28 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 12:38:28 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 12:38:28 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 12:38:28 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 12:38:28 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 12:38:28 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 12:38:34 --> {"city_id":3,"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:40:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:40:25 --> {"city_id":3,"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 12:40:43 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:41:01 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:01 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:01 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:01 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:01 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:01 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:29 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:29 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:29 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:29 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:41:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-26 12:41:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:41:36 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:41:51 --> {"state_id":2,"bank_id":5,"type_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:44:19 --> {"0":{"city_id":0,"state_id":2,"bank_id":5,"type_id":3,"locality":3,"batch_size":12,"batch_number":1}}
ERROR - 2022-08-26 12:44:42 --> {"city_id":2,"state_id":2,"bank_id":5,"type_id":3,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:47:54 --> {"city_id":2,"state_id":2,"bank_id":5,"type_id":3,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:48:12 --> {"city_id":2,"state_id":2,"bank_id":5,"type_id":3,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:49:07 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:07 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:07 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:07 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-26 12:49:08 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:49:19 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:19 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:19 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:19 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-26 12:49:19 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:49:54 --> Severity: error --> Exception: syntax error, unexpected '?>' /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:49:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-26 12:50:09 --> Severity: error --> Exception: syntax error, unexpected '?>' /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:50:23 --> Severity: error --> Exception: syntax error, unexpected '?>' /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:50:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:50:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:50:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:50:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:50:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:50:31 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:50:31 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:50:31 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:50:31 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:50:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 216
ERROR - 2022-08-26 12:50:32 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:51:12 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:12 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:12 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:12 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:12 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:13 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:13 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:51:32 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:32 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:32 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:32 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:33 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:33 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:51:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:52:02 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:02 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:02 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:02 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:02 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:02 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:03 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:52:05 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:05 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:05 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:05 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:05 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:05 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:52:06 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:52:10 --> {"state_id":3,"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:52:25 --> {"state_id":3,"type_id":2,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 12:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:54:29 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:29 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:29 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:29 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:29 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:29 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:54:40 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:40 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:40 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:40 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:40 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:40 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:41 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 12:54:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 12:54:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 12:54:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 12:54:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 12:54:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 12:54:59 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:59 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:59 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:59 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:59 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:54:59 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 12:55:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 13:00:20 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:00:20 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:00:20 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:00:20 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:00:20 --> Severity: Notice --> Undefined variable: getresult /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:00:20 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:00:21 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 13:00:45 --> {"state_id":4,"type_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 13:18:23 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:23 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:23 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:23 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:23 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:23 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:24 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:53 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:18:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 13:20:00 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:20:00 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:20:00 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:20:00 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:20:00 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:20:00 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 13:20:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 13:29:59 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:30:45 --> Severity: Notice --> Trying to get property '3' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:31:25 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:32:08 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:32:09 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:32:09 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:32:10 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:33:00 --> Severity: error --> Exception: Call to undefined method stdClass::getResult() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:33:19 --> Severity: error --> Exception: Call to undefined method stdClass::Details() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 13:33:20 --> Severity: error --> Exception: Call to undefined method stdClass::Details() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:27:58 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:28:55 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:29:24 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:29:24 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:29:24 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:29:24 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:29:24 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:29:24 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:29:24 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:29:24 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:29:29 --> {"city_id":4,"state_id":4,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 15:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 15:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 15:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 15:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 15:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 15:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Propert_ID' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Property_Type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'City_Name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:50 --> Severity: Notice --> Trying to get property 'Locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:46:56 --> {"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 15:48:10 --> {"city_id":4,"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 15:48:33 --> {"city_id":4,"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 15:49:26 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:49:26 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:49:26 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:49:26 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:49:26 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:49:26 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:49:26 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:49:26 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:49:34 --> {"city_id":3,"state_id":2,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 15:50:36 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:50:36 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:50:37 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:50:37 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:50:37 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:50:37 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:50:37 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:50:37 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:50:56 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:51:12 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:51:15 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:55:34 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:55:34 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:55:34 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:55:34 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:55:34 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:55:34 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:55:38 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 15:55:38 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 15:55:38 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 15:55:38 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 15:55:38 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 15:55:38 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 15:55:45 --> {"city_id":4,"state_id":2,"type_id":3,"locality":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 15:55:52 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:55:52 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:55:52 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:55:52 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:55:52 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:55:52 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:55:58 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 15:55:58 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 15:55:58 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 15:55:58 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 15:55:58 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 15:55:58 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 15:56:05 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 15:57:19 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:57:19 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:57:19 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:57:19 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:57:19 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:57:19 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:57:21 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 15:57:29 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 15:57:29 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 15:57:29 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 15:57:29 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 15:57:29 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 15:57:29 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 15:57:31 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 15:58:26 --> Severity: Notice --> Undefined property: stdClass::$property_type /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 15:58:26 --> Severity: Notice --> Undefined property: stdClass::$city_name /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 15:58:26 --> Severity: Notice --> Undefined property: stdClass::$locality /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 15:58:28 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 15:59:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 15:59:28 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:00:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:00:03 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:01:16 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:01:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-26 16:01:48 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:01:50 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:02:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:02:32 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 16:02:32 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 16:02:32 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 16:02:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:02:33 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:03:09 --> {"city_id":3,"state_id":2,"bank_id":2,"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 16:03:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:03:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 16:03:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 16:03:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 16:03:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:03:12 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:03:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:03:32 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:04:10 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:05:14 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:05:15 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:05:45 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:06:35 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:06:36 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:49:13 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 16:49:14 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:49:38 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:50:17 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:50:18 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:51:09 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:51:44 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:55:24 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:55:42 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:55:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 16:55:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 16:55:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 16:55:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 16:55:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 16:55:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:55:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 16:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 16:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 16:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 16:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 16:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 16:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 16:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 16:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 16:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 16:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:56:18 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:56:19 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:56:20 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 16:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 16:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 16:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 16:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 16:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:56:29 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 16:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 16:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 16:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 16:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 16:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:57:11 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 16:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 16:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 16:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 16:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 16:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:57:27 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:57:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 16:57:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 16:57:35 --> {"state_id":4,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 16:58:15 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:58:38 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:58:38 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:58:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Frontend.php:78) /sam_tool/system/core/Common.php 570
ERROR - 2022-08-26 16:58:57 --> Severity: Compile Error --> Cannot use [] for reading /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:59:04 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:59:13 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 16:59:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-26 17:01:00 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:01:05 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:01:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:02:04 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:02:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:03:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:03:26 --> {"city_id":2,"state_id":1,"locality":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 17:03:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-26 17:04:34 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:04:34 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:04:34 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:04:55 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:04:55 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:04:55 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:05:16 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:05:16 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:05:16 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:05:51 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:05:51 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:05:51 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:06:08 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:06:08 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:06:08 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:11:12 --> Severity: Notice --> Trying to get property 'count' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 17:11:21 --> Severity: Notice --> Undefined variable: result /sam_tool/application/controllers/Frontend.php 77
ERROR - 2022-08-26 17:11:21 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:11:21 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:11:21 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:11:37 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:11:37 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:11:37 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:12:03 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:12:03 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:12:03 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:12:03 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:12:11 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ';' /sam_tool/application/views/frontend/dashboard.php 206
ERROR - 2022-08-26 17:13:02 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:02 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:02 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:02 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:02 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:02 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:02 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:02 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:27 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:13:51 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:10 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:14:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:15:05 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:15:34 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 17:15:34 --> Severity: Notice --> Trying to get property 'property_id' of non-object /sam_tool/application/views/frontend/property_details.php 215
ERROR - 2022-08-26 17:15:34 --> Severity: Notice --> Undefined variable: order /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 17:15:35 --> Severity: Notice --> Trying to get property 'bank_id' of non-object /sam_tool/application/views/frontend/property_details.php 216
ERROR - 2022-08-26 17:15:35 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 17:15:35 --> Severity: error --> Exception: Call to a member function get_common() on null /sam_tool/application/views/frontend/property_details.php 219
ERROR - 2022-08-26 17:18:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Frontend.php:77) /sam_tool/system/core/Common.php 570
ERROR - 2022-08-26 17:18:56 --> Severity: Compile Error --> Cannot use [] for reading /sam_tool/application/controllers/Frontend.php 77
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:19:03 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:19:19 --> {"city_id":2,"state_id":1,"locality":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 17:21:19 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 17:21:19 --> Severity: Notice --> Trying to get property 'Details' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 17:21:30 --> Severity: Notice --> Trying to get property 'Details' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 17:21:42 --> Severity: Notice --> Trying to get property 'Details' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 17:21:43 --> Severity: Notice --> Trying to get property 'Details' of non-object /sam_tool/application/controllers/Frontend.php 78
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:27:10 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:27:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:27:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:27:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:27:21 --> {"city_id":2,"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 17:28:30 --> {"city_id":2,"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 17:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 17:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 17:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 17:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 17:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 17:28:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:28:55 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 17:28:55 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 17:28:55 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 17:28:56 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 17:28:56 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 17:28:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:29:23 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:29:29 --> {"city_id":3,"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 17:30:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-26 17:32:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-26 17:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 17:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 17:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 17:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 17:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 17:32:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 17:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 17:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 17:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 17:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 17:33:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 17:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 17:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 17:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 17:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 17:33:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 17:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 17:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 17:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 17:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 17:33:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 17:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 17:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 17:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 17:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 17:33:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 101
ERROR - 2022-08-26 17:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-08-26 17:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 132
ERROR - 2022-08-26 17:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 148
ERROR - 2022-08-26 17:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 164
ERROR - 2022-08-26 17:34:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:34:44 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:34:52 --> {"state_id":3,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 17:38:11 --> Severity: Notice --> Trying to get property 'data' of non-object /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:38:11 --> Severity: Notice --> Trying to get property 'Details' of non-object /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:38:11 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:38:41 --> Severity: Notice --> Trying to get property 'Details' of non-object /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:38:41 --> Severity: Notice --> Trying to get property 'Details' of non-object /sam_tool/application/views/frontend/dashboard.php 197
ERROR - 2022-08-26 17:38:41 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:43:20 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:43:33 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:43:34 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:43:44 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:45:39 --> Severity: Notice --> Trying to get property 'Details' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:47:35 --> Severity: Notice --> Undefined index: property_type /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:47:58 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:48:16 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:48:24 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:48:45 --> Severity: Notice --> Undefined index: Details /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:51:00 --> Severity: Notice --> Undefined index: property_id /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:51:13 --> Severity: Notice --> Undefined index: Count /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:51:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:51:48 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:51:48 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:51:48 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:51:48 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:51:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:51:48 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:51:48 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:51:48 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:51:48 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:51:56 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 17:52:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:52:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 199
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:52:01 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 210
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:52:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:52:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/views/frontend/dashboard.php 198
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:52:41 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:53:04 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:53:28 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:54:58 --> Severity: Notice --> Array to string conversion /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:54:58 --> Severity: Notice --> Undefined variable: Array /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 196
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:11 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:12 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:13 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:27 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:27 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:27 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:27 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:27 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:27 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:27 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:28 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 0 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 1 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 2 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 3 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 4 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 5 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 6 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:29 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:30 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:55:30 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:30 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:55:30 --> Severity: Notice --> Undefined offset: 7 /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:55:30 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:56:18 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:56:43 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:56:43 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:56:43 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:56:43 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:56:43 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:56:43 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:56:44 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:56:44 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:56:44 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:06 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'property_type' of non-object /sam_tool/application/views/frontend/dashboard.php 207
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:17 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:58 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:58 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:58 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:58 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:57:58 --> Severity: Notice --> Trying to get property 'city_name' of non-object /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 17:57:58 --> Severity: Notice --> Trying to get property 'locality' of non-object /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 17:59:15 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 17:59:40 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:00:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:00:23 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:00:59 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:13:34 --> Severity: error --> Exception: syntax error, unexpected 'to' (T_STRING), expecting ',' or ';' /sam_tool/application/views/frontend/dashboard.php 208
ERROR - 2022-08-26 18:13:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 18:13:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 18:13:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 18:14:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 18:14:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 18:14:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /sam_tool/application/views/frontend/dashboard.php 209
ERROR - 2022-08-26 18:18:46 --> {"city_id":1,"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:18:56 --> {"state_id":6,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:21:29 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:22:08 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:22:28 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:22:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:22:36 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:23:05 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:23:10 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:23:13 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:23:13 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:23:13 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:23:13 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:23:14 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:23:14 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:23:14 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:25:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:25:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:25:54 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:25:55 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:25:55 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:25:55 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:26:00 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:26:20 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:26:25 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:26:27 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:26:27 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:26:55 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:26:59 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:27:05 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:28:26 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:28:30 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:28:53 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:28:58 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:29:31 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:29:34 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:29:36 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:29:37 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:29:43 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:29:44 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:29:48 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:29:48 --> 404 Page Not Found: Theme/assets
ERROR - 2022-08-26 18:29:56 --> {"state_id":2,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:34:33 --> {"state_id":1,"batch_size":12,"batch_number":1}
ERROR - 2022-08-26 18:35:43 --> {"city_id":1,"state_id":1,"bank_id":1,"type_id":1,"locality":1,"batch_size":12,"batch_number":1}
