<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-06 13:35:17 --> {"state_id":1}
ERROR - 2022-09-06 13:35:30 --> {"state_id":3}
ERROR - 2022-09-06 13:35:35 --> {"state_id":2}
ERROR - 2022-09-06 13:38:12 --> {"state_id":1}
ERROR - 2022-09-06 14:06:58 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:07:09 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:07:11 --> {"state_id":1}
ERROR - 2022-09-06 14:08:50 --> {"state_id":13}
ERROR - 2022-09-06 14:17:11 --> Severity: Notice --> Undefined variable: city /sam_tool/application/controllers/Frontend.php 69
ERROR - 2022-09-06 14:17:11 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-09-06 14:17:12 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-09-06 14:17:15 --> Severity: Notice --> Undefined variable: city /sam_tool/application/controllers/Frontend.php 69
ERROR - 2022-09-06 14:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-09-06 14:17:16 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:17:19 --> Severity: Notice --> Undefined variable: city /sam_tool/application/controllers/Frontend.php 69
ERROR - 2022-09-06 14:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-09-06 14:17:20 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:17:24 --> Severity: Notice --> Undefined variable: city /sam_tool/application/controllers/Frontend.php 69
ERROR - 2022-09-06 14:17:24 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-09-06 14:17:24 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:17:42 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-09-06 14:17:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 117
ERROR - 2022-09-06 14:17:43 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:17:45 --> {"state_id":1}
ERROR - 2022-09-06 14:19:34 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:19:35 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:19:37 --> {"state_id":1}
ERROR - 2022-09-06 14:20:57 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:20:58 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:21:00 --> {"state_id":1}
ERROR - 2022-09-06 14:21:42 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:21:43 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:21:44 --> {"state_id":3}
ERROR - 2022-09-06 14:22:11 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:22:12 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:23:10 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:23:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:23:11 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:23:13 --> {"state_id":1}
ERROR - 2022-09-06 14:23:48 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:23:48 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:23:49 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:23:51 --> {"state_id":14}
ERROR - 2022-09-06 14:25:19 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:25:19 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:25:20 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:25:31 --> {"state_id":2}
ERROR - 2022-09-06 14:26:00 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:26:00 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:26:01 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:26:04 --> {"state_id":3}
ERROR - 2022-09-06 14:26:58 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:26:58 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:26:59 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:27:01 --> {"state_id":1}
ERROR - 2022-09-06 14:30:33 --> {"state_id":2}
ERROR - 2022-09-06 14:32:58 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:32:58 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:33:00 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:33:02 --> {"state_id":2}
ERROR - 2022-09-06 14:34:02 --> {"state_id":3}
ERROR - 2022-09-06 14:40:15 --> {"state_id":1}
ERROR - 2022-09-06 14:41:26 --> Severity: Notice --> Undefined variable: address /sam_tool/application/controllers/Frontend.php 59
ERROR - 2022-09-06 14:41:26 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:41:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:41:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 134
ERROR - 2022-09-06 14:41:27 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:41:29 --> Severity: Notice --> Undefined variable: address /sam_tool/application/controllers/Frontend.php 59
ERROR - 2022-09-06 14:41:29 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:41:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:41:29 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 134
ERROR - 2022-09-06 14:41:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:41:31 --> Severity: Notice --> Undefined variable: address /sam_tool/application/controllers/Frontend.php 59
ERROR - 2022-09-06 14:41:31 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:41:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:41:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 134
ERROR - 2022-09-06 14:41:32 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:41:51 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:41:51 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 134
ERROR - 2022-09-06 14:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 134
ERROR - 2022-09-06 14:41:52 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:42:15 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 118
ERROR - 2022-09-06 14:42:16 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 134
ERROR - 2022-09-06 14:42:16 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 134
ERROR - 2022-09-06 14:42:17 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:43:24 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 14:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 14:43:24 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 14:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 14:43:25 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 14:43:31 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 14:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 14:43:31 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 14:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 14:43:31 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 15:41:18 --> {"state_id":2}
ERROR - 2022-09-06 15:41:23 --> {"state_id":3}
ERROR - 2022-09-06 15:43:14 --> Severity: Notice --> Undefined property: CI_Loader::$session /sam_tool/application/views/frontend/_includes/header_home.php 150
ERROR - 2022-09-06 15:43:14 --> Severity: error --> Exception: Call to a member function userdata() on null /sam_tool/application/views/frontend/_includes/header_home.php 150
ERROR - 2022-09-06 15:43:46 --> Severity: error --> Exception: syntax error, unexpected '?>' /sam_tool/application/views/frontend/_includes/header_home.php 150
ERROR - 2022-09-06 15:44:10 --> Severity: Notice --> Undefined property: CI_Loader::$session /sam_tool/application/views/frontend/_includes/header_home.php 217
ERROR - 2022-09-06 15:44:10 --> Severity: error --> Exception: Call to a member function userdata() on null /sam_tool/application/views/frontend/_includes/header_home.php 217
ERROR - 2022-09-06 15:44:29 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 15:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 15:44:30 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 15:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 15:44:31 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 15:46:33 --> {"state_id":1}
ERROR - 2022-09-06 15:46:55 --> {"state_id":3}
ERROR - 2022-09-06 15:47:05 --> {"state_id":4}
ERROR - 2022-09-06 15:48:58 --> {"state_id":1}
ERROR - 2022-09-06 16:28:30 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:28:30 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:28:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 16:46:38 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:46:38 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:46:38 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 16:46:43 --> {"state_id":1}
ERROR - 2022-09-06 16:46:47 --> {"state_id":2}
ERROR - 2022-09-06 16:46:55 --> {"state_id":1}
ERROR - 2022-09-06 16:55:26 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:55:26 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:55:27 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 16:55:32 --> {"state_id":1}
ERROR - 2022-09-06 16:56:15 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:56:15 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:56:15 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 16:56:19 --> {"state_id":1}
ERROR - 2022-09-06 16:57:27 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 16:57:27 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 16:57:28 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 16:57:34 --> {"state_id":1}
ERROR - 2022-09-06 17:09:21 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:09:21 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:09:21 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:09:21 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:09:22 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 17:09:23 --> {"state_id":2}
ERROR - 2022-09-06 17:35:25 --> {"state_id":3}
ERROR - 2022-09-06 17:36:06 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:36:06 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:36:06 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 17:36:10 --> {"state_id":1}
ERROR - 2022-09-06 17:40:11 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:40:11 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:40:11 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:40:11 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:40:12 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 17:40:30 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:40:30 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:40:30 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 17:41:02 --> {"state_id":2}
ERROR - 2022-09-06 17:49:08 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:49:08 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:49:08 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:49:08 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:49:09 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 17:49:11 --> {"state_id":1}
ERROR - 2022-09-06 17:50:02 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:50:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:50:02 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:50:02 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:50:03 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 17:57:28 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 17:57:28 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 17:57:28 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 17:57:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /sam_tool/application/controllers/Frontend.php:273) /sam_tool/application/controllers/Frontend.php 278
ERROR - 2022-09-06 17:57:33 --> {"state_id":1}
ERROR - 2022-09-06 17:57:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/controllers/Frontend.php 294
ERROR - 2022-09-06 17:58:03 --> {"state_id":2}
ERROR - 2022-09-06 17:58:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /sam_tool/application/controllers/Frontend.php 293
ERROR - 2022-09-06 18:02:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /sam_tool/application/controllers/Frontend.php 371
ERROR - 2022-09-06 18:03:10 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 18:03:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 18:03:10 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 18:03:10 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 18:03:11 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 18:03:17 --> {"state_id":1}
ERROR - 2022-09-06 18:03:17 --> 
ERROR - 2022-09-06 18:03:17 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/controllers/Frontend.php 296
ERROR - 2022-09-06 18:05:29 --> Severity: error --> Exception: syntax error, unexpected '.' /sam_tool/application/controllers/Frontend.php 299
ERROR - 2022-09-06 18:05:47 --> Severity: error --> Exception: syntax error, unexpected '$v' (T_VARIABLE) /sam_tool/application/controllers/Frontend.php 299
ERROR - 2022-09-06 18:07:04 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /sam_tool/application/controllers/Frontend.php 371
ERROR - 2022-09-06 18:07:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /sam_tool/application/controllers/Frontend.php 371
ERROR - 2022-09-06 18:07:18 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 18:07:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 18:07:18 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 18:07:18 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 18:07:19 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 18:07:23 --> {"state_id":2}
ERROR - 2022-09-06 18:07:23 --> 
ERROR - 2022-09-06 18:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/controllers/Frontend.php 296
ERROR - 2022-09-06 18:08:27 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 18:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 18:08:27 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 18:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 18:08:28 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 18:08:31 --> {"state_id":1}
ERROR - 2022-09-06 18:08:31 --> 
ERROR - 2022-09-06 18:08:31 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/controllers/Frontend.php 296
ERROR - 2022-09-06 18:09:47 --> Severity: Notice --> Undefined variable: city /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 18:09:47 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 121
ERROR - 2022-09-06 18:09:47 --> Severity: Notice --> Undefined variable: address /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 18:09:47 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/views/frontend/dashboard.php 137
ERROR - 2022-09-06 18:09:48 --> 404 Page Not Found: Theme/assets
ERROR - 2022-09-06 18:09:52 --> {"state_id":1}
ERROR - 2022-09-06 18:09:52 --> 
ERROR - 2022-09-06 18:09:52 --> Severity: Warning --> Invalid argument supplied for foreach() /sam_tool/application/controllers/Frontend.php 296
